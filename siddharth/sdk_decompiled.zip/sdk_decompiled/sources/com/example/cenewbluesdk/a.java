package com.example.cenewbluesdk;

/* loaded from: classes.jar:com/example/cenewbluesdk/a.class */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f58a = false;
    public static final String b = "com.example.cenewbluesdk";
    public static final String c = "release";
}
