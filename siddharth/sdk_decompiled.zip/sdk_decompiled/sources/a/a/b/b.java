package a.a.b;

import android.os.ParcelUuid;
import android.util.SparseArray;
import androidx.annotation.Nullable;
import java.util.List;
import java.util.Map;

/* loaded from: classes.jar:a/a/b/b.class */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    private static final String f1a = "ScanRecord";
    private static final int b = 1;
    private static final int c = 2;
    private static final int d = 3;
    private static final int e = 4;
    private static final int f = 5;
    private static final int g = 6;
    private static final int h = 7;
    private static final int i = 8;
    private static final int j = 9;
    private static final int k = 10;
    private static final int l = 22;
    private static final int m = 32;
    private static final int n = 33;
    private static final int o = 255;
    private final int p;

    @Nullable
    private final List<ParcelUuid> q;
    private final SparseArray<byte[]> r;
    private final Map<ParcelUuid, byte[]> s;
    private final int t;
    private final String u;
    private final byte[] v;

    private b(List<ParcelUuid> list, SparseArray<byte[]> sparseArray, Map<ParcelUuid, byte[]> map, int i2, int i3, String str, byte[] bArr) {
        this.q = list;
        this.r = sparseArray;
        this.s = map;
        this.u = str;
        this.p = i2;
        this.t = i3;
        this.v = bArr;
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x0181  */
    @androidx.annotation.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static a.a.b.b a(byte[] r10) {
        /*
            Method dump skipped, instructions count: 452
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a.a.b.b.a(byte[]):a.a.b.b");
    }

    private static int a(byte[] bArr, int i2, int i3, int i4, List<ParcelUuid> list) {
        while (i3 > 0) {
            list.add(a.a.a.a(a(bArr, i2, i4)));
            i3 -= i4;
            i2 += i4;
        }
        return i2;
    }

    private static byte[] a(byte[] bArr, int i2, int i3) {
        byte[] bArr2 = new byte[i3];
        System.arraycopy(bArr, i2, bArr2, 0, i3);
        return bArr2;
    }

    public int a() {
        return this.p;
    }

    @Nullable
    public List<ParcelUuid> f() {
        return this.q;
    }

    public SparseArray<byte[]> d() {
        return this.r;
    }

    @Nullable
    public byte[] a(int i2) {
        return this.r.get(i2);
    }

    public Map<ParcelUuid, byte[]> e() {
        return this.s;
    }

    @Nullable
    public byte[] a(ParcelUuid parcelUuid) {
        if (parcelUuid == null) {
            return null;
        }
        return this.s.get(parcelUuid);
    }

    public int g() {
        return this.t;
    }

    @Nullable
    public String c() {
        return this.u;
    }

    public byte[] b() {
        return this.v;
    }

    public String toString() {
        return "ScanRecord [mAdvertiseFlags=" + this.p + ", mServiceUuids=" + this.q + ", mManufacturerSpecificData=" + a.a(this.r) + ", mServiceData=" + a.a(this.s) + ", mTxPowerLevel=" + this.t + ", mDeviceName=" + this.u + "]";
    }
}
