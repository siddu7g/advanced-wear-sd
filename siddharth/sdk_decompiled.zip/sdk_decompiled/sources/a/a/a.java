package a.a;

import android.os.ParcelUuid;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.UUID;

/* loaded from: classes.jar:a/a/a.class */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final ParcelUuid f0a;
    public static final ParcelUuid b;
    public static final ParcelUuid c;
    public static final ParcelUuid d;
    public static final ParcelUuid e;
    public static final ParcelUuid f;
    public static final ParcelUuid g;
    public static final ParcelUuid h;
    public static final ParcelUuid i;
    public static final ParcelUuid j;
    public static final ParcelUuid k;
    public static final ParcelUuid l;
    public static final ParcelUuid m;
    public static final ParcelUuid n;
    public static final ParcelUuid o;
    public static final ParcelUuid p;
    public static final ParcelUuid q;
    public static final ParcelUuid r;
    public static final ParcelUuid s;
    public static final ParcelUuid t;
    public static final ParcelUuid u;
    public static final ParcelUuid v;
    public static final int w = 2;
    public static final int x = 4;
    public static final int y = 16;
    public static final ParcelUuid[] z;

    public static boolean f(ParcelUuid parcelUuid) {
        return parcelUuid.equals(b);
    }

    public static boolean e(ParcelUuid parcelUuid) {
        return parcelUuid.equals(f0a);
    }

    public static boolean d(ParcelUuid parcelUuid) {
        return parcelUuid.equals(c);
    }

    public static boolean j(ParcelUuid parcelUuid) {
        return parcelUuid.equals(f);
    }

    public static boolean k(ParcelUuid parcelUuid) {
        return parcelUuid.equals(d);
    }

    public static boolean g(ParcelUuid parcelUuid) {
        return parcelUuid.equals(h);
    }

    public static boolean h(ParcelUuid parcelUuid) {
        return parcelUuid.equals(i);
    }

    public static boolean l(ParcelUuid parcelUuid) {
        return parcelUuid.equals(k);
    }

    public static boolean q(ParcelUuid parcelUuid) {
        return parcelUuid.equals(m);
    }

    public static boolean p(ParcelUuid parcelUuid) {
        return parcelUuid.equals(n);
    }

    public static boolean i(ParcelUuid parcelUuid) {
        return parcelUuid.equals(o);
    }

    public static boolean m(ParcelUuid parcelUuid) {
        return parcelUuid.equals(r);
    }

    public static boolean o(ParcelUuid parcelUuid) {
        return parcelUuid.equals(s);
    }

    public static boolean n(ParcelUuid parcelUuid) {
        return parcelUuid.equals(t);
    }

    public static boolean r(ParcelUuid parcelUuid) {
        return parcelUuid.equals(u);
    }

    public static boolean a(ParcelUuid[] parcelUuidArr, ParcelUuid parcelUuid) {
        if ((parcelUuidArr == null || parcelUuidArr.length == 0) && parcelUuid == null) {
            return true;
        }
        if (parcelUuidArr == null) {
            return false;
        }
        for (ParcelUuid parcelUuid2 : parcelUuidArr) {
            if (parcelUuid2.equals(parcelUuid)) {
                return true;
            }
        }
        return false;
    }

    public static boolean b(ParcelUuid[] parcelUuidArr, ParcelUuid[] parcelUuidArr2) {
        if (parcelUuidArr == null && parcelUuidArr2 == null) {
            return true;
        }
        if (parcelUuidArr == null) {
            return parcelUuidArr2.length == 0;
        }
        if (parcelUuidArr2 == null) {
            return parcelUuidArr.length == 0;
        }
        HashSet hashSet = new HashSet(Arrays.asList(parcelUuidArr));
        for (ParcelUuid parcelUuid : parcelUuidArr2) {
            if (hashSet.contains(parcelUuid)) {
                return true;
            }
        }
        return false;
    }

    public static boolean a(ParcelUuid[] parcelUuidArr, ParcelUuid[] parcelUuidArr2) {
        if (parcelUuidArr == null && parcelUuidArr2 == null) {
            return true;
        }
        if (parcelUuidArr == null) {
            return parcelUuidArr2.length == 0;
        }
        if (parcelUuidArr2 == null) {
            return true;
        }
        HashSet hashSet = new HashSet(Arrays.asList(parcelUuidArr));
        for (ParcelUuid parcelUuid : parcelUuidArr2) {
            if (!hashSet.contains(parcelUuid)) {
                return false;
            }
        }
        return true;
    }

    public static int a(ParcelUuid parcelUuid) {
        return (int) ((parcelUuid.getUuid().getMostSignificantBits() & 281470681743360L) >>> 32);
    }

    public static ParcelUuid a(byte[] bArr) {
        if (bArr == null) {
            throw new IllegalArgumentException("uuidBytes cannot be null");
        }
        int length = bArr.length;
        if (length != 2 && length != 4 && length != 16) {
            throw new IllegalArgumentException("uuidBytes length invalid - " + length);
        }
        if (length == 16) {
            ByteBuffer byteBufferOrder = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN);
            return new ParcelUuid(new UUID(byteBufferOrder.getLong(8), byteBufferOrder.getLong(0)));
        }
        long j2 = length == 2 ? (bArr[0] & 255) + ((bArr[1] & 255) << 8) : (bArr[0] & 255) + ((bArr[1] & 255) << 8) + ((bArr[2] & 255) << 16) + ((bArr[3] & 255) << 24);
        ParcelUuid parcelUuid = v;
        return new ParcelUuid(new UUID(parcelUuid.getUuid().getMostSignificantBits() + (j2 << 32), parcelUuid.getUuid().getLeastSignificantBits()));
    }

    public static byte[] s(ParcelUuid parcelUuid) {
        if (parcelUuid == null) {
            throw new IllegalArgumentException("uuid cannot be null");
        }
        if (b(parcelUuid)) {
            int iA = a(parcelUuid);
            return new byte[]{(byte) (iA & 255), (byte) ((iA & 65280) >> 8)};
        }
        if (c(parcelUuid)) {
            int iA2 = a(parcelUuid);
            return new byte[]{(byte) (iA2 & 255), (byte) ((iA2 & 65280) >> 8), (byte) ((iA2 & 16711680) >> 16), (byte) ((iA2 & (-16777216)) >> 24)};
        }
        long mostSignificantBits = parcelUuid.getUuid().getMostSignificantBits();
        long leastSignificantBits = parcelUuid.getUuid().getLeastSignificantBits();
        byte[] bArr = new byte[16];
        ByteBuffer byteBufferOrder = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.putLong(8, mostSignificantBits);
        byteBufferOrder.putLong(0, leastSignificantBits);
        return bArr;
    }

    public static boolean b(ParcelUuid parcelUuid) {
        UUID uuid = parcelUuid.getUuid();
        return uuid.getLeastSignificantBits() == v.getUuid().getLeastSignificantBits() && (uuid.getMostSignificantBits() & (-281470681743361L)) == 4096;
    }

    public static boolean c(ParcelUuid parcelUuid) {
        UUID uuid = parcelUuid.getUuid();
        return uuid.getLeastSignificantBits() == v.getUuid().getLeastSignificantBits() && !b(parcelUuid) && (uuid.getMostSignificantBits() & 4294967295L) == 4096;
    }

    static {
        ParcelUuid parcelUuidFromString = ParcelUuid.fromString("0000110B-0000-1000-8000-00805F9B34FB");
        f0a = parcelUuidFromString;
        ParcelUuid parcelUuidFromString2 = ParcelUuid.fromString("0000110A-0000-1000-8000-00805F9B34FB");
        b = parcelUuidFromString2;
        ParcelUuid parcelUuidFromString3 = ParcelUuid.fromString("0000110D-0000-1000-8000-00805F9B34FB");
        c = parcelUuidFromString3;
        ParcelUuid parcelUuidFromString4 = ParcelUuid.fromString("00001108-0000-1000-8000-00805F9B34FB");
        d = parcelUuidFromString4;
        e = ParcelUuid.fromString("00001112-0000-1000-8000-00805F9B34FB");
        ParcelUuid parcelUuidFromString5 = ParcelUuid.fromString("0000111E-0000-1000-8000-00805F9B34FB");
        f = parcelUuidFromString5;
        g = ParcelUuid.fromString("0000111F-0000-1000-8000-00805F9B34FB");
        ParcelUuid parcelUuidFromString6 = ParcelUuid.fromString("0000110E-0000-1000-8000-00805F9B34FB");
        h = parcelUuidFromString6;
        ParcelUuid parcelUuidFromString7 = ParcelUuid.fromString("0000110C-0000-1000-8000-00805F9B34FB");
        i = parcelUuidFromString7;
        ParcelUuid parcelUuidFromString8 = ParcelUuid.fromString("00001105-0000-1000-8000-00805f9b34fb");
        j = parcelUuidFromString8;
        k = ParcelUuid.fromString("00001124-0000-1000-8000-00805f9b34fb");
        l = ParcelUuid.fromString("00001812-0000-1000-8000-00805f9b34fb");
        ParcelUuid parcelUuidFromString9 = ParcelUuid.fromString("00001115-0000-1000-8000-00805F9B34FB");
        m = parcelUuidFromString9;
        ParcelUuid parcelUuidFromString10 = ParcelUuid.fromString("00001116-0000-1000-8000-00805F9B34FB");
        n = parcelUuidFromString10;
        o = ParcelUuid.fromString("0000000f-0000-1000-8000-00805F9B34FB");
        p = ParcelUuid.fromString("0000112e-0000-1000-8000-00805F9B34FB");
        q = ParcelUuid.fromString("0000112f-0000-1000-8000-00805F9B34FB");
        ParcelUuid parcelUuidFromString11 = ParcelUuid.fromString("00001134-0000-1000-8000-00805F9B34FB");
        r = parcelUuidFromString11;
        ParcelUuid parcelUuidFromString12 = ParcelUuid.fromString("00001133-0000-1000-8000-00805F9B34FB");
        s = parcelUuidFromString12;
        ParcelUuid parcelUuidFromString13 = ParcelUuid.fromString("00001132-0000-1000-8000-00805F9B34FB");
        t = parcelUuidFromString13;
        ParcelUuid parcelUuidFromString14 = ParcelUuid.fromString("0000112D-0000-1000-8000-00805F9B34FB");
        u = parcelUuidFromString14;
        v = ParcelUuid.fromString("00000000-0000-1000-8000-00805F9B34FB");
        z = new ParcelUuid[]{parcelUuidFromString, parcelUuidFromString2, parcelUuidFromString3, parcelUuidFromString4, parcelUuidFromString5, parcelUuidFromString6, parcelUuidFromString7, parcelUuidFromString8, parcelUuidFromString9, parcelUuidFromString10, parcelUuidFromString11, parcelUuidFromString12, parcelUuidFromString13, parcelUuidFromString14};
    }
}
