package ce.com.cenewbluesdk.ota.ota_modea;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Messenger;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.k6.K6_OTAStateInfo;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OtaK6Control.class */
public class OtaK6Control {
    public static final int STATE_NONE = 0;
    public static final int STATE_NEED_UPDATE = 1;
    public static final int STATE_DOWNLOADING = 2;
    public static final int STATE_READY_OK = 3;
    public static final int STATE_HAS_DEV_STATE = 4;
    public static final int STATE_SENDING = 5;
    public static final int STATE_SENT = 6;
    public static final int STATE_CRC_OK = 7;
    private static final int OTA_SEND_FILE_MAX_TIME = 5;
    private static final int OTA_STATE_MAX_TIME = 3;
    private static String otaFilePath = "";
    private static String otaFilePathBase = "";
    private CEDevK6Proxy proxy;
    private Context mContext;
    private Messenger mainMessenger;
    private int otaPos;
    private OTASendEntity mOTASendEntity;
    private String netVersion;
    private String OTAFileUrl;
    private String devVersion;
    private boolean needSendOTAInfoToMain = false;
    private int otaState = 0;
    private OtaInfo mOtaK3Info = new OtaInfo();
    private int otaSendFileMAXTime = 5;
    private int getOtaStateMAXTime = 3;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OtaK6Control$UpdateTask.class */
    private class UpdateTask extends AsyncTask<Void, Void, Void> {
        private UpdateTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Type inference failed for: r0v7, types: [ce.com.cenewbluesdk.ota.ota_modea.OtaK6Control, java.lang.Exception] */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... voidArr) {
            ?? r0;
            try {
                OtaK6Control.this.setOtaState(2);
                byte[] binFromServer = OtaK6Control.getBinFromServer(OtaK6Control.this.OTAFileUrl);
                if (!OtaK6Control.this.processOtaFile(binFromServer, false)) {
                    return null;
                }
                r0 = OtaK6Control.this;
                r0.writeFile(binFromServer);
                return null;
            } catch (Exception e) {
                OtaK6Control.this.setOtaState(0);
                OtaK6Control.otaLog(e.toString());
                r0.printStackTrace();
                return null;
            }
        }
    }

    public OtaK6Control(CEDevK6Proxy cEDevK6Proxy, Context context) {
        this.proxy = cEDevK6Proxy;
        this.mContext = context;
        if (context == null) {
            BleFactory.getInstance();
            context = BleFactory.context;
        }
        if (context != null) {
            otaFilePathBase = context.getExternalFilesDir("yuedong").getAbsolutePath();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void otaLog(String str) {
        Lg.e("OTA 升级:" + str);
    }

    private void dealOTAUpdataFromFile(String str, String str2, String str3) {
        setOtaState(1);
        this.netVersion = str3;
        otaFilePath = str;
        this.devVersion = str2;
        this.mOtaK3Info.setDevVersion(str2);
        processOtaFile(OtaUtil.getBytes(otaFilePath, this.mContext), false);
    }

    private void dealOTAUpdata(String str, String str2, String str3) {
        setOtaState(1);
        this.netVersion = str3;
        otaFilePath = otaFilePathBase + "/YD_device(V" + str3 + ").img";
        this.OTAFileUrl = str;
        this.devVersion = str2;
        this.mOtaK3Info.setDevVersion(str2);
        otaLog("netV：" + str3 + "————存储版本号：" + CEBlueSharedPreference.getInstance(this.mContext).getNewK3OTAFileVersion());
        if (!str3.equals(CEBlueSharedPreference.getInstance(this.mContext).getNewK3OTAFileVersion())) {
            new UpdateTask().execute(new Void[0]);
        } else {
            otaLog("存储的版本号和服务器一样，不需要下载文件，直接升级");
            processOtaFile(OtaUtil.getBytes(otaFilePath, this.mContext), true);
        }
    }

    private void getOTAState() {
        CEDevK6Proxy cEDevK6Proxy = this.proxy;
        if (cEDevK6Proxy == null || !cEDevK6Proxy.isConnectOK()) {
            setOtaState(0);
        } else {
            setOtaState(3);
            this.proxy.getSendHelper().getOTAState();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean processOtaFile(byte[] bArr, boolean z) {
        try {
            this.mOTASendEntity = new DealOtaFile(bArr).getOTASendEntity();
            Map<Integer, Integer> mapVersionStr2Map = OtaUtil.versionStr2Map(this.devVersion);
            setOtaState(3);
            this.mOTASendEntity.initOTAData(mapVersionStr2Map);
            getOTAState();
            return true;
        } catch (OtaFileException unused) {
            if (z) {
                new UpdateTask().execute(new Void[0]);
                return false;
            }
            setOtaState(0);
            return false;
        }
    }

    public static boolean needOTA(String str, String str2) {
        if (str == null || str2 == null) {
            return false;
        }
        String[] strArrSplit = str.split("\\.");
        String[] strArrSplit2 = str2.split("\\.");
        if (strArrSplit.length != 5 || strArrSplit2.length != 5) {
            otaLog("解析出来的版本号长度不等于5   dev=" + strArrSplit.toString() + "   net= " + strArrSplit2.toString());
            return false;
        }
        if (!strArrSplit[0].trim().equals(strArrSplit2[0].trim())) {
            otaLog("不是同一个客户的   dev=" + strArrSplit[0] + "   net= " + strArrSplit2[0]);
            return false;
        }
        try {
            return Integer.parseInt(new StringBuilder().append(strArrSplit2[0]).append(strArrSplit2[2]).append(strArrSplit2[3]).toString()) != Integer.parseInt(new StringBuilder().append(strArrSplit[0]).append(strArrSplit[2]).append(strArrSplit[3]).toString());
        } catch (Exception e) {
            otaLog("OTA版本比对错误" + e.toString());
            return false;
        }
    }

    public static byte[] getBinFromServer(String str) throws Exception {
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
        httpURLConnection.setConnectTimeout(5000);
        int contentLength = httpURLConnection.getContentLength();
        byte[] bArr = new byte[contentLength];
        InputStream inputStream = httpURLConnection.getInputStream();
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        byte[] bArr2 = new byte[1024];
        int i = 0;
        otaLog("ifileLength=" + contentLength);
        while (true) {
            int i2 = bufferedInputStream.read(bArr2);
            if (i2 == -1) {
                bufferedInputStream.close();
                inputStream.close();
                otaLog("myByte=" + contentLength);
                return bArr;
            }
            System.arraycopy(bArr2, 0, bArr, i, i2);
            i += i2;
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v23 ??, still in use, count: 4, list:
          (r0v23 ??) from 0x0087: PHI (r0v17 ??) = (r0v11 ??), (r0v23 ??) binds: [B:20:0x0085, B:16:0x007a] A[DONT_GENERATE, DONT_INLINE]
          (r0v23 ??) from 0x0084: PHI (r0v11 ??) = (r0v9 ??), (r0v23 ??) binds: [B:36:0x0049, B:41:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v23 ?? I:java.io.FileOutputStream) from 0x0074: INVOKE (r0v23 ?? I:java.io.FileOutputStream) VIRTUAL call: java.io.FileOutputStream.close():void A[Catch: Exception -> 0x007a, IOException -> 0x0097, all -> 0x009b, MD:():void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
          (r0v23 ??) from 0x009a: PHI (r0v20 ??) = (r0v19 ??), (r0v23 ??) binds: [B:23:0x008f, B:15:0x0077] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    /* JADX INFO: Access modifiers changed from: private */
    public void writeFile(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v23 ??, still in use, count: 4, list:
          (r0v23 ??) from 0x0087: PHI (r0v17 ??) = (r0v11 ??), (r0v23 ??) binds: [B:20:0x0085, B:16:0x007a] A[DONT_GENERATE, DONT_INLINE]
          (r0v23 ??) from 0x0084: PHI (r0v11 ??) = (r0v9 ??), (r0v23 ??) binds: [B:36:0x0049, B:41:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v23 ?? I:java.io.FileOutputStream) from 0x0074: INVOKE (r0v23 ?? I:java.io.FileOutputStream) VIRTUAL call: java.io.FileOutputStream.close():void A[Catch: Exception -> 0x007a, IOException -> 0x0097, all -> 0x009b, MD:():void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
          (r0v23 ??) from 0x009a: PHI (r0v20 ??) = (r0v19 ??), (r0v23 ??) binds: [B:23:0x008f, B:15:0x0077] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r8v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */

    public void setNeedSendOTAInfoToMain(boolean z) {
        this.needSendOTAInfoToMain = z;
    }

    public void setOtaState(int i) {
        if (this.otaState != i) {
            this.otaState = i;
        }
    }

    public void setMainMessenger(Messenger messenger) {
        this.mainMessenger = messenger;
    }

    public void startOta(String str, String str2, String str3) {
        otaLog("otaState=" + this.otaState);
        if (str2 == null || str3 == null || this.otaState > 0) {
            return;
        }
        otaLog("devV=" + str2 + "  netV=" + str);
        dealOTAUpdata(str3, str2, str);
    }

    public void startOtaFromFile(String str, String str2, String str3) {
        otaLog("otaState=" + this.otaState);
        if (str2 == null || str3 == null || this.otaState > 0) {
            return;
        }
        otaLog("devV=" + str2 + "  netV=" + str);
        dealOTAUpdataFromFile(str3, str2, str);
    }

    public void otaDataSendResult(int i) {
        if (i != -101) {
            int i2 = this.otaSendFileMAXTime - 1;
            this.otaSendFileMAXTime = i2;
            if (i2 < 0) {
                setOtaState(0);
            } else {
                getOTAState();
            }
            otaLog("ota 失败  剩余失败次数：" + this.otaSendFileMAXTime);
            return;
        }
        setOtaState(5);
        this.otaSendFileMAXTime = 5;
        int lastSendBytesLen = this.otaPos + this.mOTASendEntity.getLastSendBytesLen();
        this.otaPos = lastSendBytesLen;
        long j = lastSendBytesLen * 1000;
        this.mOtaK3Info.setFileSize(this.mOTASendEntity.getOtaFileLen());
        this.mOtaK3Info.setOtaPos(this.otaPos);
        if (this.mOTASendEntity.getOtaFileLen() != 0) {
            this.mOtaK3Info.setBaifenbi(j / this.mOTASendEntity.getOtaFileLen());
        }
        if (this.otaPos >= this.mOTASendEntity.getOtaFileLen()) {
            otaLog("ota 完成:" + this.otaPos);
            setOtaState(6);
            this.proxy.getSendHelper().sendOTAFinish();
        } else {
            otaLog("ota otaPos=" + this.otaPos + "   all Len=" + this.mOTASendEntity.getOtaFileLen());
            IK6SendDataManager sendHelper = this.proxy.getSendHelper();
            int otaFileCRC = this.mOTASendEntity.getOtaFileCRC();
            int otaFileLen = this.mOTASendEntity.getOtaFileLen();
            int i3 = this.otaPos;
            sendHelper.sendOTAData(otaFileCRC, otaFileLen, i3, this.mOTASendEntity.getSendIndexDate(i3));
        }
    }

    public void otaStateResult(K6_OTAStateInfo k6_OTAStateInfo) {
        this.otaSendFileMAXTime = 5;
        this.otaPos = k6_OTAStateInfo.getFile_pos();
        otaLog(k6_OTAStateInfo.toString());
        if (k6_OTAStateInfo.getStatus() == 0 || k6_OTAStateInfo.getStatus() == 1) {
            if (this.otaState >= 4) {
                return;
            } else {
                setOtaState(4);
            }
        } else if (k6_OTAStateInfo.getStatus() == 2) {
            setOtaState(7);
        } else {
            setOtaState(0);
        }
        switch (k6_OTAStateInfo.getStatus()) {
            case 0:
                this.otaPos = 0;
                IK6SendDataManager sendHelper = this.proxy.getSendHelper();
                int otaFileCRC = this.mOTASendEntity.getOtaFileCRC();
                int otaFileLen = this.mOTASendEntity.getOtaFileLen();
                int i = this.otaPos;
                sendHelper.sendOTAData(otaFileCRC, otaFileLen, i, this.mOTASendEntity.getSendIndexDate(i));
                otaLog("没有升级过，从头开始升级");
                break;
            case 1:
                if (this.mOTASendEntity.getOtaFileCRC() != k6_OTAStateInfo.getFile_crc16()) {
                    this.otaPos = 0;
                    IK6SendDataManager sendHelper2 = this.proxy.getSendHelper();
                    int otaFileCRC2 = this.mOTASendEntity.getOtaFileCRC();
                    int otaFileLen2 = this.mOTASendEntity.getOtaFileLen();
                    int i2 = this.otaPos;
                    sendHelper2.sendOTAData(otaFileCRC2, otaFileLen2, i2, this.mOTASendEntity.getSendIndexDate(i2));
                    otaLog("有升级过，但是crc校验不正确");
                    break;
                } else {
                    this.otaPos = k6_OTAStateInfo.getFile_pos();
                    IK6SendDataManager sendHelper3 = this.proxy.getSendHelper();
                    int otaFileCRC3 = this.mOTASendEntity.getOtaFileCRC();
                    int otaFileLen3 = this.mOTASendEntity.getOtaFileLen();
                    int i3 = this.otaPos;
                    sendHelper3.sendOTAData(otaFileCRC3, otaFileLen3, i3, this.mOTASendEntity.getSendIndexDate(i3));
                    otaLog("有升级过，从+" + this.otaPos + "+开始升级");
                    break;
                }
            case 2:
                otaLog("升级成功");
                this.mOtaK3Info.setFileSize(this.mOTASendEntity.getOtaFileLen());
                this.mOtaK3Info.setOtaPos(this.mOTASendEntity.getOtaFileLen());
                if (this.mOTASendEntity.getOtaFileLen() != 0) {
                    this.mOtaK3Info.setBaifenbi(1000L);
                    break;
                }
                break;
            case 3:
            case 4:
            case 5:
            default:
                otaLog("升级错误");
                break;
        }
    }

    public void bleStateChange() {
        CEDevK6Proxy cEDevK6Proxy = this.proxy;
        if (cEDevK6Proxy != null) {
            if (cEDevK6Proxy.isDisconnect()) {
                setOtaState(0);
                this.mOtaK3Info = new OtaInfo();
            } else if (this.proxy.isConnectOK()) {
                this.otaSendFileMAXTime = 5;
                this.getOtaStateMAXTime = 3;
            }
        }
    }

    public void getOTAInfoResult(int i) {
        if (i == 0) {
            int i2 = this.getOtaStateMAXTime - 1;
            this.getOtaStateMAXTime = i2;
            if (i2 < 0) {
                setOtaState(0);
            } else {
                getOTAState();
            }
        }
    }
}
