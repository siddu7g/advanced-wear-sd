package ce.com.cenewbluesdk.ota.ota_modea;

import android.content.Context;
import android.util.Log;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.e;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OtaUtil.class */
public class OtaUtil {
    public static Map<Integer, Integer> versionStr2Map(String str) {
        HashMap map = new HashMap();
        String[] strArrSplit = str.split("\\.");
        int i = 0;
        while (i < strArrSplit.length) {
            int i2 = i;
            int i3 = i2 + 1;
            i = i3;
            map.put(Integer.valueOf(i3), Integer.valueOf(strArrSplit[i2]));
        }
        return map;
    }

    public static boolean equalVersionMap(Map<Integer, Integer> map, Map<Integer, Integer> map2) {
        if (map.size() != map2.size()) {
            return false;
        }
        for (Integer num : map.keySet()) {
            if (!map.get(num).equals(map2.get(num))) {
                return false;
            }
        }
        return true;
    }

    public static byte[] getBytes(String str, Context context) throws IOException {
        FileInputStream fileInputStream;
        InputStream inputStreamOpen;
        if (str == null) {
            return null;
        }
        byte[] byteArray = null;
        try {
            if (str.startsWith("android_asset/")) {
                inputStreamOpen = context.getAssets().open(str.replace("android_asset/", ""));
            } else {
                File file = new File(str);
                inputStreamOpen = fileInputStream;
                fileInputStream = new FileInputStream(file);
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1000);
            byte[] bArr = new byte[1000];
            while (true) {
                int i = inputStreamOpen.read(bArr);
                if (i == -1) {
                    break;
                }
                byteArrayOutputStream.write(bArr, 0, i);
            }
            inputStreamOpen.close();
            byteArrayOutputStream.close();
            byteArray = byteArrayOutputStream.toByteArray();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Lg.d("FileTransControl" + e);
        } catch (IOException e2) {
            e2.printStackTrace();
            Lg.d("FileTransControl" + e2);
        }
        return byteArray;
    }

    public static boolean checkCrc16OK(int i, byte[] bArr) {
        return i == e.a(bArr);
    }

    public static String otaLog(String str) {
        Log.e("otak6 ", str);
        return str;
    }
}
