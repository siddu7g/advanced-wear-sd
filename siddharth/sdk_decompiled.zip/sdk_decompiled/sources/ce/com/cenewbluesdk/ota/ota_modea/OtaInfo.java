package ce.com.cenewbluesdk.ota.ota_modea;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OtaInfo.class */
public class OtaInfo implements Serializable {
    private int fileSize;
    private int otaPos;
    private long baifenbi;
    private String netVersion;
    private String devVersion;

    public int getFileSize() {
        return this.fileSize;
    }

    public void setFileSize(int i) {
        this.fileSize = i;
    }

    public int getOtaPos() {
        return this.otaPos;
    }

    public void setOtaPos(int i) {
        this.otaPos = i;
    }

    public long getBaifenbi() {
        return this.baifenbi;
    }

    public void setBaifenbi(long j) {
        this.baifenbi = j;
    }

    public String getNetVersion() {
        return this.netVersion;
    }

    public void setNetVersion(String str) {
        this.netVersion = str;
    }

    public String getDevVersion() {
        return this.devVersion;
    }

    public void setDevVersion(String str) {
        this.devVersion = str;
    }
}
