package ce.com.cenewbluesdk.ota.ota_modea;

import ce.com.cenewbluesdk.uitl.ByteUtil;

/* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/DealOtaFile.class */
public class DealOtaFile {
    byte[] fileBytes;
    private OTASendEntity mOTASendEntity;

    public DealOtaFile(byte[] bArr) throws OtaFileException {
        this.fileBytes = bArr;
        resolveFile();
    }

    public OTASendEntity getOTASendEntity() {
        return this.mOTASendEntity;
    }

    public void resolveFile() throws OtaFileException {
        this.mOTASendEntity = null;
        byte[] bArr = this.fileBytes;
        if (bArr == null || bArr.length < 5000) {
            throw new OtaFileException("文件异常  是空，或者长度小于100");
        }
        int iByte4ToInt = ByteUtil.byte4ToInt(new byte[]{bArr[0], bArr[1], bArr[2], bArr[3]});
        byte[] bArr2 = this.fileBytes;
        int iByte2ToInt = ByteUtil.byte2ToInt(new byte[]{bArr2[4], bArr2[5]});
        byte[] bArr3 = this.fileBytes;
        if (iByte4ToInt != bArr3.length) {
            throw new OtaFileException("文件异常  文件解析出来的长度，不等于文件的实际长度");
        }
        int i = iByte4ToInt - 6;
        byte[] bArr4 = new byte[i];
        System.arraycopy(bArr3, 6, bArr4, 0, i);
        if (!OtaUtil.checkCrc16OK(iByte2ToInt, bArr4)) {
            throw new OtaFileException("文件异常  文件的crc校验不正确");
        }
        byte b = bArr4[0];
        int i2 = iByte4ToInt - 7;
        byte[] bArr5 = new byte[i2];
        System.arraycopy(bArr4, 1, bArr5, 0, i2);
        this.mOTASendEntity = new OTASendEntity(bArr5, b);
        OtaUtil.otaLog("fileCrc=" + iByte2ToInt + "fileLen=" + iByte4ToInt);
    }
}
