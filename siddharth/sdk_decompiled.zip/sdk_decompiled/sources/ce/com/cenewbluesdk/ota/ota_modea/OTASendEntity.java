package ce.com.cenewbluesdk.ota.ota_modea;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.e;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OTASendEntity.class */
public class OTASendEntity {
    public static final int FILE_TYPE_NULL = 0;
    public static final int FILE_TYPE_CUSTOMER = 1;
    public static final int FILE_TYPE_HARDWARE = 2;
    public static final int FILE_TYPE_CODE = 3;
    public static final int FILE_TYPE_PIC = 4;
    public static final int FILE_TYPE_FONT = 5;
    public static final int FILE_TYPE_DATA = 6;
    public static final int OTA_NONE = 0;
    public static final int OTA_RUNING = 1;
    public static final int OTA_FINISH_SUCCESS = 2;
    public static final int OTA_FINISH_WRONG = 3;
    public static final int OTA_IMG_SIZE_ERROR = 4;
    public static final int OTA_IMG_CRC16_ERROR = 5;
    public static final int OTA_ITEM_HEAD_LEN_ERROR = 6;
    public static final int OTA_ITEM_HEAD_LEN_ERROR_ALL = 16;
    public static final int OTA_ITEM_MEDIA_ERROR = 17;
    public static final int OTA_ITEM_MEDIA_ERROR_ALL = 27;
    public static final int OTA_ITEM_SIZE_ERROR = 28;
    public static final int OTA_ITEM_SIZE_ERROR_ALL = 38;
    public static final int OTA_ITEM_CRC16_ERROR = 39;
    public static final int OTA_ITEM_CRC16_ERROR_ALL = 49;
    public static final int DF_SendOTAbytesLen = 300;
    private ArrayList<Otak3Entity> mOtak3Entities;
    private int dateLen;
    private byte[] sendBytes;
    private int otaFileLen;
    private int otaFileCRC;
    private int lastSendBytesLen;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OTASendEntity$Otak3Entity.class */
    class Otak3Entity {
        public static final int itemHeadLen = 18;
        private byte headLen;
        private byte file_type;
        private byte version_id;
        private byte media_type;
        private byte[] start_addr;
        private byte[] end_addr;
        private byte[] len;
        private byte[] crc16;
        private byte[] data;
        private int entityLen;

        public Otak3Entity(byte b, byte b2, byte b3, byte b4, byte[] bArr, byte[] bArr2, int i, int i2, byte[] bArr3) {
            this.start_addr = new byte[4];
            this.end_addr = new byte[4];
            this.len = new byte[]{(byte) (i & 255), (byte) ((i >>> 8) & 255), (byte) ((i >>> 16) & 255), (byte) ((i >>> 24) & 255)};
            this.crc16 = new byte[]{(byte) (i2 & 255), (byte) ((i2 >>> 8) & 255)};
            this.headLen = b;
            this.file_type = b2;
            this.version_id = b3;
            this.media_type = b4;
            this.start_addr = bArr;
            this.end_addr = bArr2;
            this.data = bArr3;
            this.entityLen = i + 18;
        }

        public byte[] getSendData() {
            byte[] bArr = new byte[this.data.length + 18];
            bArr[0] = this.headLen;
            bArr[1] = this.file_type;
            bArr[2] = this.version_id;
            bArr[3] = this.media_type;
            byte[] bArr2 = this.start_addr;
            System.arraycopy(bArr2, 0, bArr, 4, bArr2.length);
            byte[] bArr3 = this.end_addr;
            System.arraycopy(bArr3, 0, bArr, 8, bArr3.length);
            byte[] bArr4 = this.len;
            System.arraycopy(bArr4, 0, bArr, 12, bArr4.length);
            byte[] bArr5 = this.crc16;
            System.arraycopy(bArr5, 0, bArr, 16, bArr5.length);
            byte[] bArr6 = this.data;
            System.arraycopy(bArr6, 0, bArr, 18, bArr6.length);
            return bArr;
        }

        public byte[] getCrc16() {
            return this.crc16;
        }

        public int getEntityLen() {
            return this.entityLen;
        }

        public byte getVersion_id() {
            return this.version_id;
        }

        public byte getFile_type() {
            return this.file_type;
        }

        public String toString() {
            return "Otak3Entity{file_type=" + ((int) this.file_type) + "\n, version_id=" + ((int) this.version_id) + "\n, media_type=" + ((int) this.media_type) + "\n, entityLen=" + this.entityLen + "\n, start_addr=" + Arrays.toString(this.start_addr) + "\n, end_addr=" + Arrays.toString(this.end_addr) + "\n, len=" + Arrays.toString(this.len) + "\n, crc16=" + Arrays.toString(this.crc16) + '}';
        }
    }

    private void generateSendBytes(ArrayList<Otak3Entity> arrayList) {
        Iterator<Otak3Entity> it = arrayList.iterator();
        while (it.hasNext()) {
            this.dateLen += it.next().getEntityLen();
        }
        int i = this.dateLen + 7;
        this.otaFileLen = i;
        this.sendBytes = new byte[i];
        int entityLen = 7;
        Iterator<Otak3Entity> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Otak3Entity next = it2.next();
            if (OtaUtil.checkCrc16OK(ByteUtil.byte2ToInt(next.crc16), next.data)) {
                OtaUtil.otaLog("item 的crc   ok， +" + ((int) next.file_type));
            } else {
                OtaUtil.otaLog("item 的crc错了， +" + ((int) next.file_type));
            }
            OtaUtil.otaLog("合成文件时ITem的crc=" + ByteUtil.byte2ToInt(next.crc16));
            OtaUtil.otaLog(next.toString());
            OtaUtil.otaLog(" 111   saddr=" + ByteUtil.byte4ToInt(next.start_addr) + "   eaddr=" + ByteUtil.byte4ToInt(next.end_addr));
            System.arraycopy(next.getSendData(), 0, this.sendBytes, entityLen, next.getEntityLen());
            entityLen += next.getEntityLen();
        }
        this.sendBytes[6] = (byte) arrayList.size();
        System.arraycopy(ByteUtil.intToByte4(this.otaFileLen), 0, this.sendBytes, 0, 4);
        OtaUtil.otaLog("sendBytes[6]=" + ((int) this.sendBytes[6]));
        this.otaFileCRC = e.a(this.sendBytes, 6);
        OtaUtil.otaLog("新生成的文件的Ota crc=" + this.otaFileCRC + "   otaFileLen=" + this.otaFileLen + "  index=" + entityLen);
        System.arraycopy(ByteUtil.int2bytes2(this.otaFileCRC), 0, this.sendBytes, 4, 2);
    }

    public OTASendEntity(byte[] bArr, int i) throws OtaFileException {
        ArrayList<Otak3Entity> arrayList = new ArrayList<>();
        this.mOtak3Entities = arrayList;
        int i2 = 0;
        if (arrayList != null) {
            arrayList.clear();
        } else {
            this.mOtak3Entities = new ArrayList<>();
        }
        String[] strArr = new String[i];
        int i3 = 0;
        while (i3 < i) {
            int i4 = i2 + 18;
            if (i4 > bArr.length) {
                throw new OtaFileException("OtaItem 文件解析长度出了问题");
            }
            byte b = bArr[i2];
            byte b2 = bArr[i2 + 1];
            byte b3 = bArr[i2 + 2];
            byte b4 = bArr[i2 + 3];
            byte[] bArr2 = {bArr[i2 + 4], bArr[i2 + 5], bArr[i2 + 6], bArr[i2 + 7]};
            byte[] bArr3 = {bArr[i2 + 8], bArr[i2 + 9], bArr[i2 + 10], bArr[i2 + 11]};
            OtaUtil.otaLog("file_type=" + ((int) b2));
            OtaUtil.otaLog("saddr=" + ByteUtil.byte4ToInt(bArr2) + "   eaddr=" + ByteUtil.byte4ToInt(bArr3));
            int iByte4ToInt = ByteUtil.byte4ToInt(new byte[]{bArr[i2 + 12], bArr[i2 + 13], bArr[i2 + 14], bArr[i2 + 15]});
            int iByte2ToInt = ByteUtil.byte2ToInt(new byte[]{bArr[i2 + 16], bArr[i2 + 17]});
            byte[] bArr4 = new byte[iByte4ToInt];
            int i5 = i4 + iByte4ToInt;
            int i6 = i5;
            if (i5 > bArr.length) {
                throw new OtaFileException("长度错误?");
            }
            System.arraycopy(bArr, i4, bArr4, 0, iByte4ToInt);
            OtaUtil.otaLog("解析文件时ITem的crc=" + iByte2ToInt);
            if (OtaUtil.checkCrc16OK(iByte2ToInt, bArr4)) {
                strArr[i3] = "ok";
                OtaUtil.otaLog("item 的crc16  OK  OK的item是第" + i3 + "个");
                this.mOtak3Entities.add(new Otak3Entity(b, b2, b3, b4, bArr2, bArr3, iByte4ToInt, iByte2ToInt, bArr4));
            } else {
                strArr[i3] = "item 的crc16错误  错误的item是第" + i3 + "个";
                i6 = i2;
            }
            i3++;
            i2 = i6;
        }
        if (this.mOtak3Entities.size() != i) {
            throw new OtaFileException("item 的数量不对,mOtak3Entities list的size是" + this.mOtak3Entities.size() + "  itemCount=" + i + ", log:" + Arrays.toString(strArr));
        }
    }

    public int getLastSendBytesLen() {
        return this.lastSendBytesLen;
    }

    public int getOtaFileLen() {
        return this.otaFileLen;
    }

    public int getOtaFileCRC() {
        return this.otaFileCRC;
    }

    public byte[] getSendIndexDate(int i) {
        int i2 = this.otaFileLen;
        if (i >= i2) {
            return null;
        }
        int i3 = i + DF_SendOTAbytesLen <= i2 ? 300 : i2 - i;
        this.lastSendBytesLen = i3;
        byte[] bArr = new byte[i3];
        System.arraycopy(this.sendBytes, i, bArr, 0, i3);
        return bArr;
    }

    public void initOTAData(Map<Integer, Integer> map) {
        generateSendBytes(this.mOtak3Entities);
    }

    public Map<Integer, Integer> getVersionMap() {
        HashMap map = new HashMap();
        Iterator<Otak3Entity> it = this.mOtak3Entities.iterator();
        while (it.hasNext()) {
            Otak3Entity next = it.next();
            map.put(Integer.valueOf(next.getFile_type()), Integer.valueOf(next.getVersion_id()));
        }
        return map;
    }
}
