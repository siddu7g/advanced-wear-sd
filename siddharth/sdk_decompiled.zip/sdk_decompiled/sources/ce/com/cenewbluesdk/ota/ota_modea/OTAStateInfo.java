package ce.com.cenewbluesdk.ota.ota_modea;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OTAStateInfo.class */
public class OTAStateInfo implements Serializable {
    private int status;
    private int file_crc16;
    private int file_size;
    private int file_pos;

    public OTAStateInfo(byte[] bArr) {
        this.status = bArr[0] & 255;
        this.file_crc16 = ByteUtil.byte2ToInt(new byte[]{bArr[1], bArr[2]});
        this.file_size = ByteUtil.byte4ToInt(new byte[]{bArr[3], bArr[4], bArr[5], bArr[6]});
        this.file_pos = ByteUtil.byte4ToInt(new byte[]{bArr[7], bArr[8], bArr[9], bArr[10]});
    }

    public static int getItemSize() {
        return 11;
    }

    public int getStatus() {
        return this.status;
    }

    public int getFile_crc16() {
        return this.file_crc16;
    }

    public int getFile_size() {
        return this.file_size;
    }

    public int getFile_pos() {
        return this.file_pos;
    }

    public String toString() {
        return "OTAStateInfo{status=" + this.status + ", file_crc16=" + this.file_crc16 + ", file_size=" + this.file_size + ", file_pos=" + this.file_pos + '}';
    }
}
