package ce.com.cenewbluesdk.ota.ota_modea;

/* loaded from: classes.jar:ce/com/cenewbluesdk/ota/ota_modea/OtaFileException.class */
class OtaFileException extends Exception {
    public OtaFileException(String str) {
        super(str);
    }

    public OtaFileException(String str, Throwable th) {
        super(str, th);
    }

    public OtaFileException(Throwable th) {
        super(th);
    }

    public OtaFileException() {
    }
}
