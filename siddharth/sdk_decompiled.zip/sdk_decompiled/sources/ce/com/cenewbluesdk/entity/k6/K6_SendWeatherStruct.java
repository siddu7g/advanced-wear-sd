package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendWeatherStruct.class */
public class K6_SendWeatherStruct extends BaseData implements Serializable {
    byte[] time;
    public ArrayList<K6WeatherInfoItem> item;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendWeatherStruct$K6WeatherInfoItem.class */
    public static class K6WeatherInfoItem implements Serializable {
        byte weather;
        byte low_temperature;
        byte high_temperature;
        byte pm1;
        byte pm2;
        List<Integer> codeArr0 = Arrays.asList(10);
        List<Integer> codeArr1 = Arrays.asList(new Integer[0]);
        List<Integer> codeArr2 = Arrays.asList(11, 12, 22, 13);
        List<Integer> codeArr3 = Arrays.asList(13, 14, 15, 16, 17, 18);
        List<Integer> codeArr4 = Arrays.asList(19, 20, 21);

        public K6WeatherInfoItem(int i, int i2, int i3, int i4) {
            this.weather = (byte) (i & 255);
            this.low_temperature = (byte) (i2 & 255);
            this.high_temperature = (byte) (i3 & 255);
            this.pm1 = (byte) (i4 % 256);
            this.pm2 = (byte) (i4 / 256);
        }

        public int appWeatherCodeToOriginalDeviceWeatherCode(int i) {
            if (this.codeArr0.contains(Integer.valueOf(i))) {
                return 0;
            }
            if (this.codeArr1.contains(Integer.valueOf(i))) {
                return 1;
            }
            if (this.codeArr2.contains(Integer.valueOf(i))) {
                return 2;
            }
            if (this.codeArr3.contains(Integer.valueOf(i))) {
                return 3;
            }
            return this.codeArr4.contains(Integer.valueOf(i)) ? 4 : 0;
        }

        public byte[] getBytes() {
            return new byte[]{this.weather, this.low_temperature, this.high_temperature, this.pm1, this.pm2};
        }
    }

    public K6_SendWeatherStruct(int i, ArrayList<K6WeatherInfoItem> arrayList) {
        this.item = new ArrayList<>();
        this.time = ByteUtil.intToByte4(i);
        this.item = arrayList;
    }

    public static int getItemSize() {
        return 7;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[19];
        System.arraycopy(this.time, 0, bArr, 0, 4);
        for (int i = 0; i < 3; i++) {
            byte[] bytes = this.item.get(i).getBytes();
            System.arraycopy(bytes, 0, bArr, (i * bytes.length) + 4, bytes.length);
        }
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(105);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
