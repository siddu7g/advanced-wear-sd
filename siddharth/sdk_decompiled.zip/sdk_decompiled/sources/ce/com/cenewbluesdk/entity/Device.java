package ce.com.cenewbluesdk.entity;

import ce.com.cenewbluesdk.scan.K6ManufacturerInfo;
import java.io.Serializable;
import java.util.Objects;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/Device.class */
public class Device implements Serializable {
    private String name;
    private String address;
    private int rssi;
    private String pid;
    private K6ManufacturerInfo info;

    public Device() {
    }

    public Device(String str, String str2, int i, K6ManufacturerInfo k6ManufacturerInfo) {
        this.name = str;
        this.address = str2;
        this.rssi = i;
        this.info = k6ManufacturerInfo;
    }

    public Device(String str, String str2) {
        this.address = str;
        this.name = str2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return this.address.equals(((Device) obj).address);
    }

    public int hashCode() {
        return Objects.hash(this.address);
    }

    public String getPid() {
        return this.pid;
    }

    public void setPid(String str) {
        this.pid = str;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String str) {
        this.address = str;
    }

    public int getRssi() {
        return this.rssi;
    }

    public void setRssi(int i) {
        this.rssi = i;
    }

    public K6ManufacturerInfo getInfo() {
        return this.info;
    }

    public void setInfo(K6ManufacturerInfo k6ManufacturerInfo) {
        this.info = k6ManufacturerInfo;
    }
}
