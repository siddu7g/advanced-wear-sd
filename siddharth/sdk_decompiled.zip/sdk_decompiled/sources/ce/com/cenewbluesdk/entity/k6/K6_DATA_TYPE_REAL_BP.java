package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_REAL_BP.class */
public class K6_DATA_TYPE_REAL_BP extends BaseData implements Serializable {
    public static final int BP_SWITCH_OPEN = 1;
    public static final int BP_SWITCH_CLOSE = 0;
    private int time;
    private int bp_sbp;
    private int bp_dbp;
    private boolean isEnd;

    public K6_DATA_TYPE_REAL_BP(byte[] bArr) {
        if (bArr[0] == 0) {
            this.isEnd = true;
            return;
        }
        this.time = ByteUtil.byte4ToInt(new byte[]{bArr[0], bArr[1], bArr[2], bArr[3]});
        this.bp_sbp = bArr[4] & 255;
        this.bp_dbp = bArr[5] & 255;
    }

    public K6_DATA_TYPE_REAL_BP(int i) {
        this.time = i;
        this.bp_sbp = 0;
        this.bp_dbp = 0;
    }

    public static int getItemSize() {
        return 6;
    }

    public boolean isEnd() {
        return this.isEnd;
    }

    public byte[] getSendByte() {
        return new byte[]{(byte) this.time, 0, 0, 0, (byte) this.bp_sbp, (byte) this.bp_dbp};
    }

    public int getTime() {
        return this.time;
    }

    public void setTime(int i) {
        this.time = i;
    }

    public int getBp_sbp() {
        return this.bp_sbp;
    }

    public void setBp_sbp(int i) {
        this.bp_sbp = i;
    }

    public int getBp_dbp() {
        return this.bp_dbp;
    }

    public void setBp_dbp(int i) {
        this.bp_dbp = i;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(18);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "K6_DATA_TYPE_REAL_BP{time=" + this.time + ", bp_sbp=" + this.bp_sbp + ", bp_dbp=" + this.bp_dbp + '}';
    }
}
