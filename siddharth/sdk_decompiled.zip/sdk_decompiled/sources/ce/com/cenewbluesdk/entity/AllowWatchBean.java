package ce.com.cenewbluesdk.entity;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/AllowWatchBean.class */
public class AllowWatchBean extends BaseBean<AllowWatchBean> implements Serializable {
    private int id;
    private int customerId;
    private int version;
    private String btNames;

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public int getCustomerId() {
        return this.customerId;
    }

    public void setCustomerId(int i) {
        this.customerId = i;
    }

    public int getVersion() {
        return this.version;
    }

    public void setVersion(int i) {
        this.version = i;
    }

    public String getBtNames() {
        return this.btNames;
    }

    public void setBtNames(String str) {
        this.btNames = str;
    }
}
