package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_LANGUAGE_SETTING.class */
public class K6_DATA_TYPE_LANGUAGE_SETTING extends BaseData implements Serializable {
    byte lan;

    public K6_DATA_TYPE_LANGUAGE_SETTING() {
        this.lan = (byte) (BleSystemUtils.getSystemLanguageStatus() & 255);
    }

    public K6_DATA_TYPE_LANGUAGE_SETTING(Integer num) {
        this.lan = (byte) (num.intValue() & 255);
    }

    public static int getItemSize() {
        return 1;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = this.lan;
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(103);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
