package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_WATCH_FACE_SYN_NNNOMAL_CHOICE.class */
public class K6_DATA_TYPE_WATCH_FACE_SYN_NNNOMAL_CHOICE extends BaseData implements Serializable {
    private int cmd;
    private int index;
    int[] all_len;
    int[] current_pos;

    public K6_DATA_TYPE_WATCH_FACE_SYN_NNNOMAL_CHOICE(byte[] bArr) {
        this.all_len = new int[4];
        this.current_pos = new int[4];
    }

    public K6_DATA_TYPE_WATCH_FACE_SYN_NNNOMAL_CHOICE(int i) {
        this.all_len = new int[4];
        this.current_pos = new int[4];
        this.cmd = 1;
        this.index = i;
    }

    public static int getItemSize() {
        return 2;
    }

    public byte[] getSendByte() {
        return new byte[]{(byte) this.cmd, (byte) this.index};
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(131);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
