package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_FileDownLoad.class */
public class K6_FileDownLoad implements Serializable {
    private int index;
    private int cmd;
    private int file_size;
    private int file_pos;

    public K6_FileDownLoad(byte[] bArr) {
        this.index = bArr[0] & 255;
        this.cmd = bArr[1] & 255;
        this.file_size = ByteUtil.byte4ToInt(new byte[]{bArr[2], bArr[3], bArr[4], bArr[5]});
        this.file_pos = ByteUtil.byte4ToInt(new byte[]{bArr[6], bArr[7], bArr[8], bArr[9]});
    }

    public int getIndex() {
        return this.index;
    }

    public void setIndex(int i) {
        this.index = i;
    }

    public int getCmd() {
        return this.cmd;
    }

    public void setCmd(int i) {
        this.cmd = i;
    }

    public int getFile_size() {
        return this.file_size;
    }

    public void setFile_size(int i) {
        this.file_size = i;
    }

    public int getFile_pos() {
        return this.file_pos;
    }

    public void setFile_pos(int i) {
        this.file_pos = i;
    }
}
