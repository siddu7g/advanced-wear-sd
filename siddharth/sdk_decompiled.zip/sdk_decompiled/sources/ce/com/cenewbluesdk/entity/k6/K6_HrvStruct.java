package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.TimeUtil;
import ce.com.cenewbluesdk.uitl.d;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_HrvStruct.class */
public class K6_HrvStruct implements Serializable {
    long time;
    int hrvNums;

    public K6_HrvStruct(byte[] bArr) {
        d dVar = new d(bArr);
        this.time = TimeUtil.s2CForDev(dVar.c(4), true).getTimeInMillis();
        this.hrvNums = dVar.c(1);
    }

    public K6_HrvStruct(long j, int i) {
        this.time = j;
        this.hrvNums = i;
    }

    public static ArrayList<K6_HrvStruct> parse(byte[] bArr) {
        ArrayList<K6_HrvStruct> arrayList = new ArrayList<>();
        d dVar = new d(bArr);
        for (int i = 0; i < bArr.length / 5; i++) {
            arrayList.add(new K6_HrvStruct(dVar.b(5)));
        }
        return arrayList;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[5];
        System.arraycopy(ByteBuffer.allocate(4).putLong(this.time).array(), 0, bArr, 0, 4);
        bArr[4] = (byte) this.hrvNums;
        return bArr;
    }

    public long getTime() {
        return this.time;
    }

    public void setTime(long j) {
        this.time = j;
    }

    public int getHrvNums() {
        return this.hrvNums;
    }

    public void setHrvNums(int i) {
        this.hrvNums = i;
    }

    public String toString() {
        return "Heart_struct_K3{time=" + this.time + ", hrvNums=" + this.hrvNums + ", time=" + TimeUtil.long2String(this.time) + '}';
    }
}
