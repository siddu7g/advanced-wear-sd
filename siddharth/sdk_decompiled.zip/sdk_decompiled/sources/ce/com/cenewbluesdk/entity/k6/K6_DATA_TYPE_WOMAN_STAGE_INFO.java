package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_WOMAN_STAGE_INFO.class */
public class K6_DATA_TYPE_WOMAN_STAGE_INFO extends BaseData implements Serializable {
    byte type;
    long start_time;
    byte day_num;
    byte peroid;
    byte remind_onoff;
    byte[] remind_time;
    byte remind_mode_menstrual;
    byte remind_mode_ovulation;
    byte remind_mode_ovulation_peak;
    byte remind_mode_end_ovulation;

    public static final List<String> getCycleDay() {
        ArrayList arrayList = new ArrayList();
        for (int i = 10; i <= 60; i++) {
            arrayList.add(i + "");
        }
        return arrayList;
    }

    public static final List<String> getDurationDay() {
        ArrayList arrayList = new ArrayList();
        for (int i = 1; i <= 15; i++) {
            arrayList.add(i + "");
        }
        return arrayList;
    }

    public static final List<String> getHourData() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i <= 23; i++) {
            if (i < 10) {
                arrayList.add("0" + i);
            } else {
                arrayList.add(i + "");
            }
        }
        return arrayList;
    }

    public static final List<String> getMinData() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i <= 59; i++) {
            if (i < 10) {
                arrayList.add("0" + i);
            } else {
                arrayList.add(i + "");
            }
        }
        return arrayList;
    }

    public K6_DATA_TYPE_WOMAN_STAGE_INFO(int i, long j, int i2, int i3, int i4, byte[] bArr, int i5, int i6, int i7, int i8) {
        this.type = (byte) 1;
        this.remind_time = new byte[2];
        this.type = (byte) (i & 255);
        this.start_time = j;
        this.day_num = (byte) (i2 & 255);
        this.peroid = (byte) (i3 & 255);
        this.remind_onoff = (byte) (i4 & 255);
        this.remind_time = bArr;
        this.remind_mode_menstrual = (byte) (i5 & 255);
        this.remind_mode_ovulation = (byte) (i6 & 255);
        this.remind_mode_ovulation_peak = (byte) (i7 & 255);
        this.remind_mode_end_ovulation = (byte) (i8 & 255);
    }

    public K6_DATA_TYPE_WOMAN_STAGE_INFO(byte[] bArr) {
        this.type = (byte) 1;
        this.remind_time = new byte[2];
        this.start_time = ByteUtil.byte4ToInt(new byte[]{bArr[1], bArr[2], bArr[3], bArr[4]}) * 1000;
        this.day_num = bArr[5];
        this.peroid = bArr[6];
        this.remind_onoff = bArr[7];
        this.remind_time = new byte[]{bArr[8], bArr[9]};
        this.remind_mode_menstrual = bArr[10];
        this.remind_mode_ovulation = bArr[11];
        this.remind_mode_ovulation_peak = bArr[12];
        this.remind_mode_end_ovulation = bArr[13];
    }

    public static int getItemSize() {
        return 22;
    }

    public byte getType() {
        return this.type;
    }

    public void setType(byte b) {
        this.type = b;
    }

    public long getStart_time() {
        return this.start_time;
    }

    public void setStart_time(long j) {
        this.start_time = j;
    }

    public int getDay_num() {
        return this.day_num & 255;
    }

    public void setDay_num(int i) {
        this.day_num = (byte) (i & 255);
    }

    public int getPeroid() {
        return (byte) (this.peroid & 255);
    }

    public void setPeroid(int i) {
        this.peroid = (byte) (i & 255);
    }

    public int getRemind_onoff() {
        return this.remind_onoff & 255;
    }

    public void setRemind_onoff(int i) {
        this.remind_onoff = (byte) (i & 255);
    }

    public int[] getRemind_time() {
        byte[] bArr = this.remind_time;
        return new int[]{bArr[0] & 255, bArr[1] & 255};
    }

    public void setRemind_time(int[] iArr) {
        byte[] bArr = this.remind_time;
        bArr[0] = (byte) (iArr[0] & 255);
        bArr[1] = (byte) (iArr[1] & 255);
    }

    public int getRemind_mode_menstrual() {
        return this.remind_mode_menstrual & 255;
    }

    public void setRemind_mode_menstrual(int i) {
        this.remind_mode_menstrual = (byte) (i & 255);
    }

    public int getRemind_mode_ovulation() {
        return this.remind_mode_ovulation & 255;
    }

    public void setRemind_mode_ovulation(int i) {
        this.remind_mode_ovulation = (byte) (i & 255);
    }

    public int getRemind_mode_ovulation_peak() {
        return this.remind_mode_ovulation_peak & 255;
    }

    public void setRemind_mode_ovulation_peak(int i) {
        this.remind_mode_ovulation_peak = (byte) (i & 255);
    }

    public int getRemind_mode_end_ovulation() {
        return this.remind_mode_end_ovulation & 255;
    }

    public void setRemind_mode_end_ovulation(int i) {
        this.remind_mode_end_ovulation = (byte) (i & 255);
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = this.type;
        System.arraycopy(ByteUtil.intToByte4((int) (this.start_time / 1000)), 0, bArr, 1, 4);
        bArr[5] = this.day_num;
        bArr[6] = this.peroid;
        bArr[7] = this.remind_onoff;
        byte[] bArr2 = this.remind_time;
        System.arraycopy(bArr2, 0, bArr, 8, bArr2.length);
        bArr[10] = this.remind_mode_menstrual;
        bArr[11] = this.remind_mode_ovulation;
        bArr[12] = this.remind_mode_ovulation_peak;
        bArr[13] = this.remind_mode_end_ovulation;
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(133);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
