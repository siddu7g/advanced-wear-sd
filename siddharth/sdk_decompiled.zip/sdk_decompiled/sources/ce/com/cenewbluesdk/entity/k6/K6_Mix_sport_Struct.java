package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.TimeUtil;
import ce.com.cenewbluesdk.uitl.d;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_Mix_sport_Struct.class */
public class K6_Mix_sport_Struct implements K6_MixSportType, Serializable {
    private int sport_type;
    private long startTime;
    private long endTime;
    private int totalTime;
    private int distance;
    private int calories;
    private int avgSpeed;
    private int avgHr;
    private int step = 0;
    private int maxSpeed = 0;
    private int maxHr = 0;

    private static int toTimeS(int i) {
        return i / 100;
    }

    public K6_Mix_sport_Struct() {
    }

    public K6_Mix_sport_Struct(int i, byte[] bArr) {
        this.sport_type = i;
    }

    public static K6_Mix_sport_Struct parse(byte[] bArr) {
        d dVar = new d(bArr);
        K6_Mix_sport_Struct k6_Mix_sport_Struct = new K6_Mix_sport_Struct();
        k6_Mix_sport_Struct.setSport_type(dVar.c(1));
        k6_Mix_sport_Struct.setStartTime(TimeUtil.s2CForDev(dVar.c(4), true).getTimeInMillis());
        k6_Mix_sport_Struct.setEndTime(TimeUtil.s2CForDev(dVar.c(4), true).getTimeInMillis());
        k6_Mix_sport_Struct.setTotalTime((int) ((k6_Mix_sport_Struct.getEndTime() - k6_Mix_sport_Struct.getStartTime()) / 1000));
        k6_Mix_sport_Struct.setDistance(dVar.c(4));
        k6_Mix_sport_Struct.setAvgHr(dVar.c(1));
        k6_Mix_sport_Struct.setMaxHr(dVar.c(1));
        k6_Mix_sport_Struct.setStep(dVar.c(4));
        k6_Mix_sport_Struct.setCalories(dVar.c(4));
        k6_Mix_sport_Struct.setAvgSpeed(dVar.c(2));
        k6_Mix_sport_Struct.setMaxSpeed(dVar.c(2));
        return k6_Mix_sport_Struct;
    }

    public int getSport_type() {
        return this.sport_type;
    }

    public void setSport_type(int i) {
        this.sport_type = i;
    }

    public long getStartTime() {
        return this.startTime;
    }

    public void setStartTime(long j) {
        this.startTime = j;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public void setEndTime(long j) {
        this.endTime = j;
    }

    public int getTotalTime() {
        return this.totalTime;
    }

    public void setTotalTime(int i) {
        this.totalTime = i;
    }

    public int getStep() {
        return this.step;
    }

    public void setStep(int i) {
        this.step = i;
    }

    public int getDistance() {
        return this.distance;
    }

    public void setDistance(int i) {
        this.distance = i;
    }

    public int getCalories() {
        return this.calories;
    }

    public void setCalories(int i) {
        this.calories = i;
    }

    public int getAvgSpeed() {
        return this.avgSpeed;
    }

    public void setAvgSpeed(int i) {
        this.avgSpeed = i;
    }

    public int getMaxSpeed() {
        return this.maxSpeed;
    }

    public void setMaxSpeed(int i) {
        this.maxSpeed = i;
    }

    public int getAvgHr() {
        return this.avgHr;
    }

    public void setAvgHr(int i) {
        this.avgHr = i;
    }

    public int getMaxHr() {
        return this.maxHr;
    }

    public void setMaxHr(int i) {
        this.maxHr = i;
    }

    public String toString() {
        return "K6_Mix_sport_Struct{sport_type=" + this.sport_type + ", startTime=" + this.startTime + ", endTime=" + this.endTime + ", totalTime=" + this.totalTime + ", step=" + this.step + ", distance=" + this.distance + ", calories=" + this.calories + ", avgSpeed=" + this.avgSpeed + ", maxSpeed=" + this.maxSpeed + ", avgHr=" + this.avgHr + ", maxHr=" + this.maxHr + '}';
    }
}
