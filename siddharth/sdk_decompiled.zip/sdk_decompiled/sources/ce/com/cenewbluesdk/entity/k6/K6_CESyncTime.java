package ce.com.cenewbluesdk.entity.k6;

import android.os.Parcel;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.TimeUtil;
import java.io.Serializable;
import java.util.TimeZone;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_CESyncTime.class */
public class K6_CESyncTime extends BaseData implements Serializable {
    byte[] abs_time;
    byte[] offset_time;
    byte mdFormat;
    byte format;

    public K6_CESyncTime(long j, long j2, byte b) {
        this.abs_time = new byte[4];
        this.offset_time = new byte[4];
        this.abs_time = ByteUtil.intToByte((int) (j / 1000));
        this.offset_time = ByteUtil.intToByte4((int) (j2 / 1000));
        this.format = b;
    }

    public K6_CESyncTime(long j, long j2, byte b, byte b2) {
        this.abs_time = new byte[4];
        this.offset_time = new byte[4];
        this.abs_time = ByteUtil.intToByte((int) (j / 1000));
        this.offset_time = ByteUtil.intToByte4((int) (j2 / 1000));
        this.format = b;
        this.mdFormat = b2;
    }

    public K6_CESyncTime(byte[] bArr) {
        byte[] bArr2 = new byte[4];
        this.abs_time = bArr2;
        this.offset_time = new byte[4];
        System.arraycopy(bArr2, 0, bArr, 0, 4);
        System.arraycopy(this.offset_time, 0, bArr, 4, 4);
        byte b = bArr[8];
        this.format = (byte) (b & 1);
        this.mdFormat = (byte) ((b >> 1) & 1);
    }

    protected K6_CESyncTime(Parcel parcel) {
        this.abs_time = new byte[4];
        this.offset_time = new byte[4];
        this.abs_time = parcel.createByteArray();
        this.offset_time = parcel.createByteArray();
    }

    public static K6_CESyncTime getCurrentTime() {
        return new K6_CESyncTime(TimeUtil.now(), TimeZone.getDefault().getOffset(r0), (byte) (CEBlueSharedPreference.getAppTimeDisplay() & 255), (byte) (CEBlueSharedPreference.getAppDateDisplay() & 255));
    }

    public static int getItemSize() {
        return 9;
    }

    public byte[] getAbs_time() {
        return this.abs_time;
    }

    public void setAbs_time(byte[] bArr) {
        this.abs_time = bArr;
    }

    public byte[] getOffset_time() {
        return this.offset_time;
    }

    public void setOffset_time(byte[] bArr) {
        this.offset_time = bArr;
    }

    public int getMdFormat() {
        return this.mdFormat & 255;
    }

    public void setMdFormat(int i) {
        this.mdFormat = (byte) (i & 255);
    }

    public int getFormat() {
        return this.format & 255;
    }

    public void setFormat(int i) {
        this.format = (byte) (i & 255);
    }

    public byte[] getBytes() {
        byte[] bArr = this.abs_time;
        int length = bArr.length;
        byte[] bArr2 = this.offset_time;
        byte[] bArr3 = new byte[length + bArr2.length + 1];
        System.arraycopy(bArr, 0, bArr3, 0, bArr2.length);
        System.arraycopy(this.offset_time, 0, bArr3, 4, 4);
        bArr3[8] = (byte) ((this.format ^ (this.mdFormat << 1)) & 255);
        return bArr3;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(104);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(9);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
