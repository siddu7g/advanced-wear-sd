package ce.com.cenewbluesdk.entity;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/BaseBean.class */
public class BaseBean<T> implements Serializable {
    private int code;
    private String err;
    private T result;

    public int getCode() {
        return this.code;
    }

    public void setCode(int i) {
        this.code = i;
    }

    public String getErr() {
        return this.err;
    }

    public void setErr(String str) {
        this.err = str;
    }

    public T getResult() {
        return this.result;
    }

    public void setResult(T t) {
        this.result = t;
    }
}
