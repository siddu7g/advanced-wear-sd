package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_MUSIC_CONTROL.class */
public class K6_DATA_TYPE_MUSIC_CONTROL extends BaseData implements Serializable {
    public static final int BP_SWITCH_OPEN = 1;
    public static final int BP_SWITCH_CLOSE = 0;
    private int cmd;
    private int len;
    private byte[] content;

    public K6_DATA_TYPE_MUSIC_CONTROL(int i, byte[] bArr) {
        this.cmd = i;
        this.content = bArr;
    }

    public static int getItemSize() {
        return 66;
    }

    public byte[] getSendByte() {
        byte[] bArr = this.content;
        this.len = bArr.length;
        if (bArr.length > 62) {
            this.len = 62;
        }
        byte[] bArr2 = new byte[66];
        System.arraycopy(new byte[]{(byte) (this.cmd & 255), (byte) (this.len & 255)}, 0, bArr2, 0, 2);
        System.arraycopy(bArr, 0, bArr2, 2, this.len);
        return bArr2;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(113);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
