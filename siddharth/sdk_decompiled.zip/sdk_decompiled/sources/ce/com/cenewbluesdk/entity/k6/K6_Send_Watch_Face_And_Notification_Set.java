package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_Send_Watch_Face_And_Notification_Set.class */
public class K6_Send_Watch_Face_And_Notification_Set extends BaseData implements Serializable {
    private byte[] send_byte;

    public K6_Send_Watch_Face_And_Notification_Set(byte[] bArr) {
        this.send_byte = bArr;
    }

    public K6_Send_Watch_Face_And_Notification_Set(int i) {
        this.send_byte = new byte[]{(byte) (i & 255), (byte) ((i >> 8) & 255), 0, 0};
    }

    public static int getItemSize() {
        return 4;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[4];
        byte[] bArr2 = this.send_byte;
        System.arraycopy(bArr2, 0, bArr, 0, bArr2.length);
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData(1, 124);
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        cEDevData.setData(getBytes());
        return cEDevData;
    }

    public String toString() {
        return "K6_Send_Watch_Face_And_Notification_Set{send_byte=" + ByteUtil.byte2hex(this.send_byte) + '}';
    }
}
