package ce.com.cenewbluesdk.entity.k6;

import android.os.Parcel;
import android.os.Parcelable;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendUserInfo.class */
public class K6_SendUserInfo extends BaseData implements Parcelable {
    public static final Parcelable.Creator<K6_SendUserInfo> CREATOR = new Parcelable.Creator<K6_SendUserInfo>() { // from class: ce.com.cenewbluesdk.entity.k6.K6_SendUserInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public K6_SendUserInfo createFromParcel(Parcel parcel) {
            return new K6_SendUserInfo(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public K6_SendUserInfo[] newArray(int i) {
            return new K6_SendUserInfo[i];
        }
    };
    byte[] userid;
    byte sex;
    byte age;
    byte height;
    byte weight;
    byte lr_hand;

    public K6_SendUserInfo(int i, int i2, int i3, int i4, int i5, int i6) {
        this.userid = new byte[4];
        this.userid = ByteUtil.intToByte(i);
        this.sex = (byte) (i2 & 255);
        this.age = (byte) (i3 & 255);
        this.height = (byte) (i4 & 255);
        this.weight = (byte) (i5 & 255);
        this.lr_hand = (byte) (i6 & 255);
    }

    protected K6_SendUserInfo(Parcel parcel) {
        this.userid = new byte[4];
        this.userid = parcel.createByteArray();
        this.sex = parcel.readByte();
        this.age = parcel.readByte();
        this.height = parcel.readByte();
        this.weight = parcel.readByte();
        this.lr_hand = parcel.readByte();
    }

    public static int getItemSize() {
        return 9;
    }

    public void setUserid(int i) {
        this.userid = ByteUtil.intToByte(i);
    }

    public byte[] getBytes() {
        byte[] bArr = this.userid;
        byte[] bArr2 = new byte[bArr.length + 5];
        System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        bArr2[4] = this.sex;
        bArr2[5] = this.age;
        bArr2[6] = this.height;
        bArr2[7] = this.weight;
        bArr2[8] = this.lr_hand;
        return bArr2;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByteArray(this.userid);
        parcel.writeByte(this.sex);
        parcel.writeByte(this.age);
        parcel.writeByte(this.height);
        parcel.writeByte(this.weight);
        parcel.writeByte(this.lr_hand);
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(102);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
