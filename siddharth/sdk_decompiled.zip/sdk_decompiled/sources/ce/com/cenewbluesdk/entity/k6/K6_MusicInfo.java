package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.Serializable;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_MusicInfo.class */
public class K6_MusicInfo extends BaseData implements Serializable {
    private int musicstatus;
    private String musicName;
    private String artistName;
    private String albumName;

    public K6_MusicInfo() {
    }

    public K6_MusicInfo(int i, String str, String str2, String str3) {
        this.musicstatus = i;
        this.musicName = str;
        this.artistName = str2;
        this.albumName = str3;
    }

    public int getMusicstatus() {
        return this.musicstatus;
    }

    public void setMusicstatus(int i) {
        this.musicstatus = i;
    }

    public String getMusicName() {
        return this.musicName;
    }

    public void setMusicName(String str) {
        this.musicName = str;
    }

    public String getArtistName() {
        return this.artistName;
    }

    public void setArtistName(String str) {
        this.artistName = str;
    }

    public String getAlbumName() {
        return this.albumName;
    }

    public void setAlbumName(String str) {
        this.albumName = str;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        byte[] bytes = getBytes();
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(113);
        cEDevData.setData(bytes);
        cEDevData.setItemL(bytes.length);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[76];
        bArr[0] = (byte) this.musicstatus;
        if (this.musicName != null) {
            while (this.musicName.getBytes().length > 24) {
                String str = this.musicName;
                this.musicName = str.substring(0, str.length() - 1);
            }
            bArr[1] = (byte) this.musicName.getBytes().length;
            System.arraycopy(this.musicName.getBytes(), 0, bArr, 2, bArr[1]);
            Lg.e("musicName=" + ByteUtil.byte2hex(this.musicName.getBytes()));
        }
        if (this.artistName != null) {
            while (this.artistName.getBytes().length > 24) {
                String str2 = this.artistName;
                this.artistName = str2.substring(0, str2.length() - 1);
            }
            bArr[26] = (byte) this.artistName.getBytes().length;
            System.arraycopy(this.artistName.getBytes(), 0, bArr, 27, bArr[26]);
            Lg.e("artistName=" + ByteUtil.byte2hex(this.artistName.getBytes()));
        }
        if (this.albumName != null) {
            while (this.albumName.getBytes().length > 24) {
                String str3 = this.albumName;
                this.albumName = str3.substring(0, str3.length() - 1);
            }
            bArr[51] = (byte) this.albumName.getBytes().length;
            System.arraycopy(this.albumName.getBytes(), 0, bArr, 52, bArr[51]);
            Lg.e("albumName=" + ByteUtil.byte2hex(this.albumName.getBytes()));
        }
        Lg.e(ByteUtil.byte2hex(bArr));
        return bArr;
    }
}
