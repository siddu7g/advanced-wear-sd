package ce.com.cenewbluesdk.entity;

import ce.com.cenewbluesdk.entity.k6.K6_Sleep;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/K6_sleepData.class */
public class K6_sleepData implements Serializable {
    private List<K6_sleepData> k6SleepData = new ArrayList();
    private List<K6_Sleep> k6_sleeps = new ArrayList();
    private long sleepDay;
    private String userId;
    private String devId;
    private long startTime;
    private long endTime;
    private int sleepTime;
    private int deepTime;
    private int lightTime;
    private int movementTime;
    private String sleepDetail;
    private long uploadTime;
    private int revivetimes;

    public List<K6_sleepData> getK6SleepData() {
        return this.k6SleepData;
    }

    public void setK6SleepData(List<K6_sleepData> list) {
        this.k6SleepData = list;
    }

    public List<K6_Sleep> getK6_sleeps() {
        return this.k6_sleeps;
    }

    public void setK6_sleeps(List<K6_Sleep> list) {
        this.k6_sleeps = list;
    }

    public int getRevivetimes() {
        return this.revivetimes;
    }

    public void setRevivetimes(int i) {
        this.revivetimes = i;
    }

    public String getDevId() {
        return this.devId;
    }

    public void setDevId(String str) {
        this.devId = str;
    }

    public long getSleepDay() {
        return this.sleepDay;
    }

    public void setSleepDay(long j) {
        this.sleepDay = j;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String str) {
        this.userId = str;
    }

    public long getStartTime() {
        return this.startTime;
    }

    public void setStartTime(long j) {
        this.startTime = j;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public void setEndTime(long j) {
        this.endTime = j;
    }

    public int getSleepTime() {
        return this.sleepTime;
    }

    public void setSleepTime(int i) {
        this.sleepTime = i;
    }

    public int getDeepTime() {
        return this.deepTime;
    }

    public void setDeepTime(int i) {
        this.deepTime = i;
    }

    public int getLightTime() {
        return this.lightTime;
    }

    public void setLightTime(int i) {
        this.lightTime = i;
    }

    public String getSleepDetail() {
        return this.sleepDetail;
    }

    public void setSleepDetail(String str) {
        this.sleepDetail = str;
    }

    public long getUploadTime() {
        return this.uploadTime;
    }

    public void setUploadTime(long j) {
        this.uploadTime = j;
    }

    public int getMovementTime() {
        return this.movementTime;
    }

    public void setMovementTime(int i) {
        this.movementTime = i;
    }

    public Map<String, Object> toMap() {
        Hashtable hashtable = new Hashtable();
        hashtable.put("userId", getUserId());
        hashtable.put("sleepDay", Long.valueOf(getSleepDay()));
        hashtable.put("startTime", Long.valueOf(getStartTime()));
        hashtable.put("endTime", Long.valueOf(getEndTime()));
        hashtable.put("sleepTime", Integer.valueOf(getSleepTime()));
        hashtable.put("deepTime", Integer.valueOf(getDeepTime()));
        hashtable.put("lightTime", Integer.valueOf(getLightTime()));
        hashtable.put("sleepDetail", getSleepDetail());
        hashtable.put("uploadTime", Long.valueOf(getUploadTime()));
        hashtable.put("devId", getDevId());
        return hashtable;
    }

    public String toString() {
        return "K6_sleepData{k6SleepData=" + this.k6SleepData + ", k6_sleeps=" + this.k6_sleeps + ", sleepDay=" + this.sleepDay + ", userId='" + this.userId + "', devId='" + this.devId + "', startTime=" + this.startTime + ", endTime=" + this.endTime + ", sleepTime=" + this.sleepTime + ", deepTime=" + this.deepTime + ", lightTime=" + this.lightTime + ", sleepDetail='" + this.sleepDetail + "', uploadTime=" + this.uploadTime + ", revivetimes=" + this.revivetimes + '}';
    }
}
