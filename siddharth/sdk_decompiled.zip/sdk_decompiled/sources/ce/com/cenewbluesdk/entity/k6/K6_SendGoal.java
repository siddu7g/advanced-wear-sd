package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendGoal.class */
public class K6_SendGoal extends BaseData implements Serializable {
    private byte[] step;
    private byte[] distance;
    private byte[] calories;
    private byte[] sleep;
    private byte[] duration;
    private int targetStep;
    private int targetDistance;
    private int targetCalories;
    private int targetSleep;
    private int targetDuration;

    public K6_SendGoal(int i, int i2, int i3, int i4, int i5) {
        this.targetStep = i;
        this.targetDistance = i2;
        this.targetCalories = i3;
        this.targetSleep = i4;
        this.targetDuration = i5;
        this.step = ByteUtil.intToByte4(i);
        this.distance = ByteUtil.intToByte4(i2);
        this.calories = ByteUtil.intToByte4(i3);
        this.sleep = ByteUtil.int2bytes2(i4);
        this.duration = ByteUtil.int2bytes2(i5);
    }

    public static int getItemSize() {
        return 16;
    }

    public int getTargetStep() {
        return this.targetStep;
    }

    public int getTargetDistance() {
        return this.targetDistance;
    }

    public int getTargetCalories() {
        return this.targetCalories;
    }

    public int getTargetSleep() {
        return this.targetSleep;
    }

    public int getTargetDuration() {
        return this.targetDuration;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        System.arraycopy(this.step, 0, bArr, 0, 4);
        System.arraycopy(this.distance, 0, bArr, 4, 4);
        System.arraycopy(this.calories, 0, bArr, 8, 4);
        System.arraycopy(this.sleep, 0, bArr, 12, 2);
        System.arraycopy(this.duration, 0, bArr, 14, 2);
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData(1, 111);
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        cEDevData.setData(getBytes());
        return cEDevData;
    }
}
