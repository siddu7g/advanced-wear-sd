package ce.com.cenewbluesdk.entity.k6;

import java.io.Serializable;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6NoDisturbSummary.class */
public class K6NoDisturbSummary implements Serializable {
    private int swit;
    ArrayList<K6_NoDisturb> list;

    public K6NoDisturbSummary(int i, ArrayList<K6_NoDisturb> arrayList) {
        this.swit = i;
        this.list = arrayList;
    }

    public int getSwit() {
        return this.swit;
    }

    public void setSwit(int i) {
        this.swit = i;
    }

    public ArrayList<K6_NoDisturb> getList() {
        return this.list;
    }

    public void setList(ArrayList<K6_NoDisturb> arrayList) {
        this.list = arrayList;
    }
}
