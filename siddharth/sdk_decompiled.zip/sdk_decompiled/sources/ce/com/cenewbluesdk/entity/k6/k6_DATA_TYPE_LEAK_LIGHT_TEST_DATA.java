package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/k6_DATA_TYPE_LEAK_LIGHT_TEST_DATA.class */
public class k6_DATA_TYPE_LEAK_LIGHT_TEST_DATA extends BaseData implements Serializable {
    private int leakType;
    private int infrared;
    private int redLight;
    private int greenLight;
    private int wearingThresholdHr;
    private int wearingThresholdOb;
    private int thresholdRelease;

    private byte[] getSendByte() {
        return new byte[getItemSize()];
    }

    public static int getItemSize() {
        return 13;
    }

    public int getLeakType() {
        return this.leakType;
    }

    public void setLeakType(int i) {
        this.leakType = i;
    }

    public int getInfrared() {
        return this.infrared;
    }

    public void setInfrared(int i) {
        this.infrared = i;
    }

    public int getRedLight() {
        return this.redLight;
    }

    public void setRedLight(int i) {
        this.redLight = i;
    }

    public int getGreenLight() {
        return this.greenLight;
    }

    public void setGreenLight(int i) {
        this.greenLight = i;
    }

    public int getWearingThresholdHr() {
        return this.wearingThresholdHr;
    }

    public void setWearingThresholdHr(int i) {
        this.wearingThresholdHr = i;
    }

    public int getWearingThresholdOb() {
        return this.wearingThresholdOb;
    }

    public void setWearingThresholdOb(int i) {
        this.wearingThresholdOb = i;
    }

    public int getThresholdRelease() {
        return this.thresholdRelease;
    }

    public void setThresholdRelease(int i) {
        this.thresholdRelease = i;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(CEBC.K6.DATA_TYPE_LEAKLIGHT_TEST);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
