package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_HARDWARE_INFO.class */
public class K6_DATA_TYPE_HARDWARE_INFO extends BaseData implements Serializable {
    byte[] lcd_width;
    byte[] lcd_height;
    byte RGB;
    byte[] download_dia;
    byte[] reserved = new byte[9];
    private int defaultSize = 240;

    public K6_DATA_TYPE_HARDWARE_INFO(byte[] bArr) {
        this.lcd_width = new byte[2];
        this.lcd_height = new byte[2];
        this.download_dia = new byte[2];
        this.lcd_width = new byte[]{bArr[0], bArr[1]};
        this.lcd_height = new byte[]{bArr[2], bArr[3]};
        this.RGB = bArr[4];
        this.download_dia = new byte[]{bArr[5], bArr[6]};
        CEBlueSharedPreference.setDialSize(getDialSize() + "");
    }

    private byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        return new byte[0];
    }

    private int getItemSize() {
        return 16;
    }

    /* JADX WARN: Not initialized variable reg: 0, insn: 0x0017: INVOKE (r0 I:java.lang.Exception) VIRTUAL call: java.lang.Exception.printStackTrace():void A[MD:():void (c)], block:B:8:0x0017 */
    public int getWidth() {
        Exception excPrintStackTrace;
        try {
            return ByteUtil.byte2ToInt(this.lcd_width) > 0 ? ByteUtil.byte2ToInt(this.lcd_width) : this.defaultSize;
        } catch (Exception unused) {
            excPrintStackTrace.printStackTrace();
            return this.defaultSize;
        }
    }

    /* JADX WARN: Not initialized variable reg: 0, insn: 0x0017: INVOKE (r0 I:java.lang.Exception) VIRTUAL call: java.lang.Exception.printStackTrace():void A[MD:():void (c)], block:B:8:0x0017 */
    public int getHeight() {
        Exception excPrintStackTrace;
        try {
            return ByteUtil.byte2ToInt(this.lcd_height) > 0 ? ByteUtil.byte2ToInt(this.lcd_height) : this.defaultSize;
        } catch (Exception unused) {
            excPrintStackTrace.printStackTrace();
            return this.defaultSize;
        }
    }

    /* JADX WARN: Type inference failed for: r0v8, types: [int, java.lang.Exception] */
    public int getDialSize() {
        ?? Byte2ToInt;
        try {
            if (ByteUtil.byte2ToInt(this.download_dia) <= 0) {
                return 0;
            }
            Byte2ToInt = ByteUtil.byte2ToInt(this.download_dia);
            return Byte2ToInt * 4 * 1024;
        } catch (Exception unused) {
            Byte2ToInt.printStackTrace();
            return 0;
        }
    }

    public int getRGB() {
        return this.RGB;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(23);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
