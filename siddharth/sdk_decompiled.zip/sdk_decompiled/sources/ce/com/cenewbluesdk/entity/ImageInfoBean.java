package ce.com.cenewbluesdk.entity;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/ImageInfoBean.class */
public class ImageInfoBean implements Serializable {
    private int id;
    private int pic_type;
    private int pic_num;
    private int width;
    private int height;
    private int offset;
    private int depth;

    public int getId() {
        return this.id;
    }

    public int getPic_type() {
        return this.pic_type;
    }

    public void setPic_type(int i) {
        this.pic_type = i;
    }

    public int getPic_num() {
        return this.pic_num;
    }

    public void setPic_num(int i) {
        this.pic_num = i;
    }

    public void setId(int i) {
        this.id = i;
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int i) {
        this.width = i;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int i) {
        this.height = i;
    }

    public int getOffset() {
        return this.offset;
    }

    public void setOffset(int i) {
        this.offset = i;
    }

    public int getDepth() {
        return this.depth;
    }

    public void setDepth(int i) {
        this.depth = i;
    }

    public String toString() {
        return "ImageInfoBean{id=" + this.id + ", pic_type=" + this.pic_type + ", pic_num=" + this.pic_num + ", width=" + this.width + ", height=" + this.height + ", offset=" + this.offset + ", depth=" + this.depth + '}';
    }
}
