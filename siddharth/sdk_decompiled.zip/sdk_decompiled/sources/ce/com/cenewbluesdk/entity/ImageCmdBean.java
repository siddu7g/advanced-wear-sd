package ce.com.cenewbluesdk.entity;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/ImageCmdBean.class */
public class ImageCmdBean implements Serializable {
    private int id;
    private int pos_dir;
    private int pos_x;
    private int pos_y;
    private int r;
    private int g;
    private int b;
    private int pic_type;
    private int pic_num;
    private int pic_x_interval;
    private int period;
    private int act_num;
    private int act_pic;
    private int line_width;
    private int line_size;
    private int start_pos;
    private int end_pos;

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public int getPos_dir() {
        return this.pos_dir;
    }

    public void setPos_dir(int i) {
        this.pos_dir = i;
    }

    public int getPos_x() {
        return this.pos_x;
    }

    public void setPos_x(int i) {
        this.pos_x = i;
    }

    public int getPos_y() {
        return this.pos_y;
    }

    public void setPos_y(int i) {
        this.pos_y = i;
    }

    public int getR() {
        return this.r;
    }

    public void setR(int i) {
        this.r = i;
    }

    public int getG() {
        return this.g;
    }

    public void setG(int i) {
        this.g = i;
    }

    public int getB() {
        return this.b;
    }

    public void setB(int i) {
        this.b = i;
    }

    public int getPic_type() {
        return this.pic_type;
    }

    public void setPic_type(int i) {
        this.pic_type = i;
    }

    public int getPic_num() {
        return this.pic_num;
    }

    public void setPic_num(int i) {
        this.pic_num = i;
    }

    public int getPic_x_interval() {
        return this.pic_x_interval;
    }

    public void setPic_x_interval(int i) {
        this.pic_x_interval = i;
    }

    public int getPeriod() {
        return this.period;
    }

    public void setPeriod(int i) {
        this.period = i;
    }

    public int getAct_num() {
        return this.act_num;
    }

    public void setAct_num(int i) {
        this.act_num = i;
    }

    public int getAct_pic() {
        return this.act_pic;
    }

    public void setAct_pic(int i) {
        this.act_pic = i;
    }

    public int getLine_width() {
        return this.line_width;
    }

    public void setLine_width(int i) {
        this.line_width = i;
    }

    public int getLine_size() {
        return this.line_size;
    }

    public void setLine_size(int i) {
        this.line_size = i;
    }

    public int getStart_pos() {
        return this.start_pos;
    }

    public void setStart_pos(int i) {
        this.start_pos = i;
    }

    public int getEnd_pos() {
        return this.end_pos;
    }

    public void setEnd_pos(int i) {
        this.end_pos = i;
    }

    public String toString() {
        return "ImageCmdBean{id=" + this.id + ", pos_dir=" + this.pos_dir + ", pos_x=" + this.pos_x + ", pos_y=" + this.pos_y + ", r=" + this.r + ", g=" + this.g + ", b=" + this.b + ", pic_type=" + this.pic_type + ", pic_num=" + this.pic_num + ", pic_x_interval=" + this.pic_x_interval + ", period=" + this.period + ", act_num=" + this.act_num + ", act_pic=" + this.act_pic + ", line_width=" + this.line_width + ", line_size=" + this.line_size + ", start_pos=" + this.start_pos + ", end_pos=" + this.end_pos + '}';
    }
}
