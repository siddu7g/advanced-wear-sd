package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_Sport.class */
public class K6_Sport implements Serializable {
    private int starTime;
    private int walkSteps;
    private int distance;
    private int calories;
    private int duration;

    public K6_Sport(byte[] bArr) {
        this.starTime = ByteUtil.byte4ToInt(new byte[]{bArr[0], bArr[1], bArr[2], bArr[3]});
        this.walkSteps = ByteUtil.byte4ToInt(new byte[]{bArr[4], bArr[5], bArr[6], bArr[7]});
        this.distance = ByteUtil.byte3ToInt(new byte[]{bArr[8], bArr[9], bArr[10], bArr[11]});
        this.calories = ByteUtil.byte3ToInt(new byte[]{bArr[12], bArr[13], bArr[14], bArr[15]});
        this.duration = ByteUtil.byte3ToInt(new byte[]{bArr[16], bArr[17], bArr[18], bArr[19]});
    }

    public K6_Sport() {
    }

    public static int getItemSize() {
        return 20;
    }

    public int getStarTime() {
        return this.starTime;
    }

    public void setStarTime(int i) {
        this.starTime = i;
    }

    public int getWalkSteps() {
        return this.walkSteps;
    }

    public void setWalkSteps(int i) {
        this.walkSteps = i;
    }

    public int getDistance() {
        return this.distance;
    }

    public void setDistance(int i) {
        this.distance = i;
    }

    public int getCalories() {
        return this.calories;
    }

    public void setCalories(int i) {
        this.calories = i;
    }

    public int getDuration() {
        return this.duration;
    }

    public void setDuration(int i) {
        this.duration = i;
    }

    public String toString() {
        return "K6_Sport{starTime=" + this.starTime + ", walkSteps=" + this.walkSteps + ", distance=" + this.distance + ", calories=" + this.calories + ", duration=" + this.duration + '}';
    }
}
