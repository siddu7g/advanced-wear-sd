package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_GSensor.class */
public class K6_GSensor implements Serializable {
    private short x;
    private short y;
    private short z;

    public K6_GSensor(byte[] bArr) {
        this.x = ByteUtil.byteToShort3(new byte[]{bArr[0], bArr[1]});
        this.y = ByteUtil.byteToShort3(new byte[]{bArr[2], bArr[3]});
        this.z = ByteUtil.byteToShort3(new byte[]{bArr[4], bArr[5]});
    }

    public static int getItemSize() {
        return 6;
    }

    public String toString() {
        return "K6_GSensor{x=" + ((int) this.x) + ", y=" + ((int) this.y) + ", z=" + ((int) this.z) + '}';
    }
}
