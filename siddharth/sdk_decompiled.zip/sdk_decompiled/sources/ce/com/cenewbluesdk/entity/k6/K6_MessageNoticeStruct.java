package ce.com.cenewbluesdk.entity.k6;

import android.util.Log;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_MessageNoticeStruct.class */
public class K6_MessageNoticeStruct extends BaseData implements Serializable {
    private static int MESSAGE_CONTENT_MAX_LENGTH = 230;
    public static final byte TYPE_PHONE = 1;
    public static final byte TYPE_MSG = 2;
    public static final byte TYPE_QQ = 3;
    public static final byte TYPE_WX = 4;
    public static final byte TYPE_EMAIL = 5;
    public static final byte TYPE_FACEBOOK = 6;
    public static final byte TYPE_TWITTER = 7;
    public static final byte TYPE_WHATSAPP = 8;
    public static final byte TYPE_SKYPE = 9;
    public static final byte TYPE_LINKED_IN = 10;
    public static final byte TYPE_LINE = 11;
    public static final byte TYPE_GOOGLE_MESSAGE = 12;
    public static final byte TYPE_GOOGLE_CALENDAR = 13;
    public static final byte TYPE_NATIVE_CALENDAR = 14;
    public static final byte TYPE_GOOGLE_GMAIL = 15;
    public static final byte TYPE_OTHER = 16;
    public static final byte TYPE_KAKAO = 17;
    public static final byte TYPE_INSTAGRAM = 18;
    public static final byte TYPE_TELEGRAM = 19;
    public static String WEIXIN = "com.tencent.mm";
    public static String QQ = "com.tencent.mobileqq";
    public static String TWITTER = "com.twitter.android";
    public static String FACEBOOK = "com.facebook.katana";
    public static String FACEBOOK_ORCA = "com.facebook.orca";
    public static String WHATSAPP = "com.whatsapp";
    public static String INSTAGRAM = "com.instagram.android";
    public static String SKYPE = "com.skype.raider";
    public static String SKYPE_CN = "com.skype.rover";
    public static String LINKEDIN = "com.linkedin.android";
    public static String LINE = "jp.naver.line.android";
    public static String MISSCALL = "com.android.incallui";
    public static String MESSAGING = "com.samsung.android.messaging";
    public static String MMS = "com.android.mms";
    public static String MESSAGING_GOOGLE = "com.google.android.apps.messaging";
    public static String MMS2 = "com.mms";
    public static String SMS = "com.sms";
    public static String MESSAGING_COMMON = "android.messaging";
    public static String CONTACTS = "com.android.contacts";
    public static String CONTACTS_HUAWEI = "com.huawei.contacts";
    public static String DIALER = "com.android.dialer";
    public static String XIAOMIMISSCALL = "com.android.server.telecom";
    public static String KAKAOTALK = "com.kakao.talk";
    public static String KAKAO_SIMPLE = "com.kakao.talk.theme.simple";
    public static String KAKAO_YELLOWID = "com.kakao.yellowid";
    public static String TELEGRAM = "org.telegram.messenger";
    public static String TELEGRAM_WEB = "org.telegram.messenger.web";
    public static String PLAY_STORE = "com.android.vending";
    public static String MISSCALLPHONE = "con.android.phone";
    public static String PUSH_OTHER = "other";
    public long absTimeValue;
    private byte[] abs_time;
    private byte type;
    private List<Property> infos = new ArrayList();
    private String name;
    private byte contextType;
    private String content;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_MessageNoticeStruct$Property.class */
    public class Property implements Serializable {
        public static final byte TYPE_PHONE_NUM = 0;
        public static final byte TYPE_NAME = 1;
        public static final byte TYPE_CONTENT = 2;
        byte attribute;
        byte len;
        byte[] data;

        public Property() {
        }

        public byte[] getBytes() {
            byte[] bArr = this.data;
            byte[] bArr2 = new byte[bArr.length + 2];
            bArr2[0] = this.attribute;
            bArr2[1] = this.len;
            System.arraycopy(bArr, 0, bArr2, 2, bArr.length);
            return bArr2;
        }

        public byte getAttribute() {
            return this.attribute;
        }
    }

    public static void setMESSAGE_CONTENT_MAX_LENGTH(int i) {
        MESSAGE_CONTENT_MAX_LENGTH = i;
    }

    public K6_MessageNoticeStruct(long j, byte b) {
        this.abs_time = new byte[4];
        this.absTimeValue = j;
        this.abs_time = ByteUtil.intToByte((int) (j / 1000));
        this.type = b;
    }

    private void addProperty(byte b, String str) {
        Property property = new Property();
        str.getBytes();
        Property property2 = null;
        for (int i = 0; i < this.infos.size(); i++) {
            if (this.infos.get(i).getAttribute() == 1) {
                property2 = this.infos.get(i);
            }
        }
        int length = property2 != null ? property2.getBytes().length : 0;
        boolean z = false;
        int i2 = b == 1 ? 60 : MESSAGE_CONTENT_MAX_LENGTH;
        while (str.getBytes().length > ((i2 - length) - 2) - 6) {
            String str2 = str;
            str = str2.substring(0, str2.length() - 1);
            z = true;
        }
        if (z) {
            String str3 = str;
            str = str3.substring(0, str3.length() - 3) + "...";
        }
        byte[] bytes = str.getBytes();
        property.data = bytes;
        property.len = (byte) bytes.length;
        property.attribute = b;
        this.infos.add(property);
    }

    public String getName() {
        return this.name;
    }

    public byte getContextType() {
        return this.contextType;
    }

    public String getContent() {
        return this.content;
    }

    public void setSendContext(String str, byte b, String str2) {
        this.name = str;
        this.contextType = b;
        this.content = str2;
        addProperty((byte) 1, str);
        addProperty(b, str2);
    }

    public byte[] getBytes() {
        int length = 0;
        for (Property property : this.infos) {
            Log.d("liu", "p.getBytes().length=" + property.getBytes().length);
            length += property.getBytes().length & 255;
        }
        Log.d("liu", "abs_time.length=" + this.abs_time.length + "   len=" + length);
        byte[] bArr = this.abs_time;
        byte[] bArr2 = new byte[bArr.length + 2 + length];
        System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        byte[] bArr3 = this.abs_time;
        bArr2[bArr3.length] = this.type;
        bArr2[bArr3.length + 1] = (byte) this.infos.size();
        int length2 = 6;
        for (Property property2 : this.infos) {
            System.arraycopy(property2.getBytes(), 0, bArr2, length2, property2.getBytes().length);
            length2 += property2.getBytes().length;
        }
        return bArr2;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(107);
        byte[] bytes = getBytes();
        cEDevData.setData(bytes);
        cEDevData.setItemL(bytes.length);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
