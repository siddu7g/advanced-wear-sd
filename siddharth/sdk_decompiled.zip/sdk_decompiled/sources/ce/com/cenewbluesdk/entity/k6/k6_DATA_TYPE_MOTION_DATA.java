package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/k6_DATA_TYPE_MOTION_DATA.class */
public class k6_DATA_TYPE_MOTION_DATA extends BaseData implements Serializable {
    private int Speed_Throw;
    private int X_Move_Distance;
    private int Y_Move_Distance;
    private byte[] bytes;

    private byte[] getSendByte() {
        return new byte[getItemSize()];
    }

    public static int getItemSize() {
        return 3;
    }

    public byte[] getBytes() {
        return this.bytes;
    }

    public void setBytes(byte[] bArr) {
        this.bytes = bArr;
    }

    public int getSpeed_Throw() {
        return this.Speed_Throw;
    }

    public void setSpeed_Throw(int i) {
        this.Speed_Throw = i;
    }

    public int getX_Move_Distance() {
        return this.X_Move_Distance;
    }

    public void setX_Move_Distance(int i) {
        this.X_Move_Distance = i;
    }

    public int getY_Move_Distance() {
        return this.Y_Move_Distance;
    }

    public void setY_Move_Distance(int i) {
        this.Y_Move_Distance = i;
    }

    public List<k6_DATA_TYPE_MOTION_DATA> getList() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.bytes.length / 6; i++) {
            k6_DATA_TYPE_MOTION_DATA k6_data_type_motion_data = new k6_DATA_TYPE_MOTION_DATA();
            byte[] bArr = this.bytes;
            int i2 = i * 6;
            k6_data_type_motion_data.setSpeed_Throw(ByteUtil.byte2ToInt2(new byte[]{bArr[i2 + 0], bArr[i2 + 1]}));
            byte[] bArr2 = this.bytes;
            k6_data_type_motion_data.setX_Move_Distance(ByteUtil.byte2ToInt2(new byte[]{bArr2[i2 + 2], bArr2[i2 + 3]}));
            byte[] bArr3 = this.bytes;
            k6_data_type_motion_data.setY_Move_Distance(ByteUtil.byte2ToInt2(new byte[]{bArr3[i2 + 4], bArr3[i2 + 5]}));
            arrayList.add(k6_data_type_motion_data);
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(144);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
