package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_REAL_HR.class */
public class K6_DATA_TYPE_REAL_HR extends BaseData implements Serializable {
    public static final int HR_SWITCH_OPEN = 1;
    public static final int HR_SWITCH_CLOSE = 0;
    private int value;
    private boolean isEnd;

    public K6_DATA_TYPE_REAL_HR(byte[] bArr) {
        if (bArr[0] == 0) {
            this.isEnd = true;
        } else {
            this.value = bArr[1] & 255;
        }
    }

    public K6_DATA_TYPE_REAL_HR(int i) {
        this.value = i;
    }

    public static int getItemSize() {
        return 1;
    }

    public boolean isEnd() {
        return this.isEnd;
    }

    public byte[] getSendByte() {
        return new byte[]{(byte) this.value};
    }

    public int getTime() {
        return this.value;
    }

    public void setTime(int i) {
        this.value = i;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int i) {
        this.value = i;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(24);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "K6_DATA_TYPE_REAL_HR{, value=" + this.value + '}';
    }
}
