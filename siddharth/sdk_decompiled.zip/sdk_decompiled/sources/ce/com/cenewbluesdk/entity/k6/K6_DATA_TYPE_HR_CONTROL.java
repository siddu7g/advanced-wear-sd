package ce.com.cenewbluesdk.entity.k6;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_HR_CONTROL.class */
public class K6_DATA_TYPE_HR_CONTROL implements Serializable {
    public static final int HR_CONTROL_TYPE_NULL = 0;
    public static final int HR_CONTROL_TYPE_HR = 1;
    public static final int HR_CONTROL_TYPE_BP = 2;
    public static final int HR_CONTROL_TYPE_O2 = 3;
    public static final int HR_CONTROL_TYPE_ECG = 4;
    public static final int HR_CONTROL_CLOSE = 0;
    public static final int HR_CONTROL_OPEN = 1;
    public int controlType;
    public int controlState;

    public K6_DATA_TYPE_HR_CONTROL(byte[] bArr) {
        if (bArr.length > 0) {
            this.controlType = (bArr[0] & 240) >> 4;
            this.controlState = bArr[0] & 15;
        }
    }

    public String toString() {
        return "K6_DATA_TYPE_HR_CONTROL{controlType=" + this.controlType + ", controlState=" + this.controlState + '}';
    }
}
