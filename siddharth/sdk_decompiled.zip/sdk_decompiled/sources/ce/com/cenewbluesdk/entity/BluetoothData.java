package ce.com.cenewbluesdk.entity;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/BluetoothData.class */
public class BluetoothData implements Serializable {
    private String bleAddress;
    private String bleName;

    public String getBleAddress() {
        return this.bleAddress;
    }

    public void setBleAddress(String str) {
        this.bleAddress = str;
    }

    public String getBleName() {
        return this.bleName;
    }

    public void setBleName(String str) {
        this.bleName = str;
    }
}
