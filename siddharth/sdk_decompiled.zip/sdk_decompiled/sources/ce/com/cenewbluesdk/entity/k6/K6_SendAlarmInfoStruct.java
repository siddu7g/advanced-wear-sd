package ce.com.cenewbluesdk.entity.k6;

import android.os.Parcel;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.Serializable;
import java.util.Arrays;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendAlarmInfoStruct.class */
public class K6_SendAlarmInfoStruct implements Serializable {
    public static int pidType;
    byte week_repeat;
    byte hour;
    byte min;
    byte switchState;
    byte[] name;

    public K6_SendAlarmInfoStruct(int i, int i2, int i3, int i4, String str) {
        this.name = new byte[20];
        this.week_repeat = (byte) (i & 255);
        this.hour = (byte) (i2 & 255);
        this.min = (byte) (i3 & 255);
        this.switchState = (byte) (i4 & 255);
        Lg.e("K6_SendAlarmInfoStruct hour " + i2 + " min " + i3);
    }

    protected K6_SendAlarmInfoStruct(Parcel parcel) {
        this.name = new byte[20];
        this.week_repeat = parcel.readByte();
        this.hour = parcel.readByte();
        this.min = parcel.readByte();
        this.switchState = parcel.readByte();
        this.name = parcel.createByteArray();
    }

    public static int getItemSize() {
        return 5;
    }

    public byte getSwitchState() {
        return this.switchState;
    }

    public void setSwitchState(byte b) {
        this.switchState = b;
    }

    public byte getWeek_repeat() {
        return this.week_repeat;
    }

    public void setWeek_repeat(byte b) {
        this.week_repeat = b;
    }

    public byte getHour() {
        return this.hour;
    }

    public void setHour(byte b) {
        this.hour = b;
    }

    public byte getMin() {
        return this.min;
    }

    public void setMin(byte b) {
        this.min = b;
    }

    public byte[] getName() {
        return this.name;
    }

    public void setName(byte[] bArr) {
        this.name = bArr;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = 0;
        bArr[1] = this.week_repeat;
        bArr[2] = this.hour;
        bArr[3] = this.min;
        bArr[4] = this.switchState;
        return bArr;
    }

    public String toString() {
        return "K6_SendAlarmInfoStruct{type=0, week_repeat=" + ((int) this.week_repeat) + ", hour=" + ((int) this.hour) + ", min=" + ((int) this.min) + ", switchState=" + ((int) this.switchState) + ", name=" + Arrays.toString(this.name) + '}';
    }
}
