package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendDevSettingStruct.class */
public class K6_SendDevSettingStruct extends BaseData implements Serializable {
    byte clock_disp_type;
    byte hand_rise;
    byte language;
    byte mainLcok;

    public static K6_SendDevSettingStruct initData(int i) {
        return new K6_SendDevSettingStruct((byte) 1, (byte) 1, (byte) i);
    }

    public K6_SendDevSettingStruct(byte b, byte b2, byte b3) {
        this.clock_disp_type = b;
        this.hand_rise = b2;
        this.language = b3;
        this.mainLcok = (byte) 0;
    }

    public K6_SendDevSettingStruct(byte[] bArr) {
        this.clock_disp_type = bArr[0];
        this.hand_rise = bArr[1];
        this.language = bArr[2];
        this.mainLcok = bArr[3];
    }

    public static int getItemSize() {
        return 8;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[8];
        bArr[0] = this.clock_disp_type;
        bArr[1] = this.hand_rise;
        bArr[2] = this.language;
        return bArr;
    }

    public int getClock_disp_type() {
        return this.clock_disp_type & 255;
    }

    public int getHand_rise() {
        return this.hand_rise & 255;
    }

    public void setClock_disp_type(int i) {
        this.clock_disp_type = (byte) i;
    }

    public void setHand_rise(int i) {
        this.hand_rise = (byte) i;
    }

    public byte getLanguage() {
        return this.language;
    }

    public void setLanguage(int i) {
        this.language = (byte) i;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData(1, 72);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "K6_SendDevSettingStruct{clock_disp_type=" + ((int) this.clock_disp_type) + ", hand_rise=" + ((int) this.hand_rise) + ", language=" + ((int) this.language) + '}';
    }
}
