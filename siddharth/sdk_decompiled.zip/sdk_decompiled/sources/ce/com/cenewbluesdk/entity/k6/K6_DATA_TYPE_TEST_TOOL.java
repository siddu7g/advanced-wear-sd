package ce.com.cenewbluesdk.entity.k6;

import android.text.TextUtils;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_TEST_TOOL.class */
public class K6_DATA_TYPE_TEST_TOOL extends BaseData implements Serializable {
    public static int APP_TEST_CMD_NONE = 0;
    public static int APP_TEST_FACTORY_RESTORE = 1;
    public static int APP_TEST_FACTORY_SHUTDOWN = 2;
    public static int APP_TEST_SET_LANGUAGE = 3;
    public static int APP_TEST_SET_DEV_NAME = 4;
    private int mainCMD;
    private int cmd_type;
    private int dat_len;
    private byte[] data;
    private String name;

    public K6_DATA_TYPE_TEST_TOOL(String str) {
        this.name = str;
        this.cmd_type = APP_TEST_SET_DEV_NAME;
    }

    public K6_DATA_TYPE_TEST_TOOL(int i, String str) {
        this.mainCMD = i;
        this.name = str;
    }

    private byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = (byte) this.cmd_type;
        byte[] contentData = getContentData();
        if (contentData != null) {
            bArr[1] = (byte) contentData.length;
            System.arraycopy(contentData, 0, bArr, 2, contentData.length);
        }
        return bArr;
    }

    private byte[] getContentData() {
        this.name.replaceAll(" ", "").replaceAll("\n", "");
        String strTruncateString = ByteUtil.truncateString(this.name, 22);
        this.name = strTruncateString;
        if (!TextUtils.isEmpty(strTruncateString)) {
            this.data = this.name.getBytes(StandardCharsets.UTF_8);
        }
        return this.data;
    }

    public int getMainCMD() {
        return this.mainCMD;
    }

    public void setMainCMD(int i) {
        this.mainCMD = i;
    }

    public int getCmd_type() {
        return this.cmd_type;
    }

    public void setCmd_type(int i) {
        this.cmd_type = i;
    }

    public int getDat_len() {
        return this.dat_len;
    }

    public void setDat_len(int i) {
        this.dat_len = i;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] bArr) {
        this.data = bArr;
    }

    public int getItemSize() {
        byte[] contentData = getContentData();
        if (contentData != null) {
            return contentData.length + 2;
        }
        return 2;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(142);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
