package ce.com.cenewbluesdk.entity.k6;

import android.os.Parcel;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_NoDisturb.class */
public class K6_NoDisturb extends BaseData implements Serializable {
    byte start_time_hour;
    byte start_time_min;
    byte end_time_hour;
    byte end_time_min;

    public K6_NoDisturb(int i, int i2, int i3, int i4) {
        this.start_time_hour = (byte) (i & 255);
        this.start_time_min = (byte) (i2 & 255);
        this.end_time_hour = (byte) (i3 & 255);
        this.end_time_min = (byte) (i4 & 255);
    }

    public K6_NoDisturb(byte[] bArr) {
        this.start_time_hour = bArr[0];
        this.start_time_min = bArr[1];
        this.end_time_hour = bArr[2];
        this.end_time_min = bArr[3];
    }

    protected K6_NoDisturb(Parcel parcel) {
        this.start_time_hour = parcel.readByte();
        this.start_time_min = parcel.readByte();
        this.end_time_hour = parcel.readByte();
        this.end_time_min = parcel.readByte();
    }

    public static int getItemSize() {
        return 4;
    }

    public byte[] getBytes() {
        return new byte[]{this.start_time_hour, this.start_time_min, this.end_time_hour, this.end_time_min};
    }

    public int getStart_time_hour() {
        return this.start_time_hour & 255;
    }

    public int getStart_time_min() {
        return this.start_time_min & 255;
    }

    public int getEnd_time_hour() {
        return this.end_time_hour & 255;
    }

    public int getEnd_time_min() {
        return this.end_time_min & 255;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(115);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(4);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
