package ce.com.cenewbluesdk.entity;

import ce.com.cenewbluesdk.uitl.d;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/MusicControl_Struct.class */
public class MusicControl_Struct implements Serializable {
    public static final int MUSIC_CMD_NULL = 0;
    public static final int MUSIC_CMD_PLAY = 1;
    public static final int MUSIC_CMD_PAUSE = 2;
    public static final int MUSIC_CMD_STOP = 3;
    public static final int MUSIC_CMD_BACKWARD = 4;
    public static final int MUSIC_CMD_FORWARD = 5;
    public static final int MUSIC_CMD_PLAY_PAUSE = 6;
    public static final int MUSIC_CMD_CONTENT = 7;
    public static final int MUSIC_CMD_VOLUME_UP = 8;
    public static final int MUSIC_CMD_VOLUME_DOWN = 9;
    public static final int MUSIC_CMD_VOLUME_VALUE = 10;
    private int commend;
    private int len;
    private byte[] datas = new byte[64];

    public MusicControl_Struct(byte[] bArr) {
        this.commend = new d(bArr).c(1);
    }

    public int getCommend() {
        return this.commend;
    }

    public void setCommend(int i) {
        this.commend = i;
    }

    public String toString() {
        return "MusicControl_Struct{}";
    }
}
