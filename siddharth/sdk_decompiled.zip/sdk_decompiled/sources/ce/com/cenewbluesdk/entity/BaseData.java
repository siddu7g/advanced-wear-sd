package ce.com.cenewbluesdk.entity;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/BaseData.class */
public abstract class BaseData {
    public abstract CEDevData toCEDevData();
}
