package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_BATTERY_INFO.class */
public class K6_DATA_TYPE_BATTERY_INFO extends BaseData implements Serializable {
    private int battery;
    private boolean chargerStatus;

    public K6_DATA_TYPE_BATTERY_INFO() {
    }

    public K6_DATA_TYPE_BATTERY_INFO(int i, boolean z) {
        this.battery = i;
        this.chargerStatus = z;
    }

    public int getBattery() {
        return this.battery;
    }

    public void setBattery(int i) {
        this.battery = i;
    }

    public boolean isChargerStatus() {
        return this.chargerStatus;
    }

    public void setChargerStatus(boolean z) {
        this.chargerStatus = z;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        return null;
    }
}
