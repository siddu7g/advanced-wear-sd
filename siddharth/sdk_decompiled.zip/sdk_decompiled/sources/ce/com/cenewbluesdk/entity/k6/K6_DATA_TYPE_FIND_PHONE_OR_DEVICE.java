package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_FIND_PHONE_OR_DEVICE.class */
public class K6_DATA_TYPE_FIND_PHONE_OR_DEVICE extends BaseData implements Serializable {
    byte onoff;

    public K6_DATA_TYPE_FIND_PHONE_OR_DEVICE() {
    }

    public K6_DATA_TYPE_FIND_PHONE_OR_DEVICE(int i) {
        this.onoff = (byte) (i & 255);
    }

    public K6_DATA_TYPE_FIND_PHONE_OR_DEVICE(byte[] bArr) {
        this.onoff = bArr[0];
    }

    public static int getItemSize() {
        return 1;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = this.onoff;
        return bArr;
    }

    public int getOnoff() {
        return this.onoff & 255;
    }

    public void setOnoff(byte b) {
        this.onoff = b;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(11);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
