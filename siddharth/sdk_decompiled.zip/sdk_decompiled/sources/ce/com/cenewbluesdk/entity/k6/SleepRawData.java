package ce.com.cenewbluesdk.entity.k6;

import java.io.Serializable;
import java.util.Calendar;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/SleepRawData.class */
public class SleepRawData implements Serializable {
    long timeMili;
    String userId;
    String startSecsStr;
    int stepsTotalNum;
    int walkTimes;
    int walkOnceMaxSteps;
    int slopeTotalNum;
    int slopeOnceMaxNum;
    int noMotionTotalNum;
    int xAxisSameTotalNum;
    int xAxisSameOnceMaxNum;
    int xAxisSameAvgData;
    int devStatus;
    int reserveChars;
    Calendar calendar;

    public SleepRawData() {
    }

    public SleepRawData(String str, long j, String str2, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11) {
        this.userId = str;
        this.timeMili = j;
        this.startSecsStr = str2;
        this.stepsTotalNum = i;
        this.walkTimes = i2;
        this.walkOnceMaxSteps = i3;
        this.slopeTotalNum = i4;
        this.slopeOnceMaxNum = i5;
        this.noMotionTotalNum = i6;
        this.xAxisSameTotalNum = i7;
        this.xAxisSameOnceMaxNum = i8;
        this.xAxisSameAvgData = i9;
        this.devStatus = i10;
        this.reserveChars = i11;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.util.Calendar, long] */
    public static SleepRawData parseSleepInfo(String str, byte[] bArr) {
        byte[] bArr2 = new byte[4];
        System.arraycopy(bArr, 0, bArr2, 0, 4);
        ?? Byte2C = byte2C(bArr2);
        long jByteToInt2 = byteToInt2(bArr2);
        Byte2C.setTimeInMillis(Byte2C * 1000);
        String formatDate = DateTimeUtil.getFormatDate(Byte2C.getTime(), "yyyy-MM-dd HH:mm:ss");
        byte b = (byte) (Byte2C.get(1) - 2000);
        byte b2 = (byte) (Byte2C.get(2) + 1);
        if (b < 14) {
            return null;
        }
        if (b == 14 && b2 == 1) {
            return null;
        }
        byte[] bArr3 = new byte[1];
        System.arraycopy(bArr, 4, bArr3, 0, 1);
        int i = bArr3[0] & 255;
        byte[] bArr4 = new byte[1];
        System.arraycopy(bArr, 5, bArr4, 0, 1);
        int i2 = bArr4[0] & 255;
        byte[] bArr5 = new byte[1];
        System.arraycopy(bArr, 6, bArr5, 0, 1);
        int i3 = bArr5[0] & 255;
        byte[] bArr6 = new byte[1];
        System.arraycopy(bArr, 7, bArr6, 0, 1);
        int i4 = bArr6[0] & 255;
        byte[] bArr7 = new byte[1];
        System.arraycopy(bArr, 8, bArr7, 0, 1);
        int i5 = bArr7[0] & 255;
        byte[] bArr8 = new byte[1];
        System.arraycopy(bArr, 9, bArr8, 0, 1);
        int i6 = bArr8[0] & 255;
        byte[] bArr9 = new byte[1];
        System.arraycopy(bArr, 10, bArr9, 0, 1);
        int i7 = bArr9[0] & 255;
        byte[] bArr10 = new byte[1];
        System.arraycopy(bArr, 11, bArr10, 0, 1);
        int i8 = bArr10[0] & 255;
        byte[] bArr11 = new byte[2];
        System.arraycopy(bArr, 12, bArr11, 0, 2);
        short sByteToShort3 = byteToShort3(bArr11);
        byte[] bArr12 = new byte[1];
        System.arraycopy(bArr, 14, bArr12, 0, 1);
        int i9 = bArr12[0] & 255;
        byte[] bArr13 = new byte[1];
        System.arraycopy(bArr, 15, bArr13, 0, 1);
        return new SleepRawData(str, jByteToInt2, formatDate, i, i2, i3, i4, i5, i6, i7, i8, sByteToShort3, i9, bArr13[0] & 255);
    }

    public static Calendar byte2C(byte[] bArr) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis((byteToInt2(bArr) * 1000) - calendar.getTimeZone().getOffset(System.currentTimeMillis()));
        return calendar;
    }

    public static int byteToInt2(byte[] bArr) {
        int i = bArr[0] & 255;
        int i2 = (bArr[1] & 255) << 8;
        return i + i2 + ((bArr[2] & 255) << 16) + ((bArr[3] & 255) << 24);
    }

    public static short byteToShort3(byte[] bArr) {
        return (short) (((short) (bArr[0] & 255)) + ((short) ((bArr[1] & 255) << 8)));
    }

    public static int getItemSize() {
        return 16;
    }

    public Calendar getCalendar() {
        Calendar calendar = this.calendar;
        if (calendar != null) {
            return calendar;
        }
        long startSecs = getStartSecs();
        Calendar calendar2 = Calendar.getInstance();
        this.calendar = calendar2;
        calendar2.setTimeInMillis(startSecs);
        return this.calendar;
    }

    public long getStartSecs() {
        return DateTimeUtil.getFormatDateTime(this.startSecsStr).getTime();
    }

    public int getRawYear() {
        return getCalendar().get(1);
    }

    public int getRawMonth() {
        return getCalendar().get(2) + 1;
    }

    public int getRawDay() {
        return getCalendar().get(5);
    }

    public int getRawHour() {
        return getCalendar().get(11);
    }

    public int getRawMin() {
        return getCalendar().get(12);
    }

    public int getRawSec() {
        return getCalendar().get(13);
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String str) {
        this.userId = str;
    }

    public String getStartSecsStr() {
        return this.startSecsStr;
    }

    public void setStartSecsStr(String str) {
        this.startSecsStr = str;
    }

    public int getStepsTotalNum() {
        return this.stepsTotalNum;
    }

    public void setStepsTotalNum(int i) {
        this.stepsTotalNum = i;
    }

    public int getWalkTimes() {
        return this.walkTimes;
    }

    public void setWalkTimes(int i) {
        this.walkTimes = i;
    }

    public int getWalkOnceMaxSteps() {
        return this.walkOnceMaxSteps;
    }

    public void setWalkOnceMaxSteps(int i) {
        this.walkOnceMaxSteps = i;
    }

    public int getSlopeTotalNum() {
        return this.slopeTotalNum;
    }

    public void setSlopeTotalNum(int i) {
        this.slopeTotalNum = i;
    }

    public int getSlopeOnceMaxNum() {
        return this.slopeOnceMaxNum;
    }

    public void setSlopeOnceMaxNum(int i) {
        this.slopeOnceMaxNum = i;
    }

    public int getNoMotionTotalNum() {
        return this.noMotionTotalNum;
    }

    public void setNoMotionTotalNum(int i) {
        this.noMotionTotalNum = i;
    }

    public int getxAxisSameTotalNum() {
        return this.xAxisSameTotalNum;
    }

    public void setxAxisSameTotalNum(int i) {
        this.xAxisSameTotalNum = i;
    }

    public int getxAxisSameOnceMaxNum() {
        return this.xAxisSameOnceMaxNum;
    }

    public void setxAxisSameOnceMaxNum(int i) {
        this.xAxisSameOnceMaxNum = i;
    }

    public int getxAxisSameAvgData() {
        return this.xAxisSameAvgData;
    }

    public void setxAxisSameAvgData(int i) {
        this.xAxisSameAvgData = i;
    }

    public int getDevStatus() {
        return this.devStatus;
    }

    public void setDevStatus(int i) {
        this.devStatus = i;
    }

    public int getReserveChars() {
        return this.reserveChars;
    }

    public void setReserveChars(int i) {
        this.reserveChars = i;
    }

    @Deprecated
    public long getTimeMili() {
        return this.timeMili;
    }

    @Deprecated
    public void setTimeMili(long j) {
        this.timeMili = j;
    }

    public String toString() {
        return this.timeMili + "," + this.startSecsStr + "," + this.stepsTotalNum + "," + this.walkTimes + "," + this.walkOnceMaxSteps + "," + this.slopeTotalNum + "," + this.slopeOnceMaxNum + "," + this.noMotionTotalNum + "," + this.xAxisSameTotalNum + "," + this.xAxisSameOnceMaxNum + "," + this.xAxisSameAvgData + "," + this.devStatus + "," + this.reserveChars;
    }

    public String toString111() {
        return "SleepRawData{timeMili=" + this.timeMili + ", userId='" + this.userId + "', startSecsStr='" + this.startSecsStr + "', stepsTotalNum=" + this.stepsTotalNum + ", walkTimes=" + this.walkTimes + ", walkOnceMaxSteps=" + this.walkOnceMaxSteps + ", slopeTotalNum=" + this.slopeTotalNum + ", slopeOnceMaxNum=" + this.slopeOnceMaxNum + ", noMotionTotalNum=" + this.noMotionTotalNum + ", xAxisSameTotalNum=" + this.xAxisSameTotalNum + ", xAxisSameOnceMaxNum=" + this.xAxisSameOnceMaxNum + ", xAxisSameAvgData=" + this.xAxisSameAvgData + ", devStatus=" + this.devStatus + ", reserveChars=" + this.reserveChars + ", calendar=" + this.calendar + '}';
    }
}
