package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_MixInfoStruct.class */
public class K6_MixInfoStruct extends BaseData implements Serializable {
    int len;
    byte items;
    List<Property> list = new ArrayList();

    /* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_MixInfoStruct$Property.class */
    public static class Property {
        byte date_type;
        byte[] data;

        public Property(byte b, byte[] bArr) {
            this.date_type = b;
            this.data = bArr;
        }

        public byte getDate_type() {
            return this.date_type;
        }

        public byte[] getData() {
            return this.data;
        }

        public byte[] getBytes() {
            int length = this.data.length + 3;
            byte[] bArr = new byte[length];
            System.arraycopy(ByteUtil.int2bytes2(length), 0, bArr, 0, 2);
            bArr[2] = this.date_type;
            byte[] bArr2 = this.data;
            System.arraycopy(bArr2, 0, bArr, 3, bArr2.length);
            return bArr;
        }

        public String toString() {
            return "Property{date_type=" + ((int) this.date_type) + ", data=" + Arrays.toString(this.data) + '}';
        }
    }

    public K6_MixInfoStruct(List<Property> list) {
        this.items = (byte) list.size();
        this.list.addAll(list);
    }

    public static K6_MixInfoStruct parse(byte[] bArr) {
        int i = bArr[2] & 255;
        Lg.e(" 收到的混合数据的item数量：" + i);
        int i2 = 3;
        ArrayList arrayList = new ArrayList();
        for (int i3 = 0; i3 < i; i3++) {
            int iByte2ToInt = ByteUtil.byte2ToInt(new byte[]{bArr[i2], bArr[i2 + 1]});
            int i4 = i2 + 2;
            byte b = bArr[i4];
            Lg.e(" 收到的混合数据item 类型：" + ((int) b));
            int i5 = i4 + 1;
            int i6 = iByte2ToInt - 3;
            byte[] bArr2 = new byte[i6];
            System.arraycopy(bArr, i5, bArr2, 0, i6);
            i2 = i5 + i6;
            arrayList.add(new Property(b, bArr2));
        }
        return new K6_MixInfoStruct(arrayList);
    }

    public List<Property> getList() {
        return this.list;
    }

    public byte[] getBytes() {
        int length = 0;
        Iterator<Property> it = this.list.iterator();
        while (it.hasNext()) {
            length += it.next().getBytes().length;
        }
        int i = length + 3;
        byte[] bArr = new byte[i];
        System.arraycopy(ByteUtil.int2bytes2(i - 2), 0, bArr, 0, 2);
        bArr[2] = (byte) this.list.size();
        int length2 = 3;
        for (Property property : this.list) {
            System.arraycopy(property.getBytes(), 0, bArr, length2, property.getBytes().length);
            length2 += property.getBytes().length;
        }
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        byte[] bytes = getBytes();
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(110);
        cEDevData.setData(bytes);
        cEDevData.setItemL(bytes.length);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "Mix_Info_Struct_K2{len=" + this.len + ", items=" + ((int) this.items) + ", list=" + this.list + '}';
    }
}
