package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_DRINK_ALARM.class */
public class K6_DATA_TYPE_DRINK_ALARM extends BaseData implements Serializable {
    public static final String[] INTERVAL_ARR = {"30", "60", "120", "180"};
    byte onoff;
    byte start_hour;
    byte start_min;
    byte end_hour;
    byte end_min;
    byte interval;

    public static String getShowInterVal(int i) {
        return (i >= 0 && i <= 3) ? INTERVAL_ARR[i] : "";
    }

    public static final int getIntervalByShowStr(String str) {
        for (int i = 0; i < 4; i++) {
            if (INTERVAL_ARR[i].equals(str)) {
                return i;
            }
        }
        return 0;
    }

    public K6_DATA_TYPE_DRINK_ALARM() {
    }

    public K6_DATA_TYPE_DRINK_ALARM(int i, int i2, int i3, int i4, int i5, int i6) {
        this.onoff = (byte) (i & 255);
        this.start_hour = (byte) (i2 & 255);
        this.start_min = (byte) (i3 & 255);
        this.end_hour = (byte) (i4 & 255);
        this.end_min = (byte) (i5 & 255);
        this.interval = (byte) (i6 & 255);
    }

    public K6_DATA_TYPE_DRINK_ALARM(byte[] bArr) {
        this.onoff = bArr[0];
        this.start_hour = bArr[1];
        this.start_min = bArr[2];
        this.end_hour = bArr[3];
        this.end_min = bArr[4];
        this.interval = bArr[5];
    }

    public static int getItemSize() {
        return 6;
    }

    public int getOnoff() {
        return this.onoff & 255;
    }

    public void setOnoff(int i) {
        this.onoff = (byte) (i & 255);
    }

    public int getStart_hour() {
        return this.start_hour;
    }

    public void setStart_hour(int i) {
        this.start_hour = (byte) (i & 255);
    }

    public int getStart_min() {
        return this.start_min & 255;
    }

    public void setStart_min(int i) {
        this.start_min = (byte) (i & 255);
    }

    public int getEnd_hour() {
        return this.end_hour & 255;
    }

    public void setEnd_hour(int i) {
        this.end_hour = (byte) (i & 255);
    }

    public int getEnd_min() {
        return this.end_min;
    }

    public void setEnd_min(int i) {
        this.end_min = (byte) (i & 255);
    }

    public int getInterval() {
        return this.interval & 255;
    }

    public void setInterval(int i) {
        this.interval = (byte) (i & 255);
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = this.onoff;
        bArr[1] = this.start_hour;
        bArr[2] = this.start_min;
        bArr[3] = this.end_hour;
        bArr[4] = this.end_min;
        bArr[5] = this.interval;
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(126);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
