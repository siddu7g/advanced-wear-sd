package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_QR_CODE_INFO.class */
public class K6_DATA_TYPE_QR_CODE_INFO extends BaseData implements Serializable {
    private int qrIndex;
    private int qrType;
    private String qrName;
    private int qrLen;
    private String qrContent;

    public K6_DATA_TYPE_QR_CODE_INFO() {
    }

    public K6_DATA_TYPE_QR_CODE_INFO(int i, int i2, String str, int i3, String str2) {
        this.qrIndex = i;
        this.qrType = i2;
        this.qrName = str;
        this.qrLen = i3;
        this.qrContent = str2;
    }

    public int getItemSize() {
        return this.qrContent.getBytes().length + 24;
    }

    public byte[] getSendByte() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = (byte) (this.qrIndex & 255);
        bArr[1] = (byte) (this.qrType & 255);
        System.arraycopy(this.qrName.getBytes(), 0, bArr, 2, this.qrName.getBytes().length);
        System.arraycopy(ByteUtil.int2bytes2(this.qrContent.getBytes().length), 0, bArr, 22, 2);
        System.arraycopy(this.qrContent.getBytes(), 0, bArr, 24, this.qrContent.getBytes().length);
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(26);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public int getQrIndex() {
        return this.qrIndex;
    }

    public void setQrIndex(int i) {
        this.qrIndex = i;
    }

    public int getQrType() {
        return this.qrType;
    }

    public void setQrType(int i) {
        this.qrType = i;
    }

    public String getQrName() {
        return this.qrName;
    }

    public void setQrName(String str) {
        this.qrName = str;
    }

    public int getQrLen() {
        return this.qrLen;
    }

    public void setQrLen(int i) {
        this.qrLen = i;
    }

    public String getQrContent() {
        return this.qrContent;
    }

    public void setQrContent(String str) {
        this.qrContent = str;
    }
}
