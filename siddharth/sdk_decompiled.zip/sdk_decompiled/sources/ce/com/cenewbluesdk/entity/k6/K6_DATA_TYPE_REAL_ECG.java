package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_REAL_ECG.class */
public class K6_DATA_TYPE_REAL_ECG extends BaseData implements Serializable {
    public static final int ECG_SWITCH_OPEN = 1;
    public static final int ECG_SWITCH_CLOSE = 0;
    private int time;
    private int heart;
    private int sbp;
    private int dbp;
    private int O2;

    public K6_DATA_TYPE_REAL_ECG(byte[] bArr) {
        this.time = ByteUtil.byte4ToInt(new byte[]{bArr[0], bArr[1], bArr[2], bArr[3]});
        this.heart = bArr[4];
        this.sbp = bArr[5] & 255;
        this.dbp = bArr[6] & 255;
        this.O2 = bArr[7] & 255;
    }

    public K6_DATA_TYPE_REAL_ECG(int i) {
        this.time = i;
    }

    public static int getItemSize() {
        return 12;
    }

    public static int getEcgSwitchOpen() {
        return 1;
    }

    public static int getEcgSwitchClose() {
        return 0;
    }

    public byte[] getSendByte() {
        return new byte[]{(byte) this.time, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    }

    public int getTime() {
        return this.time;
    }

    public void setTime(int i) {
        this.time = i;
    }

    public int getHeart() {
        return this.heart;
    }

    public void setHeart(int i) {
        this.heart = i;
    }

    public int getSbp() {
        return this.sbp;
    }

    public void setSbp(int i) {
        this.sbp = i;
    }

    public int getDbp() {
        return this.dbp;
    }

    public void setDbp(int i) {
        this.dbp = i;
    }

    public int getO2() {
        return this.O2;
    }

    public void setO2(int i) {
        this.O2 = i;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(19);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "K6_DATA_TYPE_REAL_ECG{time=" + this.time + ", heart=" + this.heart + ", sbp=" + this.sbp + ", dbp=" + this.dbp + ", O2=" + this.O2 + '}';
    }
}
