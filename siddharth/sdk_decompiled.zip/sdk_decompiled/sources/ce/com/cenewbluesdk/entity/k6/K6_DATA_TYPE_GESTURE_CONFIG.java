package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_GESTURE_CONFIG.class */
public class K6_DATA_TYPE_GESTURE_CONFIG extends BaseData implements Serializable {
    public static final int GESTURE_CTRL_TYPE_NONE = 0;
    public static final int GESTURE_CTRL_TYPE_TIKTOK = 1;
    public static final int GESTURE_CTRL_TYPE_MUSIC = 2;
    public static final int GESTURE_CTRL_TYPE_READER = 3;
    public static final int GESTURE_CTRL_TYPE_PHOTO = 4;
    public static final int GESTURE_CTRL_TYPE_TELEPHONE = 5;
    private byte controlType;

    public K6_DATA_TYPE_GESTURE_CONFIG(int i) {
        this.controlType = (byte) (i & 255);
    }

    public K6_DATA_TYPE_GESTURE_CONFIG(byte[] bArr) {
        this.controlType = bArr[0];
    }

    public static int getItemSize() {
        return 8;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = this.controlType;
        return bArr;
    }

    public int getControlType() {
        return this.controlType & 255;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(128);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
