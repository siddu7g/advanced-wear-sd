package ce.com.cenewbluesdk.entity.k6;

import java.io.Serializable;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6SleepTotal.class */
public class K6SleepTotal implements Serializable {
    public int totalItems;
    public ArrayList<K6SleepItems> mK6SleepItems;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6SleepTotal$K6SleepItems.class */
    public static class K6SleepItems {
        public ArrayList<K6_Sleep> datas;

        public String toString() {
            return "K6SleepItems{, datas=" + this.datas + '}';
        }
    }

    public String toString() {
        return "K6SleepTotal{, totalItems=" + this.totalItems + ", mK6SleepItems=" + this.mK6SleepItems + '}';
    }
}
