package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SittingRemind.class */
public class K6_SittingRemind extends BaseData implements Serializable {
    byte switch_flag;
    byte noon_onoff;
    byte repeat;
    byte start_time_hour;
    byte start_time_min;
    byte end_time_hour;
    byte end_time_min;

    public K6_SittingRemind() {
    }

    public K6_SittingRemind(int i, int i2, int i3, int i4, int i5, int i6, int i7) {
        this.switch_flag = (byte) (i & 255);
        this.noon_onoff = (byte) (i2 & 255);
        this.repeat = (byte) (i3 & 255);
        this.start_time_hour = (byte) (i4 & 255);
        this.start_time_min = (byte) (i5 & 255);
        this.end_time_hour = (byte) (i6 & 255);
        this.end_time_min = (byte) (i7 & 255);
    }

    public K6_SittingRemind(byte[] bArr) {
        this.switch_flag = bArr[0];
        this.noon_onoff = bArr[1];
        this.repeat = bArr[2];
        this.start_time_hour = bArr[3];
        this.start_time_min = bArr[4];
        this.end_time_hour = bArr[5];
        this.end_time_min = bArr[6];
    }

    public static int getItemSize() {
        return 7;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = this.switch_flag;
        bArr[1] = this.noon_onoff;
        bArr[2] = this.repeat;
        bArr[3] = this.start_time_hour;
        bArr[4] = this.start_time_min;
        bArr[5] = this.end_time_hour;
        bArr[6] = this.end_time_min;
        return bArr;
    }

    public int getNoon_onoff() {
        return this.noon_onoff & 255;
    }

    public void setNoon_onoff(int i) {
        this.noon_onoff = (byte) (i & 255);
    }

    public byte getRepeat() {
        return this.repeat;
    }

    public void setRepeat(int i) {
        this.repeat = (byte) i;
    }

    public int getSwitch_flag() {
        return this.switch_flag & 255;
    }

    public void setSwitch_flag(int i) {
        this.switch_flag = (byte) (i & 255);
    }

    public int getStart_time_hour() {
        return this.start_time_hour & 255;
    }

    public void setStart_time_hour(int i) {
        this.start_time_hour = (byte) (i & 255);
    }

    public int getStart_time_min() {
        return this.start_time_min & 255;
    }

    public void setStart_time_min(int i) {
        this.start_time_min = (byte) (i & 255);
    }

    public int getEnd_time_hour() {
        return this.end_time_hour & 255;
    }

    public void setEnd_time_hour(int i) {
        this.end_time_hour = (byte) (i & 255);
    }

    public int getEnd_time_min() {
        return this.end_time_min & 255;
    }

    public void setEnd_time_min(int i) {
        this.end_time_min = (byte) (i & 255);
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(114);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
