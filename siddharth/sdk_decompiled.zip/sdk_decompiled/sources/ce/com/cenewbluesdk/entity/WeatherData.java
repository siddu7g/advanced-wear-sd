package ce.com.cenewbluesdk.entity;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/WeatherData.class */
public class WeatherData implements Serializable {
    private int weatherType;
    private int lowTemperature;
    private int highTemperature;

    public WeatherData(int i, int i2, int i3) {
        this.weatherType = i;
        this.lowTemperature = i2;
        this.highTemperature = i3;
    }

    public int getWeatherType() {
        return this.weatherType;
    }

    public void setWeatherType(int i) {
        this.weatherType = i;
    }

    public int getLowTemperature() {
        return this.lowTemperature;
    }

    public void setLowTemperature(int i) {
        this.lowTemperature = i;
    }

    public int getHighTemperature() {
        return this.highTemperature;
    }

    public void setHighTemperature(int i) {
        this.highTemperature = i;
    }
}
