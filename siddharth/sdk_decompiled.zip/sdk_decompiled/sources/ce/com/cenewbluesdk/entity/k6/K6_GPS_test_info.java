package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_GPS_test_info.class */
public class K6_GPS_test_info {
    public static String parse(byte[] bArr) {
        int i = 0;
        StringBuilder sb = new StringBuilder();
        sb.append("###################\n");
        String[] strArr = {"G", "R", "B"};
        int[][] iArr = new int[3][12];
        for (int i2 = 0; i2 < 3; i2++) {
            int i3 = i;
            int i4 = i3 + 1;
            int i5 = bArr[i3] & 255;
            iArr[i2][0] = i5;
            for (int i6 = 1; i6 <= i5; i6++) {
                iArr[i2][i6] = bArr[(i4 + i6) - 1] & 255;
            }
            i = i4 + 12;
        }
        int i7 = 0;
        for (int i8 = 0; i8 < 3; i8++) {
            int i9 = i;
            int i10 = i9 + 1;
            byte b = bArr[i9];
            int i11 = i10 + 1;
            int i12 = bArr[i10] & 255;
            int i13 = iArr[i8][0];
            for (int i14 = 0; i14 < i12; i14++) {
                int i15 = i11 + i14;
                int i16 = bArr[i15] & 255;
                sb.append(String.format("%s%02d: %02d", strArr[i8], Integer.valueOf(i16), Integer.valueOf(bArr[i15 + 12] & 255)));
                boolean z = false;
                int i17 = 1;
                while (true) {
                    if (i17 > i13) {
                        break;
                    }
                    if (i16 == iArr[i8][i17]) {
                        if (i7 == 0) {
                            sb.append(" ---- ok         |         ");
                            i7++;
                        } else {
                            sb.append(" ---- ok \n");
                            i7 = 0;
                        }
                        z = true;
                    } else {
                        i17++;
                    }
                }
                if (!z) {
                    if (i7 == 0) {
                        sb.append(" ----               |         ");
                        i7++;
                    } else {
                        sb.append(" ----    \n");
                        i7 = 0;
                    }
                }
            }
            i = i11 + 24;
        }
        int i18 = i;
        int i19 = i18 + 1;
        int i20 = bArr[i18] & 255;
        int i21 = i19 + 1;
        int i22 = i21 + 1;
        int i23 = i22 + 1;
        int i24 = i23 + 1;
        int iByte4ToInt = ByteUtil.byte4ToInt(new byte[]{bArr[i19], bArr[i21], bArr[i22], bArr[i23]});
        int i25 = i24 + 1;
        int i26 = i25 + 1;
        int iByte4ToInt2 = ByteUtil.byte4ToInt(new byte[]{bArr[i24], bArr[i25], bArr[i26], bArr[i26 + 1]});
        return (i20 == 0 ? "非法数据 纬度: " + (iByte4ToInt / 100000.0f) + " 经度: " + (iByte4ToInt2 / 100000.0f) : "合法数据 纬度: " + (iByte4ToInt / 100000.0f) + " 经度: " + (iByte4ToInt2 / 100000.0f)) + "\n" + sb.toString();
    }
}
