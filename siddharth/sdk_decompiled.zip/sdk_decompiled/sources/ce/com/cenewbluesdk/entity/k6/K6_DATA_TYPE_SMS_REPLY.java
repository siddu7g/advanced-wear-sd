package ce.com.cenewbluesdk.entity.k6;

import com.example.cenewbluesdk.R;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_SMS_REPLY.class */
public class K6_DATA_TYPE_SMS_REPLY implements Serializable {
    private int smsPosition;
    private int smsContent;

    public K6_DATA_TYPE_SMS_REPLY(int i) {
        setSmsPosition(i);
        switch (i) {
            case 1:
                this.smsContent = R.string.call_you_later;
                break;
            case 2:
                this.smsContent = R.string.will_arrive_soon;
                break;
            case 3:
                this.smsContent = R.string.answer_the_phone;
                break;
            case 4:
                this.smsContent = R.string.call_me_later;
                break;
            case 5:
                this.smsContent = R.string.will_contact_you_later;
                break;
        }
    }

    public int getSmsContent() {
        return this.smsContent;
    }

    public void setSmsContent(int i) {
        this.smsContent = i;
    }

    public int getSmsPosition() {
        return this.smsPosition;
    }

    public void setSmsPosition(int i) {
        this.smsPosition = i;
    }
}
