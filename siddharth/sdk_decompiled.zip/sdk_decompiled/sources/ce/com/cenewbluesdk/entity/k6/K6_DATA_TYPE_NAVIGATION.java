package ce.com.cenewbluesdk.entity.k6;

import android.text.TextUtils;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_NAVIGATION.class */
public class K6_DATA_TYPE_NAVIGATION extends BaseData implements Serializable {
    public static int DT_MAP_CMD_NONE = 0;
    public static int DT_MAP_CMD_START = 1;
    public static int DT_MAP_CMD_START_IND = 2;
    public static int DT_MAP_CMD_STOP = 3;
    public static int DT_MAP_CMD_STOP_IND = 4;
    public static int DT_MAP_CMD_NAVIGATION = 5;
    public static int DT_MAP_NAV_START_POINT = 5;
    public static int DT_MAP_NAV_END_POINT = 6;
    public static int DT_MAP_NAV_STRAIGHT_TRAVEL = 7;
    public static int DT_MAP_NAV_TURN_LEFT = 8;
    public static int DT_MAP_NAV_FRONT_LEFT = 9;
    public static int DT_MAP_NAV_LEFT_REAR = 10;
    public static int DT_MAP_NAV_TURN_RIGHT = 11;
    public static int DT_MAP_NAV_FRONT_RIGHT = 12;
    public static int DT_MAP_NAV_RIGHT_REAR = 13;
    public static int DT_MAP_NAV_TRUN_AROUND = 14;
    private int mainCMD;
    private int cmd_type;
    private int dat_len;
    private byte[] data;
    private int navigation;
    private String content;

    private byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        int i = this.cmd_type;
        bArr[0] = (byte) i;
        if (i == DT_MAP_CMD_START_IND || i == DT_MAP_CMD_STOP_IND) {
            bArr[1] = 0;
        } else if (i == DT_MAP_CMD_NAVIGATION) {
            bArr[0] = (byte) this.navigation;
            byte[] contentData = getContentData();
            if (contentData != null) {
                bArr[1] = (byte) contentData.length;
                System.arraycopy(contentData, 0, bArr, 2, contentData.length);
            }
        }
        return bArr;
    }

    private byte[] getContentData() {
        if (TextUtils.isEmpty(this.content)) {
            this.content = "";
        }
        this.content.replaceAll(" ", "").replaceAll("\n", "");
        String strTruncateString = ByteUtil.truncateString(this.content, 249);
        this.content = strTruncateString;
        if (!TextUtils.isEmpty(strTruncateString)) {
            this.data = this.content.getBytes(StandardCharsets.UTF_8);
        }
        return this.data;
    }

    public int getMainCMD() {
        return this.mainCMD;
    }

    public void setMainCMD(int i) {
        this.mainCMD = i;
    }

    public int getCmd_type() {
        return this.cmd_type;
    }

    public void setCmd_type(int i) {
        this.cmd_type = i;
    }

    public int getDat_len() {
        return this.dat_len;
    }

    public void setDat_len(int i) {
        this.dat_len = i;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] bArr) {
        this.data = bArr;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public int getNavigation() {
        return this.navigation;
    }

    public void setNavigation(int i) {
        this.navigation = i;
    }

    public int getItemSize() {
        byte[] contentData;
        int i = this.cmd_type;
        if (i == DT_MAP_CMD_START_IND || i == DT_MAP_CMD_STOP_IND || i != DT_MAP_CMD_NAVIGATION || (contentData = getContentData()) == null) {
            return 2;
        }
        return contentData.length + 2;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(this.mainCMD);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
