package ce.com.cenewbluesdk.entity;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/MusicDatas.class */
public class MusicDatas implements Serializable {
    private String musicPackage;
    private int musicIcon;

    public MusicDatas(String str, int i) {
        this.musicPackage = str;
        this.musicIcon = i;
    }

    public String getMusicPackage() {
        return this.musicPackage;
    }

    public void setMusicPackage(String str) {
        this.musicPackage = str;
    }

    public int getMusicIcon() {
        return this.musicIcon;
    }

    public void setMusicIcon(int i) {
        this.musicIcon = i;
    }
}
