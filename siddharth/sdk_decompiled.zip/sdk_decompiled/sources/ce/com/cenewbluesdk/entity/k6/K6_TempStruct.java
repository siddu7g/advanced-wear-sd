package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.TimeUtil;
import ce.com.cenewbluesdk.uitl.d;
import java.io.Serializable;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_TempStruct.class */
public class K6_TempStruct implements Serializable {
    long time;
    float tempValue;

    public K6_TempStruct(byte[] bArr) {
        this.time = TimeUtil.s2CForDev(new d(bArr).c(4), true).getTimeInMillis();
        this.tempValue = r1.c(2) / 10.0f;
    }

    public K6_TempStruct(byte[] bArr, int i) {
        this.time = TimeUtil.s2CForDev(new d(bArr).c(4), true).getTimeInMillis();
        this.tempValue = r1.c(2) / 10.0f;
    }

    public static ArrayList<K6_TempStruct> parse(byte[] bArr) {
        ArrayList<K6_TempStruct> arrayList = new ArrayList<>();
        d dVar = new d(bArr);
        for (int i = 0; i < bArr.length / 5; i++) {
            arrayList.add(new K6_TempStruct(dVar.b(5)));
        }
        return arrayList;
    }

    public static ArrayList<K6_TempStruct> parseFloat(byte[] bArr) {
        ArrayList<K6_TempStruct> arrayList = new ArrayList<>();
        d dVar = new d(bArr);
        for (int i = 0; i < bArr.length / 8; i++) {
            arrayList.add(new K6_TempStruct(dVar.b(8), 0));
        }
        return arrayList;
    }

    public long getTime() {
        return this.time;
    }

    public void setTime(long j) {
        this.time = j;
    }

    public float getTempValue() {
        return this.tempValue;
    }

    public String toString() {
        return "K6_TempStruct{time=" + this.time + ", tempValue=" + this.tempValue + ", timeStr=" + TimeUtil.long2String(this.time) + '}';
    }
}
