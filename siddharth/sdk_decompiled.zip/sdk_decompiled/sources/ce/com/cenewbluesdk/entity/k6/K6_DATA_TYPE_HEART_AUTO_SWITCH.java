package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_HEART_AUTO_SWITCH.class */
public class K6_DATA_TYPE_HEART_AUTO_SWITCH extends BaseData implements Serializable {
    byte autoHROnoff;
    byte hr24hOnoff;
    byte timeInterval;
    byte autoO2noff;

    public K6_DATA_TYPE_HEART_AUTO_SWITCH(int i) {
    }

    public K6_DATA_TYPE_HEART_AUTO_SWITCH(int i, int i2) {
        this.autoHROnoff = (byte) (i & 255);
        this.hr24hOnoff = (byte) (i2 & 255);
    }

    public K6_DATA_TYPE_HEART_AUTO_SWITCH(int i, int i2, int i3) {
        this.autoHROnoff = (byte) (i & 255);
        this.autoO2noff = (byte) (i2 & 255);
        this.timeInterval = (byte) (i3 & 255);
    }

    public K6_DATA_TYPE_HEART_AUTO_SWITCH(byte[] bArr) {
        if (bArr.length >= 2) {
            this.autoHROnoff = bArr[0];
            this.hr24hOnoff = bArr[1];
            this.timeInterval = bArr[2];
            this.autoO2noff = bArr[3];
        }
    }

    public static int getItemSize() {
        return 8;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        bArr[0] = this.autoHROnoff;
        bArr[1] = this.hr24hOnoff;
        bArr[2] = this.timeInterval;
        bArr[3] = this.autoO2noff;
        return bArr;
    }

    public int getAutoHROnoff() {
        return this.autoHROnoff & 255;
    }

    public void setAutoHROnoff(int i) {
        this.autoHROnoff = (byte) (i & 255);
    }

    public int getHr24hOnoff() {
        return this.hr24hOnoff & 255;
    }

    public void setHr24hOnoff(int i) {
        this.hr24hOnoff = (byte) (i & 255);
    }

    public byte getTimeInterval() {
        return this.timeInterval;
    }

    public void setTimeInterval(int i) {
        this.timeInterval = (byte) (i & 255);
    }

    public int getAutoO2noff() {
        return this.autoO2noff & 255;
    }

    public void setAutoO2noff(int i) {
        this.autoO2noff = (byte) (i & 255);
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(128);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "K6_DATA_TYPE_HEART_AUTO_SWITCH{autoHROnoff=" + ((int) this.autoHROnoff) + ", hr24hOnoff=" + ((int) this.hr24hOnoff) + ", timeInterval=" + ((int) this.timeInterval) + ", autoO2noff=" + ((int) this.autoO2noff) + '}';
    }
}
