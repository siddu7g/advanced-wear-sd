package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_FUNCTION_CONTROL.class */
public class K6_DATA_TYPE_FUNCTION_CONTROL extends BaseData implements Serializable {
    private static final int SWITCH_OPEN = 1;
    private static final int SWITCH_CLOSE = 0;
    boolean hasBp;
    boolean hasO2;
    boolean hasEcg;
    boolean hasHR24H;
    boolean hasWomanStage;
    boolean hasContacts;
    boolean hasWeatherNow;
    boolean btedr_call;
    boolean autoConnectBluetooth;
    boolean qrCodeManager;
    boolean hr_measure_button;
    boolean photo_watchface;
    boolean download_logo;
    boolean hasALIPAY;
    boolean hasGame;
    boolean hasAi;
    int supportEdrBackConnect;
    boolean hasNavigation;
    boolean hasGestureSupported;
    boolean hasHrvSupported;
    boolean hasTemperature;
    boolean O2AutoSwitch;
    int weatherType;
    byte bytes1;
    byte bytes2;
    byte bytes3;

    public K6_DATA_TYPE_FUNCTION_CONTROL(byte[] bArr) {
        this.weatherType = 0;
        byte b = bArr[0];
        this.bytes1 = b;
        if ((b & 1) > 0) {
            this.hasBp = true;
        } else {
            this.hasBp = false;
        }
        if (((b >> 1) & 1) > 0) {
            this.hasO2 = true;
        } else {
            this.hasO2 = false;
        }
        if (((b >> 2) & 1) > 0) {
            this.hasEcg = true;
        } else {
            this.hasEcg = false;
        }
        this.weatherType = (b >> 3) & 17;
        if (((b >> 5) & 1) > 0) {
            this.hasHR24H = true;
        } else {
            this.hasHR24H = false;
        }
        if (((b >> 6) & 1) > 0) {
            this.hasWomanStage = true;
        } else {
            this.hasWomanStage = false;
        }
        if (((b >> 7) & 1) > 0) {
            this.hasContacts = true;
        } else {
            this.hasContacts = false;
        }
        byte b2 = bArr[1];
        this.bytes2 = b2;
        if ((b2 & 1) > 0) {
            this.hasWeatherNow = true;
        } else {
            this.hasWeatherNow = false;
        }
        if (((b2 >> 1) & 1) > 0) {
            this.btedr_call = true;
        } else {
            this.btedr_call = false;
        }
        if (((b2 >> 2) & 1) > 0) {
            this.autoConnectBluetooth = true;
        } else {
            this.autoConnectBluetooth = false;
        }
        if (((b2 >> 3) & 1) > 0) {
            this.qrCodeManager = true;
        } else {
            this.qrCodeManager = false;
        }
        if (((b2 >> 4) & 1) > 0) {
            this.hr_measure_button = true;
        } else {
            this.hr_measure_button = false;
        }
        if (((b2 >> 5) & 1) > 0) {
            this.photo_watchface = true;
        } else {
            this.photo_watchface = false;
        }
        if (((b2 >> 6) & 1) > 0) {
            this.download_logo = true;
        } else {
            this.download_logo = false;
        }
        if (((b2 >> 7) & 1) > 0) {
            this.hasALIPAY = true;
        } else {
            this.hasALIPAY = false;
        }
        byte b3 = bArr[2];
        this.bytes3 = b3;
        if ((b3 & 1) > 0) {
            this.hasGame = true;
        } else {
            this.hasGame = false;
        }
        if (((b3 >> 1) & 1) > 0) {
            this.hasAi = true;
        } else {
            this.hasAi = false;
        }
        this.supportEdrBackConnect = (b3 >> 2) & 1;
        if (((b3 >> 3) & 1) > 0) {
            this.hasNavigation = true;
        } else {
            this.hasNavigation = false;
        }
        if (((b3 >> 4) & 1) > 0) {
            this.hasGestureSupported = true;
        } else {
            this.hasGestureSupported = false;
        }
        if (((b3 >> 5) & 1) > 0) {
            this.hasHrvSupported = true;
        } else {
            this.hasHrvSupported = false;
        }
        if (((b3 >> 6) & 1) > 0) {
            this.hasTemperature = true;
        } else {
            this.hasTemperature = false;
        }
        if (((b3 >> 7) & 1) > 0) {
            this.O2AutoSwitch = true;
        } else {
            this.O2AutoSwitch = false;
        }
    }

    public K6_DATA_TYPE_FUNCTION_CONTROL(int i) {
        this.weatherType = 0;
    }

    public static int getItemSize() {
        return 8;
    }

    public boolean isHasGame() {
        return this.hasGame;
    }

    public void setHasGame(boolean z) {
        this.hasGame = z;
    }

    public boolean isHasAi() {
        return this.hasAi;
    }

    public void setHasAi(boolean z) {
        this.hasAi = z;
    }

    public int isSupportEdrBackConnect() {
        return this.supportEdrBackConnect;
    }

    public void setSupportEdrBackConnect(int i) {
        this.supportEdrBackConnect = i;
    }

    public boolean isHasNavigation() {
        return this.hasNavigation;
    }

    public void setHasNavigation(boolean z) {
        this.hasNavigation = z;
    }

    public boolean isHasALIPAY() {
        return this.hasALIPAY;
    }

    public void setHasALIPAY(boolean z) {
        this.hasALIPAY = z;
    }

    public boolean isDownload_logo() {
        return this.download_logo;
    }

    public void setDownload_logo(boolean z) {
        this.download_logo = z;
    }

    public boolean isPhoto_watchface() {
        return this.photo_watchface;
    }

    public void setPhoto_watchface(boolean z) {
        this.photo_watchface = z;
    }

    public boolean isHr_measure_button() {
        return this.hr_measure_button;
    }

    public void setHr_measure_button(boolean z) {
        this.hr_measure_button = z;
    }

    public boolean isAutoConnectBluetooth() {
        return this.autoConnectBluetooth;
    }

    public void setAutoConnectBluetooth(boolean z) {
        this.autoConnectBluetooth = z;
    }

    public boolean isQrCodeManager() {
        return this.qrCodeManager;
    }

    public void setQrCodeManager(boolean z) {
        this.qrCodeManager = z;
    }

    public boolean isBtedr_call() {
        return this.btedr_call;
    }

    public void setBtedr_call(boolean z) {
        this.btedr_call = z;
    }

    public boolean isHasWeatherNow() {
        return this.hasWeatherNow;
    }

    public void setHasWeatherNow(boolean z) {
        this.hasWeatherNow = z;
    }

    public boolean isHasContacts() {
        return this.hasContacts;
    }

    public boolean isHasWomanStage() {
        return this.hasWomanStage;
    }

    public boolean isHasBp() {
        return this.hasBp;
    }

    public boolean isHasO2() {
        return this.hasO2;
    }

    public boolean isHasEcg() {
        return this.hasEcg;
    }

    public boolean isNewType() {
        return this.weatherType == 1;
    }

    public int getWeatherType() {
        return this.weatherType;
    }

    public void setWeatherType(int i) {
        this.weatherType = i;
    }

    public boolean isHasHR24H() {
        return this.hasHR24H;
    }

    public boolean isHasGestureSupported() {
        return this.hasGestureSupported;
    }

    public void setHasGestureSupported(boolean z) {
        this.hasGestureSupported = z;
    }

    public boolean isHasHrvSupported() {
        return this.hasHrvSupported;
    }

    public void setHasHrvSupported(boolean z) {
        this.hasHrvSupported = z;
    }

    public boolean isO2AutoSwitch() {
        return this.O2AutoSwitch;
    }

    public void setO2AutoSwitch(boolean z) {
        this.O2AutoSwitch = z;
    }

    public boolean isHasTemperature() {
        return this.hasTemperature;
    }

    public void setHasTemperature(boolean z) {
        this.hasTemperature = z;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        return null;
    }
}
