package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SEND_APP_SPORT_STRUCT.class */
public class K6_SEND_APP_SPORT_STRUCT extends BaseData implements Serializable {
    public static final int SPORT_STATUS_STOP = 0;
    public static final int SPORT_STATUS_START = 1;
    public static final int SPORT_STATUS_PAUSE = 2;
    public static final int SPORT_STATUS_CONTINUE = 3;
    public static final int SPORT_STATUS_STOP_FORCE = 4;
    public static final int SPORT_STATUS_SYNC = 5;
    private int type;
    private int status;
    private int time;
    private int distance;

    public K6_SEND_APP_SPORT_STRUCT(byte[] bArr) {
        this.type = bArr[0];
        this.status = bArr[1];
        this.time = ByteUtil.byte4ToInt(new byte[]{bArr[2], bArr[3], bArr[4], bArr[5]});
        this.distance = ByteUtil.byte4ToInt(new byte[]{bArr[6], bArr[7], bArr[8], bArr[9]});
    }

    public K6_SEND_APP_SPORT_STRUCT(int i, int i2, int i3, int i4) {
        this.type = i;
        this.status = i2;
        this.time = i3;
        this.distance = i4;
    }

    public static int getItemSize() {
        return 10;
    }

    public byte[] getSendByte() {
        byte[] bArrIntToByte4 = ByteUtil.intToByte4(this.time);
        byte[] bArrIntToByte42 = ByteUtil.intToByte4(this.distance);
        return new byte[]{(byte) this.type, (byte) this.status, bArrIntToByte4[0], bArrIntToByte4[1], bArrIntToByte4[2], bArrIntToByte4[3], bArrIntToByte42[0], bArrIntToByte42[1], bArrIntToByte42[2], bArrIntToByte42[3]};
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public int getStatus() {
        return this.status;
    }

    public void setStatus(int i) {
        this.status = i;
    }

    public int getTime() {
        return this.time;
    }

    public void setTime(int i) {
        this.time = i;
    }

    public int getDistance() {
        return this.distance;
    }

    public void setDistance(int i) {
        this.distance = i;
    }

    public String toString() {
        return "K6_SEND_APP_SPORT_STRUCT{type=" + this.type + ", status=" + this.status + ", time=" + this.time + ", distance=" + this.distance + '}';
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(130);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
