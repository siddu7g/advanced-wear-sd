package ce.com.cenewbluesdk.entity.k6;

import android.text.TextUtils;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_CONTACT_SYNC.class */
public class K6_DATA_TYPE_CONTACT_SYNC extends BaseData implements Serializable {
    byte[] name;
    byte[] number;
    private int position;
    private String phoneName;
    private String phoneNumber;

    public K6_DATA_TYPE_CONTACT_SYNC() {
    }

    public K6_DATA_TYPE_CONTACT_SYNC(String str, String str2) {
        this.name = str.getBytes();
        this.number = str2.getBytes();
    }

    private byte[] getSendByte() {
        byte[] bArr = new byte[getItemSize()];
        byte[] bArr2 = this.name;
        System.arraycopy(bArr2, 0, bArr, 0, bArr2.length);
        if (isLongName()) {
            byte[] bArr3 = this.number;
            System.arraycopy(bArr3, 0, bArr, 50, bArr3.length);
        } else {
            byte[] bArr4 = this.number;
            System.arraycopy(bArr4, 0, bArr, 20, bArr4.length);
        }
        return bArr;
    }

    private boolean isLongName() {
        String deviceName = CEBlueSharedPreference.getDeviceName();
        return !TextUtils.isEmpty(deviceName) && deviceName.equalsIgnoreCase("DM10Pro");
    }

    public static int getItemSize() {
        return 40;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(135);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public void setPhoneName(String str) {
        this.phoneName = str;
    }

    public void setPhoneNumber(String str) {
        this.phoneNumber = str;
    }

    public void setPosition(int i) {
        this.position = i;
    }

    public int getPosition() {
        return this.position;
    }

    public String getPhoneName() {
        return this.phoneName;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public String toString() {
        return "K6_DATA_TYPE_CONTACT_SYNC{userName='" + this.phoneName + "', userNumber='" + this.phoneNumber + "'}";
    }
}
