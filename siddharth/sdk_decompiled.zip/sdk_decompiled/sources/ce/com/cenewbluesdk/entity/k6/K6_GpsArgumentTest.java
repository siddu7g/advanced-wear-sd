package ce.com.cenewbluesdk.entity.k6;

import android.util.Log;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.e;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_GpsArgumentTest.class */
public class K6_GpsArgumentTest implements Serializable {
    public static final int GPS_ONLINE_TYPE = 0;
    public static final int GPS_OFFLINE_TYPE = 1;
    private int crc16;
    private int type;
    private byte[] time;
    private int len;
    private byte[] data;
    private int packIndex;
    private int itemLength;
    private byte[] sendByte;

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v18 ??, still in use, count: 6, list:
          (r0v18 ??) from 0x0057: PHI (r0v11 ??) = (r0v8 ??), (r0v18 ??) binds: [B:21:0x0055, B:16:0x0047] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ??) from 0x006a: PHI (r0v14 ??) = (r0v9 ??), (r0v18 ??) binds: [B:26:0x0068, B:17:0x004a] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ??) from 0x0067: PHI (r0v9 ??) = (r0v2 ??), (r0v18 ??) binds: [B:40:0x0017, B:47:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ??) from 0x0054: PHI (r0v8 ??) = (r0v2 ??), (r0v18 ??) binds: [B:40:0x0017, B:47:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ?? I:java.io.FileInputStream) from 0x003b: INVOKE (r0v18 ?? I:java.io.FileInputStream) VIRTUAL call: java.io.FileInputStream.close():void A[Catch: all -> 0x0041, IOException -> 0x0047, FileNotFoundException -> 0x004a, IOException -> 0x007a, MD:():void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
          (r0v18 ??) from 0x007d: PHI (r0v17 ??) = (r0v13 ??), (r0v16 ??), (r0v18 ??) binds: [B:24:0x005f, B:29:0x0072, B:13:0x003e] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public K6_GpsArgumentTest(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v18 ??, still in use, count: 6, list:
          (r0v18 ??) from 0x0057: PHI (r0v11 ??) = (r0v8 ??), (r0v18 ??) binds: [B:21:0x0055, B:16:0x0047] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ??) from 0x006a: PHI (r0v14 ??) = (r0v9 ??), (r0v18 ??) binds: [B:26:0x0068, B:17:0x004a] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ??) from 0x0067: PHI (r0v9 ??) = (r0v2 ??), (r0v18 ??) binds: [B:40:0x0017, B:47:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ??) from 0x0054: PHI (r0v8 ??) = (r0v2 ??), (r0v18 ??) binds: [B:40:0x0017, B:47:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v18 ?? I:java.io.FileInputStream) from 0x003b: INVOKE (r0v18 ?? I:java.io.FileInputStream) VIRTUAL call: java.io.FileInputStream.close():void A[Catch: all -> 0x0041, IOException -> 0x0047, FileNotFoundException -> 0x004a, IOException -> 0x007a, MD:():void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
          (r0v18 ??) from 0x007d: PHI (r0v17 ??) = (r0v13 ??), (r0v16 ??), (r0v18 ??) binds: [B:24:0x005f, B:29:0x0072, B:13:0x003e] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r8v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */

    public K6_GpsArgumentTest(byte[] bArr, int i, long j) {
        this.time = new byte[4];
        init(bArr, i, j);
    }

    private void init(byte[] bArr, int i, long j) {
        if (bArr == null) {
            throw new IllegalArgumentException("data must not be null");
        }
        this.data = bArr;
        Log.e("文件长度", "" + bArr.length);
        this.type = i;
        this.time = ByteUtil.intToByte4((int) (j / 1000));
        Log.e("UTC", ByteUtil.byte4ToInt(this.time) + "");
        Log.e("UTC", ByteUtil.byte4ToInt(this.time) + "");
        Log.e("当前时间", ByteUtil.byte2hex(this.time));
        this.len = this.data.length;
        this.crc16 = e.a(getSendByte(), 2);
        Log.e("CRC校验", this.crc16 + "");
        byte[] sendByte = getSendByte();
        this.sendByte = sendByte;
        this.packIndex = 0;
        this.itemLength = sendByte.length > 500 ? 500 : sendByte.length;
    }

    public void updateIndex() {
        int i = this.packIndex + this.itemLength;
        this.packIndex = i;
        byte[] bArr = this.sendByte;
        if (i >= bArr.length) {
            return;
        }
        if (bArr.length - i < 500) {
            this.itemLength = bArr.length - i;
        } else {
            this.itemLength = 500;
        }
    }

    public void resetIndex() {
        this.packIndex = 0;
        byte[] bArr = this.sendByte;
        this.itemLength = bArr.length > 500 ? 500 : bArr.length;
    }

    public List<byte[]> getGpsArgHeadBytesList() {
        byte[] gpsArgHeadBytes;
        ArrayList arrayList = new ArrayList();
        while (this.packIndex < this.sendByte.length && (gpsArgHeadBytes = getGpsArgHeadBytes()) != null) {
            arrayList.add(gpsArgHeadBytes);
        }
        resetIndex();
        return arrayList;
    }

    public byte[] getGpsArgHeadBytes() {
        if (this.packIndex >= this.sendByte.length) {
            resetIndex();
            return null;
        }
        byte[] bArr = new byte[this.itemLength + 7];
        System.arraycopy(ByteUtil.intToByte(this.type, 1), 0, bArr, 0, 1);
        System.arraycopy(ByteUtil.int2bytes2(this.data.length + 9), 0, bArr, 1, 2);
        System.arraycopy(ByteUtil.int2bytes2(this.itemLength), 0, bArr, 3, 2);
        System.arraycopy(ByteUtil.int2bytes2(this.packIndex), 0, bArr, 5, 2);
        System.arraycopy(this.sendByte, this.packIndex, bArr, 7, this.itemLength);
        if (this.packIndex == 0) {
            Log.e("pack crc", ByteUtil.byte2ToInt(Arrays.copyOfRange(bArr, 7, 9)) + " ");
        }
        Log.e("pack offset", "" + this.packIndex);
        Log.e("pack length", "" + this.itemLength);
        updateIndex();
        return bArr;
    }

    public int getCrc16() {
        return this.crc16;
    }

    public void setCrc16(int i) {
        this.crc16 = i;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public byte[] getTime() {
        return this.time;
    }

    public void setTime(byte[] bArr) {
        this.time = bArr;
    }

    public int getLen() {
        return this.len;
    }

    public void setLen(int i) {
        this.len = i;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] bArr) {
        this.data = bArr;
    }

    public byte[] getSendByte() {
        byte[] bArr = new byte[this.data.length + 9];
        System.arraycopy(ByteUtil.int2bytes2(this.crc16), 0, bArr, 0, 2);
        System.arraycopy(ByteUtil.intToByte(this.type, 1), 0, bArr, 2, 1);
        System.arraycopy(this.time, 0, bArr, 3, 4);
        System.arraycopy(ByteUtil.int2bytes2(this.len), 0, bArr, 7, 2);
        byte[] bArr2 = this.data;
        System.arraycopy(bArr2, 0, bArr, 9, bArr2.length);
        return bArr;
    }
}
