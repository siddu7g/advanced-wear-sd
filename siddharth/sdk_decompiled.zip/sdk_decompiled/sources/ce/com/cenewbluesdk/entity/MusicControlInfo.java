package ce.com.cenewbluesdk.entity;

import android.graphics.drawable.Drawable;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/MusicControlInfo.class */
public class MusicControlInfo implements Serializable {
    private Drawable icon;
    private String appName;
    private String pkgName;
    private boolean isChoice;

    public boolean isChoice() {
        return this.isChoice;
    }

    public void setChoice(boolean z) {
        this.isChoice = z;
    }

    public String getPkgName() {
        return this.pkgName;
    }

    public void setPkgName(String str) {
        this.pkgName = str;
    }

    public Drawable getIcon() {
        return this.icon;
    }

    public void setIcon(Drawable drawable) {
        this.icon = drawable;
    }

    public String getAppName() {
        return this.appName;
    }

    public void setAppName(String str) {
        this.appName = str;
    }
}
