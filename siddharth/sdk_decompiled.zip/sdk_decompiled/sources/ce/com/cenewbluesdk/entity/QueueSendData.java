package ce.com.cenewbluesdk.entity;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/QueueSendData.class */
public class QueueSendData {
    public int index = -1;
    public byte[] sendData;
    private int currentPackage;

    public int getIndex() {
        return this.index;
    }

    public void setIndex(int i) {
        this.index = i;
    }

    public byte[] getSendData() {
        return this.sendData;
    }

    public void setSendData(byte[] bArr) {
        this.sendData = bArr;
    }

    public void setCurrentPackage(int i) {
        this.currentPackage = i;
    }

    public int getCurrentPackage() {
        return this.currentPackage;
    }
}
