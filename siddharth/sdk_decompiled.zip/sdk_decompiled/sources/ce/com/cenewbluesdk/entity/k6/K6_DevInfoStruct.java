package ce.com.cenewbluesdk.entity.k6;

import android.os.Parcel;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DevInfoStruct.class */
public class K6_DevInfoStruct implements Serializable {
    private static final long serialVersionUID = 3765629512912029068L;
    public static int devInfoByteLen = 6;
    private int items;
    private int customer_id;
    private int hardware_id;
    private int code_id;
    private int picture_id;
    private int font_id;
    private int customer_id_h;
    String hardwareVer;
    String softwareVer;
    String hexSoftWareVer;

    public K6_DevInfoStruct() {
    }

    public K6_DevInfoStruct(int i, int i2, int i3, int i4, int i5, int i6) {
        this.items = i;
        this.customer_id = i2;
        this.hardware_id = i3;
        this.code_id = i4;
        this.picture_id = i5;
        this.font_id = i6;
        this.hardwareVer = i3 + "";
        this.softwareVer = i2 + "." + i3 + "." + i4 + "." + i5 + "." + i6;
        this.hexSoftWareVer = i2 + "." + Integer.toHexString(i3) + "." + i4 + "." + i5 + "." + i6;
    }

    public K6_DevInfoStruct(int i, int i2, int i3, int i4, int i5, int i6, int i7) {
        this.items = i;
        this.customer_id = i2;
        this.hardware_id = i3;
        this.code_id = i4;
        this.picture_id = i5;
        this.font_id = i6;
        this.hardwareVer = i3 + "";
        this.customer_id_h = i7;
        this.softwareVer = (i2 + this.customer_id_h) + "." + i3 + "." + i4 + "." + i5 + "." + i6;
        this.hexSoftWareVer = (i2 + this.customer_id_h) + "." + Integer.toHexString(i3) + "." + i4 + "." + i5 + "." + i6;
    }

    protected K6_DevInfoStruct(Parcel parcel) {
        this.items = parcel.readInt();
        this.customer_id = parcel.readInt();
        this.hardware_id = parcel.readInt();
        this.code_id = parcel.readInt();
        this.picture_id = parcel.readInt();
        this.font_id = parcel.readInt();
        this.hardwareVer = parcel.readString();
        this.softwareVer = parcel.readString();
    }

    public static K6_DevInfoStruct parseDevInfo(byte[] bArr) {
        K6_DevInfoStruct k6_DevInfoStruct;
        if ((bArr[0] & 255) == 12) {
            k6_DevInfoStruct = k6_DevInfoStruct;
            K6_DevInfoStruct k6_DevInfoStruct2 = new K6_DevInfoStruct(bArr[0] & 255, bArr[1] & 255, bArr[2] & 255, bArr[3] & 255, bArr[4] & 255, bArr[5] & 255, bArr[6] << 8);
        } else {
            k6_DevInfoStruct = k6_DevInfoStruct;
            K6_DevInfoStruct k6_DevInfoStruct3 = new K6_DevInfoStruct(bArr[0] & 255, bArr[1] & 255, bArr[2] & 255, bArr[3] & 255, bArr[4] & 255, bArr[5] & 255);
        }
        return k6_DevInfoStruct;
    }

    public static int getItemSize() {
        return 6;
    }

    public byte[] getBytes() {
        return new byte[]{(byte) this.items, (byte) this.customer_id, (byte) this.hardware_id, (byte) this.code_id, (byte) this.picture_id, (byte) this.font_id};
    }

    public String toString() {
        return "K6_DevInfoStruct{items=" + this.items + ", customer_id=" + this.customer_id + ", hardware_id=" + this.hardware_id + ", code_id=" + this.code_id + ", picture_id=" + this.picture_id + ", font_id=" + this.font_id + ", hardwareVer='" + this.hardwareVer + "', softwareVer='" + this.softwareVer + "', hexSoftWareVer='" + this.hexSoftWareVer + "'}";
    }

    public String getHardwareVer() {
        return this.hardwareVer;
    }

    public String getSoftwareVer() {
        return this.softwareVer;
    }

    public String getHexSoftWareVer() {
        return this.hexSoftWareVer;
    }

    public int getCustomer_id() {
        return this.customer_id + getCustomer_id_h();
    }

    public int getCode_id() {
        return this.code_id;
    }

    public int getPicture_id() {
        return this.picture_id;
    }

    public int getHardware_id() {
        return this.hardware_id;
    }

    public int getCustomer_id_h() {
        return this.customer_id_h;
    }

    public void setCustomer_id_h(int i) {
        this.customer_id_h = i;
    }
}
