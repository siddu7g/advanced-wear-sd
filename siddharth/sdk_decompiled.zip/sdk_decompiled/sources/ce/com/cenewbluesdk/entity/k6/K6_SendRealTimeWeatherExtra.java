package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendRealTimeWeatherExtra.class */
public class K6_SendRealTimeWeatherExtra extends BaseData implements Serializable {
    private byte[] time;
    private byte weather;
    private byte temperature;
    private byte windScale;
    private byte humidity;
    private byte sensoryTemp;
    private byte windDirection;
    private byte phenomenonDay;
    private byte phenomenonNight;
    private byte windPowerDay;
    private byte windPowerNight;

    public K6_SendRealTimeWeatherExtra() {
    }

    public K6_SendRealTimeWeatherExtra(int i, int i2, int i3, int i4, int i5, int i6) {
        this.sensoryTemp = (byte) (i & 255);
        this.windDirection = (byte) (i2 & 255);
        this.phenomenonDay = (byte) (i3 & 255);
        this.phenomenonNight = (byte) (i4 & 255);
        this.windPowerDay = (byte) (i5 & 255);
        this.windPowerNight = (byte) (i6 & 255);
    }

    public static int getItemSize() {
        return 16;
    }

    public byte[] getTime() {
        return this.time;
    }

    public void setTime(byte[] bArr) {
        this.time = bArr;
    }

    public byte getWeather() {
        return this.weather;
    }

    public void setWeather(byte b) {
        this.weather = b;
    }

    public byte getTemperature() {
        return this.temperature;
    }

    public void setTemperature(byte b) {
        this.temperature = b;
    }

    public byte getWindScale() {
        return this.windScale;
    }

    public void setWindScale(byte b) {
        this.windScale = b;
    }

    public byte getHumidity() {
        return this.humidity;
    }

    public void setHumidity(byte b) {
        this.humidity = b;
    }

    public byte getSensoryTemp() {
        return this.sensoryTemp;
    }

    public void setSensoryTemp(byte b) {
        this.sensoryTemp = b;
    }

    public byte getWindDirection() {
        return this.windDirection;
    }

    public void setWindDirection(byte b) {
        this.windDirection = b;
    }

    public byte getPhenomenonDay() {
        return this.phenomenonDay;
    }

    public void setPhenomenonDay(byte b) {
        this.phenomenonDay = b;
    }

    public byte getPhenomenonNight() {
        return this.phenomenonNight;
    }

    public void setPhenomenonNight(byte b) {
        this.phenomenonNight = b;
    }

    public byte getWindPowerDay() {
        return this.windPowerDay;
    }

    public void setWindPowerDay(byte b) {
        this.windPowerDay = b;
    }

    public byte getWindPowerNight() {
        return this.windPowerNight;
    }

    public void setWindPowerNight(byte b) {
        this.windPowerNight = b;
    }

    public String toString() {
        return "K6_SendRealTimeWeatherExtra{time=" + this.time + ", weather=" + ((int) this.weather) + ", temperature=" + ((int) this.temperature) + ", windScale=" + ((int) this.windScale) + ", humidity=" + ((int) this.humidity) + ", sensoryTemp=" + ((int) this.sensoryTemp) + ", windDirection=" + ((int) this.windDirection) + ", phenomenonDay=" + ((int) this.phenomenonDay) + ", phenomenonNight=" + ((int) this.phenomenonNight) + ", windPowerDay=" + ((int) this.windPowerDay) + ", windPowerNight=" + ((int) this.windPowerNight) + '}';
    }

    public byte[] getBytes() {
        byte[] bArr = this.time;
        return new byte[]{bArr[0], bArr[1], bArr[2], bArr[3], this.weather, this.phenomenonDay, this.phenomenonNight, this.temperature, this.sensoryTemp, this.windScale, this.windPowerDay, this.windPowerNight, this.windDirection, this.humidity, 0, 0};
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(CEBC.K6.DATA_TYPE_EXTERN_WEATHER);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
