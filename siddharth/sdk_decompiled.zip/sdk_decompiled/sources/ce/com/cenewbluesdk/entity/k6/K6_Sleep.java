package ce.com.cenewbluesdk.entity.k6;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_Sleep.class */
public class K6_Sleep implements Serializable {
    public static final int SLEEP_START = 1;
    public static final int SLEEP_DEEP = 2;
    public static final int SLEEP_LIGHT = 3;
    public static final int SLEEP_WAKEUP = 4;
    public static final int SLEEP_MOVEMENT = 5;
    private int sleepType;
    private int sleepTime;

    public K6_Sleep(int i, int i2) {
        this.sleepType = i;
        this.sleepTime = i2;
    }

    public int getSleepType() {
        return this.sleepType;
    }

    public void setSleepType(int i) {
        this.sleepType = i;
    }

    public int getSleepTime() {
        return this.sleepTime;
    }

    public void setSleepTime(int i) {
        this.sleepTime = i;
    }

    public String toString() {
        return "[SleepType " + this.sleepType + " sleepTime " + this.sleepTime + "]";
    }
}
