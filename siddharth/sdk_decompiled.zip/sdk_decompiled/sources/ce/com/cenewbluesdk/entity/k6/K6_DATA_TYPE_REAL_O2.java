package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_REAL_O2.class */
public class K6_DATA_TYPE_REAL_O2 extends BaseData implements Serializable {
    public static final int O2_SWITCH_OPEN = 1;
    public static final int O2_SWITCH_CLOSE = 0;
    private int time;
    private int value;
    private boolean isEnd;

    public K6_DATA_TYPE_REAL_O2(byte[] bArr) {
        if (bArr[0] == 0) {
            this.isEnd = true;
        } else {
            this.time = ByteUtil.byte4ToInt(new byte[]{bArr[0], bArr[1], bArr[2], bArr[3]});
            this.value = bArr[4] & 255;
        }
    }

    public K6_DATA_TYPE_REAL_O2(int i) {
        this.time = i;
        this.value = 0;
    }

    public static int getItemSize() {
        return 5;
    }

    public boolean isEnd() {
        return this.isEnd;
    }

    public byte[] getSendByte() {
        return new byte[]{(byte) this.time, 0, 0, 0, (byte) this.value};
    }

    public int getTime() {
        return this.time;
    }

    public void setTime(int i) {
        this.time = i;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int i) {
        this.value = i;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(20);
        cEDevData.setData(getSendByte());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "K6_DATA_TYPE_REAL_O2{time=" + this.time + ", value=" + this.value + '}';
    }
}
