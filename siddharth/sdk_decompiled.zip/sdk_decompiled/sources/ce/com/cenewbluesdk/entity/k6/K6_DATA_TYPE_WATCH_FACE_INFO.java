package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_WATCH_FACE_INFO.class */
public class K6_DATA_TYPE_WATCH_FACE_INFO implements Serializable {
    private int index;
    private K6_DATA_TYPE_WATCH_FACE_INFO_CMD2 cmd2;
    private int cmd3Id;
    private int all_len;
    private int current_pos;

    public K6_DATA_TYPE_WATCH_FACE_INFO() {
    }

    public K6_DATA_TYPE_WATCH_FACE_INFO(byte[] bArr) {
        this.index = bArr[0];
        K6_DATA_TYPE_WATCH_FACE_INFO_CMD2 k6_data_type_watch_face_info_cmd2 = new K6_DATA_TYPE_WATCH_FACE_INFO_CMD2();
        this.cmd2 = k6_data_type_watch_face_info_cmd2;
        int iSizeWithOutpic = k6_data_type_watch_face_info_cmd2.sizeWithOutpic();
        byte[] bArr2 = new byte[iSizeWithOutpic];
        System.arraycopy(bArr, 1, bArr2, 0, iSizeWithOutpic);
        this.cmd2.processBytes(bArr2);
        int i = iSizeWithOutpic + 1;
        this.cmd3Id = ByteUtil.byte2ToInt(new byte[]{bArr[i + 1], bArr[i]});
        int i2 = i + 2;
        this.all_len = ByteUtil.byte4ToInt(new byte[]{bArr[i2], bArr[i2 + 1], bArr[i2 + 2], bArr[i2 + 3]});
        int i3 = i2 + 4;
        this.current_pos = ByteUtil.byte4ToInt(new byte[]{bArr[i3], bArr[i3 + 1], bArr[i3 + 2], bArr[i3 + 3]});
    }

    public int getIndex() {
        return this.index;
    }

    public void setIndex(int i) {
        this.index = i;
    }

    public K6_DATA_TYPE_WATCH_FACE_INFO_CMD2 getCmd2() {
        return this.cmd2;
    }

    public void setCmd2(K6_DATA_TYPE_WATCH_FACE_INFO_CMD2 k6_data_type_watch_face_info_cmd2) {
        this.cmd2 = k6_data_type_watch_face_info_cmd2;
    }

    public int getCmd3Id() {
        return this.cmd3Id;
    }

    public void setCmd3Id(int i) {
        this.cmd3Id = i;
    }

    public int getAll_len() {
        return this.all_len;
    }

    public void setAll_len(int i) {
        this.all_len = i;
    }

    public int getCurrent_pos() {
        return this.current_pos;
    }

    public void setCurrent_pos(int i) {
        this.current_pos = i;
    }

    public String getBinId() {
        return String.format("%04x", Integer.valueOf(getCmd3Id()));
    }

    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception, java.lang.String] */
    public String toString() {
        ?? string;
        try {
            StringBuilder sbAppend = new StringBuilder().append("K6_DATA_TYPE_WATCH_FACE_INFO{index=").append(this.index).append(", cmd2=");
            K6_DATA_TYPE_WATCH_FACE_INFO_CMD2 k6_data_type_watch_face_info_cmd2 = this.cmd2;
            K6_DATA_TYPE_WATCH_FACE_INFO_CMD2 string2 = k6_data_type_watch_face_info_cmd2;
            if (k6_data_type_watch_face_info_cmd2 != null) {
                string2 = string2.toString();
            }
            string = sbAppend.append(string2).append(", cmd3Id=").append(this.cmd3Id).append(", all_len=").append(this.all_len).append(", current_pos=").append(this.current_pos).append('}').toString();
            return string;
        } catch (Exception unused) {
            string.printStackTrace();
            return "";
        }
    }
}
