package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.TimeUtil;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/DateTimeUtil.class */
public class DateTimeUtil {
    public static final int TIME_DAY_MILLISECOND = 86400000;
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_FORMAT_CN = "yyyy年MM月dd日";
    public static final String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String TIME_FORMAT_MILL = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String TIME_FORMAT_CN = "yyyy年MM月dd日 HH:mm:ss";
    public static final String MONTH_FORMAT = "yyyy-MM";
    public static final String MONTH_DAY_FORMAT = "MM月dd";
    public static final String DAY_FORMAT = "yyyyMMdd";
    public static final String MINUTE_FORMAT = "yyyy-MM-dd HH:mm";
    public static final Locale locale = Locale.ENGLISH;
    public static final String dtSimple = "yyyy-MM-dd";
    private int[] mTermInfo = {0, 21208, 42467, 63836, 85337, 107014, 128867, 150921, 173149, 195551, 218072, 240693, 263343, 285989, 308563, 331033, 353350, 375494, 397447, 419210, 440795, 462224, 483532, 504758};

    public static Date getCurrDate() {
        return new Date();
    }

    public static Timestamp getCurrTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }

    public static Integer getCurrDateAMorPM() {
        return Integer.valueOf(Calendar.getInstance().get(9));
    }

    public static String getFormatDate(Date date) {
        return getFormatDate(date, "yyyy-MM-dd");
    }

    public static String getFormatDate2(Date date) {
        return getFormatDate(date, "yyyy-M-d");
    }

    public static Date getFormatDateToDate(Date date) {
        return getFormatDate(getFormatDate(date));
    }

    public static String getFormatDate_CN(Date date) {
        return getFormatDate(date, DATE_FORMAT_CN);
    }

    public static Date getFormatDateToDate_CN(Date date) {
        return getFormatDate_CN(getFormatDate_CN(date));
    }

    public static Date getFormatDate(String str) {
        return getFormatDate(str, "yyyy-MM-dd");
    }

    public static Date getFormatDate_CN(String str) {
        return getFormatDate(str, DATE_FORMAT_CN);
    }

    public static String getFormatDate(Date date, String str) {
        if (date == null) {
            return "";
        }
        try {
            return new SimpleDateFormat(str, locale).format(date);
        } catch (Exception unused) {
            try {
                return new SimpleDateFormat("yyyy-MM-dd", locale).format(date);
            } catch (Exception unused2) {
                return null;
            }
        }
    }

    public static String getFormatDateTime(Date date) {
        return getFormatDateTime(date, "yyyy-MM-dd HH:mm:ss");
    }

    public static Date getFormatDateTimeToTime(Date date) {
        return getFormatDateTime(getFormatDateTime(date));
    }

    public static Date getFormatDateTime(String str) {
        return getFormatDateTime(str, "yyyy-MM-dd HH:mm:ss");
    }

    public static String getFormatDateTime_CN(Date date) {
        return getFormatDateTime(date, TIME_FORMAT_CN);
    }

    public static Date getFormatDateTimeToTime_CN(Date date) {
        return getFormatDateTime_CN(getFormatDateTime_CN(date));
    }

    public static Date getFormatDateTime_CN(String str) {
        return getFormatDateTime(str, TIME_FORMAT_CN);
    }

    public static String getFormatDateTime(Date date, String str) {
        if (date == null) {
            return "";
        }
        try {
            return new SimpleDateFormat(str, locale).format(date);
        } catch (Exception unused) {
            try {
                return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale).format(date);
            } catch (Exception unused2) {
                return "";
            }
        }
    }

    public static Date getFormatDate(String str, String str2) {
        if (str == null) {
            return null;
        }
        try {
            return new SimpleDateFormat(str2, locale).parse(str);
        } catch (Exception unused) {
            try {
                return new SimpleDateFormat("yyyy-MM-dd", locale).parse(str);
            } catch (Exception unused2) {
                return null;
            }
        }
    }

    public static Date getFormatDateTime(String str, String str2) {
        if (str == null) {
            return null;
        }
        try {
            return new SimpleDateFormat(str2, locale).parse(str);
        } catch (Exception unused) {
            try {
                return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale).parse(str);
            } catch (Exception unused2) {
                return null;
            }
        }
    }

    public static String getDateBeforeMonth() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(2, -1);
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static String getDateBeforeMonth(int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(2, -i);
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.text.SimpleDateFormat] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.text.ParseException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.String] */
    public static String getStringDate(String str, String str2, String str3) {
        Locale locale2 = locale;
        ?? simpleDateFormat = new SimpleDateFormat(str2, locale2);
        try {
            simpleDateFormat = new SimpleDateFormat(str3, locale2).format(simpleDateFormat.parse(str));
            return simpleDateFormat;
        } catch (ParseException unused) {
            simpleDateFormat.printStackTrace();
            return null;
        }
    }

    public static String getDateBeforeMonth(Date date, int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(2, -i);
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static long getDaysOfDates(Date date, Date date2) {
        return (getFormatDateTime(getFormatDate(date), "yyyy-MM-dd").getTime() - getFormatDateTime(getFormatDate(date2), "yyyy-MM-dd").getTime()) / TimeUtil.ONE_DAY_MS;
    }

    public static int getDaysBetweenDates(Date date, Date date2) {
        return Long.valueOf((getFormatDateTime(getFormatDate(date2), "yyyy-MM-dd").getTime() - getFormatDateTime(getFormatDate(date), "yyyy-MM-dd").getTime()) / TimeUtil.ONE_DAY_MS).intValue();
    }

    public static int getDaysBetweenDates(String str, String str2) {
        return Long.valueOf((getFormatDateTime(str2, "yyyy-MM-dd").getTime() - getFormatDateTime(str, "yyyy-MM-dd").getTime()) / TimeUtil.ONE_DAY_MS).intValue();
    }

    public static List<Date> getDaysListBetweenDates(Date date, Date date2) {
        Date dateBeforeOrAfter;
        ArrayList arrayList = new ArrayList();
        Date formatDateTime = getFormatDateTime(getFormatDate(date), "yyyy-MM-dd");
        Date date3 = formatDateTime;
        Date formatDateTime2 = getFormatDateTime(getFormatDate(date2), "yyyy-MM-dd");
        if (formatDateTime.compareTo(formatDateTime2) > 0) {
            return arrayList;
        }
        do {
            arrayList.add(date3);
            dateBeforeOrAfter = getDateBeforeOrAfter(date3, 1);
            date3 = dateBeforeOrAfter;
        } while (dateBeforeOrAfter.compareTo(formatDateTime2) <= 0);
        return arrayList;
    }

    public static List<String> getDaysStrListBetweenDates(Date date, Date date2) {
        Date dateBeforeOrAfter;
        ArrayList arrayList = new ArrayList();
        Date formatDateTime = getFormatDateTime(getFormatDate(date), "yyyy-MM-dd");
        Date date3 = formatDateTime;
        Date formatDateTime2 = getFormatDateTime(getFormatDate(date2), "yyyy-MM-dd");
        if (formatDateTime.compareTo(formatDateTime2) > 0) {
            return arrayList;
        }
        do {
            arrayList.add(getFormatDate(date3));
            dateBeforeOrAfter = getDateBeforeOrAfter(date3, 1);
            date3 = dateBeforeOrAfter;
        } while (dateBeforeOrAfter.compareTo(formatDateTime2) <= 0);
        return arrayList;
    }

    public static List<String> getDaysStrListCurMonths(String str) {
        Date dateBeforeOrAfter;
        ArrayList arrayList = new ArrayList();
        Date formatDate = getFormatDate(getFirstDayOfMonth(getFormatDate(str)));
        Date date = formatDate;
        Date formatDate2 = getFormatDate(getLastDayOfMonth(getFormatDate(str)));
        if (formatDate.compareTo(formatDate2) > 0) {
            return arrayList;
        }
        do {
            arrayList.add(getFormatDate(date));
            dateBeforeOrAfter = getDateBeforeOrAfter(date, 1);
            date = dateBeforeOrAfter;
        } while (dateBeforeOrAfter.compareTo(formatDate2) <= 0);
        return arrayList;
    }

    public static String getWeekOfDate(Date date) {
        String[] strArr = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return strArr[calendar.get(7) - 1];
    }

    public static String getDateBeforeDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(6, -1);
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static String getCurrDateStr() {
        return getFormatDate(getCurrDate());
    }

    public static String getCurrDateTimeStr() {
        return getFormatDateTime(getCurrDate());
    }

    public static String getCurrDateTimeStrMill() {
        return getFormatDateTime(getCurrDate(), "yyyy-MM-dd HH:mm:ss.SSS");
    }

    public static String getCurrDateStr_CN() {
        return getFormatDate(getCurrDate(), DATE_FORMAT_CN);
    }

    public static String getCurrDateTimeStr_CN() {
        return getFormatDateTime(getCurrDate(), TIME_FORMAT_CN);
    }

    public static Date getDateBeforeOrAfter(int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(5, i);
        return calendar.getTime();
    }

    public static Date getDateBeforeOrAfter(Date date, int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(5, i);
        return calendar.getTime();
    }

    public static String getFormatMonth(Date date) {
        return getFormatDate(date, MONTH_FORMAT);
    }

    public static String getFormatMonth(Date date, String str) {
        return getFormatDate(date, str);
    }

    public static String getFormatDay(Date date) {
        return getFormatDate(date, DAY_FORMAT);
    }

    public static String getFormatDAY(Date date) {
        return getFormatDate(date, MONTH_DAY_FORMAT);
    }

    public static String getFirstDayOfMonth() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(5, calendar.getMinimum(5));
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static String getFirstDayOfNextMonth() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(2, 1);
        calendar.set(5, calendar.getMinimum(5));
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static String getFirstDayOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(5, calendar.getMinimum(5));
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static String getLastDayOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(5, calendar.getActualMaximum(5));
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static String getLastDayOfMonth() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(5, calendar.getActualMaximum(5));
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static Date getDateBeforeOrAfterHours(Date date, int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(11, i);
        return calendar.getTime();
    }

    public static boolean isSameWeek(Date date, Date date2) {
        if (date == null || date2 == null) {
            return false;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(getFormatDateToDate(date));
        calendar.set(7, 1);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(calendar.getTime());
        calendar2.add(5, 7);
        Calendar calendar3 = Calendar.getInstance();
        calendar3.setTime(date2);
        return calendar3.after(calendar) && calendar3.before(calendar2);
    }

    public static String addDateEndfix(String str) {
        if (str == null || str.equals("")) {
            return null;
        }
        return str + " 23:59:59";
    }

    public static Date getFormatDateEndfix(String str) {
        return getFormatDateTime(addDateEndfix(str));
    }

    public static Date formatEndTime(String str) {
        if (str == null) {
            return null;
        }
        return getFormatDateTime(addDateEndfix(str));
    }

    public static Boolean compareDay(Date date, int i) {
        if (date != null && getDateBeforeOrAfter(date, i).after(new Date())) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public static String convertBinaryTime2Hex(String str) {
        if (str == null || str.equals("")) {
            return "";
        }
        String str2 = "";
        String str3 = "";
        int i = 0;
        while (i < str.length()) {
            str3 = (str3 + str.charAt(i)) + str.charAt(i);
            int i2 = i + 1;
            i = i2;
            if (i2 % 16 == 0) {
                if (!str2.equals("")) {
                    str2 = str2 + ",";
                }
                String hexString = Long.toHexString(Long.valueOf(Long.parseLong(str3, 2)).longValue());
                String str4 = hexString;
                if (hexString.length() < 8) {
                    int length = str4.length();
                    for (int i3 = 0; i3 < 8 - length; i3++) {
                        str4 = "0" + str4;
                    }
                }
                str2 = str2 + str4;
                str3 = "";
            }
        }
        return str2;
    }

    public static String convertHexTime2Binary(String str) {
        if (str == null || str.equals("")) {
            return "";
        }
        String str2 = "";
        String str3 = "";
        for (String str4 : str.split(",")) {
            String binaryString = Long.toBinaryString(Long.parseLong(str4, 16));
            String str5 = binaryString;
            if (binaryString.length() < 32) {
                int length = str5.length();
                for (int i = 0; i < 32 - length; i++) {
                    str5 = "0" + str5;
                }
            }
            str2 = str2 + str5;
        }
        for (int i2 = 0; i2 < 48; i2++) {
            str3 = str3 + str2.charAt(i2 * 2);
        }
        return str3;
    }

    public static String convertDecTime2Binary(String str) {
        if (str == null || str.equals("")) {
            return "";
        }
        String str2 = "";
        String str3 = "";
        for (String str4 : str.split(",")) {
            String binaryString = Long.toBinaryString(Long.parseLong(str4, 10));
            String str5 = binaryString;
            if (binaryString.length() < 32) {
                int length = str5.length();
                for (int i = 0; i < 32 - length; i++) {
                    str5 = "0" + str5;
                }
            }
            str2 = str2 + str5;
        }
        for (int i2 = 0; i2 < 48; i2++) {
            str3 = str3 + str2.charAt(i2 * 2);
        }
        return str3;
    }

    public static String convertBinaryTime2Dec(String str) {
        if (str == null || str.equals("")) {
            return "";
        }
        String str2 = "";
        String str3 = "";
        int i = 0;
        while (i < str.length()) {
            str3 = (str3 + str.charAt(i)) + str.charAt(i);
            int i2 = i + 1;
            i = i2;
            if (i2 % 16 == 0) {
                if (!str2.equals("")) {
                    str2 = str2 + ",";
                }
                String string = Long.toString(Long.valueOf(Long.parseLong(str3, 2)).longValue());
                String str4 = string;
                if (string.length() < 10) {
                    int length = str4.length();
                    for (int i3 = 0; i3 < 10 - length; i3++) {
                        str4 = "0" + str4;
                    }
                }
                str2 = str2 + str4;
                str3 = "";
            }
        }
        return str2;
    }

    public static String genericSpecdate(Date date, int i, int i2) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(2, i);
        calendar.set(5, i2);
        return getFormatDate(calendar.getTime(), "yyyy-MM-dd");
    }

    public static Date getDateBeforeOrAfterV2(int i) {
        return getDateBeforeOrAfter(getFormatDateToDate(getCurrDate()), i);
    }

    public static Date getSpecifiedDateTimeBySeconds(Date date, int i) {
        date.setTime(((date.getTime() / 1000) + i) * 1000);
        return date;
    }

    public static Date getSpecifiedDateTime_235959(Date date) {
        return getSpecifiedDateTimeBySeconds(getFormatDateToDate(date), 86399);
    }

    public static String getSpecifiedDateTime_month(Date date) {
        return getFormatDateTime(date, "MM.dd");
    }

    public static String getDiffStringDate(Date date, int i) {
        Calendar calendar = Calendar.getInstance();
        if (date == null) {
            calendar.setTime(new Date());
        } else {
            calendar.setTime(date);
        }
        calendar.add(5, i);
        return dtSimpleFormat(calendar.getTime());
    }

    public static final String dtSimpleFormat(Date date) {
        return date == null ? "" : getFormat("yyyy-MM-dd").format(date);
    }

    private static final DateFormat getFormat(String str) {
        return new SimpleDateFormat(str, locale);
    }

    public static int maxContinuousDays(Date[][] dateArr) {
        for (int i = 0; i < dateArr.length - 1; i++) {
            int i2 = 0;
            while (true) {
                int i3 = i2;
                if (i3 < (dateArr.length - i) - 1) {
                    int i4 = i3 + 1;
                    if (getDaysBetweenDates(dateArr[i4][0], dateArr[i3][0]) > 0) {
                        Date[] dateArr2 = dateArr[i3];
                        dateArr[i3] = dateArr[i4];
                        dateArr[i4] = dateArr2;
                    }
                    i2 = i4;
                }
            }
        }
        int i5 = 0;
        Date[][] dateArr3 = new Date[dateArr.length][2];
        for (int i6 = 0; i6 < dateArr3.length && i5 < dateArr.length; i6++) {
            dateArr3[i6] = dateArr[i5];
            i5++;
            while (i5 < dateArr.length && getDaysBetweenDates(dateArr3[i6][1], dateArr[i5][0]) <= 0) {
                if (getDaysBetweenDates(dateArr3[i6][1], dateArr[i5][1]) > 0) {
                    dateArr3[i6][1] = dateArr[i5][1];
                    i5++;
                } else if (getDaysBetweenDates(dateArr3[i6][1], dateArr[i5][1]) <= 0) {
                    i5++;
                }
            }
        }
        int i7 = 0;
        int i8 = 0;
        while (i8 < dateArr3.length - 1) {
            Date date = dateArr3[i8][1];
            int i9 = i8 + 1;
            i8 = i9;
            Date date2 = dateArr3[i9][0];
            if (date == null || date2 == null) {
                break;
            }
            int daysBetweenDates = getDaysBetweenDates(date, date2);
            int i10 = daysBetweenDates;
            if (daysBetweenDates <= i7) {
                i10 = i7;
            }
            i7 = i10;
        }
        return i7;
    }

    public static int maxContinuousDays(String str) {
        String[] strArrSplit = str.split(";");
        Date[][] dateArr = new Date[strArrSplit.length][2];
        for (int i = 0; i < strArrSplit.length; i++) {
            String[] strArrSplit2 = strArrSplit[i].split(",");
            dateArr[i][0] = getFormatDate(strArrSplit2[0]);
            dateArr[i][1] = getFormatDate(strArrSplit2[1]);
        }
        return maxContinuousDays(dateArr);
    }

    public static boolean isConfilct(String str, String str2, String str3, String str4) {
        Date formatDate = getFormatDate(str);
        Date formatDate2 = getFormatDate(str2);
        Date formatDate3 = getFormatDate(str3);
        Date formatDate4 = getFormatDate(str4);
        if (formatDate.compareTo(formatDate3) <= 0 && formatDate2.compareTo(formatDate3) >= 0) {
            return true;
        }
        if (formatDate.compareTo(formatDate4) <= 0 && formatDate2.compareTo(formatDate4) >= 0) {
            return true;
        }
        if (formatDate3.compareTo(formatDate) > 0 || formatDate4.compareTo(formatDate) < 0) {
            return formatDate3.compareTo(formatDate2) <= 0 && formatDate4.compareTo(formatDate2) >= 0;
        }
        return true;
    }

    public static void main(String[] strArr) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.text.SimpleDateFormat] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.text.ParseException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    public static String getHourAndMinutes(String str) {
        Locale locale2 = locale;
        ?? simpleDateFormat = new SimpleDateFormat("H:ss", locale2);
        try {
            simpleDateFormat = simpleDateFormat.format(new SimpleDateFormat("yyyy-MM-dd HH:ss", locale2).parse(str));
            return simpleDateFormat;
        } catch (ParseException unused) {
            simpleDateFormat.printStackTrace();
            return null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.text.ParseException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.Calendar] */
    public static Calendar getCalendar(String str, String str2) {
        ?? calendar = 0;
        Calendar calendar2 = null;
        try {
            calendar = Calendar.getInstance();
            calendar2 = calendar;
            calendar.setTime(new SimpleDateFormat(str2, locale).parse(str));
        } catch (ParseException unused) {
            calendar.printStackTrace();
        }
        return calendar2;
    }

    public static List<String> ThisWeekDay() {
        ArrayList arrayList = new ArrayList();
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
        calendar.set(7, 2);
        arrayList.add(simpleDateFormat.format(calendar.getTime()));
        calendar.set(7, 1);
        calendar.add(3, 1);
        arrayList.add(simpleDateFormat.format(calendar.getTime()));
        return arrayList;
    }

    public static List<String> ThisMonth() {
        ArrayList arrayList = new ArrayList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
        Calendar calendar = Calendar.getInstance();
        calendar.set(5, 1);
        arrayList.add(simpleDateFormat.format(calendar.getTime()));
        calendar.add(2, 1);
        calendar.set(5, -1);
        arrayList.add(simpleDateFormat.format(calendar.getTime()));
        return arrayList;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.text.SimpleDateFormat] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.text.ParseException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    public static String getCurrentDate(String str, String str2) {
        Locale locale2 = locale;
        ?? simpleDateFormat = new SimpleDateFormat(str, locale2);
        try {
            simpleDateFormat = simpleDateFormat.format(new SimpleDateFormat("yyyy-MM-dd", locale2).parse(str2));
            return simpleDateFormat;
        } catch (ParseException unused) {
            simpleDateFormat.printStackTrace();
            return null;
        }
    }

    private Date getTermDate(int i, int i2) {
        new GregorianCalendar(TimeZone.getTimeZone("GMT")).set(1900, 0, 6, 2, 5, 0);
        return new Date((long) (((i - 1900) * 3.15569259747E10d) + (this.mTermInfo[i2] * 60000) + r0.getTimeInMillis()));
    }

    public static Calendar addDay(int i, int i2, int i3, int i4) {
        Calendar calendarByTime = getCalendarByTime(i, i2, i3);
        calendarByTime.add(5, i4);
        return calendarByTime;
    }

    public static Calendar getCalendarByTime(int i, int i2, int i3) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(1, i + 2000);
        calendar.set(2, i2 - 1);
        calendar.set(5, i3);
        return calendar;
    }

    public static Calendar getCalendarByTime(int i, int i2, int i3, int i4, int i5, int i6) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(1, i + 2000);
        calendar.set(2, i2 - 1);
        calendar.set(5, i3);
        calendar.set(11, i4);
        calendar.set(12, i5);
        calendar.set(13, i6);
        return calendar;
    }
}
