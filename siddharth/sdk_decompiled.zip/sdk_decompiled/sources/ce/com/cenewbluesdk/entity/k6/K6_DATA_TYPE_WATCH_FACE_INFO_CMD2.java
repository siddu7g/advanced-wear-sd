package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.util.Arrays;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_WATCH_FACE_INFO_CMD2.class */
public class K6_DATA_TYPE_WATCH_FACE_INFO_CMD2 implements Serializable {
    int time_pos;
    int time_up;
    int time_down;
    int color;
    int picture;
    byte[] pictrueArrs;

    public K6_DATA_TYPE_WATCH_FACE_INFO_CMD2() {
    }

    public K6_DATA_TYPE_WATCH_FACE_INFO_CMD2(byte[] bArr) {
        processBytes(bArr);
    }

    public K6_DATA_TYPE_WATCH_FACE_INFO_CMD2(int i, int i2, int i3, int i4, int i5, byte[] bArr) {
        this.time_pos = i;
        this.time_up = i2;
        this.time_down = i3;
        this.color = i4;
        this.picture = i5;
        this.pictrueArrs = bArr;
    }

    public int sizeWithOutpic() {
        return 6;
    }

    public void processBytes(byte[] bArr) {
        this.time_pos = bArr[0];
        this.time_up = bArr[1];
        this.time_down = bArr[2];
        this.color = ByteUtil.byte2ToInt(new byte[]{bArr[3], bArr[4]});
        this.picture = bArr[5];
    }

    public int getTime_pos() {
        return this.time_pos;
    }

    public void setTime_pos(int i) {
        this.time_pos = i;
    }

    public int getTime_up() {
        return this.time_up;
    }

    public void setTime_up(int i) {
        this.time_up = i;
    }

    public int getTime_down() {
        return this.time_down;
    }

    public void setTime_down(int i) {
        this.time_down = i;
    }

    public int getColor() {
        return this.color;
    }

    public void setColor(int i) {
        this.color = i;
    }

    public int getPicture() {
        return this.picture;
    }

    public void setPicture(int i) {
        this.picture = i;
    }

    public byte[] getPictrueArrs() {
        return this.pictrueArrs;
    }

    public void setPictrueArrs(byte[] bArr) {
        this.pictrueArrs = bArr;
    }

    public String toString() {
        return "K6_DATA_TYPE_WATCH_FACE_INFO_CMD2{time_pos=" + this.time_pos + ", time_up=" + this.time_up + ", time_down=" + this.time_down + ", color=" + this.color + ", picture=" + this.picture + ", pictrueArrs=" + Arrays.toString(this.pictrueArrs) + '}';
    }
}
