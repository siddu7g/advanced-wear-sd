package ce.com.cenewbluesdk.entity;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/ModifyWatchInfo.class */
public class ModifyWatchInfo {
    private int time_pos;
    private int time_up;
    private int time_down;
    private int color;
    private int switch_mode;
    private int switch_time = 1;
    private int time_x;
    private int time_y;
    private String filePath;
    private String savePath;
    private boolean isChange;
    private int faceType;

    public int getFaceType() {
        return this.faceType;
    }

    public void setFaceType(int i) {
        this.faceType = i;
    }

    public int getSwitch_mode() {
        return this.switch_mode;
    }

    public void setSwitch_mode(int i) {
        this.switch_mode = i;
    }

    public int getSwitch_time() {
        return this.switch_time;
    }

    public void setSwitch_time(int i) {
        this.switch_time = i;
    }

    public int getTime_x() {
        return this.time_x;
    }

    public void setTime_x(int i) {
        this.time_x = i;
    }

    public int getTime_y() {
        return this.time_y;
    }

    public void setTime_y(int i) {
        this.time_y = i;
    }

    public boolean isChange() {
        return this.isChange;
    }

    public void setChange(boolean z) {
        this.isChange = z;
    }

    public String getSavePath() {
        return this.savePath;
    }

    public void setSavePath(String str) {
        this.savePath = str;
    }

    public int getTime_pos() {
        return this.time_pos;
    }

    public void setTime_pos(int i) {
        this.time_pos = i;
    }

    public int getTime_up() {
        return this.time_up;
    }

    public void setTime_up(int i) {
        this.time_up = i;
    }

    public int getTime_down() {
        return this.time_down;
    }

    public void setTime_down(int i) {
        this.time_down = i;
    }

    public int getColor() {
        return this.color;
    }

    public void setColor(int i) {
        this.color = i;
    }

    public String getFilePath() {
        return this.filePath;
    }

    public void setFilePath(String str) {
        this.filePath = str;
    }

    public String toString() {
        return "ModifyWatchInfo{time_pos=" + this.time_pos + ", time_up=" + this.time_up + ", time_down=" + this.time_down + ", color=" + this.color + ", filePath='" + this.filePath + "'}";
    }
}
