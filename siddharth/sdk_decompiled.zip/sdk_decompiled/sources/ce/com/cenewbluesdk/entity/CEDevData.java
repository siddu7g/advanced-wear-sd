package ce.com.cenewbluesdk.entity;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/CEDevData.class */
public class CEDevData implements Comparable<CEDevData> {
    int pid;
    int cmd;
    int dataType;
    int itemL;
    int itemNumber;
    byte[] data;
    byte[] otherData;
    int dataCrc16;
    int currentIndex;
    int totalIndex;
    int N;
    protected int priority = 0;

    public CEDevData() {
    }

    public CEDevData(int i, int i2) {
        this.cmd = i;
        this.dataType = i2;
    }

    public int getPid() {
        return this.pid;
    }

    public void setPid(int i) {
        this.pid = i;
    }

    public int getCmd() {
        return this.cmd;
    }

    public void setCmd(int i) {
        this.cmd = i;
    }

    public int getDataType() {
        return this.dataType;
    }

    public void setDataType(int i) {
        this.dataType = i;
    }

    public int getItemL() {
        return this.itemL;
    }

    public void setItemL(int i) {
        this.itemL = i;
    }

    public int getItemNumber() {
        return this.itemNumber;
    }

    public void setItemNumber(int i) {
        this.itemNumber = i;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] bArr) {
        this.data = bArr;
    }

    public byte[] getOtherData() {
        return this.otherData;
    }

    public void setOtherData(byte[] bArr) {
        this.otherData = bArr;
    }

    public int getDataCrc16() {
        return this.dataCrc16;
    }

    public void setDataCrc16(int i) {
        this.dataCrc16 = i;
    }

    public int figureCrc16() {
        return 0;
    }

    public int getN() {
        return this.N;
    }

    public void setN(int i) {
        this.N = i;
    }

    public int getCurrentIndex() {
        return this.currentIndex;
    }

    public void setCurrentIndex(int i) {
        this.currentIndex = i;
    }

    public int getTotalIndex() {
        return this.totalIndex;
    }

    public void setTotalIndex(int i) {
        this.totalIndex = i;
    }

    public int getPriority() {
        return this.priority;
    }

    public void setPriority(int i) {
        this.priority = i;
    }

    @Override // java.lang.Comparable
    public int compareTo(CEDevData cEDevData) {
        if (cEDevData == null) {
            Lg.e("compareTo -1");
            return -1;
        }
        int i = this.priority;
        int i2 = cEDevData.priority;
        if (i > i2) {
            Lg.e("compareTo -1");
            return -1;
        }
        if (i < i2) {
            Lg.e("compareTo 1");
            return 1;
        }
        Lg.e("compareTo 0");
        return 0;
    }

    public int getRealCMD(int i) {
        return (i ^ (-1)) - 1;
    }

    public String toString() {
        return "CEDevData{cmd=" + this.cmd + ", dataType=" + (this.dataType & 255) + ", itemL=" + this.itemL + ", itemNumber=" + this.itemNumber + ", data=" + ByteUtil.byte2hex(this.data) + ", otherData=" + ByteUtil.byte2hex(this.otherData) + ", dataCrc16=" + this.dataCrc16 + ", currentIndex=" + this.currentIndex + ", totalIndex=" + this.totalIndex + ", priority=" + this.priority + '}';
    }
}
