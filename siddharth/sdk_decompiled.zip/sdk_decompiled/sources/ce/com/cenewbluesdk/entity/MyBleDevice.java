package ce.com.cenewbluesdk.entity;

import android.bluetooth.BluetoothDevice;
import ce.com.cenewbluesdk.scan.K6ManufacturerInfo;
import java.io.Serializable;
import java.util.Objects;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/MyBleDevice.class */
public class MyBleDevice implements Serializable {
    private BluetoothDevice mBluetoothDevice;
    private K6ManufacturerInfo mK6ManufacturerInfo;
    private String name;
    private String macId;
    private int rssi;
    private int leakType;
    private int greenLightV;
    private int redLightV;
    private int infraredV;
    private int testResults = 1;
    private int wearingThresholdHr;
    private int wearingThresholdOb;
    private int thresholdRelease;
    private boolean isSelected;

    public MyBleDevice(BluetoothDevice bluetoothDevice, K6ManufacturerInfo k6ManufacturerInfo, String str, int i) {
        this.mBluetoothDevice = bluetoothDevice;
        this.mK6ManufacturerInfo = k6ManufacturerInfo;
        this.name = str;
        this.rssi = i;
    }

    public MyBleDevice(BluetoothDevice bluetoothDevice, K6ManufacturerInfo k6ManufacturerInfo, String str, String str2, int i) {
        this.mBluetoothDevice = bluetoothDevice;
        this.mK6ManufacturerInfo = k6ManufacturerInfo;
        this.name = str;
        this.rssi = i;
        this.macId = str2;
    }

    public BluetoothDevice getmBluetoothDevice() {
        return this.mBluetoothDevice;
    }

    public K6ManufacturerInfo getmK6ManufacturerInfo() {
        return this.mK6ManufacturerInfo;
    }

    public String getName() {
        return this.name;
    }

    public int getRssi() {
        return this.rssi;
    }

    public String getMacId() {
        return this.macId;
    }

    public void setMacId(String str) {
        this.macId = str;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public int getGreenLightV() {
        return this.greenLightV;
    }

    public void setGreenLightV(int i) {
        this.greenLightV = i;
    }

    public int getRedLightV() {
        return this.redLightV;
    }

    public void setRedLightV(int i) {
        this.redLightV = i;
    }

    public int getInfraredV() {
        return this.infraredV;
    }

    public void setInfraredV(int i) {
        this.infraredV = i;
    }

    public int getTestResults() {
        return this.testResults;
    }

    public void setTestResults(int i) {
        this.testResults = i;
    }

    public int getWearingThresholdHr() {
        return this.wearingThresholdHr;
    }

    public void setWearingThresholdHr(int i) {
        this.wearingThresholdHr = i;
    }

    public int getWearingThresholdOb() {
        return this.wearingThresholdOb;
    }

    public void setWearingThresholdOb(int i) {
        this.wearingThresholdOb = i;
    }

    public int getThresholdRelease() {
        return this.thresholdRelease;
    }

    public void setThresholdRelease(int i) {
        this.thresholdRelease = i;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.macId, ((MyBleDevice) obj).macId);
    }

    public int hashCode() {
        return Objects.hash(this.macId);
    }
}
