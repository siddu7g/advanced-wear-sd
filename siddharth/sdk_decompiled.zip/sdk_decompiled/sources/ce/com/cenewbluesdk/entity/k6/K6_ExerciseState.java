package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_ExerciseState.class */
public class K6_ExerciseState implements Serializable {
    public static final int sportState_null = 0;
    public static final int sportState_start = 1;
    public static final int sportState_pause = 2;
    public static final int sportState_continue = 3;
    public static final int sportState_stop_force = 4;
    private int sportType;
    private int value;
    private int startTime;
    private int totalTime;

    public K6_ExerciseState(byte[] bArr) {
        this.sportType = bArr[0];
        this.value = bArr[1];
        this.startTime = ByteUtil.byte4ToInt(new byte[]{bArr[2], bArr[3], bArr[4], bArr[5]});
        this.totalTime = ByteUtil.byte4ToInt(new byte[]{bArr[6], bArr[7], bArr[8], bArr[9]});
    }

    public K6_ExerciseState(int i, int i2) {
        this.sportType = i;
        this.value = i2;
        this.startTime = 0;
        this.totalTime = 0;
    }

    public static int getItemSize() {
        return 10;
    }

    public byte[] getSendByte() {
        return new byte[]{(byte) this.sportType, (byte) this.value, 0, 0, 0, 0, 0, 0, 0, 0};
    }

    public int getSportType() {
        return this.sportType;
    }

    public void setSportType(int i) {
        this.sportType = i;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int i) {
        this.value = i;
    }

    public int getStartTime() {
        return this.startTime;
    }

    public void setStartTime(int i) {
        this.startTime = i;
    }

    public int getTotalTime() {
        return this.totalTime;
    }

    public void setTotalTime(int i) {
        this.totalTime = i;
    }

    public String toString() {
        return "K6_ExerciseState{sportType=" + this.sportType + ", value=" + this.value + ", startTime=" + this.startTime + ", totalTime=" + this.totalTime + '}';
    }
}
