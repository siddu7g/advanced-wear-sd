package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_GPS.class */
public class K6_GPS implements Serializable {
    private long time;
    private double longitude;
    private int lonTag;
    private double latitude;
    private int latTag;
    private double speed;

    public K6_GPS(byte[] bArr) {
        int i = bArr[3] & 255;
        int i2 = i;
        this.longitude = ByteUtil.byteToInt(bArr[0], bArr[1], bArr[2], (byte) (i >= 128 ? i2 - 128 : i2)) / 100000.0d;
        this.lonTag = bArr[3] & 128;
        int i3 = bArr[7] & 255;
        int i4 = i3;
        this.latitude = ByteUtil.byteToInt(bArr[4], bArr[5], bArr[6], (byte) (i3 >= 128 ? i4 - 128 : i4)) / 100000.0d;
        this.latTag = bArr[7] & 128;
        this.speed = ByteUtil.byteToInt(bArr[8], bArr[9]) / 100.0d;
        this.time = ByteUtil.byte4ToInt(new byte[]{bArr[10], bArr[11], bArr[12], bArr[13]});
    }

    public static int getItemSize() {
        return 14;
    }

    public long getTime() {
        return this.time;
    }

    public double getLongitude() {
        return this.longitude;
    }

    public int getLonTag() {
        return this.lonTag;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public int getLatTag() {
        return this.latTag;
    }

    public double getSpeed() {
        return this.speed;
    }
}
