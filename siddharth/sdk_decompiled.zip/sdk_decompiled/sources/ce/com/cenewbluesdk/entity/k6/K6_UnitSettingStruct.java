package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_UnitSettingStruct.class */
public class K6_UnitSettingStruct extends BaseData implements Serializable {
    private int mWeightUnit;
    private int mDistanceUnit;
    private int mWeatherUnit;

    public K6_UnitSettingStruct(int i, int i2, int i3) {
        this.mWeightUnit = i;
        this.mDistanceUnit = i2;
        this.mWeatherUnit = i3;
    }

    public K6_UnitSettingStruct(byte[] bArr) {
        this.mWeightUnit = bArr[0] & 15;
        this.mDistanceUnit = (bArr[0] >> 4) & 15;
        this.mWeatherUnit = bArr[1] & 15;
    }

    public int getmWeightUnit() {
        return this.mWeightUnit;
    }

    public void setmWeightUnit(int i) {
        this.mWeightUnit = i;
    }

    public int getmDistanceUnit() {
        return this.mDistanceUnit;
    }

    public void setmDistanceUnit(int i) {
        this.mDistanceUnit = i;
    }

    public int getmWeatherUnit() {
        return this.mWeatherUnit;
    }

    public void setmWeatherUnit(int i) {
        this.mWeatherUnit = i;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[8];
        bArr[0] = (byte) ((this.mWeightUnit ^ (this.mDistanceUnit << 4)) & 255);
        bArr[1] = (byte) this.mWeatherUnit;
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData(1, 121);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(8);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }

    public String toString() {
        return "weightUnit " + this.mWeightUnit + " LenghtUnit " + this.mDistanceUnit + " mWeatherUnit " + this.mWeatherUnit;
    }
}
