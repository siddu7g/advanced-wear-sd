package ce.com.cenewbluesdk.entity.k6;

import android.os.Parcel;
import android.os.Parcelable;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_PairStruct.class */
public class K6_PairStruct extends BaseData implements Parcelable {
    public static final Parcelable.Creator<K6_PairStruct> CREATOR = new Parcelable.Creator<K6_PairStruct>() { // from class: ce.com.cenewbluesdk.entity.k6.K6_PairStruct.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public K6_PairStruct createFromParcel(Parcel parcel) {
            return new K6_PairStruct(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public K6_PairStruct[] newArray(int i) {
            return new K6_PairStruct[i];
        }
    };
    byte phone_type;
    byte pair_type;
    int status;
    boolean hasDevice;
    String devName;

    public K6_PairStruct(int i, int i2) {
        this.phone_type = (byte) (i & 255);
        this.pair_type = (byte) (i2 & 255);
    }

    protected K6_PairStruct(Parcel parcel) {
        this.phone_type = parcel.readByte();
        this.pair_type = parcel.readByte();
    }

    public static int getItemSize() {
        return 3;
    }

    public int getStatus() {
        return this.status;
    }

    public void setStatus(int i) {
        this.status = i;
    }

    public boolean isHasDevice() {
        return this.hasDevice;
    }

    public void setHasDevice(boolean z) {
        this.hasDevice = z;
    }

    public String getDevName() {
        return this.devName;
    }

    public void setDevName(String str) {
        this.devName = str;
    }

    public byte[] getBytes() {
        return new byte[]{this.phone_type, this.pair_type};
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.phone_type);
        parcel.writeByte(this.pair_type);
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(70);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(2);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
