package ce.com.cenewbluesdk.entity.k6;

import android.text.TextUtils;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Logger;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendCurrentLocationInfo.class */
public class K6_SendCurrentLocationInfo extends BaseData implements Serializable {
    private String locality;
    private String countryCode;
    private double lon;
    private double lat;

    private byte[] getLocalityData() {
        byte[] bArr = new byte[40];
        if (TextUtils.isEmpty(this.locality)) {
            this.locality = "龙华区";
        }
        String strTruncateString = ByteUtil.truncateString(this.locality, 255);
        if (!TextUtils.isEmpty(strTruncateString)) {
            byte[] bytes = strTruncateString.getBytes(StandardCharsets.UTF_8);
            System.arraycopy(bytes, 0, bArr, 0, bytes.length);
        }
        return bArr;
    }

    public String getLocality() {
        return this.locality;
    }

    public void setLocality(String str) {
        this.locality = str;
    }

    public String getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(String str) {
        this.countryCode = str;
    }

    public double getLon() {
        return this.lon;
    }

    public void setLon(double d) {
        this.lon = d;
    }

    public double getLat() {
        return this.lat;
    }

    public void setLat(double d) {
        this.lat = d;
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[getItemSize()];
        byte[] localityData = getLocalityData();
        int i = (int) (this.lon * 1000000.0d);
        int i2 = (int) (this.lat * 1000000.0d);
        byte[] bArrIntToByte4 = ByteUtil.intToByte4(i);
        byte[] bArrIntToByte42 = ByteUtil.intToByte4(i2);
        System.arraycopy(bArrIntToByte4, 0, bArr, 0, bArrIntToByte4.length);
        System.arraycopy(bArrIntToByte42, 0, bArr, 4, bArrIntToByte42.length);
        System.arraycopy(localityData, 0, bArr, 8, localityData.length);
        return bArr;
    }

    public int getItemSize() {
        return 48;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        Logger.i("CHENGUIRUI", "c-25");
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(CEBC.K6.DATA_TYPE_CURRENT_LOCATION);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
