package ce.com.cenewbluesdk.entity.k6;

import android.text.TextUtils;
import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_AI_INFO.class */
public class K6_DATA_TYPE_AI_INFO extends BaseData implements Serializable {
    public static int DT_AI_CMD_NONE = 0;
    public static int DT_AI_CMD_START = 1;
    public static int DT_AI_CMD_START_IND = 2;
    public static int DT_AI_CMD_STOP = 3;
    public static int DT_AI_CMD_STOP_IND = 4;
    public static int DT_AI_CMD_I_INFO = 5;
    public static int DT_AI_CMD_AI_INFO = 6;
    private int mainCMD;
    private int cmd_type;
    private int dat_len;
    private byte[] data;
    private String content;
    private String iSpeak;
    private String aiSpeak;

    private byte[] getBytes() {
        byte[] contentData;
        byte[] bArr = new byte[getItemSize()];
        int i = this.cmd_type;
        bArr[0] = (byte) i;
        if (i == DT_AI_CMD_START_IND || i == DT_AI_CMD_STOP_IND) {
            bArr[1] = 0;
        } else if ((i == DT_AI_CMD_I_INFO || i == DT_AI_CMD_AI_INFO) && (contentData = getContentData(i)) != null) {
            bArr[1] = (byte) contentData.length;
            System.arraycopy(contentData, 0, bArr, 2, contentData.length);
        }
        return bArr;
    }

    private byte[] getContentData(int i) {
        this.content = "";
        if (i == DT_AI_CMD_I_INFO) {
            if (!TextUtils.isEmpty(this.iSpeak)) {
                this.content = this.iSpeak;
            }
        } else if (i == DT_AI_CMD_AI_INFO && !TextUtils.isEmpty(this.aiSpeak)) {
            this.content = this.aiSpeak;
        }
        this.content.replaceAll(" ", "").replaceAll("\n", "");
        String strTruncateString = ByteUtil.truncateString(this.content, 249);
        this.content = strTruncateString;
        if (!TextUtils.isEmpty(strTruncateString)) {
            this.data = this.content.getBytes(StandardCharsets.UTF_8);
        }
        return this.data;
    }

    public String getiSpeak() {
        return this.iSpeak;
    }

    public void setiSpeak(String str) {
        this.iSpeak = str;
    }

    public String getAiSpeak() {
        return this.aiSpeak;
    }

    public void setAiSpeak(String str) {
        this.aiSpeak = str;
    }

    public int getMainCMD() {
        return this.mainCMD;
    }

    public void setMainCMD(int i) {
        this.mainCMD = i;
    }

    public int getCmd_type() {
        return this.cmd_type;
    }

    public void setCmd_type(int i) {
        this.cmd_type = i;
    }

    public int getDat_len() {
        return this.dat_len;
    }

    public void setDat_len(int i) {
        this.dat_len = i;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] bArr) {
        this.data = bArr;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public int getItemSize() {
        byte[] contentData;
        int i = this.cmd_type;
        if (i == DT_AI_CMD_START_IND || i == DT_AI_CMD_STOP_IND) {
            return 2;
        }
        if ((i == DT_AI_CMD_AI_INFO || i == DT_AI_CMD_I_INFO) && (contentData = getContentData(i)) != null) {
            return contentData.length + 2;
        }
        return 2;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(this.mainCMD);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
