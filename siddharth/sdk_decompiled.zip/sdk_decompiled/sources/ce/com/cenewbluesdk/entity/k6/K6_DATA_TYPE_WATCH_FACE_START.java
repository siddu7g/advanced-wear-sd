package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_DATA_TYPE_WATCH_FACE_START.class */
public class K6_DATA_TYPE_WATCH_FACE_START extends BaseData implements Serializable {
    private boolean timeOut;

    public boolean isTimeOut() {
        return this.timeOut;
    }

    public void setTimeOut(boolean z) {
        this.timeOut = z;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(134);
        cEDevData.setData(null);
        cEDevData.setItemL(0);
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
