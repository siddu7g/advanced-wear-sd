package ce.com.cenewbluesdk.entity.k6;

import ce.com.cenewbluesdk.entity.BaseData;
import ce.com.cenewbluesdk.entity.CEDevData;
import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/entity/k6/K6_SendRealTimeWeather.class */
public class K6_SendRealTimeWeather extends BaseData implements Serializable {
    private byte weather;
    private byte temperature;
    private byte windScale;
    private byte humidity;

    public K6_SendRealTimeWeather() {
    }

    public K6_SendRealTimeWeather(int i, int i2, int i3, int i4) {
        this.weather = (byte) (i & 255);
        this.temperature = (byte) (i2 & 255);
        this.windScale = (byte) (i3 & 255);
        this.humidity = (byte) (i4 & 255);
    }

    public static int getItemSize() {
        return 10;
    }

    public byte getWeather() {
        return this.weather;
    }

    public void setWeather(byte b) {
        this.weather = b;
    }

    public byte getTemperature() {
        return this.temperature;
    }

    public void setTemperature(byte b) {
        this.temperature = b;
    }

    public byte getWindScale() {
        return this.windScale;
    }

    public void setWindScale(byte b) {
        this.windScale = b;
    }

    public byte getHumidity() {
        return this.humidity;
    }

    public void setHumidity(byte b) {
        this.humidity = b;
    }

    public String toString() {
        return "K6_SendRealTimeWeather{weather=" + ((int) this.weather) + ", temperature=" + ((int) this.temperature) + ", windScale=" + ((int) this.windScale) + ", humidity=" + ((int) this.humidity) + '}';
    }

    public byte[] getBytes() {
        byte[] bArr = new byte[10];
        bArr[0] = this.weather;
        bArr[1] = this.temperature;
        bArr[2] = this.windScale;
        bArr[3] = this.humidity;
        return bArr;
    }

    @Override // ce.com.cenewbluesdk.entity.BaseData
    public CEDevData toCEDevData() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(139);
        cEDevData.setData(getBytes());
        cEDevData.setItemL(getItemSize());
        cEDevData.setItemNumber(1);
        return cEDevData;
    }
}
