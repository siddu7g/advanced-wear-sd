package ce.com.cenewbluesdk.a;

/* loaded from: classes.jar:ce/com/cenewbluesdk/a/a.class */
public interface a {
    int d();

    long c();

    void b();

    void e();

    boolean a();

    void g();

    void f();
}
