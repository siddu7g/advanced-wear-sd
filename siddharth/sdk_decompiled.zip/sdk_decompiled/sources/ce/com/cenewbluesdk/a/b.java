package ce.com.cenewbluesdk.a;

/* loaded from: classes.jar:ce/com/cenewbluesdk/a/b.class */
public class b implements a {

    /* renamed from: a, reason: collision with root package name */
    private final int f3a = 5;
    private int b = 5;
    private int c = 0;
    private long[] d = {2000, 5000, 5000, 5000};

    @Override // ce.com.cenewbluesdk.a.a
    public int d() {
        return this.c;
    }

    @Override // ce.com.cenewbluesdk.a.a
    public long c() {
        int i = this.c / 10;
        int i2 = i;
        if (i > 3) {
            i2 = 3;
        }
        return this.d[i2];
    }

    @Override // ce.com.cenewbluesdk.a.a
    public void b() {
        this.c = 0;
    }

    @Override // ce.com.cenewbluesdk.a.a
    public void e() {
        this.c++;
    }

    @Override // ce.com.cenewbluesdk.a.a
    public boolean a() {
        int i = this.b - 1;
        this.b = i;
        return i >= 0;
    }

    @Override // ce.com.cenewbluesdk.a.a
    public void g() {
        this.b = 5;
    }

    @Override // ce.com.cenewbluesdk.a.a
    public void f() {
        this.b = -1;
    }
}
