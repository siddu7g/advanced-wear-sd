package ce.com.cenewbluesdk.scan;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import ce.com.cenewbluesdk.scan.CEScanDevBase;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;

/* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDev_3.class */
public class CEScanDev_3 extends CEScanDevBase {
    private static final String name = "CEScanDev_3";
    private BluetoothAdapter mAdapter;
    private boolean haveRegisterBroad;
    Handler handler;
    IntentFilter filter;
    private BroadcastReceiver mReceiver;
    StopScanRun stopScanRun;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDev_3$StopScanRun.class */
    class StopScanRun implements Runnable {
        StopScanRun() {
        }

        @Override // java.lang.Runnable
        public void run() {
            CEScanDev_3.this.stopScan();
        }
    }

    public CEScanDev_3(Context context, CEScanDevBase.FindBlueTooth findBlueTooth) {
        super(context, findBlueTooth);
        this.haveRegisterBroad = false;
        this.handler = new Handler();
        this.mReceiver = new BroadcastReceiver() { // from class: ce.com.cenewbluesdk.scan.CEScanDev_3.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context2, Intent intent) {
                String action = intent.getAction();
                action.hashCode();
                if (action.equals("android.bluetooth.device.action.FOUND")) {
                    CEScanDev_3.this.findDev((BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE"), intent.getShortExtra("android.bluetooth.device.extra.RSSI", (short) 0), null);
                }
            }
        };
        this.stopScanRun = new StopScanRun();
        this.mAdapter = BleSystemUtils.getBluetoothAdapter(context);
        IntentFilter intentFilter = new IntentFilter();
        this.filter = intentFilter;
        intentFilter.addAction("android.bluetooth.device.action.FOUND");
        this.filter.addAction("android.bluetooth.adapter.action.DISCOVERY_STARTED");
        this.filter.addAction("android.bluetooth.adapter.action.DISCOVERY_FINISHED");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0069 A[Catch: all -> 0x007e, LOOP:0: B:16:0x0060->B:18:0x0069, LOOP_END, TRY_ENTER, TryCatch #1 {, blocks: (B:4:0x0006, B:6:0x000c, B:7:0x0012, B:8:0x0015, B:9:0x001b, B:11:0x0027, B:12:0x002a, B:13:0x0046, B:14:0x004d, B:15:0x0054, B:16:0x0060, B:18:0x0069, B:20:0x007c), top: B:27:0x0006, inners: #0 }] */
    /* JADX WARN: Type inference failed for: r0v0, types: [ce.com.cenewbluesdk.scan.CEScanDev_3] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v11, types: [ce.com.cenewbluesdk.scan.CEScanDevBase, ce.com.cenewbluesdk.scan.CEScanDev_3, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9 */
    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void startScan() {
        /*
            r8 = this;
            r0 = r8
            java.lang.String r1 = "CEScanDev_3"
            r2 = r1
            r9 = r2
            monitor-enter(r1)
            boolean r0 = r0.haveRegisterBroad     // Catch: java.lang.Throwable -> L7e
            if (r0 != 0) goto L2a
            r0 = r8
            r1 = r0
            r2 = 1
            r1.haveRegisterBroad = r2     // Catch: java.lang.Throwable -> L7e
            android.content.Context r0 = r0.mContext     // Catch: java.lang.Exception -> L27 java.lang.Throwable -> L7e java.lang.Throwable -> L7e
            r1 = r8
            r2 = r1
            android.content.BroadcastReceiver r2 = r2.mReceiver     // Catch: java.lang.Exception -> L27 java.lang.Throwable -> L7e
            r10 = r2
            android.content.IntentFilter r1 = r1.filter     // Catch: java.lang.Exception -> L27 java.lang.Throwable -> L7e
            r2 = r10
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.Exception -> L27 java.lang.Throwable -> L7e
            android.content.Intent r0 = r0.registerReceiver(r1, r2)     // Catch: java.lang.Exception -> L27 java.lang.Throwable -> L7e
            goto L2a
        L27:
            r0.printStackTrace()     // Catch: java.lang.Throwable -> L7e
        L2a:
            r0 = r8
            r1 = r0
            r2 = r1
            r3 = r1; r4 = r2;      // Catch: java.lang.Throwable -> L7e
            android.os.Handler r4 = r4.handler     // Catch: java.lang.Throwable -> L7e
            r5 = r8
            ce.com.cenewbluesdk.scan.CEScanDev_3$StopScanRun r5 = r5.stopScanRun     // Catch: java.lang.Throwable -> L7e
            r4.removeCallbacks(r5)     // Catch: java.lang.Throwable -> L7e
            android.os.Handler r3 = r3.handler     // Catch: java.lang.Throwable -> L7e
            r4 = r8
            ce.com.cenewbluesdk.scan.CEScanDev_3$StopScanRun r4 = r4.stopScanRun     // Catch: java.lang.Throwable -> L7e
            r5 = 12000(0x2ee0, double:5.929E-320)
            boolean r3 = r3.postDelayed(r4, r5)     // Catch: java.lang.Throwable -> L7e
            android.bluetooth.BluetoothAdapter r2 = r2.mAdapter     // Catch: java.lang.Throwable -> L7e
            boolean r2 = r2.cancelDiscovery()     // Catch: java.lang.Throwable -> L7e
            android.bluetooth.BluetoothAdapter r1 = r1.mAdapter     // Catch: java.lang.Throwable -> L7e
            boolean r1 = r1.startDiscovery()     // Catch: java.lang.Throwable -> L7e
            android.bluetooth.BluetoothAdapter r0 = r0.mAdapter     // Catch: java.lang.Throwable -> L7e
            java.util.Set r0 = r0.getBondedDevices()     // Catch: java.lang.Throwable -> L7e
            java.util.Iterator r0 = r0.iterator()     // Catch: java.lang.Throwable -> L7e
            r10 = r0
        L60:
            r0 = r10
            boolean r0 = r0.hasNext()     // Catch: java.lang.Throwable -> L7e
            if (r0 == 0) goto L7b
            r0 = r8
            r1 = r10
            java.lang.Object r1 = r1.next()     // Catch: java.lang.Throwable -> L7e
            android.bluetooth.BluetoothDevice r1 = (android.bluetooth.BluetoothDevice) r1     // Catch: java.lang.Throwable -> L7e
            r2 = -1
            r3 = 0
            r0.findDev(r1, r2, r3)     // Catch: java.lang.Throwable -> L7e
            goto L60
        L7b:
            r0 = r9
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L7e
            return
        L7e:
            r1 = move-exception
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L7e
            throw r0     // Catch: java.lang.Throwable -> L7e
        */
        throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.scan.CEScanDev_3.startScan():void");
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void startScan_filter(String str) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [ce.com.cenewbluesdk.scan.CEScanDev_3] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r4v0, types: [ce.com.cenewbluesdk.scan.CEScanDevBase, ce.com.cenewbluesdk.scan.CEScanDev_3, java.lang.Exception] */
    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void stopScan() {
        ?? r0 = this;
        synchronized (name) {
            if (r0.haveRegisterBroad) {
                this.haveRegisterBroad = false;
                try {
                    this.mContext.unregisterReceiver(this.mReceiver);
                } catch (Exception unused) {
                    printStackTrace();
                }
            }
            r0 = name;
            this.mAdapter.cancelDiscovery();
        }
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public boolean isBleEnabled() {
        BluetoothAdapter bluetoothAdapter = this.mAdapter;
        if (bluetoothAdapter == null) {
            return false;
        }
        return bluetoothAdapter.isEnabled();
    }
}
