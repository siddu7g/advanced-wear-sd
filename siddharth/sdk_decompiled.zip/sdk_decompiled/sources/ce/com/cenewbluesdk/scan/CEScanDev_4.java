package ce.com.cenewbluesdk.scan;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.os.Handler;
import android.util.Log;
import ce.com.cenewbluesdk.scan.CEScanDevBase;

/* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDev_4.class */
public class CEScanDev_4 extends CEScanDevBase {
    Handler handler;
    private boolean isScan;
    private BluetoothManager manager;
    private BluetoothAdapter adapter;
    private BluetoothAdapter.LeScanCallback startLeScan;
    StopScanRun stopScanRun;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDev_4$StopScanRun.class */
    class StopScanRun implements Runnable {
        StopScanRun() {
        }

        @Override // java.lang.Runnable
        public void run() {
            CEScanDev_4.this.stopScan();
        }
    }

    public CEScanDev_4(Context context, CEScanDevBase.FindBlueTooth findBlueTooth) {
        super(context, findBlueTooth);
        this.handler = new Handler();
        this.startLeScan = new BluetoothAdapter.LeScanCallback() { // from class: ce.com.cenewbluesdk.scan.CEScanDev_4.1
            @Override // android.bluetooth.BluetoothAdapter.LeScanCallback
            public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
                Log.e("qob", "onLeScan " + bluetoothDevice.getName());
                CEScanDev_4.this.findDev(bluetoothDevice, i, bArr);
            }
        };
        this.stopScanRun = new StopScanRun();
        BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService("bluetooth");
        this.manager = bluetoothManager;
        this.adapter = bluetoothManager.getAdapter();
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void startScan() {
        this.handler.removeCallbacks(this.stopScanRun);
        this.handler.postDelayed(this.stopScanRun, 12000L);
        if (this.isScan) {
            return;
        }
        this.isScan = true;
        this.adapter.startLeScan(this.startLeScan);
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void startScan_filter(String str) {
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void stopScan() {
        if (this.isScan) {
            this.isScan = false;
            this.adapter.stopLeScan(this.startLeScan);
        }
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public synchronized boolean isBleEnabled() {
        BluetoothAdapter bluetoothAdapter = this.adapter;
        if (bluetoothAdapter == null) {
            return false;
        }
        return bluetoothAdapter.isEnabled();
    }
}
