package ce.com.cenewbluesdk.scan;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.os.Build;
import android.os.ParcelUuid;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.MyBleDevice;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.scan.CEScanDevBase;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDev_4_Android5.class */
public class CEScanDev_4_Android5 extends CEScanDevBase {
    public static int SCAN_INTERVAL_TIME = 60000;
    boolean isScan;
    private BluetoothManager manager;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeScanner bleScanner;
    private List<MyBleDevice> mDeviceList;
    private boolean isScanFinish;
    private ScanCallback bleScanCallback;
    Comparator comparator;

    private void setScan(boolean z) {
        this.isScan = z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [android.bluetooth.le.ScanResult] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16, types: [ce.com.cenewbluesdk.scan.CEScanDevBase] */
    public void filteringEquipment(int i, ScanResult scanResult) {
        ?? r0 = scanResult;
        boolean z = false;
        try {
            String address = r0.getDevice().getAddress();
            if (r0.getScanRecord().getBytes() == null) {
                return;
            }
            String name = scanResult.getDevice().getName();
            Iterator<MyBleDevice> it = this.mDeviceList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                } else if (it.next().getmBluetoothDevice().getAddress().equals(address)) {
                    z = true;
                    break;
                }
            }
            if (z) {
                return;
            }
            K6ManufacturerInfo k6ManufacturerInfo = K6ManufacturerInfo.parse(scanResult.getScanRecord().getServiceUuids(), scanResult.getScanRecord().getManufacturerSpecificData());
            if (k6ManufacturerInfo != null && k6ManufacturerInfo.pid > 0) {
                Log.i("discovered bluetooth", "pdi:" + Integer.valueOf(k6ManufacturerInfo.pid) + "  Uuids:" + scanResult.getScanRecord().getServiceUuids() + "    mac:" + address + " name:" + name + " rssi:" + scanResult.getRssi());
            }
            if (k6ManufacturerInfo == null || name == null) {
                return;
            }
            r0 = this;
            MyBleDevice myBleDevice = new MyBleDevice(scanResult.getDevice(), k6ManufacturerInfo, name, scanResult.getDevice().getAddress(), scanResult.getRssi());
            this.mDeviceList.add(myBleDevice);
            Collections.sort(this.mDeviceList, this.comparator);
            r0.findDev5(i, scanResult, this.mDeviceList, myBleDevice);
        } catch (Exception unused) {
            r0.printStackTrace();
        }
    }

    public CEScanDev_4_Android5(Context context, CEScanDevBase.FindBlueTooth5 findBlueTooth5) {
        super(context, findBlueTooth5);
        this.mDeviceList = new ArrayList();
        this.isScanFinish = true;
        this.bleScanCallback = new ScanCallback() { // from class: ce.com.cenewbluesdk.scan.CEScanDev_4_Android5.1
            @Override // android.bluetooth.le.ScanCallback
            public void onScanResult(int i, ScanResult scanResult) {
                super.onScanResult(i, scanResult);
                CEScanDev_4_Android5.this.filteringEquipment(i, scanResult);
                CEScanDev_4_Android5.this.isScanFinish = true;
            }

            @Override // android.bluetooth.le.ScanCallback
            public void onBatchScanResults(List<ScanResult> list) {
                super.onBatchScanResults(list);
                CEScanDev_4_Android5.this.isScanFinish = true;
            }

            @Override // android.bluetooth.le.ScanCallback
            public void onScanFailed(int i) {
                super.onScanFailed(i);
                CEScanDev_4_Android5.this.isScanFinish = true;
            }
        };
        this.comparator = new Comparator<MyBleDevice>() { // from class: ce.com.cenewbluesdk.scan.CEScanDev_4_Android5.2
            @Override // java.util.Comparator
            public int compare(MyBleDevice myBleDevice, MyBleDevice myBleDevice2) {
                if (myBleDevice.getRssi() == myBleDevice2.getRssi()) {
                    return 0;
                }
                return myBleDevice.getRssi() > myBleDevice2.getRssi() ? -1 : 1;
            }
        };
        if (context == null) {
            return;
        }
        BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService("bluetooth");
        this.manager = bluetoothManager;
        this.mBluetoothAdapter = bluetoothManager.getAdapter();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [android.bluetooth.le.ScanFilter$Builder, java.lang.Exception] */
    private void scanBleDevice(String str) {
        BluetoothLeScanner bluetoothLeScanner = this.mBluetoothAdapter.getBluetoothLeScanner();
        this.bleScanner = bluetoothLeScanner;
        if (bluetoothLeScanner != null) {
            ArrayList arrayList = new ArrayList();
            ?? builder = new ScanFilter.Builder();
            builder.setDeviceName(CEBlueSharedPreference.getDeviceName());
            try {
                builder.setDeviceAddress(str);
            } catch (Exception unused) {
                builder.printStackTrace();
            }
            ScanFilter scanFilterBuild = builder.build();
            arrayList.add(scanFilterBuild);
            ScanSettings.Builder builder2 = new ScanSettings.Builder();
            builder2.setScanMode(0);
            if (Build.VERSION.SDK_INT >= 23) {
                builder2.setMatchMode(1);
                builder2.setCallbackType(1);
            }
            ScanSettings scanSettingsBuild = builder2.build();
            try {
                this.isScanFinish = false;
                this.bleScanner.startScan(arrayList, scanSettingsBuild, this.bleScanCallback);
                Lg.e("开始扫描 name:" + scanFilterBuild.getDeviceName() + " address=" + scanFilterBuild.getDeviceAddress());
                setScan(true);
            } catch (Exception unused2) {
                printStackTrace();
            }
        }
    }

    private void stopSysScan() {
        BluetoothLeScanner bluetoothLeScanner;
        setScan(false);
        if (this.bleScanner != null) {
            Lg.e("停止扫描");
            BluetoothAdapter bluetoothAdapter = this.mBluetoothAdapter;
            if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled() || (bluetoothLeScanner = this.bleScanner) == null) {
                return;
            }
            try {
                bluetoothLeScanner = bluetoothLeScanner;
                bluetoothLeScanner.stopScan(this.bleScanCallback);
            } catch (Exception unused) {
                Lg.e(bluetoothLeScanner);
            }
        }
    }

    private void scanBleDevice(boolean z) {
        BluetoothLeScanner bluetoothLeScanner;
        this.bleScanner = this.mBluetoothAdapter.getBluetoothLeScanner();
        ArrayList arrayList = new ArrayList();
        try {
            new ScanFilter.Builder().setServiceUuid(ParcelUuid.fromString(CEDevK6Proxy.UUID), ParcelUuid.fromString("F618-0-0-0-0"));
        } catch (IllegalArgumentException unused) {
            Logger.e("CEScanDev_4_Android5", "ScanFilter is exception");
        }
        ScanSettings.Builder builder = new ScanSettings.Builder();
        builder.setScanMode(2);
        if (Build.VERSION.SDK_INT >= 23) {
            builder.setMatchMode(1);
            builder.setCallbackType(1);
        }
        ScanSettings scanSettingsBuild = builder.build();
        if (z && (bluetoothLeScanner = this.bleScanner) != null) {
            bluetoothLeScanner.startScan(arrayList, scanSettingsBuild, this.bleScanCallback);
            setScan(true);
        } else {
            BluetoothLeScanner bluetoothLeScanner2 = this.bleScanner;
            if (bluetoothLeScanner2 != null) {
                bluetoothLeScanner2.stopScan(this.bleScanCallback);
            }
            setScan(false);
        }
    }

    public boolean isScan() {
        return this.isScan;
    }

    public void reset(String str) {
        Lg.e("reset scan time begin:" + str);
        if (System.currentTimeMillis() - CEBlueSharedPreference.getInstance(this.mContext).getScanStartTime() > SCAN_INTERVAL_TIME) {
            stopScan();
            startScan(str);
            CEBlueSharedPreference.getInstance(this.mContext).setScanStartTime(System.currentTimeMillis());
            Lg.e("reset scan time");
        }
    }

    public void setScanFinish(boolean z) {
        this.isScanFinish = z;
    }

    public boolean isScanFinish() {
        return this.isScanFinish;
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void startScan() {
        this.mDeviceList.clear();
        BluetoothAdapter bluetoothAdapter = this.mBluetoothAdapter;
        if (bluetoothAdapter == null || bluetoothAdapter.getState() != 12) {
            scanBleDevice(false);
        } else {
            scanBleDevice(true);
        }
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void startScan_filter(String str) {
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void startScan(String str) {
        this.mDeviceList.clear();
        BluetoothAdapter bluetoothAdapter = this.mBluetoothAdapter;
        if (bluetoothAdapter == null || bluetoothAdapter.getState() != 12) {
            return;
        }
        scanBleDevice(str);
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public void stopScan() {
        this.isScanFinish = true;
        stopSysScan();
    }

    @Override // ce.com.cenewbluesdk.scan.CEScanDevBase
    public boolean isBleEnabled() {
        return this.mBluetoothAdapter.isEnabled();
    }
}
