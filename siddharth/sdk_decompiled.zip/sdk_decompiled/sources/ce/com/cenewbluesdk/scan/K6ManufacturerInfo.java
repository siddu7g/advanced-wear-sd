package ce.com.cenewbluesdk.scan;

import android.os.ParcelUuid;
import android.util.Log;
import android.util.SparseArray;
import androidx.annotation.Nullable;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/scan/K6ManufacturerInfo.class */
public class K6ManufacturerInfo implements Serializable {
    public final int pid;
    public final String name;
    public int battery;
    public int batterStatus;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.String] */
    @Nullable
    public static K6ManufacturerInfo parse(@Nullable List<ParcelUuid> list, SparseArray<byte[]> sparseArray) {
        String str;
        if (list == null || list.size() < 1 || !CEDevK6Proxy.UUID.equals(list.get(0).toString()) || sparseArray.size() != 1) {
            return null;
        }
        int iKeyAt = sparseArray.keyAt(0);
        byte[] bArrInt2byte2 = ByteUtil.int2byte2(iKeyAt);
        byte b = bArrInt2byte2[0];
        byte b2 = bArrInt2byte2[1];
        byte[] bArr = sparseArray.get(iKeyAt);
        if (bArr.length < 2) {
            return null;
        }
        byte[] bArr2 = new byte[2];
        System.arraycopy(bArr, 0, bArr2, 0, 2);
        String hexString = Integer.toHexString(ByteUtil.byte2ToInt(bArr2));
        String string = hexString;
        if (hexString.length() < 4) {
            StringBuilder sb = new StringBuilder(string);
            for (int length = string.length(); length < 4; length++) {
                sb.insert(0, "0");
                string = sb.toString();
            }
        }
        if (bArr.length > 10) {
            UnsupportedEncodingException str2 = bArr;
            byte[] bArr3 = new byte[str2.length - 10];
            System.arraycopy(str2, 10, bArr3, 0, str2.length - 10);
            try {
                str = str2;
                str2 = new String(bArr3, "UTF-8");
            } catch (UnsupportedEncodingException unused) {
                str2.printStackTrace();
            }
        } else {
            str = "";
        }
        Log.i("K6ManufacturerInfo", "pid=" + iKeyAt + " name=" + string + "versionInfo =" + str);
        return new K6ManufacturerInfo(iKeyAt, string.toUpperCase());
    }

    public K6ManufacturerInfo(int i, String str) {
        this.pid = i;
        this.name = str;
    }

    K6ManufacturerInfo(int i, String str, int i2, int i3) {
        this.pid = i;
        this.name = str;
        this.battery = i2;
        this.batterStatus = i3;
    }
}
