package ce.com.cenewbluesdk.scan;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import ce.com.cenewbluesdk.entity.MyBleDevice;
import ce.com.cenewbluesdk.uitl.h;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDevBase.class */
public abstract class CEScanDevBase {
    public Context mContext;
    public Handler handler;
    public FindBlueTooth findDev;
    public FindBlueTooth5 findDev5;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDevBase$FindBlueTooth.class */
    public interface FindBlueTooth {
        void findDev(BluetoothDevice bluetoothDevice, int i, byte[] bArr);
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/scan/CEScanDevBase$FindBlueTooth5.class */
    public interface FindBlueTooth5 {
        @Deprecated
        void findDev(int i, ScanResult scanResult);

        void findDevList(int i, ScanResult scanResult, List<MyBleDevice> list, MyBleDevice myBleDevice);
    }

    public CEScanDevBase(Context context, FindBlueTooth findBlueTooth) {
        this.mContext = context;
        this.findDev = findBlueTooth;
    }

    public CEScanDevBase(Context context, FindBlueTooth5 findBlueTooth5) {
        this.mContext = context;
        this.findDev5 = findBlueTooth5;
    }

    public abstract void startScan();

    public abstract void startScan_filter(String str);

    public void startScan(String str) {
    }

    public abstract void stopScan();

    public abstract boolean isBleEnabled();

    public void findDev(BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
        FindBlueTooth findBlueTooth = this.findDev;
        if (findBlueTooth != null) {
            findBlueTooth.findDev(bluetoothDevice, i, bArr);
        }
    }

    public void findDev5(int i, ScanResult scanResult) {
        if (this.findDev5 == null || scanResult == null || scanResult.getDevice() == null || TextUtils.isEmpty(scanResult.getDevice().getName()) || scanResult.getScanRecord() == null || h.b(scanResult.getDevice().getName())) {
            return;
        }
        this.findDev5.findDev(i, scanResult);
    }

    public void findDev5(int i, ScanResult scanResult, List<MyBleDevice> list, MyBleDevice myBleDevice) {
        if (this.findDev5 == null || scanResult == null || scanResult.getDevice() == null || TextUtils.isEmpty(scanResult.getDevice().getName()) || scanResult.getScanRecord() == null || h.b(scanResult.getDevice().getName())) {
            return;
        }
        this.findDev5.findDev(i, scanResult);
        this.findDev5.findDevList(i, scanResult, list, myBleDevice);
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }
}
