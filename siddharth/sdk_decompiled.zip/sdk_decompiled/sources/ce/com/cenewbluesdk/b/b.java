package ce.com.cenewbluesdk.b;

/* loaded from: classes.jar:ce/com/cenewbluesdk/b/b.class */
public interface b<T> {
    void onSuccess(String str);

    void onError(String str);
}
