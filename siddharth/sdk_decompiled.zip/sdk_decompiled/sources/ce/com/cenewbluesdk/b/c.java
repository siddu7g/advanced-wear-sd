package ce.com.cenewbluesdk.b;

import java.io.Serializable;

/* loaded from: classes.jar:ce/com/cenewbluesdk/b/c.class */
public class c<T> implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    private int f9a;
    private String b;
    private String c;
    private String d;
    private T e;

    public boolean f() {
        return a() == 0;
    }

    public int a() {
        return this.f9a;
    }

    public void a(int i) {
        this.f9a = i;
    }

    public String c() {
        return this.b + b() + d();
    }

    public void b(String str) {
        this.b = str;
    }

    public String d() {
        return this.c;
    }

    public void c(String str) {
        this.c = str;
    }

    public String b() {
        return this.d;
    }

    public void a(String str) {
        this.d = str;
    }

    public T e() {
        return this.e;
    }

    public void a(T t) {
        this.e = t;
    }
}
