package ce.com.cenewbluesdk.b;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import androidx.annotation.NonNull;
import java.io.InputStream;
import java.util.Map;

/* loaded from: classes.jar:ce/com/cenewbluesdk/b/a.class */
public class a {
    String b;
    ce.com.cenewbluesdk.b.b c;

    /* renamed from: a, reason: collision with root package name */
    StringBuilder f4a = new StringBuilder();
    int d = 0;
    int e = 1;
    Handler f = new HandlerC0000a(Looper.getMainLooper());

    /* renamed from: ce.com.cenewbluesdk.b.a$a, reason: collision with other inner class name */
    /* loaded from: classes.jar:ce/com/cenewbluesdk/b/a$a.class */
    class HandlerC0000a extends Handler {
        HandlerC0000a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(@NonNull Message message) {
            ce.com.cenewbluesdk.b.b bVar;
            super.handleMessage(message);
            int i = message.what;
            a aVar = a.this;
            if (i == aVar.d) {
                ce.com.cenewbluesdk.b.b bVar2 = aVar.c;
                if (bVar2 != null) {
                    bVar2.onSuccess(aVar.b);
                    return;
                }
                return;
            }
            if (i != aVar.e || (bVar = aVar.c) == null) {
                return;
            }
            bVar.onError(aVar.b);
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/b/a$b.class */
    class b implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ String f6a;
        final /* synthetic */ Map b;

        b(String str, Map map) {
            this.f6a = str;
            this.b = map;
        }

        /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
            jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
            	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
            	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
            	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
            	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:44)
            */
        @Override // java.lang.Runnable
        public void run() {
            /*
                Method dump skipped, instructions count: 391
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.b.a.b.run():void");
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/b/a$c.class */
    class c implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ Map f7a;
        final /* synthetic */ String b;

        c(Map map, String str) {
            this.f7a = map;
            this.b = str;
        }

        /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
            jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
            	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
            	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
            	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
            	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:44)
            */
        @Override // java.lang.Runnable
        public void run() {
            /*
                Method dump skipped, instructions count: 428
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.b.a.c.run():void");
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/b/a$d.class */
    private static class d {

        /* renamed from: a, reason: collision with root package name */
        private static final a f8a = new a();

        private d() {
        }
    }

    public static a a() {
        return d.f8a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0064 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.StringBuffer] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.io.BufferedReader] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.io.BufferedReader] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.io.BufferedReader] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.io.BufferedReader] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.io.BufferedReader] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.String a(java.io.InputStream r6) throws java.lang.Throwable {
        /*
            r5 = this;
            r0 = 0
            r5 = r0
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r1 = r0
            r7 = r1
            r0.<init>()
            java.io.BufferedReader r0 = new java.io.BufferedReader     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L47
            r1 = r0
            r8 = r1
            java.io.InputStreamReader r1 = new java.io.InputStreamReader     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L47
            r2 = r1
            r3 = r6
            r2.<init>(r3)     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L47
            r0.<init>(r1)     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L47
        L1a:
            r0 = r8
            java.lang.String r0 = r0.readLine()     // Catch: java.lang.Throwable -> L38 java.io.IOException -> L3e
            r1 = r0
            r5 = r1
            if (r0 == 0) goto L31
            r0 = r7
            r1 = r5
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.Throwable -> L38 java.io.IOException -> L3e
            java.lang.String r1 = "\n"
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.Throwable -> L38 java.io.IOException -> L3e
            goto L1a
        L31:
            r0 = r8
            r0.close()     // Catch: java.io.IOException -> L57
            goto L5a
        L38:
            r5 = move-exception
            r0 = r5
            r6 = r0
            goto L60
        L3e:
            goto L49
        L41:
            r6 = move-exception
            r0 = r5
            r8 = r0
            goto L60
        L47:
            r1 = move-exception
            r8 = r1
        L49:
            r0.printStackTrace()     // Catch: java.lang.Throwable -> L5f
            r0 = r8
            if (r0 == 0) goto L5a
            r0 = r8
            r0.close()     // Catch: java.io.IOException -> L57
            goto L5a
        L57:
            r0.printStackTrace()     // Catch: java.io.IOException -> L57
        L5a:
            r0 = r7
            java.lang.String r0 = r0.toString()
            return r0
        L5f:
            r6 = move-exception
        L60:
            r0 = r8
            if (r0 == 0) goto L6e
            r0 = r8
            r0.close()     // Catch: java.io.IOException -> L6b
            goto L6e
        L6b:
            r0.printStackTrace()     // Catch: java.io.IOException -> L6b
        L6e:
            r0 = r6
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.b.a.a(java.io.InputStream):java.lang.String");
    }

    static /* synthetic */ String a(a aVar, InputStream inputStream) {
        return aVar.a(inputStream);
    }

    public void b(String str, Map<String, String> map, ce.com.cenewbluesdk.b.b bVar) {
        this.c = bVar;
        new Thread(new b(str, map)).start();
    }

    public <T> void a(String str, Map<String, String> map, ce.com.cenewbluesdk.b.b<T> bVar) {
        this.c = bVar;
        new Thread(new c(map, str)).start();
    }
}
