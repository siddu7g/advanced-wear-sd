package ce.com.cenewbluesdk;

/* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC.class */
public class CEBC {
    public static final int PRIORITY_LOW = -1;
    public static final int PRIORITY_NORMAL = 0;
    public static final int PRIORITY_MIDDLE = 1;
    public static final int PRIORITY_HIGH = 2;
    public static final int PRIORITY_CURR = 10;
    public static final int BLUE_DISCONNECT = 0;
    public static final int BLUE_CONNECTED = 1;
    public static final int BLUE_CONNECTING = 2;
    public static final int PROJECT_ID = 177;
    public static final int BLUE_CONNECT_STATE_CHANGE = 6;
    public static final int CMD_TYPE_NULL = 0;
    public static final int CMD_SPECIAL_START_TYPE = 1;
    public static final int CMD_SEND_TYPE = 2;
    public static final int CMD_SEND_NO_ACK_TYPE = 3;
    public static final int CMD_REQUEST_TYPE = 4;
    public static final int CMD_ACK_TYPE = 5;
    public static final int CMD_SPECIAL_END_TYPE = 250;
    public static final int CMD_APP_ACK_TYPE = -10001;
    public static final int CMD_APP_NO_ACK_TYPE = -10002;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$AckApp.class */
    public static class AckApp {
        public static final byte CMD_ACK = -99;
        public static final byte ACK_TYPE_NULL = -100;
        public static final byte ACK_TYPE_SUCCESS = -101;
        public static final byte ACK_TYPE_WRONG = -102;
        public static final byte ACK_TYPE_CRC16_WRONG = -103;
        public static final byte ACK_TYPE_OVER = -104;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$CALLTYPE.class */
    public static final class CALLTYPE {
        public static final int ANSWERPHONE = 1;
        public static final int HANGUPPHONE = 2;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$HARDWARE_INFO.class */
    public static final class HARDWARE_INFO {
        public static final int LCD_RGB565 = 0;
        public static final int LCD_RGB888 = 1;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$HEARTTYPE.class */
    public static final class HEARTTYPE {
        public static final int ALL_HEART = -1;
        public static final int AUTO_REAL_HEART = -2;
        public static final int AUTO_HEART = 0;
        public static final int REAL_HEART = 1;
        public static final int EXERCISE_HEART = 2;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$K6.class */
    public static class K6 {
        public static final short CMD_TYPE_NULL = 0;
        public static final short CMD_TYPE_SEND = 1;
        public static final short CMD_TYPE_SEND_NO_ACK = 2;
        public static final short CMD_TYPE_REQUEST = 3;
        public static final short CMD_TYPE_ACK = 4;
        public static final short ACK_TYPE_SUCCESS = 1;
        public static final short ACK_TYPE_WRONG = 2;
        public static final short ACK_TYPE_CRC16_WRONG = 3;
        public static final short ACK_TYPE_OVER = 4;
        public static final int DATA_TYPE_DEVINFO = 2;
        public static final int DATA_TYPE_BATTERY_INFO = 3;
        public static final int DATA_TYPE_REAL_SPORT = 4;
        public static final int DATA_TYPE_HISTORY_SPORT = 5;
        public static final int DATA_TYPE_SLEEP = 6;
        public static final int DATA_TYPE_REAL_HEART = 7;
        public static final int DATA_TYPE_HISTORY_HEART = 8;
        public static final int DATA_TYPE_DEV_SYNC = 9;
        public static final int DATA_TYPE_MIX_SPORT = 10;
        public static final int DATA_TYPE_FIND_PHONE = 11;
        public static final int DATA_TYPE_BLE_PAIR_STATUS = 12;
        public static final int DATA_TYPE_USER_CHANGE = 13;
        public static final int DATA_TYPE_MUSIC_CONTROL = 14;
        public static final int DATA_TYPE_CALL_CONTROL_TO_APP = 15;
        public static final int DATA_TYPE_GSENSOR_TEST_DATA = 16;
        public static final int DATA_TYPE_EXERCISE_HEART = 17;
        public static final int DATA_TYPE_REAL_BP = 18;
        public static final int DATA_TYPE_REAL_ECG = 19;
        public static final int DATA_TYPE_REAL_O2 = 20;
        public static final int DATA_TYPE_HR_CONTROL = 21;
        public static final int DATA_TYPE_FUNCTION_CONTROL = 22;
        public static final int DATA_TYPE_HARDWARE_INFO = 23;
        public static final int DATA_TYPE_REAL_HR = 24;
        public static final int DATA_TYPE_BTEDR_ADDR = 25;
        public static final int DATA_TYPE_QR_CODE_INFO = 26;
        public static final int DATA_TYPE_QR_CODE_DEL = 27;
        public static final int DATA_TYPE_QR_CODE_CLEAR = 28;
        public static final int DATA_TYPE_PHONE_RESOLUTION = 29;
        public static final int DATA_TYPE_SMS_REPLY = 30;
        public static final int DATA_TYPE_ALIPAY_RAW_DATA = 31;
        public static final int DATA_TYPE_ALIPAY_BIND_FLAG = 32;
        public static final int DATA_TYPE_WEEK_STEPS = 33;
        public static final int DATA_TYPE_WEEK_CALORIES = 34;
        public static final int DATA_TYPE_WEEK_DISTANCE = 35;
        public static final int DATA_TYPE_WEEK_EXERCISE_DURATION = 36;
        public static final int DATA_TYPE_WEEK_SLEEP = 37;
        public static final int DATA_TYPE_MAP_NAVIGATION_QUIT = 38;
        public static final int DATA_TYPE_ANDROID_BTEDR_ADDR = 39;
        public static final int DATA_TYPE_HISTORY_O2 = 40;
        public static final int DATA_TYPE_HISTORY_HRV = 42;
        public static final int DATA_TYPE_SLEEP_MONITOR = 43;
        public static final int DATA_TYPE_GESTURE_CONFIG = 44;
        public static final int DATA_TYPE_REAL_HRV = 45;
        public static final int DATA_TYPE_REAL_TEMP = 46;
        public static final int DATA_TYPE_HISTORY_TEMP = 47;
        public static final int DATA_TYPE_NOUSE = 60;
        public static final int DATA_TYPE_USERINFO = 102;
        public static final int DATA_TYPE_LANGUAGE_SETTING = 103;
        public static final int DATA_TYPE_TIME = 104;
        public static final int DATA_TYPE_WEATHER = 105;
        public static final int DATA_TYPE_ALARM = 106;
        public static final int DATA_TYPE_MESSAGE_NOTICE = 107;
        public static final int DATA_TYPE_APP_CLOSE = 108;
        public static final int DATA_TYPE_SET_DATA_SWITCH = 109;
        public static final int DATA_TYPE_APP_SYNC = 110;
        public static final int DATA_TYPE_SET_TARGET = 111;
        public static final int DATA_TYPE_OPEN_BLE_PAIR = 112;
        public static final int DATA_TYPE_MUSIC_CONTENT = 113;
        public static final int DATA_TYPE_SITTING_REMIND = 114;
        public static final int DATA_TYPE_FORGET_DISTURB = 115;
        public static final int DATA_TYPE_PHOTOGRAPH_ONOFF = 116;
        public static final int DATA_TYPE_CALL_CONTROL_TO_DEV = 117;
        public static final int DATA_TYPE_RESET = 118;
        public static final int DATA_TYPE_SHUTDOWN = 119;
        public static final int DATA_TYPE_PAIR_FINISH = 120;
        public static final int DATA_TYPE_UNIT_SETTING = 121;
        public static final int DATA_TYPE_CALL_ALARM = 122;
        public static final int DATA_TYPE_MESSAGE_ALARM = 123;
        public static final int DATA_TYPE_MESSAGE_DISPLAY = 124;
        public static final int DATA_TYPE_TARGET_ALARM = 125;
        public static final int DATA_TYPE_DRINK_ALARM = 126;
        public static final int DATA_TYPE_HAND_RISE_SWITCH = 127;
        public static final int DATA_TYPE_HEART_AUTO_SWITCH = 128;
        public static final int DATA_TYPE_WATCH_SETTING = 129;
        public static final int DATA_TYPE_APP_SPORT = 130;
        public static final int DATA_TYPE_WATCH_FACE_SYNC = 131;
        public static final int DATA_TYPE_WATCH_FACE_INFO = 132;
        public static final int DATA_TYPE_WOMAN_STAGE_INFO = 133;
        public static final int DATA_TYPE_WATCH_FACE_START = 134;
        public static final int DATA_TYPE_CONTACT_ADD = 135;
        public static final int DATA_TYPE_CONTACT_DELETE = 136;
        public static final int DATA_TYPE_CONTACT_CLEAN = 137;
        public static final int DATA_TYPE_CONTACT_SYNC = 138;
        public static final int DATA_TYPE_REAL_TIME_WEATHER = 139;
        public static final int DATA_TYPE_WATCHFACE_PHOTO_DEL = 140;
        public static final int DATA_TYPE_POWER_LOGO_DEL = 141;
        public static final int DATA_TYPE_TEST_TOOL = 142;
        public static final int DATA_TYPE_MOTION_GAME = 143;
        public static final int DATA_TYPE_MOTION_DATA = 144;
        public static final int DATA_TYPE_AI_QA_CMD = 145;
        public static final int DATA_TYPE_AI_TR_CMD = 146;
        public static final int DATA_TYPE_AI_WATCHFACE_CMD = 147;
        public static final int DATA_TYPE_AI_CTRL_CMD = 148;
        public static final int DATA_TYPE_MAP_NAVIGATION_CMD = 149;
        public static final int DATA_TYPE_EXTERN_WEATHER = 150;
        public static final int DATA_TYPE_BEDTIM = 151;
        public static final int DATA_TYPE_CURRENT_LOCATION = 152;
        public static final int DATA_TYPE_START_GENERATING_DIAL = 153;
        public static final int DATA_TYPE_AI_TR_ENGLISH_CMD = 154;
        public static final int DATA_TYPE_OTA_STATUS = 201;
        public static final int DATA_TYPE_OTA_DATA = 202;
        public static final int DATA_TYPE_TEST_DEBUG = 203;
        public static final int DATA_TYPE_FACTORY_TEST = 205;
        public static final int DATA_TYPE_LEAKLIGHT_TEST = 206;
        public static final int DATA_TYPE_CLEAN_DATA = 207;
        public static final int DATA_TYPE_SPORT_ITEM_SET = 61;
        public static final int DATA_TYPE_SET_HEART_MAX = 62;
        public static final int DATA_TYPE_EXERCISE_CMD = 63;
        public static final int DATA_TYPE_EXERCISE_STATUS = 64;
        public static final int DATA_TYPE_SWIM_SETTING = 66;
        public static final int DATA_TYPE_GPS_ARGUMENT = 67;
        public static final int DATA_TYPE_TEST_GPS_CMD = 68;
        public static final int DATA_TYPE_APP_BOND = 69;
        public static final int DATA_TYPE_PAIR_START = 70;
        public static final int DATA_TYPE_TEST_GPS_DATA = 71;
        public static final int DATA_TYPE_SETTING = 72;
        public static final int DATA_TYPE_HISTORY_GPS = 73;
        public static final int DATA_TYPE_OTA_PROGRESS = -100;
        public static final int DATA_TYPE_ALLOW_WATCH = -200;
        public static final int CALL_CMD_NULL = 0;
        public static final int CALL_CMD_ANSWER_CALL = 1;
        public static final int CALL_CMD_HANGUP_CALL = 2;
        public static final int CALL_CMD_SOUND_OFF = 3;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$LANGUAGE.class */
    public static final class LANGUAGE {
        public static final int LAN_ENGLISH = 0;
        public static final int LAN_CHINESE_SIMPLE = 1;
        public static final int LAN_SPANISH = 2;
        public static final int LAN_ITALIAN = 3;
        public static final int LAN_PORTUGUESE = 4;
        public static final int LAN_FRENCH = 5;
        public static final int LAN_JAPANESE = 6;
        public static final int LAN_RUSSIAN = 7;
        public static final int LAN_KOREAN = 8;
        public static final int LAN_GERMAN = 9;
        public static final int LAN_CHINESE_TRADITIONAL = 10;
        public static final int LAN_ARABIC = 11;
        public static final int LAN_INDONESIA = 12;
        public static final int LAN_TURKISH = 13;
        public static final int LAN_UKRAINIAN = 14;
        public static final int LAN_HEBREW = 15;
        public static final int LAN_POLISH = 16;
        public static final int LAN_HINDI = 17;
        public static final int LAN_CROATIAN = 18;
        public static final int LAN_GREEK = 19;
        public static final int LAN_THAI = 20;
        public static final int LAN_VIETNAMESE = 21;
        public static final int LAN_FARSI = 22;
        public static final int LAN_NETHERLANDS = 23;
        public static final int LAN_ROMANIA = 24;
        public static final int LAN_GALICIAN = 25;
        public static final int LAN_BASQUE = 26;
        public static final int LAN_CATALAN = 27;
        public static final int LAN_DANISH = 28;
        public static final int LAN_SWEDISH = 29;
        public static final int LAN_NORWEGIAN = 30;
        public static final int LAN_URDU = 31;
        public static final int LAN_BENGALESE = 32;
        public static final int LAN_MALAYSIA = 33;
        public static final int LAN_MARATHI = 34;
        public static final int LAN_TELUGU = 35;
        public static final int LAN_GUJARATI = 36;
        public static final int LAN_TAMIL = 37;
        public static final int LAN_KANNADA = 38;
        public static final int LAN_SLOVAK = 39;
        public static final int LAN_CZECH = 40;
        public static final int LAN_HUNGARIAN = 41;
        public static final int LAN_BURMESE = 42;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$MUSICPACKAGE.class */
    public static final class MUSICPACKAGE {
        public static final String music_qq = "com.tencent.qqmusic";
        public static final String music_joox = "com.tencent.ibg.joox";
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$OPENSTATUS.class */
    public static final class OPENSTATUS {
        public static final int OPEN = 1;
        public static final int CLOSE = 0;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$PACKAGEINFO.class */
    public static final class PACKAGEINFO {
        public static final String KEYAPPICON = "keyAppIcon";
        public static final String KEYAPPNAME = "keyAppName";
        public static final String KEYAPPPACKAGENAME = "keyAppPackageName";
        public static final String KEYAPPISOPEN = "keyAppIsOpen";
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$PID_TYPE.class */
    public static class PID_TYPE {
        public static final int PID_618 = 1;
        public static final int PID_818 = 2;
        public static final int PID_118 = 3;
        public static final int PID_518 = 4;
        public static final int PID_S2 = 5;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$QRCODESENDSTATUS.class */
    public static final class QRCODESENDSTATUS {
        public static final int QR_CODE_SEND_SUCCEED = 1;
        public static final int QR_CODE_SEND_FAIL = 0;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$QRCODETYPE.class */
    public static final class QRCODETYPE {
        public static final int QR_WECHAT = 1;
        public static final int QR_QQ = 2;
        public static final int QR_ALIPAY = 3;
        public static final int QR_WHATSAPP = 4;
        public static final int QR_TWITTER = 5;
        public static final int QR_LINKEDIN = 6;
        public static final int QR_INSTAGRAM = 7;
        public static final int QR_FACEBOOK = 8;
        public static final int QR_WEIBO = 9;
        public static final int QR_LINE = 10;
        public static final int QR_TIM = 11;
        public static final int QR_SNAPCHAT = 12;
        public static final int QR_VIBER = 13;
        public static final int QR_PAYPAL = 14;
        public static final int QR_OTHER = 15;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$SLEEPSTATUS.class */
    public static final class SLEEPSTATUS {
        public static final int SLEEPDATA_SLEEP_NONE = 0;
        public static final int SLEEPDATA_SLEEP_START = 1;
        public static final int SLEEPDATA_SLEEP_DEEP = 2;
        public static final int SLEEPDATA_SLEEP_LIGHT = 3;
        public static final int SLEEPDATA_SLEEP_WAKEUP = 4;
        public static final int SLEEPDATA_SLEEP_MOVEMENT = 5;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$TIMEDATEFORMAT.class */
    public static final class TIMEDATEFORMAT {
        public static final int HOURS12 = 0;
        public static final int HOURS24 = 1;
        public static final int DAYMONTH = 1;
        public static final int MONTHDAY = 0;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$TIMEPOS.class */
    public static final class TIMEPOS {
        public static final int ABOVE = 0;
        public static final int BELOW = 1;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$TIMESHOWTYPE.class */
    public static final class TIMESHOWTYPE {
        public static final int NONE_TYPE = 0;
        public static final int DATE_TYPE = 1;
        public static final int SLEEP_TYPE = 2;
        public static final int HEART_TYPE = 3;
        public static final int STEP_TYPE = 4;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$UNITTYPE.class */
    public static final class UNITTYPE {
        public static final int WEIGHT_KILOGRAM = 0;
        public static final int WEIGHT_LB = 1;
        public static final int WEIGHT_STONE = 2;
        public static final int DIS_METER = 0;
        public static final int DIS_MILE = 1;
        public static final int WEATHER_CELSIUS = 0;
        public static final int WEATHER_FAHRENHEIT = 1;
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/CEBC$URIKEY.class */
    public static class URIKEY {
        public static final String DATEDISPLAY = "key_datedisplay";
        public static final String TIMEDISPLAY = "key_timedisplay";
        public static final String KEY_SCREEN_WIDTH = "KEY_SCREEN_WIDTH";
        public static final String KEY_SCREEN_HIGH = "KEY_SCREEN_HIGH";
        public static final String KEY_SCREEN_RGB = "KEY_SCREEN_RGB";
        public static final String KEY_DEVINTO = "KEY_DEVINTO";
        public static final String KEY_PUSHMESSAGE = "key_pushmessage";
        public static final String KEY_DEVICEID = "key_deviceId";
        public static final String KEY_CONNECT_STATES = "key_connect_states";
        public static final String KEY_STEP = "KEY_STEP";
        public static final String KEY_DISTANCE = "KEY_DISTANCE";
        public static final String KEY_CALORIES = "KEY_CALORIES";
        public static final String KEY_SLEEP = "KEY_SLEEP";
        public static final String KEY_DURATION = "KEY_DURATION";
        public static final String KEY_DEVNAME = "KEY_DEVNAME";
        public static final String KEY_DEVMACADDRESS = "KEY_DEVMACADDRESS";
        public static final String KEY_USERID = "KEY_USERID";
        public static final String KEY_DEVICEBATTERY = "KEY_DEVICEBATTERY";
        public static final String KEY_SOFTWARE_VERSION = "KEY_SOFTWARE_VERSION";
        public static final String KEY_MUSIC_PACKAGE = "KEY_MUSIC_PACKAGE";
        public static final String KEY_NEWWEATHER_TYPE = "KEY_NEWWEATHER_TYPE";
        public static final String KEY_A2DAMAC = "KEY_A2DAMAC";
        public static final String KEY_CUSTOMER_ID = "KEY_CUSTOMER_ID";
        public static final String KEY_UUID = "KEY_UUID";
        public static final String KEY_BT_CONNECT_STATUS = "KEY_BT_CONNECT_STATUS";
        public static final String KEY_DIAL_SIZE = "KEY_DIAL_SIZE";
        public static final String KEY_PHONE_EDR_MAC = "KEY_PHONE_EDR_MAC";
        public static final String KEY_EDR_BACK_CONNECT = "KEY_EDR_BACK_CONNECT";
    }
}
