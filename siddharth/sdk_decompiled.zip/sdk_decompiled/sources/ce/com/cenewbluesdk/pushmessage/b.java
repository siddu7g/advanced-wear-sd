package ce.com.cenewbluesdk.pushmessage;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.k6.K6_MessageNoticeStruct;
import ce.com.cenewbluesdk.proxy.interfaces.OnPushAppListListener;
import com.example.cenewbluesdk.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/b.class */
public class b {

    /* renamed from: a, reason: collision with root package name */
    private List<ResolveInfo> f38a;
    private String c;
    private String[] d;
    private String h;
    private String i;
    private Drawable j;
    private List<HashMap> b = new ArrayList();
    private List<String> e = new ArrayList();
    private List<HashMap> f = new ArrayList();
    private List g = new ArrayList();

    /* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/b$a.class */
    class a implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ Context f39a;
        final /* synthetic */ OnPushAppListListener b;

        /* renamed from: ce.com.cenewbluesdk.pushmessage.b$a$a, reason: collision with other inner class name */
        /* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/b$a$a.class */
        class C0005a implements Comparator<HashMap> {
            C0005a() {
            }

            @Override // java.util.Comparator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public int compare(HashMap map, HashMap map2) {
                return ((Integer) map2.get("keyLevel")).intValue() - ((Integer) map.get("keyLevel")).intValue();
            }
        }

        /* renamed from: ce.com.cenewbluesdk.pushmessage.b$a$b, reason: collision with other inner class name */
        /* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/b$a$b.class */
        class RunnableC0006b implements Runnable {
            RunnableC0006b() {
            }

            @Override // java.lang.Runnable
            public void run() {
                a aVar = a.this;
                OnPushAppListListener onPushAppListListener = aVar.b;
                if (onPushAppListListener != null) {
                    onPushAppListListener.onPushAppList(b.this.b);
                }
            }
        }

        /* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/b$a$c.class */
        class c implements Runnable {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ Exception f42a;

            c(Exception exc) {
                this.f42a = exc;
            }

            @Override // java.lang.Runnable
            public void run() {
                OnPushAppListListener onPushAppListListener = a.this.b;
                if (onPushAppListListener != null) {
                    onPushAppListListener.onPushAppError(this.f42a);
                }
            }
        }

        a(Context context, OnPushAppListListener onPushAppListListener) {
            this.f39a = context;
            this.b = onPushAppListListener;
        }

        @Override // java.lang.Runnable
        public void run() {
            HashMap map;
            String str;
            Boolean bool;
            HashMap map2;
            String str2;
            Boolean bool2;
            HashMap map3;
            String str3;
            int i;
            try {
                b.this.c = CEBlueSharedPreference.getAppDevicePushMessage();
                if (!TextUtils.isEmpty(b.this.c)) {
                    b bVar = b.this;
                    bVar.d = bVar.c.split("\\|");
                    if (b.this.e == null) {
                        b.this.e = new ArrayList();
                    }
                    b.this.e.clear();
                    for (int i2 = 0; i2 < b.this.d.length; i2++) {
                        b.this.e.add(b.this.d[i2]);
                    }
                }
                Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
                intent.addCategory("android.intent.category.LAUNCHER");
                if (b.this.f38a == null || b.this.f38a.size() < 1) {
                    b.this.f38a = this.f39a.getPackageManager().queryIntentActivities(intent, 0);
                }
                if (b.this.f == null) {
                    b.this.f = new ArrayList();
                }
                b.this.f.clear();
                if (b.this.g == null) {
                    b.this.g = new ArrayList();
                }
                b.this.g.clear();
                b.this.g.add(K6_MessageNoticeStruct.WEIXIN);
                b.this.g.add(K6_MessageNoticeStruct.QQ);
                b.this.g.add(K6_MessageNoticeStruct.TWITTER);
                b.this.g.add(K6_MessageNoticeStruct.FACEBOOK);
                b.this.g.add(K6_MessageNoticeStruct.FACEBOOK_ORCA);
                b.this.g.add(K6_MessageNoticeStruct.WHATSAPP);
                b.this.g.add(K6_MessageNoticeStruct.INSTAGRAM);
                b.this.g.add(K6_MessageNoticeStruct.SKYPE);
                b.this.g.add(K6_MessageNoticeStruct.SKYPE_CN);
                b.this.g.add(K6_MessageNoticeStruct.LINKEDIN);
                b.this.g.add(K6_MessageNoticeStruct.LINE);
                b.this.g.add(K6_MessageNoticeStruct.MESSAGING);
                b.this.g.add(K6_MessageNoticeStruct.MMS);
                b.this.g.add(K6_MessageNoticeStruct.CONTACTS);
                b.this.g.add(K6_MessageNoticeStruct.DIALER);
                b.this.g.add(K6_MessageNoticeStruct.KAKAOTALK);
                for (ResolveInfo resolveInfo : b.this.f38a) {
                    b.this.j = resolveInfo.loadIcon(this.f39a.getPackageManager());
                    b.this.i = resolveInfo.loadLabel(this.f39a.getPackageManager()).toString();
                    b.this.h = resolveInfo.activityInfo.packageName;
                    if (!b.this.h.equalsIgnoreCase(this.f39a.getPackageName())) {
                        HashMap map4 = new HashMap();
                        map4.put(CEBC.PACKAGEINFO.KEYAPPICON, b.this.j);
                        map4.put(CEBC.PACKAGEINFO.KEYAPPNAME, b.this.i);
                        map4.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, b.this.h.substring(b.this.h.indexOf(".") + 1, b.this.h.length()));
                        Log.e("appInfo", b.this.i + "----" + b.this.h);
                        if (b.this.e.contains(b.this.h.substring(b.this.h.indexOf(".") + 1, b.this.h.length()))) {
                            map2 = map4;
                            str2 = CEBC.PACKAGEINFO.KEYAPPISOPEN;
                            bool2 = Boolean.TRUE;
                        } else {
                            map2 = map4;
                            str2 = CEBC.PACKAGEINFO.KEYAPPISOPEN;
                            bool2 = Boolean.FALSE;
                        }
                        map2.put(str2, bool2);
                        if (b.this.g.contains(b.this.h)) {
                            map3 = map4;
                            str3 = "keyLevel";
                            i = 2;
                        } else {
                            map3 = map4;
                            str3 = "keyLevel";
                            i = 0;
                        }
                        map3.put(str3, i);
                        b.this.f.add(map4);
                    }
                }
                boolean z = false;
                Iterator it = b.this.f.iterator();
                while (it.hasNext()) {
                    if (((String) ((HashMap) it.next()).get(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME)).contains("dialer")) {
                        z = true;
                    }
                }
                if (!z) {
                    HashMap map5 = new HashMap();
                    map5.put(CEBC.PACKAGEINFO.KEYAPPICON, null);
                    map5.put(CEBC.PACKAGEINFO.KEYAPPNAME, this.f39a.getResources().getString(R.string.Phone));
                    map5.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, "dialer|contacts|telecom");
                    if (b.this.e.contains("contacts") || b.this.e.contains("dialer") || b.this.e.contains("telecom")) {
                        map = map5;
                        str = CEBC.PACKAGEINFO.KEYAPPISOPEN;
                        bool = Boolean.TRUE;
                    } else {
                        map = map5;
                        str = CEBC.PACKAGEINFO.KEYAPPISOPEN;
                        bool = Boolean.FALSE;
                    }
                    map.put(str, bool);
                    map5.put("keyLevel", 2);
                    b.this.f.add(map5);
                }
                Collections.sort(b.this.f, new C0005a());
                b.this.b.clear();
                b.this.b.addAll(b.this.f);
                new Handler(Looper.getMainLooper()).post(new RunnableC0006b());
            } catch (Exception e) {
                e.printStackTrace();
                new Handler(Looper.getMainLooper()).post(new c(e));
            }
        }
    }

    /* renamed from: ce.com.cenewbluesdk.pushmessage.b$b, reason: collision with other inner class name */
    /* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/b$b.class */
    private static class C0007b {

        /* renamed from: a, reason: collision with root package name */
        private static final b f43a = new b();

        private C0007b() {
        }
    }

    public static b a() {
        return C0007b.f43a;
    }

    public static List<HashMap> a(Context context) {
        ArrayList arrayList = new ArrayList();
        HashMap map = new HashMap();
        map.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_call));
        map.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.Phone));
        StringBuilder sb = new StringBuilder();
        String str = K6_MessageNoticeStruct.DIALER;
        StringBuilder sbAppend = sb.append(str.substring(str.indexOf(".") + 1)).append("|");
        String str2 = K6_MessageNoticeStruct.CONTACTS;
        StringBuilder sbAppend2 = sbAppend.append(str2.substring(str2.indexOf(".") + 1)).append("|");
        String str3 = K6_MessageNoticeStruct.XIAOMIMISSCALL;
        StringBuilder sbAppend3 = sbAppend2.append(str3.substring(str3.indexOf(".") + 1)).append("|");
        String str4 = K6_MessageNoticeStruct.MISSCALLPHONE;
        StringBuilder sbAppend4 = sbAppend3.append(str4.substring(str4.indexOf(".") + 1)).append("|");
        String str5 = K6_MessageNoticeStruct.CONTACTS_HUAWEI;
        map.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, sbAppend4.append(str5.substring(str5.indexOf(".") + 1)).toString());
        arrayList.add(map);
        HashMap map2 = new HashMap();
        map2.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_weixin));
        map2.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Wechat));
        String str6 = K6_MessageNoticeStruct.WEIXIN;
        map2.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str6.substring(str6.indexOf(".") + 1));
        arrayList.add(map2);
        HashMap map3 = new HashMap();
        map3.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_whatsapp));
        map3.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_WhatsApp));
        String str7 = K6_MessageNoticeStruct.WHATSAPP;
        map3.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str7.substring(str7.indexOf(".") + 1));
        arrayList.add(map3);
        HashMap map4 = new HashMap();
        map4.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_line));
        map4.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Line));
        String str8 = K6_MessageNoticeStruct.LINE;
        map4.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str8.substring(str8.indexOf(".") + 1));
        arrayList.add(map4);
        HashMap map5 = new HashMap();
        map5.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_message));
        map5.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.YD_AppMessaging));
        StringBuilder sb2 = new StringBuilder();
        String str9 = K6_MessageNoticeStruct.MESSAGING;
        StringBuilder sbAppend5 = sb2.append(str9.substring(str9.indexOf(".") + 1)).append("|");
        String str10 = K6_MessageNoticeStruct.MESSAGING_GOOGLE;
        StringBuilder sbAppend6 = sbAppend5.append(str10.substring(str10.indexOf(".") + 1)).append("|");
        String str11 = K6_MessageNoticeStruct.MESSAGING_COMMON;
        StringBuilder sbAppend7 = sbAppend6.append(str11.substring(str11.indexOf(".") + 1)).append("|");
        String str12 = K6_MessageNoticeStruct.MMS;
        StringBuilder sbAppend8 = sbAppend7.append(str12.substring(str12.indexOf(".") + 1)).append("|");
        String str13 = K6_MessageNoticeStruct.MMS;
        StringBuilder sbAppend9 = sbAppend8.append(str13.substring(str13.indexOf(".") + 1)).append("|");
        String str14 = K6_MessageNoticeStruct.MMS2;
        map5.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, sbAppend9.append(str14.substring(str14.indexOf(".") + 1)).toString());
        arrayList.add(map5);
        HashMap map6 = new HashMap();
        map6.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_qq));
        map6.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_QQ));
        String str15 = K6_MessageNoticeStruct.QQ;
        map6.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str15.substring(str15.indexOf(".") + 1));
        arrayList.add(map6);
        HashMap map7 = new HashMap();
        map7.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_twitter));
        map7.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Twitter));
        String str16 = K6_MessageNoticeStruct.TWITTER;
        map7.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str16.substring(str16.indexOf(".") + 1));
        arrayList.add(map7);
        HashMap map8 = new HashMap();
        map8.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_facebook));
        map8.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Facebook));
        StringBuilder sb3 = new StringBuilder();
        String str17 = K6_MessageNoticeStruct.FACEBOOK;
        StringBuilder sbAppend10 = sb3.append(str17.substring(str17.indexOf(".") + 1)).append("|");
        String str18 = K6_MessageNoticeStruct.FACEBOOK_ORCA;
        map8.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, sbAppend10.append(str18.substring(str18.indexOf(".") + 1)).toString());
        arrayList.add(map8);
        HashMap map9 = new HashMap();
        map9.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_skype));
        map9.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Skype));
        StringBuilder sb4 = new StringBuilder();
        String str19 = K6_MessageNoticeStruct.SKYPE;
        StringBuilder sbAppend11 = sb4.append(str19.substring(str19.indexOf(".") + 1)).append("|");
        String str20 = K6_MessageNoticeStruct.SKYPE_CN;
        map9.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, sbAppend11.append(str20.substring(str20.indexOf(".") + 1)).toString());
        arrayList.add(map9);
        HashMap map10 = new HashMap();
        map10.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_linkedin));
        map10.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Linked_in));
        String str21 = K6_MessageNoticeStruct.LINKEDIN;
        map10.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str21.substring(str21.indexOf(".") + 1));
        arrayList.add(map10);
        HashMap map11 = new HashMap();
        map11.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_telegram));
        map11.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.push_telegram));
        StringBuilder sb5 = new StringBuilder();
        String str22 = K6_MessageNoticeStruct.TELEGRAM;
        StringBuilder sbAppend12 = sb5.append(str22.substring(str22.indexOf(".") + 1)).append("|");
        String str23 = K6_MessageNoticeStruct.TELEGRAM_WEB;
        map11.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, sbAppend12.append(str23.substring(str23.indexOf(".") + 1)).toString());
        arrayList.add(map11);
        HashMap map12 = new HashMap();
        map12.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_instagram));
        map12.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Instagram));
        map12.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, K6_MessageNoticeStruct.INSTAGRAM.substring(K6_MessageNoticeStruct.FACEBOOK.indexOf(".") + 1));
        arrayList.add(map12);
        HashMap map13 = new HashMap();
        map13.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_kakaotalk));
        map13.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.push_kakao_talk));
        StringBuilder sb6 = new StringBuilder();
        String str24 = K6_MessageNoticeStruct.KAKAOTALK;
        StringBuilder sbAppend13 = sb6.append(str24.substring(str24.indexOf(".") + 1)).append("|");
        String str25 = K6_MessageNoticeStruct.KAKAO_SIMPLE;
        StringBuilder sbAppend14 = sbAppend13.append(str25.substring(str25.indexOf(".") + 1)).append("|");
        String str26 = K6_MessageNoticeStruct.KAKAO_YELLOWID;
        map13.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, sbAppend14.append(str26.substring(str26.indexOf(".") + 1)).toString());
        arrayList.add(map13);
        HashMap map14 = new HashMap();
        map14.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_playstore));
        map14.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.push_play_store));
        String str27 = K6_MessageNoticeStruct.PLAY_STORE;
        map14.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str27.substring(str27.indexOf(".") + 1));
        arrayList.add(map14);
        HashMap map15 = new HashMap();
        map15.put(CEBC.PACKAGEINFO.KEYAPPICON, context.getResources().getDrawable(R.mipmap.icon_push_other));
        map15.put(CEBC.PACKAGEINFO.KEYAPPNAME, context.getString(R.string.CE_Other));
        String str28 = K6_MessageNoticeStruct.PUSH_OTHER;
        map15.put(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME, str28.substring(str28.indexOf(".") + 1));
        arrayList.add(map15);
        return arrayList;
    }

    public void a(Context context, OnPushAppListListener onPushAppListListener) {
        new Thread(new a(context, onPushAppListListener)).start();
    }

    public List<HashMap> b(Context context) {
        String[] strArrSplit = CEBlueSharedPreference.getAppDevicePushMessage().split("\\|");
        ArrayList arrayList = new ArrayList();
        for (String str : strArrSplit) {
            arrayList.add(str);
        }
        List<HashMap> listA = a(context);
        for (HashMap map : listA) {
            for (String str2 : ((String) map.get(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME)).split("\\|")) {
                if (arrayList.contains(str2)) {
                    map.put(CEBC.PACKAGEINFO.KEYAPPISOPEN, Boolean.TRUE);
                } else {
                    map.put(CEBC.PACKAGEINFO.KEYAPPISOPEN, Boolean.FALSE);
                }
            }
        }
        this.b.clear();
        this.b.addAll(listA);
        return this.b;
    }
}
