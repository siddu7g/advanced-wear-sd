package ce.com.cenewbluesdk.pushmessage;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.content.ComponentName;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.RemoteController;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.RequiresApi;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_MUSIC_CONTROL;
import ce.com.cenewbluesdk.entity.k6.K6_MessageNoticeStruct;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.CEConnectUtilForAndroid5;
import ce.com.cenewbluesdk.proxy.MusicControl;
import ce.com.cenewbluesdk.proxy.sdkhelper.BluetoothHelper;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import ce.com.cenewbluesdk.uitl.TimeUtil;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

@SuppressLint({"OverrideAbstract"})
/* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/NtfCollector.class */
public class NtfCollector extends NotificationListenerService implements RemoteController.OnClientUpdateListener {

    /* renamed from: a, reason: collision with root package name */
    public static NtfCollector f36a;
    public Handler b;
    private String c;
    private String e;
    private String[] f;
    RemoteController g;
    MediaSessionManager i;
    private long d = 0;
    String h = null;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/NtfCollector$a.class */
    class a implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ String f37a;

        a(String str) {
            this.f37a = str;
        }

        @Override // java.lang.Runnable
        public void run() throws IOException {
            BluetoothHelper.getInstance().getMusicControl();
            MusicControl.MusicName = this.f37a;
            Lg.e("sendMusicChangeMsg", "sendMusicChangeMsg=" + this.f37a);
            BluetoothHelper.getInstance().getMusicControl();
            if (!TextUtils.isEmpty(MusicControl.MusicName) && BleFactory.getInstance().getK6Proxy().isConnectOK()) {
                BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_MUSIC_CONTROL(new K6_DATA_TYPE_MUSIC_CONTROL(7, this.f37a.getBytes()));
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v284, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v289, types: [java.lang.CharSequence, java.lang.String] */
    private void a(StatusBarNotification statusBarNotification) {
        CharSequence charSequence;
        if (statusBarNotification == null) {
            return;
        }
        if (CEConnectUtilForAndroid5.offScreen || statusBarNotification.getGroupKey() == null || !statusBarNotification.getGroupKey().contains("g:group_key_mms")) {
            String packageName = statusBarNotification.getPackageName();
            if (statusBarNotification.getNotification() == null || statusBarNotification.getNotification().actions == null || statusBarNotification.getNotification().actions.length >= 2 || !packageName.equals(K6_MessageNoticeStruct.WHATSAPP)) {
                Notification notification = statusBarNotification.getNotification();
                if (Build.VERSION.SDK_INT <= 29) {
                    try {
                        if (BluetoothHelper.getInstance().getMusicControl() != null && BluetoothHelper.getInstance().getMusicControl().isNoSupportRemoteController(packageName).booleanValue()) {
                            a();
                            return;
                        }
                    } catch (Exception unused) {
                    }
                } else if (BluetoothHelper.getInstance().getMusicControl() != null && BluetoothHelper.getInstance().getMusicControl().isExistMusicApp(packageName).booleanValue()) {
                    if (notification == null || (charSequence = notification.tickerText) == null || "网易云音乐正在播放".equals(charSequence.toString())) {
                        return;
                    }
                    String string = notification.tickerText.toString();
                    MusicControl.MusicName = string;
                    BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_MUSIC_CONTROL(new K6_DATA_TYPE_MUSIC_CONTROL(7, string.getBytes()));
                    return;
                }
                ?? r0 = 0;
                Throwable th = null;
                try {
                    String appDevicePushMessage = CEBlueSharedPreference.getAppDevicePushMessage();
                    this.e = appDevicePushMessage;
                    if (appDevicePushMessage == null) {
                        this.e = "";
                    }
                    String[] strArrSplit = this.e.split("\\|");
                    this.f = strArrSplit;
                    for (String str : strArrSplit) {
                        if (!TextUtils.isEmpty(str) && packageName.contains(str)) {
                            th = 1;
                        }
                    }
                    boolean z = false;
                    boolean z2 = false;
                    ?? r02 = this.f;
                    int length = r02.length;
                    for (int i = 0; i < length; i++) {
                        r0 = r02[i];
                        if (!TextUtils.isEmpty(r0) && r0.equals(K6_MessageNoticeStruct.PUSH_OTHER)) {
                            th = 1;
                            Iterator<HashMap> it = b.a(this).iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    if (packageName.contains((String) it.next().get(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME))) {
                                        z = true;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                            if (z) {
                                for (String str2 : this.f) {
                                    if (!TextUtils.isEmpty(str2) && packageName.contains(str2)) {
                                        z2 = true;
                                    }
                                }
                                th = z2 ? 1 : null;
                            }
                        }
                    }
                } catch (Exception unused2) {
                    r0.printStackTrace();
                }
                Throwable th2 = th;
                try {
                    try {
                        if (th2 == null) {
                            try {
                                BleFactory.getInstance().getK6Proxy().reConnectWithNtf();
                                return;
                            } catch (IllegalStateException unused3) {
                                Log.e("NtfCollector", "IllegalStateException " + packageName);
                                return;
                            }
                        }
                        if ((notification.flags & 2) != 0 && ((!packageName.equals(K6_MessageNoticeStruct.WHATSAPP) || TextUtils.isEmpty(notification.category) || !"call".equals(notification.category)) && !packageName.equals(K6_MessageNoticeStruct.SKYPE) && !packageName.equals(K6_MessageNoticeStruct.SKYPE_CN) && !packageName.equals(K6_MessageNoticeStruct.WEIXIN))) {
                            BleFactory.getInstance().getK6Proxy().reConnectWithNtf();
                            return;
                        }
                        if (packageName.equalsIgnoreCase(getPackageName())) {
                            BleFactory.getInstance().getK6Proxy().reConnectWithNtf();
                            return;
                        }
                        if (BluetoothHelper.getInstance().getMusicControl().isExistMusicApp(packageName).booleanValue()) {
                            BleFactory.getInstance().getK6Proxy().reConnectWithNtf();
                            if (BleFactory.getInstance().getK6Proxy().isConnectOK()) {
                                CharSequence charSequence2 = notification.tickerText;
                                if (charSequence2 != null) {
                                    a(charSequence2.toString());
                                    return;
                                }
                                return;
                            }
                            return;
                        }
                        int i2 = K6_MessageNoticeStruct.WEIXIN.equals(packageName) ? 4 : (K6_MessageNoticeStruct.FACEBOOK.equals(packageName) || K6_MessageNoticeStruct.FACEBOOK_ORCA.equals(packageName)) ? 6 : K6_MessageNoticeStruct.TWITTER.equals(packageName) ? 7 : K6_MessageNoticeStruct.QQ.equals(packageName) ? 3 : K6_MessageNoticeStruct.WHATSAPP.equals(packageName) ? 8 : (packageName.endsWith("mail") || "com.corp21cn.mail189".equals(packageName)) ? 5 : (K6_MessageNoticeStruct.SKYPE.equals(packageName) || K6_MessageNoticeStruct.SKYPE_CN.equals(packageName)) ? 9 : K6_MessageNoticeStruct.LINKEDIN.equals(packageName) ? 10 : K6_MessageNoticeStruct.LINE.equals(packageName) ? 11 : (packageName.contains("mms") || packageName.contains("sms") || packageName.contains("messaging")) ? 2 : K6_MessageNoticeStruct.MISSCALL.equals(packageName) ? 1 : (K6_MessageNoticeStruct.KAKAOTALK.equals(packageName) || K6_MessageNoticeStruct.KAKAO_SIMPLE.equals(packageName) || K6_MessageNoticeStruct.KAKAO_YELLOWID.equals(packageName)) ? 17 : K6_MessageNoticeStruct.INSTAGRAM.equals(packageName) ? 18 : (K6_MessageNoticeStruct.TELEGRAM.equals(packageName) || K6_MessageNoticeStruct.TELEGRAM_WEB.equals(packageName)) ? 19 : 16;
                        Lg.e("-- 开始解析通知内容 --");
                        CharSequence charSequence3 = notification.tickerText;
                        String string2 = charSequence3 != null ? charSequence3.toString() : "";
                        if (string2.equals("misscall")) {
                            return;
                        }
                        Object obj = notification.extras.get("android.title");
                        String string3 = obj != null ? obj.toString() : "";
                        Object obj2 = notification.extras.get("android.text");
                        String string4 = obj2 != null ? obj2.toString() : "";
                        Object obj3 = notification.extras.get("android.textLines");
                        String string5 = obj3 != null ? obj3.toString() : "";
                        Object obj4 = notification.extras.get("android.subText");
                        String string6 = obj4 != null ? obj4.toString() : "";
                        Object obj5 = notification.extras.get("android.summaryText");
                        String string7 = obj5 != null ? obj5.toString() : "";
                        int i3 = i2;
                        Lg.e("-- 原始通知内容:--");
                        Logger.e(Lg.getClassName(this), "-tickerText-  " + string2 + "-EXTRA_TITLE-  " + string3 + "-EXTRA_TEXT-  " + string4 + "-EXTRA_TEXT_LINES-  " + string5 + "-EXTRA_SUB_TEXT-  " + string6 + "-EXTRA_SUMMARY_TEXT-  " + string7);
                        Lg.e("-EXTRA_ALL-" + notification.extras);
                        if (i3 == 11) {
                            String string8 = notification.extras.toString();
                            String str3 = string8;
                            try {
                                String[] strArrSplit2 = string8.split(",");
                                int length2 = strArrSplit2.length;
                                int i4 = 0;
                                while (i4 < length2) {
                                    String str4 = strArrSplit2[i4];
                                    String str5 = str4;
                                    if (str4 == null || !str5.contains("line.message.id")) {
                                        str5 = str3;
                                    }
                                    i4++;
                                    str3 = str5;
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                Lg.e("Line Exception =" + e);
                            }
                            if (!TextUtils.isEmpty(this.h) && this.h.equals(str3)) {
                                return;
                            }
                            Lg.e("lineMsg=" + str3);
                            this.h = str3;
                        }
                        if (i2 == 8 || i2 == 9) {
                            if (statusBarNotification.getTag() == null && !TextUtils.isEmpty(notification.category) && "msg".equals(notification.category) && !TextUtils.isEmpty(string5)) {
                                return;
                            }
                        } else if (i2 == 2 && TextUtils.isEmpty(notification.category) && BleSystemUtils.isSAMSUNG()) {
                            return;
                        }
                        if (!TextUtils.isEmpty(this.c) && this.c.equals(string4) && System.currentTimeMillis() - this.d < 1500) {
                            this.d = System.currentTimeMillis();
                            return;
                        }
                        String str6 = string4;
                        this.d = System.currentTimeMillis();
                        this.c = string4;
                        String strTrim = "";
                        String strTrim2 = "";
                        boolean z3 = false;
                        if (str6.length() > 0 && string3.length() > 0) {
                            String str7 = string4;
                            strTrim = string3.trim();
                            strTrim2 = str7.trim();
                            z3 = true;
                        }
                        if (!z3 && string4.length() > 0 && string4.contains(":")) {
                            String[] strArrSplit3 = string4.split(":");
                            strTrim = strArrSplit3[0].trim();
                            strTrim2 = strArrSplit3[1].trim();
                            z3 = true;
                        }
                        if (!z3 && string2.length() > 0 && string2.contains(":")) {
                            String[] strArrSplit4 = string2.split(":");
                            strTrim = strArrSplit4[0].trim();
                            strTrim2 = strArrSplit4[1].trim();
                            z3 = true;
                        }
                        if (!z3 && string3.length() > 0 && string2.length() > 0) {
                            String str8 = string2;
                            strTrim = string3.trim();
                            strTrim2 = str8.trim();
                            z3 = true;
                        }
                        if (!z3 && string3.length() > 0) {
                            strTrim = string3.trim();
                            strTrim2 = "";
                            z3 = true;
                        }
                        if (!z3 && string4.length() > 0) {
                            strTrim = "";
                            strTrim2 = string4.trim();
                            z3 = true;
                        }
                        if (!z3 && string2.length() > 0) {
                            strTrim = "";
                            strTrim2 = string2.trim();
                            z3 = true;
                        }
                        if (!z3 || TextUtils.isEmpty(strTrim2) || TextUtils.isEmpty(strTrim2.trim())) {
                            return;
                        }
                        String strNoContainsEmoji = BleSystemUtils.noContainsEmoji(strTrim2);
                        String str9 = strNoContainsEmoji;
                        if (TextUtils.isEmpty(strNoContainsEmoji)) {
                            str9 = strTrim2;
                        }
                        String str10 = strTrim;
                        K6_MessageNoticeStruct k6_MessageNoticeStruct = new K6_MessageNoticeStruct(TimeUtil.now(), (byte) i2);
                        k6_MessageNoticeStruct.setSendContext(str10, (byte) 2, str9);
                        if (BleFactory.getInstance().getK6Proxy().isConnectOK()) {
                            BleFactory.getInstance().getK6Proxy().getSendHelper().sendMessage_notice(k6_MessageNoticeStruct);
                        } else {
                            BleFactory.getInstance().getK6Proxy().setMsg(k6_MessageNoticeStruct);
                            BleFactory.getInstance().getK6Proxy().reConnectWithNtf();
                        }
                    } catch (Exception unused4) {
                        th2.printStackTrace();
                    }
                } catch (Error unused5) {
                    th2.printStackTrace();
                }
            }
        }
    }

    @Override // android.app.Service
    public void onCreate() throws IllegalArgumentException {
        super.onCreate();
        b();
        f36a = this;
        this.b = new Handler(Looper.getMainLooper());
    }

    @Override // android.media.RemoteController.OnClientUpdateListener
    public void onClientChange(boolean z) {
        Log.d("test", "");
    }

    @Override // android.media.RemoteController.OnClientUpdateListener
    public void onClientPlaybackStateUpdate(int i) {
        Log.d("test", "");
    }

    @Override // android.media.RemoteController.OnClientUpdateListener
    public void onClientPlaybackStateUpdate(int i, long j, long j2, float f) {
        Log.d("test", "");
    }

    @Override // android.media.RemoteController.OnClientUpdateListener
    public void onClientTransportControlUpdate(int i) {
        Log.d("RemoteController", "onClientTransportControlUpdate");
    }

    @Override // android.media.RemoteController.OnClientUpdateListener
    public void onClientMetadataUpdate(RemoteController.MetadataEditor metadataEditor) {
        String string = metadataEditor.getString(7, "null");
        Lg.d("RemoteController", "onClientMetadataUpdate=" + string);
        if (string != null) {
            a(string);
        }
    }

    public void a(String str) {
        if ("网易云音乐正在播放".equals(str)) {
            return;
        }
        this.b.removeCallbacksAndMessages(null);
        this.b.postDelayed(new a(str), 500L);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void b() throws IllegalArgumentException {
        IllegalArgumentException illegalArgumentException;
        Log.d("RemoteController", "RemoteController");
        this.g = new RemoteController(getApplicationContext(), this);
        try {
            illegalArgumentException = ((AudioManager) getSystemService("audio")).registerRemoteController(this.g) ? 1 : 0;
            Log.d("RemoteController", "RemoteController");
        } catch (NullPointerException unused) {
            printStackTrace();
            illegalArgumentException = null;
        } catch (SecurityException unused2) {
            printStackTrace();
            illegalArgumentException = null;
        } catch (Exception unused3) {
            printStackTrace();
            illegalArgumentException = null;
        }
        IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
        if (illegalArgumentException2 != null) {
            try {
                this.g.setArtworkConfiguration(100, 100);
                this.g.setSynchronizationMode(1);
                Log.d("RemoteController", "registered");
            } catch (IllegalArgumentException unused4) {
                illegalArgumentException2.printStackTrace();
            }
        }
    }

    @Override // android.content.ContextWrapper, android.content.Context
    @RequiresApi(api = 19)
    public ComponentName startService(Intent intent) {
        Lg.e("tarting Notification service");
        return super.startService(intent);
    }

    @Override // android.service.notification.NotificationListenerService
    public void onNotificationPosted(StatusBarNotification statusBarNotification) {
        a(statusBarNotification);
    }

    /* JADX WARN: Not initialized variable reg: 0, insn: 0x00bc: INVOKE (r0 I:java.lang.Exception) VIRTUAL call: java.lang.Exception.printStackTrace():void A[MD:():void (c)], block:B:30:0x00bc */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, java.lang.Error] */
    public void a() {
        Exception excPrintStackTrace;
        ?? HasNext;
        try {
            try {
                ComponentName componentName = new ComponentName(this, (Class<?>) NtfCollector.class);
                MediaSessionManager mediaSessionManager = (MediaSessionManager) getSystemService("media_session");
                this.i = mediaSessionManager;
                List<MediaController> activeSessions = mediaSessionManager.getActiveSessions(componentName);
                Lg.e("kkkkkk", "onCreate listener: controllers size = " + activeSessions.size());
                Iterator<MediaController> it = activeSessions.iterator();
                while (true) {
                    HasNext = it.hasNext();
                    if (HasNext == 0) {
                        return;
                    }
                    MediaController next = it.next();
                    MediaMetadata metadata = next.getMetadata();
                    String packageName = next.getPackageName();
                    if (metadata != null && packageName.equals(BluetoothHelper.getInstance().getPersistent().getMusicPackageName())) {
                        String string = metadata.getString("android.media.metadata.TITLE");
                        if (!TextUtils.isEmpty(string) && BleFactory.getInstance().getK6Proxy().isConnectOK()) {
                            BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_MUSIC_CONTROL(new K6_DATA_TYPE_MUSIC_CONTROL(7, string.getBytes()));
                        }
                    }
                }
            } catch (Exception unused) {
                excPrintStackTrace.printStackTrace();
            }
        } catch (Error unused2) {
            HasNext.printStackTrace();
        }
    }

    @Override // android.service.notification.NotificationListenerService
    public void onListenerConnected() {
        Log.e("NtfCollector", "onListenerConnected");
    }

    @Override // android.service.notification.NotificationListenerService
    public void onListenerDisconnected() {
        Log.e("NtfCollector", "onListenerDisconnected");
    }

    @Override // android.service.notification.NotificationListenerService, android.app.Service
    public IBinder onBind(Intent intent) {
        Log.e("NtfCollector", "onBind");
        return super.onBind(intent);
    }

    @Override // android.service.notification.NotificationListenerService, android.app.Service
    public void onDestroy() {
        Log.e("NtfCollector", "onDestroy");
        super.onDestroy();
    }
}
