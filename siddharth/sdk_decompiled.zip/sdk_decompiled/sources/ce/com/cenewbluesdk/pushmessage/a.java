package ce.com.cenewbluesdk.pushmessage;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Process;
import android.util.Log;
import androidx.core.app.NotificationManagerCompat;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/pushmessage/a.class */
public class a {
    /* JADX WARN: Not initialized variable reg: 0, insn: 0x0087: INVOKE (r0 I:java.lang.RuntimeException) VIRTUAL call: java.lang.RuntimeException.printStackTrace():void A[MD:():void (s)], block:B:34:0x0087 */
    public static boolean b(Context context) throws SecurityException {
        RuntimeException runtimeExceptionPrintStackTrace;
        try {
            ComponentName componentName = new ComponentName(context, (Class<?>) NtfCollector.class);
            boolean z = false;
            List<ActivityManager.RunningServiceInfo> runningServices = ((ActivityManager) context.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE);
            if (runningServices == null) {
                Log.e("MyNotificationUtil", "ensureCollectorRunning() runningServices is NULL");
                return false;
            }
            for (ActivityManager.RunningServiceInfo runningServiceInfo : runningServices) {
                if (runningServiceInfo.service.equals(componentName)) {
                    if (runningServiceInfo.pid == Process.myPid()) {
                        z = true;
                    }
                }
            }
            if (z) {
                Log.d("MyNotificationUtil", "ensureCollectorRunning: collector is running");
                return true;
            }
            Log.d("MyNotificationUtil", "ensureCollectorRunning: collector not running, reviving...");
            if (!a(context)) {
                return false;
            }
            c(context);
            return false;
        } catch (RuntimeException unused) {
            runtimeExceptionPrintStackTrace.printStackTrace();
            return false;
        }
    }

    public static boolean a(Context context) {
        return NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.getPackageName());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity) {
        Intent intent;
        Intent intent2;
        Intent intent3;
        try {
            if (Build.VERSION.SDK_INT >= 22) {
                intent2 = intent3;
                intent3 = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            } else {
                intent2 = intent;
                intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            }
            activity.startActivity(intent2);
        } catch (Exception unused) {
            activity.printStackTrace();
        }
    }

    public static void c(Context context) {
        PackageManager packageManager = context.getPackageManager();
        ComponentName componentName = new ComponentName(context, (Class<?>) NtfCollector.class);
        packageManager.setComponentEnabledSetting(componentName, 2, 1);
        packageManager.setComponentEnabledSetting(componentName, 1, 1);
    }
}
