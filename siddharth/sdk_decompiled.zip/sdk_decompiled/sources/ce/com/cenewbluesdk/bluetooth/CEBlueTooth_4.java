package ce.com.cenewbluesdk.bluetooth;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_4.class */
public class CEBlueTooth_4 extends CEBlueToothBase {

    /* renamed from: a, reason: collision with root package name */
    private static final int f14a = 35000;
    private static final int b = 15000;
    private BluetoothGatt c;
    private BluetoothAdapter d;
    private Context e;
    private byte[] j;
    private String l;
    private String f = "";
    private String g = "";
    private BluetoothDevice h = null;
    public int i = 1;
    private boolean k = false;
    private List<BluetoothGattService> m = null;
    private List<BluetoothGattCharacteristic> n = new ArrayList();
    private List<BluetoothGattCharacteristic> o = new ArrayList();
    boolean p = false;
    private Handler q = new Handler();
    private c r = new c(this, null);
    private final BluetoothGattCallback s = new a();
    public BroadcastReceiver t = new b();

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_4$a.class */
    class a extends BluetoothGattCallback {
        a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v13 */
        /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.Exception] */
        /* JADX WARN: Type inference failed for: r0v27 */
        /* JADX WARN: Type inference failed for: r0v53 */
        /* JADX WARN: Type inference failed for: r0v54 */
        /* JADX WARN: Type inference failed for: r0v55 */
        /* JADX WARN: Type inference failed for: r0v56 */
        /* JADX WARN: Type inference failed for: r0v57 */
        /* JADX WARN: Type inference failed for: r0v58 */
        @Override // android.bluetooth.BluetoothGattCallback
        public void onConnectionStateChange(BluetoothGatt bluetoothGatt, int i, int i2) {
            CEBlueTooth_4 cEBlueTooth_4 = CEBlueTooth_4.this;
            if (!cEBlueTooth_4.p) {
                Context context = cEBlueTooth_4.e;
                CEBlueTooth_4 cEBlueTooth_42 = CEBlueTooth_4.this;
                context.registerReceiver(cEBlueTooth_42.t, cEBlueTooth_42.e());
                CEBlueTooth_4.this.p = true;
            }
            StringBuilder sbAppend = new StringBuilder().append("外部：");
            Object[] objArr = new Object[2];
            objArr[0] = bluetoothGatt == null ? "null" : bluetoothGatt.getDevice();
            ?? r0 = bluetoothGatt;
            objArr[1] = CEBlueTooth_4.this.c == null ? "null" : CEBlueTooth_4.this.c.getDevice();
            Lg.e(sbAppend.append(String.format("%s != %s", objArr)).toString());
            if (r0 != CEBlueTooth_4.this.c) {
                Object[] objArr2 = new Object[2];
                objArr2[0] = bluetoothGatt == null ? "null" : bluetoothGatt.getDevice();
                objArr2[1] = CEBlueTooth_4.this.c == null ? "null" : CEBlueTooth_4.this.c.getDevice();
                Lg.e(String.format("%s != %s", objArr2));
                Lg.e("New_First!!!");
                return;
            }
            try {
                Lg.e("onConnectionStateChange： newState = " + i2 + " status " + i);
                if (i2 == 2) {
                    if (i == 129 || i == 133) {
                        CEBlueTooth_4.this.k = false;
                        CEBlueTooth_4 cEBlueTooth_43 = CEBlueTooth_4.this;
                        cEBlueTooth_43.blueToothConnectStateChange(0);
                        r0 = cEBlueTooth_43;
                    } else {
                        CEBlueTooth_4.this.k = true;
                        CEBlueTooth_4 cEBlueTooth_44 = CEBlueTooth_4.this;
                        cEBlueTooth_44.h();
                        r0 = cEBlueTooth_44;
                    }
                } else if (i2 == 0) {
                    int i3 = i;
                    CEBlueTooth_4.this.blueToothConnectStateChange(0);
                    CEBlueTooth_4.this.k = false;
                    r0 = i3;
                    if (i3 > 0) {
                        BluetoothGatt bluetoothGatt2 = CEBlueTooth_4.this.c;
                        r0 = bluetoothGatt2;
                        if (bluetoothGatt2 != null) {
                            CEBlueTooth_4.this.c.close();
                            r0 = CEBlueTooth_4.this.c = null;
                        }
                    }
                } else {
                    r0 = CEBlueTooth_4.this.k = false;
                }
            } catch (Exception unused) {
                r0.printStackTrace();
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onServicesDiscovered(BluetoothGatt bluetoothGatt, int i) throws IOException {
            super.onServicesDiscovered(bluetoothGatt, i);
            Lg.e("blue_4", "status=" + i);
            if (i == 0) {
                CEBlueTooth_4.this.c();
                CEBlueTooth_4 cEBlueTooth_4 = CEBlueTooth_4.this;
                cEBlueTooth_4.a((List<BluetoothGattService>) cEBlueTooth_4.m);
            } else {
                if (i == 129 || i == 133) {
                    CEBlueTooth_4.this.a();
                }
                CEBlueTooth_4.this.d();
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicRead(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
            super.onCharacteristicRead(bluetoothGatt, bluetoothGattCharacteristic, i);
            if (i == 0) {
                CEBlueTooth_4.this.a(bluetoothGattCharacteristic);
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicWrite(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
            super.onCharacteristicWrite(bluetoothGatt, bluetoothGattCharacteristic, i);
            if (i == 0) {
                CEBlueTooth_4 cEBlueTooth_4 = CEBlueTooth_4.this;
                cEBlueTooth_4.dataSendSucceed(cEBlueTooth_4.j);
            } else {
                CEBlueTooth_4 cEBlueTooth_42 = CEBlueTooth_4.this;
                cEBlueTooth_42.dataSendFailed(cEBlueTooth_42.j);
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic) {
            super.onCharacteristicChanged(bluetoothGatt, bluetoothGattCharacteristic);
            CEBlueTooth_4.this.a(bluetoothGattCharacteristic);
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onDescriptorWrite(BluetoothGatt bluetoothGatt, BluetoothGattDescriptor bluetoothGattDescriptor, int i) {
            super.onDescriptorWrite(bluetoothGatt, bluetoothGattDescriptor, i);
            Log.e("qob", "onDescriptorWrite " + i);
            CEBlueTooth_4.this.a();
            CEBlueTooth_4.this.blueToothConnectStateChange(1);
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onMtuChanged(BluetoothGatt bluetoothGatt, int i, int i2) {
            super.onMtuChanged(bluetoothGatt, i, i2);
            Log.e("qob", "onMtuChanged " + i);
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_4$b.class */
    class b extends BroadcastReceiver {

        /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_4$b$a.class */
        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() throws IOException {
                CEBlueTooth_4 cEBlueTooth_4 = CEBlueTooth_4.this;
                cEBlueTooth_4.connect(cEBlueTooth_4.f);
            }
        }

        b() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            action.hashCode();
            if (action.equals("android.bluetooth.adapter.action.STATE_CHANGED")) {
                int intExtra = intent.getIntExtra("android.bluetooth.adapter.extra.STATE", 0);
                if (intExtra == 10) {
                    Log.i("YAN_registerBlue", "Bluetooth is off");
                    return;
                }
                if (intExtra != 12) {
                    return;
                }
                Log.i("YAN_registerBlue", "Bluetooth is on and starts connecting");
                if (CEBlueTooth_4.this.f == null) {
                    Log.i("YAN_NULL_MB", "mBluetoothDeviceAddress is null");
                    if (CEBlueTooth_4.this.g == null) {
                        Log.i("YAN_ALL_NULL", "GG");
                        return;
                    } else {
                        Log.i("YAN_NULL_MS", "mSpareDeviceAddress is not null");
                        CEBlueTooth_4 cEBlueTooth_4 = CEBlueTooth_4.this;
                        cEBlueTooth_4.f = cEBlueTooth_4.g;
                    }
                }
                CEBlueTooth_4.this.d = ((BluetoothManager) CEBlueTooth_4.this.e.getSystemService("bluetooth")).getAdapter();
                CEBlueTooth_4.this.c = null;
                String blueAddress = BleFactory.getInstance().getK6Proxy().getBlueAddress();
                Log.i("ContentValues", "蓝牙被打开" + blueAddress);
                if (blueAddress == null || blueAddress.equals("")) {
                    return;
                }
                new Handler().postDelayed(new a(), 500L);
            }
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_4$c.class */
    private class c implements Runnable {
        private c() {
        }

        /* synthetic */ c(CEBlueTooth_4 cEBlueTooth_4, a aVar) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() throws IOException {
            Lg.e("Ce blue_4", "Found service timeout");
            CEBlueTooth_4.this.d();
        }
    }

    private void g() {
        this.q.removeCallbacks(this.r);
        this.q.postDelayed(this.r, 15000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a() {
        this.q.removeCallbacks(this.r);
    }

    public CEBlueTooth_4(Context context, String str) {
        this.l = str;
        this.e = context;
        this.d = ((BluetoothManager) context.getSystemService("bluetooth")).getAdapter();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    private void f() {
        ?? r0;
        Intent intent = new Intent("connect_out_time");
        AlarmManager alarmManager = (AlarmManager) this.e.getSystemService("alarm");
        int i = Build.VERSION.SDK_INT;
        PendingIntent broadcast = PendingIntent.getBroadcast(this.e, 0, intent, 67108864);
        if (i < 19) {
            AlarmManager alarmManager2 = alarmManager;
            alarmManager2.set(2, SystemClock.elapsedRealtime() + 35000, broadcast);
            r0 = alarmManager2;
        } else {
            AlarmManager alarmManager3 = alarmManager;
            alarmManager3.setExact(2, SystemClock.elapsedRealtime() + 35000, broadcast);
            r0 = alarmManager3;
        }
        try {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("connect_out_time");
            this.e.registerReceiver(this, intentFilter);
        } catch (Exception unused) {
            r0.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(List<BluetoothGattService> list) {
        this.n.clear();
        if (list == null) {
            return;
        }
        for (BluetoothGattService bluetoothGattService : list) {
            Log.i("YAN_UID", bluetoothGattService.getUuid().toString());
            if (bluetoothGattService.getUuid().toString().toUpperCase().equals(UUID.fromString(this.l).toString().toUpperCase())) {
                for (BluetoothGattCharacteristic bluetoothGattCharacteristic : bluetoothGattService.getCharacteristics()) {
                    int properties = bluetoothGattCharacteristic.getProperties();
                    Lg.e("charaProp = " + properties);
                    if (properties == 16) {
                        a(bluetoothGattCharacteristic, true);
                        this.o.add(bluetoothGattCharacteristic);
                        Lg.e("发现的读特特征：" + bluetoothGattCharacteristic.getUuid().toString());
                    } else if (!this.n.contains(bluetoothGattCharacteristic)) {
                        this.n.add(bluetoothGattCharacteristic);
                        Lg.e("发现的写特征：" + bluetoothGattCharacteristic.getUuid().toString());
                    }
                }
            }
        }
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void connect(String str) throws IOException {
        int i;
        Lg.e("connect mac:" + str);
        String str2 = this.f;
        if (str2 != null && str2.equals(str) && ((i = this.blueConnectState) == 2 || i == 1)) {
            Lg.e("This connection will not be executed, the current connection status：" + this.blueConnectState + "  The address of the connection Device address ：" + this.f + "  mac:" + str);
            return;
        }
        d();
        Lg.e("liu", "Start the connection");
        if (this.d == null || str == null) {
            Lg.e("YAN_NULL_M", "adapter_NULL or mac_NULL");
            return;
        }
        this.f = str;
        this.g = str;
        blueToothConnectStateChange(2);
        f();
        BluetoothGatt bluetoothGatt = this.c;
        if (bluetoothGatt != null && bluetoothGatt.getDevice().getAddress().equals(str)) {
            Lg.e("YAN_GATT", "GATT重连！！！");
            if (this.c.connect()) {
                return;
            }
            Lg.e("YAN_GATT", "mBluetoothGatt.connect() is false!");
            blueToothConnectStateChange(0);
            return;
        }
        Lg.e("YAN_GATT", "GATT第一次连接！！！");
        BluetoothDevice remoteDevice = this.d.getRemoteDevice(this.f);
        this.h = remoteDevice;
        if (remoteDevice == null) {
            blueToothConnectStateChange(0);
            Lg.e("YAN_GATT", " mBluetoothDevice is null ");
            return;
        }
        this.c = remoteDevice.connectGatt(this.e, false, this.s);
        Lg.e("YAN_GATT", "connectGatt！！！");
        if (this.c == null) {
            Lg.e("YAN_GATT", "mBluetoothGatt是空的！！！");
        }
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public boolean isConnectedDevice(BluetoothDevice bluetoothDevice) {
        return false;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Lg.e("onReceive 连接超时 " + this.k);
        if (!this.k) {
            blueToothConnectStateChange(0);
        }
    }

    public IntentFilter e() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.adapter.action.STATE_CHANGED");
        return intentFilter;
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void disConnect() throws IOException {
        Lg.e("liu", "Disconnect");
        BluetoothGatt bluetoothGatt = this.c;
        if (bluetoothGatt != null) {
            this.f = null;
            bluetoothGatt.disconnect();
            b();
        }
        blueToothConnectStateChange(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void d() throws IOException {
        BluetoothGatt bluetoothGatt;
        Lg.e("liu", "internalDisConnect");
        this.k = false;
        blueToothConnectStateChange(0);
        if (this.d == null || (bluetoothGatt = this.c) == null) {
            return;
        }
        this.f = null;
        try {
            bluetoothGatt.disconnect();
            b();
        } catch (Exception unused) {
            printStackTrace();
            this.c = null;
        }
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void sendData(byte[] bArr) {
        int i = this.i + 1;
        this.i = i;
        if (i >= this.n.size()) {
            this.i = 0;
        }
        sendData(this.i, bArr);
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void sendData(int i, byte[] bArr) {
        if (!this.k || this.n.size() == 0) {
            Lg.e("CEBlueTooth4 SendFailed mConnected =" + this.k + " writeCharas.size() =" + this.n.size() + " index =" + i + " bytes=" + Arrays.toString(bArr));
            dataSendFailed(bArr);
        } else {
            if (i < 0 || i >= this.n.size()) {
                sendData(bArr);
                return;
            }
            BluetoothGattCharacteristic bluetoothGattCharacteristic = this.n.get(i);
            bluetoothGattCharacteristic.setValue(bArr);
            this.j = bArr;
            Lg.e("Sent data4：" + ByteUtil.byte2hex(this.j));
            a(bluetoothGattCharacteristic, bArr);
        }
    }

    public void b() {
        Log.d("liu", "close(), mBluetoothGatt = " + this.c);
        BluetoothGatt bluetoothGatt = this.c;
        if (bluetoothGatt != null) {
            bluetoothGatt.close();
        }
        this.c = null;
    }

    public void h() throws IOException {
        Lg.e("liu", "Began to find services");
        if (this.c == null) {
            d();
        } else {
            g();
            this.c.discoverServices();
        }
    }

    public void c() {
        List<BluetoothGattService> list = this.m;
        if (list != null && list.size() > 0) {
            this.m.clear();
        }
        BluetoothGatt bluetoothGatt = this.c;
        if (bluetoothGatt != null) {
            this.m = bluetoothGatt.getServices();
        }
    }

    public void a(BluetoothGattCharacteristic bluetoothGattCharacteristic) {
        if (this.d == null || this.c == null || bluetoothGattCharacteristic == null) {
            return;
        }
        byte[] value = bluetoothGattCharacteristic.getValue();
        bluetoothGattCharacteristic.getUuid();
        Lg.e("Received data on the device side" + ByteUtil.byte2hex(value));
        blueToothReceiptDate(value);
    }

    public void a(BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr) {
        if (this.d == null || this.c == null || bluetoothGattCharacteristic == null) {
            return;
        }
        bluetoothGattCharacteristic.setValue(bArr);
        this.c.writeCharacteristic(bluetoothGattCharacteristic);
    }

    public void a(BluetoothGattCharacteristic bluetoothGattCharacteristic, boolean z) {
        BluetoothGatt bluetoothGatt;
        if (this.d == null || (bluetoothGatt = this.c) == null) {
            return;
        }
        if (!bluetoothGatt.setCharacteristicNotification(bluetoothGattCharacteristic, z)) {
            Log.e("------", "Setting proper notification status for characteristic failed!");
        }
        BluetoothGattDescriptor descriptor = bluetoothGattCharacteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
        if (descriptor != null) {
            descriptor.setValue(z ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            this.c.writeDescriptor(descriptor);
        }
    }
}
