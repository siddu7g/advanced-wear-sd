package ce.com.cenewbluesdk.bluetooth;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import ce.com.cenewbluesdk.uitl.Logger;

/* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueToothBase.class */
public abstract class CEBlueToothBase extends BroadcastReceiver {
    protected int blueConnectState = 0;
    private a blueStateChangeListen;
    private b blueReceiptDataListen;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueToothBase$a.class */
    public interface a {
        void blueToothConnectStateChange(int i);
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueToothBase$b.class */
    public interface b {
        void blueToothReceiptData(byte[] bArr);

        void dataSendSucceed(byte[] bArr);

        void dataSendFailed(byte[] bArr);
    }

    public abstract void connect(String str);

    public void connect(BluetoothDevice bluetoothDevice) {
    }

    public abstract boolean isConnectedDevice(BluetoothDevice bluetoothDevice);

    public abstract void disConnect();

    public abstract void sendData(byte[] bArr);

    public abstract void sendData(int i, byte[] bArr);

    public void setBlueStateChangeListen(a aVar) {
        this.blueStateChangeListen = aVar;
    }

    public void setBlueReceiptDataListen(b bVar) {
        this.blueReceiptDataListen = bVar;
    }

    public void dataSendSucceed(byte[] bArr) {
        b bVar = this.blueReceiptDataListen;
        if (bVar != null) {
            bVar.dataSendSucceed(bArr);
        }
    }

    public void blueToothReceiptDate(byte[] bArr) {
        b bVar = this.blueReceiptDataListen;
        if (bVar != null) {
            bVar.blueToothReceiptData(bArr);
        }
    }

    public void dataSendFailed(byte[] bArr) {
        b bVar = this.blueReceiptDataListen;
        if (bVar != null) {
            bVar.dataSendFailed(bArr);
        }
    }

    public void blueToothConnectStateChange(int i) {
        Logger.e("timeBroad", "connectState = " + i);
        if (this.blueConnectState != i) {
            this.blueConnectState = i;
            a aVar = this.blueStateChangeListen;
            if (aVar != null) {
                aVar.blueToothConnectStateChange(i);
            }
        }
    }

    public int getBlueToothConnectState() {
        return this.blueConnectState;
    }
}
