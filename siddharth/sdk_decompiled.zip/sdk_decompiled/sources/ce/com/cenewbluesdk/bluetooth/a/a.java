package ce.com.cenewbluesdk.bluetooth.a;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import ce.com.cenewbluesdk.uitl.ThreadPoolManager;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.UUID;

/* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/a/a.class */
public class a {

    /* renamed from: a, reason: collision with root package name */
    private static final String f30a = "BleConnectTool";
    private Context c;
    private BluetoothProfile e;
    private boolean f;
    private boolean g;
    private boolean h;
    private BluetoothDevice i;
    private BluetoothDevice j;
    BluetoothSocket l;
    int n;
    private BluetoothAdapter b = BluetoothAdapter.getDefaultAdapter();
    private boolean d = false;
    private BroadcastReceiver k = new C0003a();
    byte[] m = new byte[1024];

    /* renamed from: ce.com.cenewbluesdk.bluetooth.a.a$a, reason: collision with other inner class name */
    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/a/a$a.class */
    class C0003a extends BroadcastReceiver {
        C0003a() {
        }

        /* JADX WARN: Not initialized variable reg: 0, insn: 0x01ae: INVOKE (r0 I:java.lang.Exception) VIRTUAL call: java.lang.Exception.printStackTrace():void A[MD:():void (c)], block:B:44:0x01ae */
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            Exception excPrintStackTrace;
            try {
                String action = intent.getAction();
                if (!"android.bluetooth.device.action.FOUND".equals(action)) {
                    if ("android.bluetooth.adapter.action.DISCOVERY_FINISHED".equals(action)) {
                        if (!a.this.g) {
                            a aVar = a.this;
                            aVar.i = aVar.c();
                            if (a.this.i != null && ce.com.cenewbluesdk.bluetooth.a.c.a(context).b(a.this.i)) {
                                Logger.e(a.f30a, "未搜索到指定设备，配对设备已连接");
                                a aVar2 = a.this;
                                aVar2.c(aVar2.i);
                                a.this.b(context);
                            }
                            if (a.this.i != null && !ce.com.cenewbluesdk.bluetooth.a.c.a(context).b(a.this.i) && !a.this.h) {
                                Logger.e(a.f30a, "未搜索到设备，但有配对未连接，尝试进行连接");
                                ThreadPoolManager threadPoolManager = ThreadPoolManager.getInstance();
                                a aVar3 = a.this;
                                threadPoolManager.execute(aVar3.new b(aVar3.i));
                                a.this.b(context);
                            }
                        }
                        a.this.h = false;
                        return;
                    }
                    return;
                }
                a.this.g = false;
                a aVar4 = a.this;
                aVar4.i = aVar4.c();
                if (a.this.i != null && ce.com.cenewbluesdk.bluetooth.a.c.a(context).b(a.this.i)) {
                    Logger.e(a.f30a, "设备已连接，退出搜索");
                    a.this.b.cancelDiscovery();
                    a.this.b(context);
                    return;
                }
                a.this.j = (BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE");
                Logger.i(a.f30a, "Address:" + a.this.j.getAddress() + "  name:" + a.this.j.getName());
                if (a.this.j.getAddress() == null || !CEBlueSharedPreference.getA2dpMac().contains(a.this.j.getAddress())) {
                    return;
                }
                a aVar5 = a.this;
                aVar5.i = aVar5.j;
                a.this.g = true;
                ThreadPoolManager threadPoolManager2 = ThreadPoolManager.getInstance();
                a aVar6 = a.this;
                threadPoolManager2.execute(aVar6.new b(aVar6.i));
                a.this.h = true;
                a.this.b.cancelDiscovery();
                a.this.b(context);
            } catch (Exception unused) {
                excPrintStackTrace.printStackTrace();
            }
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/a/a$b.class */
    private class b implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        private BluetoothDevice f32a;
        private BluetoothDevice b;

        public b(BluetoothDevice bluetoothDevice) {
            this.f32a = bluetoothDevice;
            if (a.this.b == null) {
                a.this.b = BluetoothAdapter.getDefaultAdapter();
            }
            this.b = a.this.b.getRemoteDevice(bluetoothDevice.getAddress());
        }

        public b(String str) {
            if (a.this.b == null) {
                a.this.b = BluetoothAdapter.getDefaultAdapter();
            }
            this.b = a.this.b.getRemoteDevice(str);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
        /* JADX WARN: Type inference failed for: r0v16, types: [ce.com.cenewbluesdk.bluetooth.a.a, java.lang.Exception] */
        /* JADX WARN: Type inference failed for: r0v8, types: [ce.com.cenewbluesdk.bluetooth.a.a] */
        @Override // java.lang.Runnable
        public void run() throws NoSuchMethodException, SecurityException, IOException {
            ?? r0;
            try {
                a.this.l = this.b.createRfcommSocketToServiceRecord(UUID.fromString(CEDevK6Proxy.UUID));
                Logger.d(a.f30a, "连接服务端...");
                boolean zC = false;
                if (this.b.getType() == 3 && Build.VERSION.SDK_INT >= 23) {
                    zC = ce.com.cenewbluesdk.bluetooth.a.b.a(this.b, 1);
                    Logger.d(a.f30a, "BLE与经典蓝牙地址相同." + zC);
                }
                if (!zC) {
                    zC = ce.com.cenewbluesdk.bluetooth.a.b.c(this.b.getClass(), this.b);
                }
                if (zC) {
                    Logger.d(a.f30a, "createBond连接成功.");
                } else {
                    Logger.d(a.f30a, "createBond连接失败.");
                }
                r0 = a.this;
                r0.a(this.b);
            } catch (Exception unused) {
                r0.printStackTrace();
                try {
                    Logger.e(a.f30a, "连接失败，尝试createRfcommSocket连接");
                    Class<?> cls = this.f32a.getClass();
                    Class<?>[] clsArr = new Class[1];
                    clsArr[0] = Integer.TYPE;
                    Method method = cls.getMethod("createRfcommSocket", clsArr);
                    a aVar = a.this;
                    BluetoothDevice bluetoothDevice = this.f32a;
                    Object[] objArr = new Object[1];
                    objArr[0] = 1;
                    aVar.l = (BluetoothSocket) method.invoke(bluetoothDevice, objArr);
                    a.this.l.connect();
                    Logger.d(a.f30a, "createRfcommSocket连接成功");
                    r0 = a.this;
                    r0.b();
                } catch (Exception unused2) {
                    r0.printStackTrace();
                    try {
                        Logger.e(a.f30a, "createRfcommSocket连接失败\n");
                        Logger.d(a.f30a, "关闭socket");
                    } catch (Exception unused3) {
                        Logger.d(a.f30a, "关闭socket");
                    }
                    a.this.b();
                }
            }
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/a/a$c.class */
    public class c implements BluetoothProfile.ServiceListener {
        public c() {
        }

        @Override // android.bluetooth.BluetoothProfile.ServiceListener
        public void onServiceConnected(int i, BluetoothProfile bluetoothProfile) {
            if (i == 1) {
                a.this.e = bluetoothProfile;
            }
        }

        @Override // android.bluetooth.BluetoothProfile.ServiceListener
        public void onServiceDisconnected(int i) {
            a.this.e = null;
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
        	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:44)
        */
    public void a(
    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r8v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [ce.com.cenewbluesdk.bluetooth.a.a] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v5, types: [android.content.Context] */
    public void b(Context context) {
        ?? r0 = this;
        Logger.e(f30a, "反注册搜索");
        r0.f = false;
        try {
            try {
                BroadcastReceiver broadcastReceiver = r0.k;
                if (broadcastReceiver != null) {
                    r0 = context;
                    r0.unregisterReceiver(broadcastReceiver);
                }
            } catch (IllegalArgumentException e) {
                Logger.e(Lg.getClassName(this), e.toString());
            }
        } catch (Exception unused) {
            r0.printStackTrace();
        }
    }

    public void b(BluetoothDevice bluetoothDevice) {
        Logger.e(f30a, "connectDevice");
        if (TextUtils.isEmpty(CEBlueSharedPreference.getDevAddress())) {
            Logger.e(f30a, "设备已断开，不再连接经典蓝牙1");
            this.i = null;
            this.b.cancelDiscovery();
            b(this.c);
            return;
        }
        this.i = bluetoothDevice;
        this.g = true;
        ThreadPoolManager.getInstance().execute(new b(this.i));
        this.h = true;
        this.b.cancelDiscovery();
        b(this.c);
    }

    public BluetoothSocket d() {
        return this.l;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    public void a(InputStream inputStream) throws IOException {
        while (true) {
            ?? r0 = inputStream;
            try {
                Logger.i(f30a, "=====bytesRead1=====" + this.n);
                r0 = r0.read(this.m);
                this.n = r0;
                if (r0 > 0) {
                    Logger.i(f30a, "=====bytesRead2=====" + this.n);
                }
            } catch (IOException unused) {
                r0.printStackTrace();
                Logger.i(f30a, "=====bytesRead3=====" + this.n);
            }
        }
    }

    public BluetoothDevice c() {
        for (BluetoothDevice bluetoothDevice : this.b.getBondedDevices()) {
            if (CEBlueSharedPreference.getA2dpMac().equals(bluetoothDevice.getAddress())) {
                this.i = bluetoothDevice;
                return bluetoothDevice;
            }
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r0v7, types: [ce.com.cenewbluesdk.bluetooth.a.c, java.lang.Exception] */
    public void b() {
        ?? A;
        try {
            Logger.d(f30a, "连接A2DP");
            BluetoothDevice bluetoothDeviceA = ce.com.cenewbluesdk.bluetooth.a.c.a(this.c).a(CEBlueSharedPreference.getA2dpMac());
            this.i = bluetoothDeviceA;
            if (bluetoothDeviceA != null) {
                A = ce.com.cenewbluesdk.bluetooth.a.c.a(this.c);
                A.a(this.i, ce.com.cenewbluesdk.bluetooth.a.c.a(this.c).d());
            }
        } catch (Exception unused) {
            A.printStackTrace();
        }
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [ce.com.cenewbluesdk.bluetooth.a.c, java.lang.Exception] */
    public void a(BluetoothDevice bluetoothDevice) {
        ?? A;
        try {
            Logger.d(f30a, "连接A2DP");
            if (bluetoothDevice != null) {
                A = ce.com.cenewbluesdk.bluetooth.a.c.a(this.c);
                A.a(bluetoothDevice, ce.com.cenewbluesdk.bluetooth.a.c.a(this.c).d());
            }
        } catch (Exception unused) {
            Logger.d(f30a, "连接A2DP exception");
            A.printStackTrace();
        }
    }

    public void a() throws IOException {
        BluetoothSocket bluetoothSocket = this.l;
        if (bluetoothSocket != null) {
            try {
                bluetoothSocket.close();
                Logger.e(f30a, "关闭socket");
            } catch (IOException e) {
                e.printStackTrace();
                Logger.e(f30a, "socket关闭出错:" + e.toString());
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    public void a(String str, boolean z) {
        if (TextUtils.isEmpty(str)) {
            Logger.d(f30a, "地址为空");
            return;
        }
        Logger.d(f30a, "开始配对");
        BluetoothDevice remoteDevice = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(str.toUpperCase());
        if (CEBlueSharedPreference.getkey_connect_states() != 1 && z) {
            Logger.d(f30a, "设备没连接");
            return;
        }
        if (d(remoteDevice)) {
            c(remoteDevice);
            return;
        }
        ?? r0 = Build.VERSION.SDK_INT;
        if (r0 >= 23) {
            try {
                Lg.e(f30a, "开始配对 createBond~", true);
                Logger.e(f30a, "开始配对 createBond~");
                boolean zCreateBond = remoteDevice.createBond();
                boolean zC = zCreateBond;
                Logger.d(f30a, "createBond" + zC);
                if (!zCreateBond) {
                    zC = ce.com.cenewbluesdk.bluetooth.a.b.c(remoteDevice.getClass(), remoteDevice);
                }
                if (zC) {
                    Logger.d(f30a, "createBond连接成功.");
                } else {
                    Logger.d(f30a, "createBond连接失败.");
                }
                r0 = "edr_连接";
                Lg.e("edr_连接", "edr_连接 配对操作状态 = " + zC, true);
            } catch (Exception unused) {
                r0.printStackTrace();
            }
        }
    }

    public boolean d(BluetoothDevice bluetoothDevice) {
        return bluetoothDevice != null && 12 == bluetoothDevice.getBondState();
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [ce.com.cenewbluesdk.bluetooth.a.c, java.lang.Exception] */
    public void c(BluetoothDevice bluetoothDevice) {
        ?? A;
        try {
            Logger.d(f30a, "连接A2DP");
            if (bluetoothDevice != null) {
                A = ce.com.cenewbluesdk.bluetooth.a.c.a(this.c);
                A.a(bluetoothDevice, ce.com.cenewbluesdk.bluetooth.a.c.a(this.c).c());
            }
        } catch (Exception unused) {
            Logger.d(f30a, "连接A2DP exception");
            A.printStackTrace();
        }
    }
}
