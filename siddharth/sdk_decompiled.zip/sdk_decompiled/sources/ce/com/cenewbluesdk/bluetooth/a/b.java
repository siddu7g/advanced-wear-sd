package ce.com.cenewbluesdk.bluetooth.a;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/a/b.class */
public class b {
    public static boolean c(Class cls, BluetoothDevice bluetoothDevice) throws Exception {
        return ((Boolean) cls.getMethod("createBond", new Class[0]).invoke(bluetoothDevice, new Object[0])).booleanValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Exception] */
    public static boolean a(BluetoothDevice bluetoothDevice, int i) throws Exception {
        Object objInvoke;
        if (bluetoothDevice == null) {
            return false;
        }
        ?? BooleanValue = bluetoothDevice;
        boolean z = false;
        try {
            Class<?> cls = BooleanValue.getClass();
            Class<?>[] clsArr = new Class[1];
            clsArr[0] = Integer.TYPE;
            Method declaredMethod = cls.getDeclaredMethod("createBond", clsArr);
            declaredMethod.setAccessible(true);
            Object[] objArr = new Object[1];
            objArr[0] = Integer.valueOf(i);
            objInvoke = declaredMethod.invoke(bluetoothDevice, objArr);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    public static boolean d(Class<?> cls, BluetoothDevice bluetoothDevice) throws Exception {
        return ((Boolean) cls.getMethod("removeBond", new Class[0]).invoke(bluetoothDevice, new Object[0])).booleanValue();
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Class, java.lang.Exception] */
    public static boolean b(BluetoothDevice bluetoothDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Object objInvoke;
        Logger.i("BleConnectTool", "解除HID配对开始 =");
        if (!a(bluetoothDevice)) {
            return false;
        }
        boolean zBooleanValue = false;
        ?? r0 = bluetoothDevice.getClass();
        try {
            Lg.e("edr_连接", "edr_连接 removeBond", true);
            objInvoke = r0.getMethod("removeBond", new Class[0]).invoke(bluetoothDevice, new Object[0]);
        } catch (Exception unused) {
            r0.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        zBooleanValue = ((Boolean) objInvoke).booleanValue();
        Logger.i("BleConnectTool", "解除HID配对 =" + zBooleanValue);
        Lg.e("edr_连接", "edr_连接 removeBond状态 = " + zBooleanValue, true);
        return zBooleanValue;
    }

    @SuppressLint({"MissingPermission"})
    public static boolean a(BluetoothDevice bluetoothDevice) {
        return bluetoothDevice != null && 12 == bluetoothDevice.getBondState();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.SecurityException] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    public static boolean a(Class<? extends BluetoothDevice> cls, BluetoothDevice bluetoothDevice, String str) throws Exception {
        ?? r0 = cls;
        try {
            try {
                Class[] clsArr = new Class[1];
                clsArr[0] = byte[].class;
                Method declaredMethod = r0.getDeclaredMethod("setPin", clsArr);
                Object[] objArr = new Object[1];
                objArr[0] = str.getBytes();
                Boolean bool = (Boolean) declaredMethod.invoke(bluetoothDevice, objArr);
                r0 = "returnValue";
                Logger.e("returnValue", "" + bool);
                return true;
            } catch (Exception unused) {
                r0.printStackTrace();
                return true;
            }
        } catch (IllegalArgumentException unused2) {
            r0.printStackTrace();
            return true;
        } catch (SecurityException unused3) {
            r0.printStackTrace();
            return true;
        }
    }

    public static boolean b(Class<?> cls, BluetoothDevice bluetoothDevice) throws Exception {
        return ((Boolean) cls.getMethod("cancelPairingUserInput", new Class[0]).invoke(bluetoothDevice, new Object[0])).booleanValue();
    }

    public static boolean a(Class<?> cls, BluetoothDevice bluetoothDevice) throws Exception {
        return ((Boolean) cls.getMethod("cancelBondProcess", new Class[0]).invoke(bluetoothDevice, new Object[0])).booleanValue();
    }

    public static void a(Class<?> cls, BluetoothDevice bluetoothDevice, boolean z) throws Exception {
        cls.getDeclaredMethod("setPairingConfirmation", Boolean.TYPE).invoke(bluetoothDevice, Boolean.valueOf(z));
    }

    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception, java.lang.IllegalArgumentException, java.lang.SecurityException] */
    public static void a(Class cls) throws SecurityException {
        ?? r0;
        try {
            Method[] methods = cls.getMethods();
            for (int i = 0; i < methods.length; i++) {
                Logger.e("method name", methods[i].getName() + ";and the i is:" + i);
            }
            Field[] fields = cls.getFields();
            int i2 = 0;
            while (true) {
                r0 = i2;
                if (r0 >= fields.length) {
                    return;
                }
                Logger.e("Field name", fields[i2].getName());
                i2++;
            }
        } catch (IllegalArgumentException unused) {
            r0.printStackTrace();
        } catch (SecurityException unused2) {
            r0.printStackTrace();
        } catch (Exception unused3) {
            r0.printStackTrace();
        }
    }
}
