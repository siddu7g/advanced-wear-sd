package ce.com.cenewbluesdk.bluetooth.a;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.util.Log;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/a/c.class */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public static final String f34a = "Hfp";
    private static c b;
    private BluetoothProfile d;
    private Context f;
    private BluetoothDevice g;
    private BluetoothHeadset h;
    private BluetoothA2dp i;
    private BluetoothHidDevice j;
    private volatile boolean l;
    private volatile boolean m;
    private volatile boolean n;
    private boolean e = false;
    public a k = new a();
    private BluetoothAdapter c = BluetoothAdapter.getDefaultAdapter();

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/a/c$a.class */
    public class a implements BluetoothProfile.ServiceListener {
        public a() {
        }

        @Override // android.bluetooth.BluetoothProfile.ServiceListener
        public void onServiceConnected(int i, BluetoothProfile bluetoothProfile) {
            if (i == 1) {
                c.this.d = bluetoothProfile;
            }
            if (2 == i) {
                c.this.i = (BluetoothA2dp) bluetoothProfile;
            } else if (1 == i) {
                c.this.h = (BluetoothHeadset) bluetoothProfile;
            } else if (19 == i) {
                c.this.j = (BluetoothHidDevice) bluetoothProfile;
            }
        }

        @Override // android.bluetooth.BluetoothProfile.ServiceListener
        public void onServiceDisconnected(int i) {
            Log.i(c.f34a, "onServiceDisconnected=" + i);
        }
    }

    private c(Context context) {
        this.f = context;
        c(context);
    }

    public static synchronized c a(Context context) {
        if (b == null) {
            b = new c(context);
        }
        return b;
    }

    public static synchronized c b(Context context) {
        c cVar = new c(context);
        b = cVar;
        return cVar;
    }

    public boolean f() {
        return this.e;
    }

    public BluetoothProfile d() {
        return this.d;
    }

    public BluetoothHidDevice c() {
        return this.j;
    }

    public BluetoothDevice a(String str) {
        for (BluetoothDevice bluetoothDevice : this.c.getBondedDevices()) {
            if (str.equals(bluetoothDevice.getAddress())) {
                this.g = bluetoothDevice;
            }
        }
        return this.g;
    }

    public int e() {
        BluetoothAdapter bluetoothAdapter = this.c;
        if (bluetoothAdapter != null) {
            return bluetoothAdapter.getProfileConnectionState(1);
        }
        return -1;
    }

    public BluetoothHeadset b() {
        return this.h;
    }

    public BluetoothA2dp a() {
        return this.i;
    }

    public boolean b(BluetoothDevice bluetoothDevice) {
        Logger.e(f34a, "hfpProfile_-->" + this.d);
        BluetoothProfile bluetoothProfile = this.d;
        return bluetoothProfile != null && bluetoothProfile.getConnectionState(bluetoothDevice) == 2;
    }

    public void a(BluetoothDevice bluetoothDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        BluetoothProfile bluetoothProfile = this.d;
        if (bluetoothProfile != null) {
            BluetoothA2dp bluetoothA2dp = (BluetoothA2dp) bluetoothProfile;
            Class<?> cls = bluetoothA2dp.getClass();
            try {
                Log.i(f34a, "use reflect to connect a2dp");
                Class<?>[] clsArr = new Class[1];
                clsArr[0] = BluetoothDevice.class;
                cls.getMethod("connect", clsArr).invoke(bluetoothA2dp, bluetoothDevice);
            } catch (Exception e) {
                Log.e(f34a, "error:" + e.toString());
            }
        }
    }

    public void a(BluetoothDevice bluetoothDevice, BluetoothProfile bluetoothProfile) throws IllegalAccessException, IOException, IllegalArgumentException, InvocationTargetException {
        if (bluetoothProfile != null) {
            Class<?> cls = bluetoothProfile.getClass();
            try {
                Log.i(f34a, "use reflect to connect a2dp");
                Lg.e("edr_连接", "edr_连接 reflect to connect a2dp", true);
                Class<?>[] clsArr = new Class[1];
                clsArr[0] = BluetoothDevice.class;
                cls.getMethod("connect", clsArr).invoke(bluetoothProfile, bluetoothDevice);
            } catch (Exception e) {
                Lg.e("edr_连接", "edr_连接 reflect to connect a2dp exception", true);
                Logger.e("aaa", "e=" + e);
                Log.e(f34a, "error:" + e.toString());
            }
        }
    }

    public void a(BluetoothDevice bluetoothDevice, BluetoothHidDevice bluetoothHidDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (bluetoothHidDevice != null) {
            try {
                Logger.d("BleConnectTool", "连接HID");
                Class<?> cls = this.j.getClass();
                Class<?>[] clsArr = new Class[1];
                clsArr[0] = BluetoothDevice.class;
                cls.getMethod("connect", clsArr).invoke(this.j, bluetoothDevice);
            } catch (Exception unused) {
            }
        }
    }

    public void b(BluetoothDevice bluetoothDevice, BluetoothHidDevice bluetoothHidDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (bluetoothHidDevice != null) {
            try {
                Class<?> cls = bluetoothHidDevice.getClass();
                Class<?>[] clsArr = new Class[1];
                clsArr[0] = BluetoothDevice.class;
                cls.getMethod("disconnect", clsArr).invoke(bluetoothHidDevice, bluetoothDevice);
                Logger.e("aaa", "a");
            } catch (Exception unused) {
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v14, types: [ce.com.cenewbluesdk.bluetooth.a.c] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v18, types: [ce.com.cenewbluesdk.bluetooth.a.c] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22, types: [ce.com.cenewbluesdk.bluetooth.a.c] */
    public void c(Context context) {
        ?? r0;
        ?? r02;
        ?? r03;
        if (context != null) {
            if (this.c == null) {
                this.c = BluetoothAdapter.getDefaultAdapter();
            }
            if (this.c == null) {
                return;
            }
            if (this.i == null && (r03 = this.l) == 0) {
                try {
                    r03 = this;
                    r03.l = r03.c.getProfileProxy(context, this.k, 2);
                } catch (Exception unused) {
                    r03.printStackTrace();
                }
            }
            if (this.h == null && (r02 = this.m) == 0) {
                try {
                    r02 = this;
                    r02.m = r02.c.getProfileProxy(context, this.k, 1);
                } catch (Exception unused2) {
                    r02.printStackTrace();
                }
            }
            if (this.j == null && (r0 = this.n) == 0) {
                try {
                    r0 = this;
                    r0.n = r0.c.getProfileProxy(context, this.k, 19);
                } catch (Exception unused3) {
                    r0.printStackTrace();
                }
            }
        }
    }
}
