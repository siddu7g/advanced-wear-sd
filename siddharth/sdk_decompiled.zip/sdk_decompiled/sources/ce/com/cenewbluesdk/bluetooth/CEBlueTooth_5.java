package ce.com.cenewbluesdk.bluetooth;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.queue.CEProtocolB;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

/* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5.class */
public class CEBlueTooth_5 extends CEBlueToothBase {

    /* renamed from: a, reason: collision with root package name */
    private static final int f19a = 15000;
    private static final int b = 15000;
    private static final int c = 15000;
    private static final String d = "TAG_CEBlueTooth_5";
    private static int e = 23;
    private BluetoothGatt f;
    private BluetoothAdapter g;
    private Context h;
    private byte[] j;
    private String l;
    private int m;
    private long u;
    private long x;
    private TimerTask y;
    private Timer z;
    public int i = 1;
    private boolean k = false;
    private List<BluetoothGattService> n = null;
    private List<BluetoothGattCharacteristic> o = new ArrayList();
    private List<BluetoothGattCharacteristic> p = new ArrayList();
    private Handler q = new Handler();
    private h r = new h(this, null);
    private Handler s = new Handler();
    private i t = new i(this, null);
    private final BluetoothGattCallback v = new a();
    Handler w = new Handler(Looper.getMainLooper());

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$a.class */
    class a extends BluetoothGattCallback {

        /* renamed from: a, reason: collision with root package name */
        private boolean f20a = true;

        /* renamed from: ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5$a$a, reason: collision with other inner class name */
        /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$a$a.class */
        class RunnableC0002a implements Runnable {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ int f21a;

            RunnableC0002a(int i) {
                this.f21a = i;
            }

            @Override // java.lang.Runnable
            public void run() {
                Logger.e(CEBlueTooth_5.d, "连接失败status=" + this.f21a + " 进行重连");
                CEBlueTooth_5.this.d();
                CEBlueTooth_5.this.f();
                CEBlueTooth_5.this.blueToothConnectStateChange(0);
                Logger.i("bind", "开始绑定-connect11");
                BleFactory.getInstance().getK6Proxy().reConnectDirect();
            }
        }

        a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1 */
        /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Exception] */
        /* JADX WARN: Type inference failed for: r0v21, types: [ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5$a] */
        /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.String] */
        @Override // android.bluetooth.BluetoothGattCallback
        public void onConnectionStateChange(BluetoothGatt bluetoothGatt, int i, int i2) {
            CEBlueTooth_5 cEBlueTooth_5;
            Logger.i("bind", "开始绑定- gatt onConnectionStateChange");
            if (bluetoothGatt != CEBlueTooth_5.this.f) {
                Object[] objArr = new Object[2];
                objArr[0] = bluetoothGatt == null ? "null" : bluetoothGatt.getDevice();
                objArr[1] = CEBlueTooth_5.this.f == null ? "null" : CEBlueTooth_5.this.f.getDevice();
                Lg.e(String.format("%s != %s", objArr));
                Lg.e("New_First!!!");
                CEBlueTooth_5.f(CEBlueTooth_5.this);
                if ((i == 133 || i == 257) && CEBlueTooth_5.this.m == 3) {
                    CEBlueTooth_5.this.blueToothConnectStateChange(133);
                    CEBlueTooth_5.this.disConnect();
                    CEBlueTooth_5.this.d();
                    return;
                }
                return;
            }
            ?? r0 = i;
            CEBlueTooth_5.this.u = System.currentTimeMillis();
            try {
                Logger.i("status=" + i + " newState=" + i2);
                Lg.e_file("Connection", "BluetoothGatt.status=" + i, "connection.log", true);
                Lg.e_file("Connection", "BluetoothProfile.newState=" + i2, "connection.log", true);
                if (r0 != 0) {
                    CEBlueTooth_5.f(CEBlueTooth_5.this);
                    if ((i == 133 || i == 257) && CEBlueTooth_5.this.m == 3) {
                        CEBlueTooth_5.this.blueToothConnectStateChange(i);
                        CEBlueTooth_5.this.disConnect();
                        CEBlueTooth_5.this.d();
                    }
                    CEBlueTooth_5.this.w.post(new RunnableC0002a(i));
                    return;
                }
                Lg.e_file("Connection", "BluetoothGatt.GATT_SUCCESS", "connection.log", true);
                if (i2 != 2) {
                    if (i2 != 0) {
                        CEBlueTooth_5.this.k = false;
                        return;
                    }
                    Logger.e(CEBlueTooth_5.d, "断开连接状态newState=" + i2);
                    CEBlueTooth_5.this.blueToothConnectStateChange(0);
                    CEBlueTooth_5.this.k = false;
                    CEBlueTooth_5.this.disConnect();
                    CEBlueTooth_5.this.d();
                    return;
                }
                r0 = this;
                Lg.e_file("Connection", "BluetoothProfile.STATE_CONNECTED", "connection.log", true);
                Logger.i(CEBlueTooth_5.d, "连接成功,状态为:" + i2);
                CEBlueTooth_5.this.k = true;
                try {
                    try {
                        boolean zRequestMtu = CEBlueTooth_5.this.f.requestMtu(512);
                        r0 = "bind";
                        Logger.i("bind", "开始绑定-requestMtu status = " + zRequestMtu);
                    } catch (Exception unused) {
                        Logger.e(CEBlueTooth_5.d, "requestMtu Exception");
                        cEBlueTooth_5 = CEBlueTooth_5.this;
                        cEBlueTooth_5.l();
                    }
                } catch (Error unused2) {
                    Logger.e(CEBlueTooth_5.d, "requestMtu Error:");
                    cEBlueTooth_5 = CEBlueTooth_5.this;
                    cEBlueTooth_5.l();
                }
            } catch (Exception unused3) {
                r0.printStackTrace();
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onServicesDiscovered(BluetoothGatt bluetoothGatt, int i) throws IOException {
            super.onServicesDiscovered(bluetoothGatt, i);
            Logger.e(CEBlueTooth_5.d, "onServicesDiscovered-status=" + i);
            if (i == 0) {
                CEBlueTooth_5.this.e();
                CEBlueTooth_5 cEBlueTooth_5 = CEBlueTooth_5.this;
                cEBlueTooth_5.a((List<BluetoothGattService>) cEBlueTooth_5.n);
            } else {
                if (i == 129 || i == 133) {
                    CEBlueTooth_5.this.b();
                }
                CEBlueTooth_5.this.f();
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicRead(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
            super.onCharacteristicRead(bluetoothGatt, bluetoothGattCharacteristic, i);
            if (i == 0) {
                CEBlueTooth_5.this.a(bluetoothGattCharacteristic);
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicWrite(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
            super.onCharacteristicWrite(bluetoothGatt, bluetoothGattCharacteristic, i);
            if (i == 0) {
                CEBlueTooth_5.this.dataSendSucceed(bluetoothGattCharacteristic.getValue());
            } else {
                CEBlueTooth_5.this.dataSendFailed(bluetoothGattCharacteristic.getValue());
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic) {
            super.onCharacteristicChanged(bluetoothGatt, bluetoothGattCharacteristic);
            CEBlueTooth_5.this.a(bluetoothGattCharacteristic);
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onDescriptorWrite(BluetoothGatt bluetoothGatt, BluetoothGattDescriptor bluetoothGattDescriptor, int i) throws IOException {
            super.onDescriptorWrite(bluetoothGatt, bluetoothGattDescriptor, i);
            CEBlueTooth_5.this.b();
            Logger.i("bind", "开始绑定-onDescriptorWrite");
            Lg.e_file("Connection", "onDescriptorWrite()", "connection.log", true);
            CEBlueTooth_5.this.blueToothConnectStateChange(1);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v0 */
        /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
        /* JADX WARN: Type inference failed for: r0v16 */
        /* JADX WARN: Type inference failed for: r0v17 */
        /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.String] */
        @Override // android.bluetooth.BluetoothGattCallback
        public void onMtuChanged(BluetoothGatt bluetoothGatt, int i, int i2) throws IOException {
            String str;
            ?? r0 = i2;
            super.onMtuChanged(bluetoothGatt, i, i2);
            CEBlueTooth_5.this.f = bluetoothGatt;
            Logger.e(CEBlueTooth_5.d, "onMtuChanged=" + i + "status=" + i2);
            Logger.i("bind", "开始绑定-onMtuChanged");
            Lg.e_file("Connection", "onMtuChanged", "connection.log", true);
            try {
                if (r0 == 0) {
                    Log.e(CEBlueTooth_5.d, "onMtuChanged SUCCESS=" + i);
                    int unused = CEBlueTooth_5.e = i - 3;
                    int unused2 = CEBlueTooth_5.e = (CEBlueTooth_5.e / 20) * 20;
                    if (CEBlueTooth_5.e <= 100) {
                        int unused3 = CEBlueTooth_5.e = 20;
                    }
                    CEProtocolB.MTU = CEBlueTooth_5.e;
                    String str2 = CEBlueTooth_5.d;
                    str = "onMtuChanged CEProtocolB.MTU=" + CEProtocolB.MTU;
                    r0 = str2;
                } else {
                    str = "onMtuChanged fail" + i;
                    r0 = CEBlueTooth_5.d;
                }
                Logger.e(r0, str);
            } catch (Exception unused4) {
                r0.printStackTrace();
            }
            CEBlueTooth_5.this.l();
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$b.class */
    class b implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ BluetoothDevice f22a;

        b(BluetoothDevice bluetoothDevice) {
            this.f22a = bluetoothDevice;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (CEBlueTooth_5.this.h == null || !BleSystemUtils.isBlePermission(CEBlueTooth_5.this.h)) {
                return;
            }
            Logger.i("bind", "开始绑定-connectGatt...");
            int i = Build.VERSION.SDK_INT;
            if (i >= 26) {
                CEBlueTooth_5 cEBlueTooth_5 = CEBlueTooth_5.this;
                cEBlueTooth_5.f = this.f22a.connectGatt(cEBlueTooth_5.h, false, CEBlueTooth_5.this.v, 2, 1);
            } else if (i >= 23) {
                CEBlueTooth_5 cEBlueTooth_52 = CEBlueTooth_5.this;
                cEBlueTooth_52.f = this.f22a.connectGatt(cEBlueTooth_52.h, false, CEBlueTooth_5.this.v, 2);
            } else {
                CEBlueTooth_5 cEBlueTooth_53 = CEBlueTooth_5.this;
                cEBlueTooth_53.f = this.f22a.connectGatt(cEBlueTooth_53.h, false, CEBlueTooth_5.this.v);
            }
            Logger.i(CEBlueTooth_5.d, "BluetoothGatt->connectGatt...");
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$c.class */
    class c implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ BluetoothDevice f23a;

        c(BluetoothDevice bluetoothDevice) {
            this.f23a = bluetoothDevice;
        }

        @Override // java.lang.Runnable
        public void run() throws IOException {
            Lg.e_file("Connection", "开始绑定-connectGatt....", "connection.log", true);
            if (CEBlueTooth_5.this.h != null && BleSystemUtils.isBlePermission(CEBlueTooth_5.this.h)) {
                int i = Build.VERSION.SDK_INT;
                if (i >= 26) {
                    Logger.i("bind", "开始绑定-connectGatt....");
                    CEBlueTooth_5 cEBlueTooth_5 = CEBlueTooth_5.this;
                    cEBlueTooth_5.f = this.f23a.connectGatt(cEBlueTooth_5.h, false, CEBlueTooth_5.this.v, 2, 1);
                } else if (i >= 23) {
                    CEBlueTooth_5 cEBlueTooth_52 = CEBlueTooth_5.this;
                    cEBlueTooth_52.f = this.f23a.connectGatt(cEBlueTooth_52.h, false, CEBlueTooth_5.this.v, 2);
                } else {
                    CEBlueTooth_5 cEBlueTooth_53 = CEBlueTooth_5.this;
                    cEBlueTooth_53.f = this.f23a.connectGatt(cEBlueTooth_53.h, false, CEBlueTooth_5.this.v);
                }
                Logger.i(CEBlueTooth_5.d, "BluetoothGatt->connectGatt......");
            }
            Lg.e(CEBlueTooth_5.d, "connectGatt！！！");
            if (CEBlueTooth_5.this.f == null) {
                Lg.e(CEBlueTooth_5.d, "mBluetoothGatt是空的！！！");
            }
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$d.class */
    class d extends TimerTask {
        d() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() throws IOException {
            if (CEBlueTooth_5.this.k) {
                return;
            }
            CEBlueTooth_5.this.blueToothConnectStateChange(0);
            CEBlueTooth_5.this.disConnect();
            CEBlueTooth_5.this.connect(CEBlueSharedPreference.getDevAddress());
            CEBlueTooth_5.this.m();
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$e.class */
    class e implements Runnable {
        e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (CEBlueTooth_5.this.f != null) {
                CEBlueTooth_5.this.f.disconnect();
            }
            Logger.e(Lg.getClassName(this), "mBluetoothGatt Disconnect");
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$f.class */
    class f implements Runnable {
        f() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (CEBlueTooth_5.this.f != null) {
                CEBlueTooth_5.this.f.disconnect();
                Logger.i(CEBlueTooth_5.d, "BluetoothGatt->disconnect");
            }
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$g.class */
    class g implements Runnable {
        g() {
        }

        @Override // java.lang.Runnable
        public void run() throws IOException {
            if (CEBlueTooth_5.this.f != null) {
                Logger.i("bind", "开始绑定-discoverServices");
                Lg.e_file("Connection", "discoverServices", "connection.log", true);
                CEBlueTooth_5.this.f.discoverServices();
            }
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$h.class */
    private class h implements Runnable {
        private h() {
        }

        /* synthetic */ h(CEBlueTooth_5 cEBlueTooth_5, a aVar) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() throws IllegalAccessException, IOException, IllegalArgumentException, InvocationTargetException {
            Logger.e(CEBlueTooth_5.d, "Found service timeout");
            if (CEBlueTooth_5.this.f != null && !TextUtils.isEmpty(CEBlueTooth_5.this.f.getDevice().getAddress())) {
                BluetoothDevice remoteDevice = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(CEBlueTooth_5.this.f.getDevice().getAddress());
                if (BleFactory.getInstance().isConnectedByProfile(remoteDevice) == 2) {
                    BleFactory.getInstance().disconnectByProfiles(remoteDevice);
                }
                ce.com.cenewbluesdk.bluetooth.a.b.b(remoteDevice);
            }
            CEBlueTooth_5.this.f();
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_5$i.class */
    private class i implements Runnable {
        private i() {
        }

        /* synthetic */ i(CEBlueTooth_5 cEBlueTooth_5, a aVar) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() throws IOException {
            Lg.e(CEBlueTooth_5.d, "mtu timeout");
            CEBlueTooth_5.this.l();
        }
    }

    private void j() {
        this.q.removeCallbacks(this.r);
        this.q.postDelayed(this.r, 15000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        this.q.removeCallbacks(this.r);
    }

    private void k() {
        this.s.removeCallbacks(this.t);
        this.s.postDelayed(this.t, 15000L);
    }

    private void c() {
        this.s.removeCallbacks(this.t);
    }

    public CEBlueTooth_5(Context context, String str) {
        this.l = str;
        this.h = context;
        if (context == null) {
            return;
        }
        this.g = ((BluetoothManager) context.getSystemService("bluetooth")).getAdapter();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.Timer] */
    private void g() {
        ?? r0 = this;
        r0.m();
        try {
            if (r0.z == null) {
                this.z = new Timer();
                this.y = new d();
            }
            r0 = this.z;
            r0.schedule(this.y, 15000L);
        } catch (Exception unused) {
            r0.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void m() {
        try {
            Timer timer = this.z;
            if (timer != null) {
                timer.cancel();
                this.z = null;
            }
        } catch (Exception unused) {
            printStackTrace();
        }
    }

    private void h() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(List<BluetoothGattService> list) throws IOException {
        this.o.clear();
        if (list == null) {
            return;
        }
        Logger.i("bind", "开始绑定-发现蓝牙服务=" + list.size());
        Lg.e_file("Connection", "发现蓝牙服务=" + list.size(), "connection.log", true);
        if (list.size() == 0) {
            disConnect();
            this.x = System.currentTimeMillis() - 10000;
            BleFactory.getInstance().getK6Proxy().reConnectDirect();
        }
        for (BluetoothGattService bluetoothGattService : list) {
            Log.i(d, bluetoothGattService.getUuid().toString());
            if (bluetoothGattService.getUuid().toString().toUpperCase().equals(UUID.fromString(this.l).toString().toUpperCase())) {
                for (BluetoothGattCharacteristic bluetoothGattCharacteristic : bluetoothGattService.getCharacteristics()) {
                    if (bluetoothGattCharacteristic.getProperties() == 16) {
                        a(bluetoothGattCharacteristic, true);
                        this.p.add(bluetoothGattCharacteristic);
                        Lg.e(d, "发现的读特特征：" + bluetoothGattCharacteristic.getUuid().toString());
                    } else if (!this.o.contains(bluetoothGattCharacteristic)) {
                        this.o.add(bluetoothGattCharacteristic);
                        Lg.e(d, "发现的写特征：" + bluetoothGattCharacteristic.getUuid().toString());
                    }
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [android.bluetooth.BluetoothManager] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.util.List, java.util.List<android.bluetooth.BluetoothDevice>] */
    @SuppressLint({"MissingPermission"})
    public static List<BluetoothDevice> a(Context context) {
        ?? connectedDevices = (BluetoothManager) context.getSystemService("bluetooth");
        if (connectedDevices == 0) {
            return null;
        }
        try {
            connectedDevices = connectedDevices.getConnectedDevices(7);
            return connectedDevices;
        } catch (Exception unused) {
            connectedDevices.printStackTrace();
            return null;
        }
    }

    static /* synthetic */ int f(CEBlueTooth_5 cEBlueTooth_5) {
        int i2 = cEBlueTooth_5.m;
        cEBlueTooth_5.m = i2 + 1;
        return i2;
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void connect(BluetoothDevice bluetoothDevice) {
        int i2;
        super.connect(bluetoothDevice);
        if (bluetoothDevice == null || (i2 = this.blueConnectState) == 2 || i2 == 1) {
            Logger.e(d, "This connection will not be executed, the current connection status：" + this.blueConnectState + "  The address of the connection Device address ：" + bluetoothDevice);
            return;
        }
        d();
        f();
        if (this.g == null) {
            Logger.e(d, "adapter_NULL can not connect!!");
            return;
        }
        blueToothConnectStateChange(2);
        g();
        if (this.h == null) {
            this.h = BleFactory.context;
        }
        this.w.post(new b(bluetoothDevice));
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void connect(String str) throws IOException {
        int i2;
        Logger.i("bind", "开始绑定连接设备MAC地址：" + str);
        Logger.e(Lg.getClassName(this), "连接设备MAC地址：" + str);
        if ((TextUtils.isEmpty(str) || (i2 = this.blueConnectState) == 2 || i2 == 1) && CEBlueSharedPreference.getkey_connect_states() != 0) {
            Logger.e(d, "This connection will not be executed, the current connection status：" + this.blueConnectState + "  mac:" + str);
            return;
        }
        Lg.e_file("Connection", "blueConnectState = " + this.blueConnectState, "connection.log", true);
        if (System.currentTimeMillis() - this.x < 2000) {
            Logger.i("bind", "连接时间间隔太短");
            return;
        }
        Lg.e_file("Connection", "startConnect", "connection.log", true);
        this.x = System.currentTimeMillis();
        Logger.e(Lg.getClassName(this), "开始连接0");
        Logger.e(Lg.getClassName(this), "开始连接");
        if (this.g == null) {
            Logger.e(d, "adapter_NULL");
            BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
            this.g = defaultAdapter;
            if (defaultAdapter == null) {
                Logger.e(d, "adapter_NULL");
                return;
            }
            Logger.e(d, "adapter is not null");
        }
        blueToothConnectStateChange(2);
        g();
        Lg.e("YAN_GATT", "GATT第一次连接！！！");
        if (TextUtils.isEmpty(str)) {
            return;
        }
        BluetoothDevice remoteDevice = this.g.getRemoteDevice(str);
        if (remoteDevice == null) {
            blueToothConnectStateChange(0);
            Lg.e("YAN_GATT", " mBluetoothDevice is null ");
            return;
        }
        if (this.h == null) {
            this.h = BleFactory.context;
        }
        BluetoothGatt bluetoothGatt = this.f;
        if (bluetoothGatt != null) {
            bluetoothGatt.close();
        }
        this.w.post(new c(remoteDevice));
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) throws IOException {
        if (this.k) {
            return;
        }
        Lg.e(d, "连接超时！！！");
        blueToothConnectStateChange(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void disConnect() {
        this.k = false;
        try {
            this.w.post(new e());
        } catch (Exception unused) {
            printStackTrace();
            d();
        }
        blueToothConnectStateChange(0);
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x000c, code lost:
    
        r0 = r5.f;
     */
    /* JADX WARN: Type inference failed for: r0v3, types: [android.bluetooth.BluetoothGatt, java.lang.Exception] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void f() {
        /*
            r5 = this;
            r0 = r5
            r1 = r0
            r2 = 0
            r1.k = r2
            android.bluetooth.BluetoothAdapter r0 = r0.g
            if (r0 == 0) goto L31
            r0 = r5
            android.bluetooth.BluetoothGatt r0 = r0.f
            if (r0 != 0) goto L16
            goto L31
        L16:
            r0 = r5
            android.os.Handler r0 = r0.s     // Catch: java.lang.Exception -> L29
            ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5$f r1 = new ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5$f     // Catch: java.lang.Exception -> L29
            r2 = r1
            r3 = r5
            r2.<init>()     // Catch: java.lang.Exception -> L29
            boolean r0 = r0.post(r1)     // Catch: java.lang.Exception -> L29
            goto L30
        L29:
            r0.printStackTrace()
            r0 = r5
            r0.d()
        L30:
            return
        L31:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5.f():void");
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void sendData(byte[] bArr) {
        int i2 = this.i + 1;
        this.i = i2;
        if (i2 >= this.o.size()) {
            this.i = 0;
        }
        sendData(this.i, bArr);
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void sendData(int i2, byte[] bArr) {
        if (!this.k || this.o.size() == 0) {
            dataSendFailed(bArr);
            return;
        }
        if (i2 < 0 || i2 >= this.o.size()) {
            sendData(bArr);
            return;
        }
        BluetoothGattCharacteristic bluetoothGattCharacteristic = this.o.get(i2);
        this.j = bArr;
        if (bArr.length <= 0) {
            return;
        }
        a(bluetoothGattCharacteristic, bArr);
        try {
            Logger.e(d, "SendData5-check：" + ByteUtil.byte2hex(this.j));
        } catch (Exception unused) {
            d.printStackTrace();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [android.bluetooth.BluetoothGatt, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.reflect.Method] */
    public boolean i() throws NoSuchMethodException, SecurityException {
        ?? BooleanValue = this.f;
        if (BooleanValue == 0) {
            return false;
        }
        try {
            ?? method = BooleanValue.getClass().getMethod("refresh", new Class[0]);
            if (method == 0) {
                return false;
            }
            BooleanValue = ((Boolean) method.invoke(BooleanValue, new Object[0])).booleanValue();
            Logger.i(d, "BluetoothGatt缓存清理成功");
            return BooleanValue;
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
            return false;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v2, types: [ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5, java.lang.Exception] */
    public void d() {
        ?? r0;
        try {
            if (this.f != null) {
                i();
                this.f.discoverServices();
                this.f.close();
            }
            r0 = this;
            r0.f = null;
        } catch (Exception unused) {
            r0.printStackTrace();
            try {
                r0 = this;
                r0.f.close();
                r0.f = null;
            } catch (Exception unused2) {
                r0.printStackTrace();
            }
        }
        Logger.i(d, "BluetoothGatt->close");
    }

    public void l() throws IOException {
        if (this.f == null) {
            f();
            return;
        }
        j();
        if (this.f != null) {
            Logger.i("bind", "开始绑定-discoverServices");
            Lg.e_file("Connection", "discoverServices", "connection.log", true);
            this.q.postDelayed(new g(), ce.com.cenewbluesdk.bluetooth.a.b.a(this.f.getDevice()) ? 2000L : 0L);
        }
    }

    public void e() {
        List<BluetoothGattService> list = this.n;
        if (list != null && list.size() > 0) {
            this.n.clear();
        }
        BluetoothGatt bluetoothGatt = this.f;
        if (bluetoothGatt != null) {
            this.n = bluetoothGatt.getServices();
        }
    }

    public void a(BluetoothGattCharacteristic bluetoothGattCharacteristic) {
        if (this.g == null || this.f == null || bluetoothGattCharacteristic == null) {
            return;
        }
        try {
            Logger.e(d, "ReceData5-check:" + ByteUtil.byte2hex(bluetoothGattCharacteristic.getValue()));
        } catch (Exception unused) {
            d.printStackTrace();
        }
        blueToothReceiptDate(bluetoothGattCharacteristic.getValue());
    }

    public void a(BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr) {
        if (this.g == null || this.f == null || bluetoothGattCharacteristic == null) {
            return;
        }
        bluetoothGattCharacteristic.setValue(bArr);
        this.f.writeCharacteristic(bluetoothGattCharacteristic);
    }

    public void a(BluetoothGattCharacteristic bluetoothGattCharacteristic, boolean z) {
        BluetoothGatt bluetoothGatt;
        if (this.g == null || (bluetoothGatt = this.f) == null) {
            return;
        }
        if (!bluetoothGatt.setCharacteristicNotification(bluetoothGattCharacteristic, z)) {
            Log.e(d, "Setting proper notification status for characteristic failed!");
        }
        BluetoothGattDescriptor descriptor = bluetoothGattCharacteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
        if (descriptor != null) {
            descriptor.setValue(z ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            this.f.writeDescriptor(descriptor);
        }
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public boolean isConnectedDevice(BluetoothDevice bluetoothDevice) {
        if (bluetoothDevice == null) {
            return false;
        }
        return a(this.h, bluetoothDevice);
    }

    public boolean a(Context context, BluetoothDevice bluetoothDevice) {
        if (context == null || bluetoothDevice == null) {
            return false;
        }
        boolean z = false;
        List<BluetoothDevice> listA = a(context);
        if (listA != null) {
            Iterator<BluetoothDevice> it = listA.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                BluetoothDevice next = it.next();
                if (next != null && bluetoothDevice.getAddress().equals(next.getAddress())) {
                    z = true;
                    break;
                }
            }
        }
        return z;
    }
}
