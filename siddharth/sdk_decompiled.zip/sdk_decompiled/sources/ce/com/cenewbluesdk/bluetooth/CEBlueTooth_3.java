package ce.com.cenewbluesdk.bluetooth;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import ce.com.cenewbluesdk.uitl.BtBondReceiver;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

/* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_3.class */
public class CEBlueTooth_3 extends CEBlueToothBase {

    /* renamed from: a, reason: collision with root package name */
    private static final UUID f10a = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private Context b;
    private BluetoothDevice c;
    private final BluetoothAdapter d;
    private a e;
    private Handler f = new Handler(Looper.getMainLooper());
    private boolean g = true;
    private boolean h = true;
    private long i = 500;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_3$a.class */
    private class a extends Thread {

        /* renamed from: a, reason: collision with root package name */
        private boolean f11a;
        private boolean b;
        private BluetoothSocket c;
        private InputStream d;
        private OutputStream e;
        private BluetoothDevice f;
        private Context g;
        private BtBondReceiver h;
        private Runnable i;

        /* renamed from: ce.com.cenewbluesdk.bluetooth.CEBlueTooth_3$a$a, reason: collision with other inner class name */
        /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_3$a$a.class */
        class RunnableC0001a implements Runnable {
            RunnableC0001a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                ce.com.cenewbluesdk.uitl.b.a(a.this.f, true);
            }
        }

        /* loaded from: classes.jar:ce/com/cenewbluesdk/bluetooth/CEBlueTooth_3$a$b.class */
        class b extends BtBondReceiver {
            b() {
            }

            @Override // ce.com.cenewbluesdk.uitl.BtBondReceiver
            @TargetApi(19)
            protected void a(BluetoothDevice bluetoothDevice, int i, int i2) {
                if ((i == 2 || i == 3) && bluetoothDevice.getAddress().equals(a.this.f.getAddress())) {
                    if (CEBlueTooth_3.this.i < 0) {
                        a.this.i.run();
                    } else {
                        CEBlueTooth_3.this.f.postDelayed(a.this.i, CEBlueTooth_3.this.i);
                    }
                }
            }
        }

        public a() {
            super(a.class.getSimpleName());
            this.f11a = false;
            this.b = false;
            this.g = CEBlueTooth_3.this.b;
            this.i = new RunnableC0001a();
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v0, types: [ce.com.cenewbluesdk.bluetooth.CEBlueTooth_3$a] */
        /* JADX WARN: Type inference failed for: r0v1, types: [java.io.IOException] */
        /* JADX WARN: Type inference failed for: r0v10 */
        /* JADX WARN: Type inference failed for: r0v7 */
        /* JADX WARN: Type inference failed for: r0v8, types: [ce.com.cenewbluesdk.bluetooth.CEBlueTooth_3$a] */
        @TargetApi(10)
        public boolean a(BluetoothDevice bluetoothDevice) throws IOException {
            BluetoothSocket bluetoothSocketCreateInsecureRfcommSocketToServiceRecord;
            ?? r0 = this;
            r0.f = bluetoothDevice;
            try {
                if (CEBlueTooth_3.this.g) {
                    r0 = this;
                    bluetoothSocketCreateInsecureRfcommSocketToServiceRecord = bluetoothDevice.createRfcommSocketToServiceRecord(CEBlueTooth_3.f10a);
                } else {
                    r0 = this;
                    bluetoothSocketCreateInsecureRfcommSocketToServiceRecord = bluetoothDevice.createInsecureRfcommSocketToServiceRecord(CEBlueTooth_3.f10a);
                }
                r0.c = bluetoothSocketCreateInsecureRfcommSocketToServiceRecord;
                return true;
            } catch (IOException unused) {
                r0.printStackTrace();
                CEBlueTooth_3.this.c();
                return false;
            }
        }

        private void b() {
            b bVar = new b();
            this.h = bVar;
            bVar.register(this.g);
        }

        private void c() {
            this.h.unregister(this.g);
            CEBlueTooth_3.this.f.removeCallbacks(this.i);
        }

        /*  JADX ERROR: JadxRuntimeException in pass: ConstInlineVisitor
            jadx.core.utils.exceptions.JadxRuntimeException: Unexpected instance arg in invoke
            	at jadx.core.dex.visitors.ConstInlineVisitor.addExplicitCast(ConstInlineVisitor.java:285)
            	at jadx.core.dex.visitors.ConstInlineVisitor.replaceArg(ConstInlineVisitor.java:267)
            	at jadx.core.dex.visitors.ConstInlineVisitor.replaceConst(ConstInlineVisitor.java:177)
            	at jadx.core.dex.visitors.ConstInlineVisitor.checkInsn(ConstInlineVisitor.java:110)
            	at jadx.core.dex.visitors.ConstInlineVisitor.process(ConstInlineVisitor.java:55)
            	at jadx.core.dex.visitors.ConstInlineVisitor.visit(ConstInlineVisitor.java:47)
            */
        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            /*
                Method dump skipped, instructions count: 374
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.bluetooth.CEBlueTooth_3.a.run():void");
        }

        /* JADX WARN: Multi-variable type inference failed */
        public boolean a(byte[] bArr) throws IOException {
            Lg.e("蓝牙3.0 写给设备测的数据：" + ByteUtil.byte2hex(bArr));
            try {
                this.e.write(bArr);
                CEBlueTooth_3.this.dataSendSucceed(bArr);
                return true;
            } catch (IOException unused) {
                printStackTrace();
                CEBlueTooth_3.this.dataSendFailed(bArr);
                return false;
            }
        }

        public void a() throws IOException {
            this.f11a = true;
            if (this.b) {
                Log.e("liu", "连接过程中请求中断    以前的 这里会有问题");
            } else {
                CEBlueTooth_3.a(this.c);
            }
            BluetoothSocket bluetoothSocket = this.c;
            if (bluetoothSocket != null) {
                BluetoothDevice remoteDevice = bluetoothSocket.getRemoteDevice();
                if (remoteDevice.getBondState() == 11) {
                    ce.com.cenewbluesdk.uitl.b.a(remoteDevice);
                }
            }
            interrupt();
        }
    }

    public CEBlueTooth_3(Context context) {
        this.b = context;
        this.d = BleSystemUtils.getBluetoothAdapter(context);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c() throws IOException {
        b();
        blueToothConnectStateChange(0);
    }

    private void a(long j) {
        this.i = j;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.io.Closeable] */
    public static void a(Closeable... closeableArr) throws IOException {
        for (?? r0 : closeableArr) {
            if (r0 != 0) {
                try {
                    r0 = r0;
                    r0.close();
                } catch (Exception unused) {
                    r0.printStackTrace();
                }
            }
        }
    }

    static /* synthetic */ void e(CEBlueTooth_3 cEBlueTooth_3) throws IOException {
        cEBlueTooth_3.c();
    }

    static /* synthetic */ BluetoothAdapter a(CEBlueTooth_3 cEBlueTooth_3) {
        return cEBlueTooth_3.d;
    }

    static /* synthetic */ boolean b(CEBlueTooth_3 cEBlueTooth_3) {
        return cEBlueTooth_3.h;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [android.bluetooth.BluetoothAdapter, java.lang.IllegalArgumentException] */
    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public synchronized void connect(String str) throws IOException {
        int i;
        BluetoothDevice bluetoothDevice = this.c;
        if (bluetoothDevice != null && bluetoothDevice.getAddress() != null && this.c.getAddress().equals(str) && ((i = this.blueConnectState) == 2 || i == 1)) {
            Lg.e("本次连接将不会执行，当前连接状态：" + this.blueConnectState + "  连接的地址mDevice 地址 ：" + this.c.getAddress() + "  mac:" + str);
            return;
        }
        Lg.e("开始连接：" + str);
        ?? r0 = this.d;
        if (r0 == 0) {
            c();
            return;
        }
        try {
            this.c = r0.getRemoteDevice(str);
            if (!this.d.isEnabled()) {
                c();
                return;
            }
            b();
            a aVar = new a();
            this.e = aVar;
            if (aVar.a(this.c)) {
                this.e.start();
            }
        } catch (IllegalArgumentException unused) {
            r0.printStackTrace();
            c();
        }
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public boolean isConnectedDevice(BluetoothDevice bluetoothDevice) {
        return false;
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void disConnect() throws IOException {
        b();
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void sendData(byte[] bArr) {
        a(bArr);
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase
    public void sendData(int i, byte[] bArr) {
        a(bArr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean a(byte[] bArr) {
        synchronized (this) {
            a aVar = this.e;
            if (aVar == null || aVar.e == null) {
                dataSendFailed(bArr);
                return false;
            }
            return this.e.a(bArr);
        }
    }

    public synchronized void b() throws IOException {
        a aVar = this.e;
        if (aVar != null) {
            aVar.a();
            this.e.e = null;
            this.e = null;
        }
    }

    public void a(boolean z) {
        this.h = z;
    }

    public void b(boolean z) {
        this.g = z;
    }

    public boolean d() {
        return this.g;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
    }
}
