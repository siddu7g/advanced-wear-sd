package ce.com.cenewbluesdk.fileTransmission;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_QR_CODE_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WATCH_FACE_INFO;
import ce.com.cenewbluesdk.ota.ota_modea.OtaUtil;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.proxy.CEDevQueue;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.io.IOException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/fileTransmission/FileTransControl.class */
public class FileTransControl {
    private static String TAG = "FileTransControl";
    private static String otaFilePath = "";
    public static final int STATE_NONE = 0;
    public static final int STATE_READY_OK = 3;
    public static final int STATE_HAS_DEV_STATE = 4;
    public static final int STATE_SENDING = 5;
    public static final int STATE_SENT = 6;
    public static final int STATE_FINISH = 7;
    private static final int OTA_SEND_FILE_MAX_TIME = 5;
    private static final int OTA_STATE_MAX_TIME = 3;
    private int DEFAULT_LENGTH;
    private byte[] head;
    private byte[] data;
    int lastSendBytesLen;
    int fPos;
    private CEDevK6Proxy proxy;
    private Context mContext;
    private int otaState;
    private int otaSendFileMAXTime;
    private int getOtaStateMAXTime;
    private boolean isSpeedUp;
    private boolean isDownloadDomplete;

    public FileTransControl(CEDevK6Proxy cEDevK6Proxy, Context context) {
        this.DEFAULT_LENGTH = 200;
        this.lastSendBytesLen = 0;
        this.fPos = 0;
        this.otaState = 0;
        this.otaSendFileMAXTime = 5;
        this.getOtaStateMAXTime = 3;
        this.proxy = cEDevK6Proxy;
        this.mContext = context;
        this.isDownloadDomplete = false;
    }

    public FileTransControl(CEDevK6Proxy cEDevK6Proxy, Context context, boolean z) {
        this.DEFAULT_LENGTH = 200;
        this.lastSendBytesLen = 0;
        this.fPos = 0;
        this.otaState = 0;
        this.otaSendFileMAXTime = 5;
        this.getOtaStateMAXTime = 3;
        this.proxy = cEDevK6Proxy;
        this.mContext = context;
        this.isSpeedUp = z;
        this.isDownloadDomplete = false;
        if (z) {
            this.DEFAULT_LENGTH = 10000;
        } else {
            this.DEFAULT_LENGTH = 200;
        }
        Log.i("FileTransControl", "DEFAULT_LENGTH=" + this.DEFAULT_LENGTH);
    }

    private void otaLog(String str) {
        Log.e(TAG, "文件下载 升级:" + str);
        if (TextUtils.isEmpty(str) || !"otaComplete".equals(str)) {
            return;
        }
        CEDevQueue.devData = null;
        BleFactory.getInstance().getK6Proxy().sendMeg(BleFactory.getInstance().getK6Proxy().createMessage(-1188848833, 0));
    }

    private void obtainFileSendStatus() {
        Log.d(TAG, "obtainFileSendStatusfileUrl");
        CEDevK6Proxy cEDevK6Proxy = this.proxy;
        if (cEDevK6Proxy == null || !cEDevK6Proxy.isConnectOK()) {
            setFileState(0);
            return;
        }
        Log.d(TAG, "obtainFileSendStatusconnect ok");
        setFileState(3);
        this.proxy.getSendHelper().getFileDownloadInfo();
    }

    public void setFileState(int i) {
        if (this.otaState != i) {
            this.otaState = i;
        }
    }

    public void sendFile(String str, byte[] bArr) throws IOException {
        if (this.otaState > 0) {
            return;
        }
        this.head = bArr;
        otaFilePath = str;
        byte[] bytes = OtaUtil.getBytes(str, this.mContext);
        this.data = bytes;
        if (bytes == null || bytes.length == 0) {
            return;
        }
        setFileState(3);
        if (this.isSpeedUp) {
            this.fPos = 0;
            Logger.e("FileTransControl", "文件传输开始 ");
            IK6SendDataManager sendHelper = this.proxy.getSendHelper();
            int length = this.data.length;
            int i = this.fPos;
            sendHelper.sendWatchFileData(bArr, length, i, getSendIndexDate(i));
        } else {
            obtainFileSendStatus();
        }
        Log.d(TAG, "sendFile fileUrl=" + str);
    }

    public byte[] getSendIndexDate(int i) {
        byte[] bArr = this.data;
        if (i >= bArr.length) {
            return null;
        }
        int i2 = this.DEFAULT_LENGTH;
        int length = i2;
        if (i + i2 > bArr.length) {
            length = bArr.length - i;
        }
        this.lastSendBytesLen = length;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, i, bArr2, 0, length);
        return bArr2;
    }

    public void fileDataSendResult(int i) {
        int i2 = this.otaState;
        if (i2 == 6 || i2 == 0) {
            return;
        }
        if (i != -101) {
            int i3 = this.otaSendFileMAXTime - 1;
            this.otaSendFileMAXTime = i3;
            if (i3 < 0) {
                setFileState(0);
            } else {
                obtainFileSendStatus();
            }
            otaLog("ota 失败  剩余失败次数：" + this.otaSendFileMAXTime);
            return;
        }
        Log.d(TAG, "fileDataSendResultACK_TYPE_SUCCESS");
        setFileState(5);
        this.otaSendFileMAXTime = 5;
        int i4 = this.fPos + this.lastSendBytesLen;
        this.fPos = i4;
        if (i4 >= this.data.length) {
            otaLog("otaComplete");
            setFileState(6);
            return;
        }
        IK6SendDataManager sendHelper = this.proxy.getSendHelper();
        byte[] bArr = this.head;
        int length = this.data.length;
        int i5 = this.fPos;
        sendHelper.sendWatchFileData(bArr, length, i5, getSendIndexDate(i5));
    }

    public boolean isDownloadDomplete() {
        return this.isDownloadDomplete;
    }

    public void fileStateResult(K6_DATA_TYPE_WATCH_FACE_INFO k6_data_type_watch_face_info) {
        this.otaSendFileMAXTime = 5;
        otaLog(k6_data_type_watch_face_info.toString());
        Log.e("zhou", "otaState=" + this.otaState);
        int i = this.otaState;
        if (i >= 4 || i == 0) {
            otaLog("当前状态不正确 不开始下载文件 otaState=" + this.otaState);
            return;
        }
        setFileState(4);
        this.fPos = 0;
        IK6SendDataManager sendHelper = this.proxy.getSendHelper();
        byte[] bArr = this.head;
        int length = this.data.length;
        int i2 = this.fPos;
        sendHelper.sendWatchFileData(bArr, length, i2, getSendIndexDate(i2));
    }

    public void sendQRInfo(K6_DATA_TYPE_QR_CODE_INFO k6_data_type_qr_code_info) {
        this.fPos = 0;
        this.data = k6_data_type_qr_code_info.getSendByte();
        this.proxy.getSendHelper().sendQRInfo(getSendIndexDate(this.fPos), this.fPos, k6_data_type_qr_code_info.getItemSize());
    }

    public void sendQRInfoSendResult(int i) {
        if (i != -101) {
            CEDevK6Proxy cEDevK6Proxy = this.proxy;
            cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(1519085138, 0));
            Log.e(Lg.getClassName(this), "二维码发送失败");
            return;
        }
        int i2 = this.fPos + this.lastSendBytesLen;
        this.fPos = i2;
        if (i2 < this.data.length) {
            this.proxy.getSendHelper().sendQRInfo(getSendIndexDate(this.fPos), this.fPos, this.data.length);
            return;
        }
        CEDevK6Proxy cEDevK6Proxy2 = this.proxy;
        cEDevK6Proxy2.sendMeg(cEDevK6Proxy2.createMessage(1519085138, 1));
        Log.e(Lg.getClassName(this), "二维码发送完成");
    }
}
