package ce.com.cenewbluesdk.uitl;

import android.util.Log;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/Logger.class */
public class Logger {
    private static final int VERBOSE = 1;
    private static final int DEBUG = 2;
    private static final int INFO = 3;
    private static final int WARN = 4;
    private static final int ERROR = 5;
    private static final int NOTHING = 6;
    private static final String TAG = "LoggerTag";
    private static int LEVEL = 1;

    public static void v(String str) {
    }

    public static void v(String str, String str2) {
    }

    public static void d(String str) {
    }

    public static void d(String str, String str2) {
    }

    public static void i(String str) {
    }

    public static void i(String str, String str2) {
    }

    public static void w(String str) {
    }

    public static void w(String str, String str2) {
    }

    public static void e(String str) {
    }

    public static void e(String str, String str2) {
    }

    public static void logOutPut(String str, String str2, int i) {
        if (str == null || str.length() == 0 || str2 == null || str2.length() == 0) {
            return;
        }
        if (str2.length() > 3072) {
            while (str2.length() > 3072) {
                String strSubstring = str2.substring(0, 3072);
                logType(str, str2, i);
                str2 = str2.replace(strSubstring, "");
            }
        }
        logType(str, str2, i);
    }

    private static void logType(String str, String str2, int i) {
        switch (i) {
            case 1:
                Log.v(str, str2);
                break;
            case 2:
                Log.d(str, str2);
                break;
            case 3:
                Log.i(str, str2);
                break;
            case 4:
                Log.w(str, str2);
                break;
            case 5:
                Log.e(str, str2);
                break;
        }
    }
}
