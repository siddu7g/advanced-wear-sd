package ce.com.cenewbluesdk.uitl;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.Log;
import androidx.annotation.RequiresApi;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/g.class */
public class g {
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v10, types: [byte[]] */
    public static byte[] a(String str) throws IOException {
        ?? file = new File(str);
        try {
            FileInputStream fileInputStream = new FileInputStream((File) file);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(10000);
            byte[] bArr = new byte[10000];
            while (true) {
                int i = fileInputStream.read(bArr);
                if (i == -1) {
                    fileInputStream.close();
                    file = byteArrayOutputStream.toByteArray();
                    byteArrayOutputStream.close();
                    return file;
                }
                byteArrayOutputStream.write(bArr, 0, i);
            }
        } catch (Exception unused) {
            file.printStackTrace();
            return null;
        }
    }

    public static byte[] b(File file) throws IOException {
        if (file.length() > 2147483647L) {
            throw new IOException("File is too large.");
        }
        try {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[(int) file.length()];
            while (true) {
                int i = bufferedInputStream.read(bArr);
                if (i == -1) {
                    return byteArrayOutputStream.toByteArray();
                }
                byteArrayOutputStream.write(bArr, 0, i);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v24 ??, still in use, count: 4, list:
          (r0v24 ??) from 0x008a: PHI (r0v11 ??) = (r0v1 ??), (r0v21 ??), (r0v24 ??) binds: [B:33:0x0086, B:29:0x0078, B:25:0x006e] A[DONT_GENERATE, DONT_INLINE]
          (r0v24 ?? I:java.io.IOException) from 0x0064: INVOKE (r0v24 ?? I:java.io.IOException) VIRTUAL call: java.io.IOException.printStackTrace():void A[Catch: IOException -> 0x0064, MD:():void (s), TRY_LEAVE]
          (r0v24 ?? I:java.io.BufferedOutputStream) from 0x005e: INVOKE (r0v24 ?? I:java.io.BufferedOutputStream) VIRTUAL call: java.io.BufferedOutputStream.close():void A[Catch: IOException -> 0x0064, Exception -> 0x006e, all -> 0x00aa, MD:():void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
          (r0v24 ?? I:java.io.BufferedOutputStream) from 0x005b: INVOKE (r0v24 ?? I:java.io.BufferedOutputStream), (r6v0 ?? I:byte[]) VIRTUAL call: java.io.BufferedOutputStream.write(byte[]):void A[Catch: Exception -> 0x006e, all -> 0x0071, Exception -> 0x0077, all -> 0x00aa, MD:(byte[]):void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static void a(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v24 ??, still in use, count: 4, list:
          (r0v24 ??) from 0x008a: PHI (r0v11 ??) = (r0v1 ??), (r0v21 ??), (r0v24 ??) binds: [B:33:0x0086, B:29:0x0078, B:25:0x006e] A[DONT_GENERATE, DONT_INLINE]
          (r0v24 ?? I:java.io.IOException) from 0x0064: INVOKE (r0v24 ?? I:java.io.IOException) VIRTUAL call: java.io.IOException.printStackTrace():void A[Catch: IOException -> 0x0064, MD:():void (s), TRY_LEAVE]
          (r0v24 ?? I:java.io.BufferedOutputStream) from 0x005e: INVOKE (r0v24 ?? I:java.io.BufferedOutputStream) VIRTUAL call: java.io.BufferedOutputStream.close():void A[Catch: IOException -> 0x0064, Exception -> 0x006e, all -> 0x00aa, MD:():void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
          (r0v24 ?? I:java.io.BufferedOutputStream) from 0x005b: INVOKE (r0v24 ?? I:java.io.BufferedOutputStream), (r6v0 ?? I:byte[]) VIRTUAL call: java.io.BufferedOutputStream.write(byte[]):void A[Catch: Exception -> 0x006e, all -> 0x0071, Exception -> 0x0077, all -> 0x00aa, MD:(byte[]):void throws java.io.IOException (c), TRY_ENTER, TRY_LEAVE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r6v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */

    public static File a(byte[] bArr, File file) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        byte[] bArr2 = new byte[bArr.length];
        while (true) {
            int i = byteArrayInputStream.read(bArr2);
            if (i == -1) {
                byteArrayInputStream.close();
                fileOutputStream.close();
                return file;
            }
            fileOutputStream.write(bArr2, 0, i);
        }
    }

    public static Bitmap a(String str, int i, int i2) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        options.inSampleSize = a(options, i, i2);
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(str, options);
    }

    public static Bitmap a(String str, int i, int i2, int i3) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        options.inSampleSize = a(options, i, i2);
        if (i3 == 0) {
            options.inPreferredConfig = Bitmap.Config.RGB_565;
        } else {
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        }
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(str, options);
    }

    public static int a(BitmapFactory.Options options, int i, int i2) {
        int i3;
        int i4 = options.outHeight;
        int i5 = options.outWidth;
        if (i4 > i2 || i5 > i) {
            int i6 = i5 / i;
            int i7 = i4 / i2;
            i3 = i7;
            if (i6 <= i7) {
                i3 = i6;
            }
        } else {
            i3 = 1;
        }
        return i3;
    }

    public static Bitmap a(Bitmap bitmap, int i, int i2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Log.e("width", "width:" + width);
        Log.e("height", "height:" + height);
        Matrix matrix = new Matrix();
        matrix.postScale(i / width, i2 / height);
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
        bitmapCreateBitmap.getWidth();
        bitmapCreateBitmap.getHeight();
        Log.e("newWidth", "newWidth" + bitmapCreateBitmap.getWidth());
        Log.e("newHeight", "newHeight" + bitmapCreateBitmap.getHeight());
        return bitmapCreateBitmap;
    }

    public static boolean a(File file) {
        if (!file.exists()) {
            return false;
        }
        if (file.isDirectory()) {
            for (File file2 : file.listFiles()) {
                a(file2);
            }
        }
        return file.delete();
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [byte[], java.io.IOException] */
    @RequiresApi(api = 26)
    public static byte[] b(String str) throws IOException {
        ?? allBytes;
        try {
            allBytes = Files.readAllBytes(Paths.get(str, new String[0]));
            return allBytes;
        } catch (IOException unused) {
            allBytes.printStackTrace();
            return new byte[0];
        }
    }
}
