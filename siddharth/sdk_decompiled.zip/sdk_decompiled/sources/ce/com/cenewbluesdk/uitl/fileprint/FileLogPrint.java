package ce.com.cenewbluesdk.uitl.fileprint;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import ce.com.cenewbluesdk.entity.k6.DateTimeUtil;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.TimeUtil;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/fileprint/FileLogPrint.class */
public class FileLogPrint {
    private static final String TAG = "LogUtil";
    private static char MYLOG_TYPE = 'v';
    private static String MYLOG_PATH_SDCARD_DIR = "/sdcard/";
    private static String MYLOG_PATH_SDCARD_DIR_FOR_SLEEP = "/sdcard/";
    private static String MYLOG_PATH_SDCARD_DIR_FOR_ECG = "";
    private static String MYLOGFILENAMESLEEP = "SleepData.log";
    private static String MYLOGFILENAMEMYLOG = "mylog.log";
    private static int SDCARD_LOG_FILE_SAVE_DAYS = 0;
    private static String MYLOGFILEName = "App.log";
    private static SimpleDateFormat timeName = new SimpleDateFormat(DateTimeUtil.DAY_FORMAT);
    private static String BTLOGFILEName = "Bluetooth.log";
    public static String SENDDATALOGPATH;
    private static SimpleDateFormat myLogSdf;
    private static SimpleDateFormat logfile;
    private static int count;

    public static void init() {
        MYLOG_PATH_SDCARD_DIR = PRINT_PARAMS.LOG_PATH;
        MYLOG_PATH_SDCARD_DIR_FOR_SLEEP = PRINT_PARAMS.LOG_PATH_TESTBLUETOOTHSLEEPDATA;
        MYLOG_PATH_SDCARD_DIR_FOR_ECG = PRINT_PARAMS.LOG_PATH_TESTBLUETOOTHECGDATA;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v2, types: [byte[]] */
    public static void PrintECGTestData(byte[] bArr) {
        ?? r0 = PRINT_PARAMS.USE_BLUE_LOCAL_PRINT_FOR_ECG;
        if (r0 != 0) {
            try {
                r0 = bArr;
                writeBytesToFile(r0, MYLOG_PATH_SDCARD_DIR_FOR_ECG);
            } catch (Exception unused) {
                r0.printStackTrace();
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v2, types: [byte[]] */
    public static void PrintBlueTestData(byte[] bArr) {
        ?? r0 = PRINT_PARAMS.USE_BLUE_LOCAL_PRINT;
        if (r0 != 0) {
            try {
                r0 = bArr;
                writeBytesToFile(r0);
            } catch (Exception unused) {
                r0.printStackTrace();
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Error] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    public static void printSendData(String str) {
        ?? r0 = PRINT_PARAMS.SENDDATA_PRINT;
        if (r0 != 0) {
            try {
                try {
                    r0 = str;
                    writeBluetoothLog(r0);
                } catch (Error unused) {
                    r0.printStackTrace();
                }
            } catch (Exception unused2) {
                r0.printStackTrace();
            }
        }
    }

    public static void w(String str, Object obj) throws IOException {
        log(str, obj.toString(), 'w');
    }

    public static void e(String str, Object obj) throws IOException {
        log(str, obj.toString(), 'e');
    }

    public static void d(String str, Object obj) throws IOException {
        log(str, obj.toString(), 'd');
    }

    public static void i(String str, Object obj) throws IOException {
        log(str, obj.toString(), 'i');
    }

    public static void v(String str, Object obj) throws IOException {
        log(str, obj.toString(), 'v');
    }

    public static void w(String str, String str2) throws IOException {
        log(str, str2, 'w');
    }

    public static void ee(String str, String str2) throws IOException {
        myLog(str, str2, 'e');
    }

    public static void e(String str, String str2) throws IOException {
        log(str, str2, 'e');
    }

    public static void d(String str, String str2) throws IOException {
        log(str, str2, 'd');
    }

    public static void i(String str, String str2) throws IOException {
        log(str, str2, 'i');
    }

    public static void v(String str, String str2) throws IOException {
        log(str, str2, 'v');
    }

    private static void myLog(String str, String str2, char c) throws IOException {
        myWriteLogToFile(String.valueOf(c), str, str2);
    }

    private static void log(String str, String str2, char c) throws IOException {
        if (PRINT_PARAMS.MYLOG_SWITCH.booleanValue() && PRINT_PARAMS.MYLOG_WRITE_TO_FILE.booleanValue()) {
            writeLogtoFile(String.valueOf(c), str, str2);
        }
    }

    private static void writeBytesToFile(byte[] bArr, String str) throws Exception {
        File file = new File(str + logfile.format(Long.valueOf(System.currentTimeMillis())) + MYLOGFILENAMEMYLOG);
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        if (!file.exists()) {
            file.createNewFile();
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file, true);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        byte[] bArr2 = new byte[1024];
        while (true) {
            int i = byteArrayInputStream.read(bArr2);
            if (i == -1) {
                byteArrayInputStream.close();
                fileOutputStream.close();
                return;
            }
            fileOutputStream.write(bArr2, 0, i);
        }
    }

    private static void writeBytesToFile(byte[] bArr) throws Exception {
        Lg.e("zhou", "writeBytesToFile=" + Arrays.toString(bArr));
        File file = new File(MYLOG_PATH_SDCARD_DIR_FOR_SLEEP + logfile.format(Long.valueOf(System.currentTimeMillis())) + MYLOGFILENAMESLEEP);
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        if (!file.exists()) {
            file.createNewFile();
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file, true);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        byte[] bArr2 = new byte[1024];
        while (true) {
            int i = byteArrayInputStream.read(bArr2);
            if (i == -1) {
                byteArrayInputStream.close();
                fileOutputStream.close();
                return;
            }
            fileOutputStream.write(bArr2, 0, i);
        }
    }

    private static void myWriteLogToFile(String str, String str2, String str3) throws IOException {
        Date date = new Date();
        String str4 = myLogSdf.format(date) + " " + str + " " + str2 + " " + str3;
        BleFactory.getInstance();
        if (BleFactory.context == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        BleFactory.getInstance();
        File file = new File(sb.append(BleFactory.context.getExternalFilesDir("Log").getAbsolutePath()).append(File.separator).append(timeName.format(date)).append(MYLOGFILEName).toString());
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(file, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(str4);
            bufferedWriter.newLine();
            bufferedWriter.close();
            fileWriter.close();
        } catch (IOException unused) {
        } catch (Exception unused2) {
        }
    }

    private static void writeLogtoFile(String str, String str2, String str3) throws IOException {
        Date date = new Date();
        logfile.format(date);
        String str4 = myLogSdf.format(date) + " " + str + " " + str2 + " " + str3;
        BleFactory.getInstance();
        if (BleFactory.context == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        BleFactory.getInstance();
        File file = new File(sb.append(BleFactory.context.getFilesDir().getAbsolutePath()).append(File.separator).append(MYLOGFILEName).toString());
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(file, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(str4);
            bufferedWriter.newLine();
            bufferedWriter.close();
            fileWriter.close();
        } catch (IOException unused) {
        } catch (Exception unused2) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.io.FileWriter, java.io.Writer] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    public static void writeLogToFile(String str, String str2, String str3) throws IOException {
        Date date = new Date();
        String str4 = myLogSdf.format(date) + "  " + str2 + ": " + str3;
        BleFactory.getInstance();
        if (BleFactory.context == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        BleFactory.getInstance();
        File file = new File(sb.append(BleFactory.context.getExternalFilesDir("log/appLog").getAbsolutePath()).append(File.separator).append(timeName.format(date)).append("_").append(DateTimeUtil.getFormatDate(date, "HH")).append(MYLOGFILEName).toString());
        boolean zExists = file.getParentFile().exists();
        ?? fileWriter = zExists;
        if (!zExists) {
            fileWriter = file.getParentFile().mkdirs();
        }
        try {
            try {
                if (!file.exists()) {
                    file.createNewFile();
                }
                fileWriter = new FileWriter(file, true);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                bufferedWriter.write(str4);
                bufferedWriter.newLine();
                bufferedWriter.close();
                fileWriter.close();
            } catch (Exception unused) {
                fileWriter.printStackTrace();
            }
        } catch (IOException unused2) {
            fileWriter.printStackTrace();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.io.FileWriter, java.io.Writer] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    public static void writeLogToFile(String str, String str2, String str3, String str4) throws IOException {
        Date date = new Date();
        String str5 = myLogSdf.format(date) + " " + str + " " + str2 + ": " + str3;
        BleFactory.getInstance();
        if (BleFactory.context == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        BleFactory.getInstance();
        File file = new File(sb.append(BleFactory.context.getExternalFilesDir("log/appLog").getAbsolutePath()).append(File.separator).append(timeName.format(date)).append("_").append(str4).toString());
        boolean zExists = file.getParentFile().exists();
        ?? fileWriter = zExists;
        if (!zExists) {
            fileWriter = file.getParentFile().mkdirs();
        }
        try {
            try {
                if (!file.exists()) {
                    file.createNewFile();
                }
                fileWriter = new FileWriter(file, true);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                bufferedWriter.write(str5);
                bufferedWriter.newLine();
                bufferedWriter.close();
                fileWriter.close();
            } catch (Exception unused) {
                fileWriter.printStackTrace();
            }
        } catch (IOException unused2) {
            fileWriter.printStackTrace();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.io.FileWriter, java.io.Writer] */
    public static void writeLogToFile(Context context, String str, String str2, String str3, String str4) throws IOException {
        Date date = new Date();
        String str5 = myLogSdf.format(date) + " " + str + " " + str2 + " " + str3;
        if (context == null) {
            return;
        }
        File file = new File(context.getExternalFilesDir("log/appLog").getAbsolutePath() + File.separator + timeName.format(date) + "_" + str4);
        boolean zExists = file.getParentFile().exists();
        ?? fileWriter = zExists;
        if (!zExists) {
            fileWriter = file.getParentFile().mkdirs();
        }
        try {
            try {
                if (!file.exists()) {
                    file.createNewFile();
                }
                fileWriter = new FileWriter(file, true);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                bufferedWriter.write(str5);
                bufferedWriter.newLine();
                bufferedWriter.close();
                fileWriter.close();
            } catch (Exception unused) {
                fileWriter.printStackTrace();
            }
        } catch (IOException unused2) {
            fileWriter.printStackTrace();
        }
    }

    /* JADX WARN: Type inference failed for: r0v17, types: [java.io.FileWriter, java.io.IOException, java.io.Writer, java.lang.Error, java.lang.Exception] */
    public static void writeBluetoothLog(String str) throws IOException {
        ?? fileWriter;
        try {
            try {
                Date date = new Date();
                StringBuilder sbAppend = new StringBuilder().append("[").append(myLogSdf.format(date)).append("] Received data ");
                int i = count + 1;
                count = i;
                String string = sbAppend.append(i).append(" : ").append(str).toString();
                File file = new File(SENDDATALOGPATH + logfile.format(date) + ".log");
                folderMethod2(SENDDATALOGPATH);
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }
                if (!file.exists()) {
                    file.createNewFile();
                }
                fileWriter = new FileWriter(file, true);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                bufferedWriter.write(string);
                bufferedWriter.newLine();
                bufferedWriter.close();
                fileWriter.close();
            } catch (Error unused) {
                fileWriter.printStackTrace();
            }
        } catch (IOException unused2) {
            fileWriter.printStackTrace();
        } catch (Exception unused3) {
            fileWriter.printStackTrace();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.io.File[]] */
    public static void folderMethod2(String str) {
        File file = new File(str);
        if (!file.exists()) {
            System.out.println("文件不存在!");
            return;
        }
        ?? ListFiles = file.listFiles();
        if (ListFiles != 0) {
            for (?? IsDirectory : ListFiles) {
                try {
                    IsDirectory = IsDirectory.isDirectory();
                    if (IsDirectory != 0 || (!TextUtils.isEmpty(IsDirectory.getName()) && System.currentTimeMillis() - TimeUtil.string2Long(IsDirectory.getName(), "yyyy-MM-dd") > 172800000)) {
                        IsDirectory.delete();
                    }
                } catch (Exception unused) {
                    IsDirectory.printStackTrace();
                }
            }
        }
    }

    public static void delFile() {
        File file = new File(MYLOG_PATH_SDCARD_DIR, logfile.format(getDateBefore()) + MYLOGFILEName);
        if (file.exists()) {
            file.delete();
        }
    }

    private static Date getDateBefore() {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(5, calendar.get(5) - SDCARD_LOG_FILE_SAVE_DAYS);
        return calendar.getTime();
    }

    public static String getErrorInfoFromException(Exception exc) {
        try {
            StringWriter stringWriter = new StringWriter();
            exc.printStackTrace(new PrintWriter(stringWriter));
            return stringWriter.toString() + "\r\n";
        } catch (Exception unused) {
            return "bad getErrorInfoFromException";
        }
    }

    static {
        StringBuilder sbAppend = new StringBuilder().append(Environment.getExternalStorageDirectory().getPath());
        String str = File.separator;
        SENDDATALOGPATH = sbAppend.append(str).append("BLUELOG").append(str).toString();
        myLogSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        logfile = new SimpleDateFormat("yyyy-MM-dd");
        count = 0;
    }
}
