package ce.com.cenewbluesdk.uitl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/i.class */
public class i implements ParameterizedType {

    /* renamed from: a, reason: collision with root package name */
    private final Class f57a;
    private final Type[] b;

    public i(Class cls, Type[] typeArr) {
        this.f57a = cls;
        this.b = typeArr == null ? new Type[0] : typeArr;
    }

    @Override // java.lang.reflect.ParameterizedType
    public Type[] getActualTypeArguments() {
        return this.b;
    }

    @Override // java.lang.reflect.ParameterizedType
    public Type getRawType() {
        return this.f57a;
    }

    @Override // java.lang.reflect.ParameterizedType
    public Type getOwnerType() {
        return null;
    }
}
