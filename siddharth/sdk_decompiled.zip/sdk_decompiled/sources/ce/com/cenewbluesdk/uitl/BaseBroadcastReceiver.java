package ce.com.cenewbluesdk.uitl;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/BaseBroadcastReceiver.class */
public abstract class BaseBroadcastReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public abstract void onReceive(Context context, Intent intent);

    @Deprecated
    protected IntentFilter createIntentFilter() {
        return new IntentFilter();
    }

    public void register(Context context) {
        IntentFilter intentFilterCreateIntentFilter = createIntentFilter();
        onCreateFilter(intentFilterCreateIntentFilter);
        context.registerReceiver(this, intentFilterCreateIntentFilter);
    }

    protected void onCreateFilter(IntentFilter intentFilter) {
    }

    public void unregister(Context context) {
        context.unregisterReceiver(this);
    }
}
