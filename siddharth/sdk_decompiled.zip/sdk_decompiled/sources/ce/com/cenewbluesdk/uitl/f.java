package ce.com.cenewbluesdk.uitl;

import android.graphics.Color;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/f.class */
public class f {
    public static int e(int i) {
        return (((i & 255) & 248) << 8) | ((((i >> 8) & 255) & 252) << 3) | (((i >> 16) & 255) >> 3);
    }

    public static int b(int i) {
        return (((i >> 3) & 31) << 11) | (((i >> 10) & 63) << 5) | ((i >> 19) & 31);
    }

    public static int a(int i) {
        return (((i & 63488) >> 8) << 16) + (((i & 2016) >> 3) << 8) + (((i & 31) << 3) << 0);
    }

    public static int h(int i) {
        return Color.rgb((i & 16711680) >> 16, (i & 65280) >> 8, i & 255);
    }

    public static int g(int i) {
        return Color.argb(255, (((i >> 0) & 31) * 255) / 31, (((i >> 5) & 63) * 255) / 63, (((i >> 11) & 31) * 255) / 31);
    }

    public static int i(int i) {
        return ((i & 31) << 11) | (((i >> 5) & 63) << 5) | ((i >> 11) & 31);
    }

    public static int f(int i) {
        return ((i & 31) << 19) | (-16777216) | (((i >> 5) & 63) << 10) | (((i >> 11) & 31) << 3);
    }

    public static int d(int i) {
        return (((i >> 16) & 15) << 16) | ((i & 31) << 11) | (((i >> 5) & 63) << 5) | ((i >> 11) & 31);
    }

    public static int c(int i) {
        return (((i >> 16) & 15) << 16) | ((i & 31) << 11) | (((i >> 5) & 63) << 5) | ((i >> 11) & 31);
    }
}
