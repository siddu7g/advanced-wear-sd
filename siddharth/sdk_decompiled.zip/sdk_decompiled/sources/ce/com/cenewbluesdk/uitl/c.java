package ce.com.cenewbluesdk.uitl;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.os.ParcelUuid;
import android.text.TextUtils;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/c.class */
public class c {

    /* renamed from: a, reason: collision with root package name */
    private static final String f52a = "c";
    private static final char[] b = "0123456789ABCDEF".toCharArray();
    public static final UUID c = UUID.fromString("0000111e-0000-1000-8000-00805f9b34fb");
    public static final UUID d = UUID.fromString("0000110b-0000-1000-8000-00805f9b34fb");
    public static final UUID e = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    public static boolean g(Context context) {
        return context != null && context.getPackageManager().hasSystemFeature("android.hardware.bluetooth_le");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [android.bluetooth.BluetoothAdapter] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [android.bluetooth.BluetoothDevice] */
    public static BluetoothDevice a(Context context, String str) {
        ?? defaultAdapter;
        if (!BluetoothAdapter.checkBluetoothAddress(str) || (defaultAdapter = BluetoothAdapter.getDefaultAdapter()) == 0) {
            return null;
        }
        try {
            defaultAdapter = defaultAdapter.getRemoteDevice(str);
            return defaultAdapter;
        } catch (Exception unused) {
            defaultAdapter.printStackTrace();
            return null;
        }
    }

    public static boolean a(BluetoothDevice bluetoothDevice, BluetoothDevice bluetoothDevice2) {
        return (bluetoothDevice == null || bluetoothDevice2 == null || !bluetoothDevice.getAddress().equals(bluetoothDevice2.getAddress())) ? false : true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    @SuppressLint({"DiscouragedPrivateApi"})
    public static boolean a(Context context, BluetoothDevice bluetoothDevice, int i) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        Object objInvoke;
        if (bluetoothDevice == null) {
            return false;
        }
        ?? BooleanValue = bluetoothDevice;
        boolean z = false;
        try {
            Class<?> cls = BooleanValue.getClass();
            Class<?>[] clsArr = new Class[1];
            clsArr[0] = Integer.TYPE;
            Method declaredMethod = cls.getDeclaredMethod("createBond", clsArr);
            declaredMethod.setAccessible(true);
            Object[] objArr = new Object[1];
            objArr[0] = Integer.valueOf(i);
            objInvoke = declaredMethod.invoke(bluetoothDevice, objArr);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean a(Context context, BluetoothDevice bluetoothDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (bluetoothDevice == null) {
            return false;
        }
        boolean zCreateBond = false;
        if (Build.VERSION.SDK_INT >= 20) {
            zCreateBond = bluetoothDevice.createBond();
        } else {
            ?? BooleanValue = bluetoothDevice.getClass();
            try {
                Object objInvoke = BooleanValue.getMethod("createBond", new Class[0]).invoke(bluetoothDevice, new Object[0]);
                if (!(objInvoke instanceof Boolean)) {
                    return false;
                }
                BooleanValue = ((Boolean) objInvoke).booleanValue();
                zCreateBond = BooleanValue;
            } catch (Exception unused) {
                BooleanValue.printStackTrace();
            }
        }
        return zCreateBond;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean f(Context context, BluetoothDevice bluetoothDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Object objInvoke;
        if (bluetoothDevice == null) {
            return false;
        }
        boolean z = false;
        ?? BooleanValue = bluetoothDevice.getClass();
        try {
            objInvoke = BooleanValue.getMethod("removeBond", new Class[0]).invoke(bluetoothDevice, new Object[0]);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    @SuppressLint({"DiscouragedPrivateApi", "MissingPermission"})
    public static int a(Context context, BluetoothAdapter bluetoothAdapter) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        ?? IntValue = bluetoothAdapter;
        int i = 0;
        if (IntValue != 0) {
            try {
                Method declaredMethod = bluetoothAdapter.getClass().getDeclaredMethod("getConnectionState", new Class[0]);
                declaredMethod.setAccessible(true);
                Object objInvoke = declaredMethod.invoke(bluetoothAdapter, new Object[0]);
                if (!(objInvoke instanceof Integer)) {
                    return i;
                }
                IntValue = ((Integer) objInvoke).intValue();
                i = IntValue;
            } catch (Exception unused) {
                IntValue.printStackTrace();
            }
        }
        return i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    @SuppressLint({"MissingPermission"})
    public static boolean d(Context context, BluetoothDevice bluetoothDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        ?? BooleanValue = bluetoothDevice;
        boolean z = false;
        if (BooleanValue != 0) {
            try {
                Object objInvoke = bluetoothDevice.getClass().getDeclaredMethod("isConnected", new Class[0]).invoke(bluetoothDevice, new Object[0]);
                if (!(objInvoke instanceof Boolean)) {
                    return false;
                }
                BooleanValue = ((Boolean) objInvoke).booleanValue();
                z = BooleanValue;
            } catch (Exception unused) {
                BooleanValue.printStackTrace();
            }
        }
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [android.bluetooth.BluetoothManager] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.util.List, java.util.List<android.bluetooth.BluetoothDevice>] */
    @SuppressLint({"MissingPermission"})
    public static List<BluetoothDevice> c(Context context) {
        ?? connectedDevices = (BluetoothManager) context.getSystemService("bluetooth");
        if (connectedDevices == 0) {
            return null;
        }
        try {
            connectedDevices = connectedDevices.getConnectedDevices(7);
            return connectedDevices;
        } catch (Exception unused) {
            connectedDevices.printStackTrace();
            return null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [android.content.Context] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v21, types: [boolean] */
    @SuppressLint({"MissingPermission"})
    public static List<BluetoothDevice> f(Context context) {
        ?? HasNext = context;
        ArrayList arrayList = arrayList;
        ArrayList arrayList2 = new ArrayList();
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        try {
            int iA = a((Context) HasNext, defaultAdapter);
            if (iA == 2 || iA == 0) {
                for (BluetoothDevice bluetoothDevice : defaultAdapter.getBondedDevices()) {
                    if (d(context, bluetoothDevice)) {
                        arrayList.add(bluetoothDevice);
                    }
                }
            }
            List<BluetoothDevice> listC = c(context);
            if (listC != null) {
                Iterator<BluetoothDevice> it = listC.iterator();
                while (true) {
                    HasNext = it.hasNext();
                    if (HasNext == 0) {
                        break;
                    }
                    BluetoothDevice next = it.next();
                    if (!arrayList.contains(next)) {
                        arrayList.add(next);
                    }
                }
            }
        } catch (Exception unused) {
            HasNext.printStackTrace();
        }
        if (arrayList.size() <= 0) {
            arrayList = null;
        }
        return arrayList;
    }

    @SuppressLint({"MissingPermission"})
    public static boolean e(Context context, BluetoothDevice bluetoothDevice) {
        if (context == null || bluetoothDevice == null) {
            return false;
        }
        boolean z = false;
        List<BluetoothDevice> listC = c(context);
        if (listC != null) {
            Iterator<BluetoothDevice> it = listC.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                BluetoothDevice next = it.next();
                if (next != null && bluetoothDevice.getAddress().equals(next.getAddress())) {
                    z = true;
                    break;
                }
            }
        }
        return z;
    }

    public static String a(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        if (bArr != null && bArr.length == 6) {
            for (int i = 0; i < bArr.length; i++) {
                int i2 = i;
                char[] cArr = b;
                sb.append(cArr[(bArr[i] & 255) >> 4]);
                sb.append(cArr[bArr[i] & 15]);
                if (i2 != bArr.length - 1) {
                    sb.append(":");
                }
            }
        }
        return sb.toString();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r6v0, types: [java.lang.CharSequence, java.lang.String] */
    public static byte[] b(String str) {
        byte[] bArr;
        if (TextUtils.isEmpty(str)) {
            bArr = null;
        } else {
            int length = str.length() / 2;
            bArr = new byte[length];
            for (int i = 0; i < length; i++) {
                int i2 = i * 2;
                ?? r0 = i2 + 2;
                if (r0 <= str.length()) {
                    try {
                        r0 = bArr;
                        r0[i] = (byte) Integer.valueOf(str.substring(i2, r0), 16).intValue();
                    } catch (Exception unused) {
                        r0.printStackTrace();
                        return null;
                    }
                }
            }
        }
        return bArr;
    }

    public static String c(String str) {
        if (!BluetoothAdapter.checkBluetoothAddress(str)) {
            return str;
        }
        if (str.contains(":")) {
            str = str.replaceAll(":", "");
        }
        byte[] bArrB = b(str);
        if (bArrB == null) {
            return str;
        }
        byte[] bArr = new byte[6];
        int i = 0;
        int length = bArrB.length - 1;
        while (true) {
            if (!(i < bArrB.length) || !(length >= 0)) {
                return a(bArr);
            }
            bArr[i] = bArrB[length];
            i++;
            length--;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15, types: [int] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.String] */
    public static byte[] a(String str) {
        byte[] bArr;
        if (TextUtils.isEmpty(str) || !str.contains(":")) {
            bArr = null;
        } else {
            ?? Replace = str.replace(":", "");
            int length = Replace.length() / 2;
            bArr = new byte[length];
            if (length == 6) {
                for (int i = 0; i < length; i++) {
                    int i2 = i * 2;
                    ?? r0 = i2 + 2;
                    if (r0 <= Replace.length()) {
                        try {
                            r0 = bArr;
                            r0[i] = (byte) Integer.valueOf(Replace.substring(i2, r0), 16).intValue();
                        } catch (Exception unused) {
                            r0.printStackTrace();
                            return null;
                        }
                    }
                }
            } else {
                bArr = null;
            }
        }
        return bArr;
    }

    @SuppressLint({"MissingPermission"})
    public static boolean b() {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        return defaultAdapter != null && defaultAdapter.isEnabled();
    }

    @SuppressLint({"MissingPermission"})
    public static boolean b(Context context) {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        if (defaultAdapter == null) {
            return false;
        }
        if (defaultAdapter.isEnabled()) {
            return true;
        }
        return defaultAdapter.enable();
    }

    @SuppressLint({"MissingPermission"})
    public static boolean a(Context context) {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        if (defaultAdapter == null) {
            return false;
        }
        if (defaultAdapter.isEnabled()) {
            return defaultAdapter.disable();
        }
        return true;
    }

    @SuppressLint({"MissingPermission"})
    public static boolean a(Context context, BluetoothDevice bluetoothDevice, UUID uuid) {
        if (!b() || bluetoothDevice == null || uuid == null || TextUtils.isEmpty(uuid.toString())) {
            return false;
        }
        boolean z = false;
        ParcelUuid[] uuids = bluetoothDevice.getUuids();
        if (uuids == null) {
            return false;
        }
        int length = uuids.length;
        int i = 0;
        while (true) {
            if (i < length) {
                ParcelUuid parcelUuid = uuids[i];
                if (parcelUuid != null && uuid.toString().equalsIgnoreCase(parcelUuid.toString())) {
                    z = true;
                    break;
                }
                i++;
            } else {
                break;
            }
        }
        return z;
    }

    public static boolean c(Context context, BluetoothDevice bluetoothDevice) {
        return a(context, bluetoothDevice, c);
    }

    public static boolean b(Context context, BluetoothDevice bluetoothDevice) {
        return a(context, bluetoothDevice, d);
    }

    public static Method a() throws Exception {
        return Class.class.getDeclaredMethod("getDeclaredMethod", String.class, Class[].class);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean a(Context context, BluetoothProfile bluetoothProfile, BluetoothDevice bluetoothDevice, int i) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        ?? BooleanValue;
        boolean z;
        if (bluetoothProfile == null || (BooleanValue = bluetoothDevice) == 0) {
            return false;
        }
        try {
            Method methodA = a();
            Class<?> cls = bluetoothProfile.getClass();
            Object[] objArr = new Object[2];
            objArr[0] = "setPriority";
            Class[] clsArr = new Class[2];
            clsArr[0] = BluetoothDevice.class;
            clsArr[1] = Integer.TYPE;
            objArr[1] = clsArr;
            Method method = (Method) methodA.invoke(cls, objArr);
            if (method == null) {
                return false;
            }
            Object[] objArr2 = new Object[2];
            objArr2[0] = bluetoothDevice;
            objArr2[1] = Integer.valueOf(i);
            Object objInvoke = method.invoke(bluetoothProfile, objArr2);
            if (objInvoke instanceof Boolean) {
                BooleanValue = ((Boolean) objInvoke).booleanValue();
                z = BooleanValue;
            } else {
                z = false;
            }
            return z;
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
            return false;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static int a(Context context, BluetoothProfile bluetoothProfile, BluetoothDevice bluetoothDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        ?? IntValue;
        int i;
        if (bluetoothProfile == null || (IntValue = bluetoothDevice) == 0) {
            return 0;
        }
        try {
            Method methodA = a();
            Class<?> cls = bluetoothProfile.getClass();
            Object[] objArr = new Object[2];
            objArr[0] = "getPriority";
            Class[] clsArr = new Class[1];
            clsArr[0] = BluetoothDevice.class;
            objArr[1] = clsArr;
            Method method = (Method) methodA.invoke(cls, objArr);
            if (method == null) {
                return 0;
            }
            Object objInvoke = method.invoke(bluetoothProfile, bluetoothDevice);
            if (objInvoke instanceof Integer) {
                IntValue = ((Integer) objInvoke).intValue();
                i = IntValue;
            } else {
                i = 0;
            }
            return i;
        } catch (Exception unused) {
            IntValue.printStackTrace();
            return 0;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    @SuppressLint({"DiscouragedPrivateApi", "MissingPermission"})
    public static boolean c(Context context, BluetoothA2dp bluetoothA2dp, BluetoothDevice bluetoothDevice) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        Object objInvoke;
        if (bluetoothA2dp == null || bluetoothDevice == null) {
            return false;
        }
        ?? BooleanValue = bluetoothA2dp;
        boolean z = false;
        try {
            Class<?> cls = BooleanValue.getClass();
            Class<?>[] clsArr = new Class[1];
            clsArr[0] = bluetoothDevice.getClass();
            Method declaredMethod = cls.getDeclaredMethod("setActiveDevice", clsArr);
            declaredMethod.setAccessible(true);
            objInvoke = declaredMethod.invoke(bluetoothA2dp, bluetoothDevice);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [android.bluetooth.BluetoothDevice] */
    @SuppressLint({"DiscouragedPrivateApi", "MissingPermission"})
    public static BluetoothDevice a(Context context, BluetoothA2dp bluetoothA2dp) throws NoSuchMethodException, SecurityException {
        if (bluetoothA2dp == null) {
            return null;
        }
        ?? r0 = bluetoothA2dp;
        BluetoothDevice bluetoothDevice = null;
        try {
            Method declaredMethod = r0.getClass().getDeclaredMethod("getActiveDevice", new Class[0]);
            declaredMethod.setAccessible(true);
            r0 = (BluetoothDevice) declaredMethod.invoke(bluetoothA2dp, new Object[0]);
            bluetoothDevice = r0;
        } catch (Exception unused) {
            r0.printStackTrace();
        }
        return bluetoothDevice;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean a(Context context, BluetoothA2dp bluetoothA2dp, BluetoothDevice bluetoothDevice) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Object objInvoke;
        if (bluetoothA2dp == null || bluetoothDevice == null) {
            return false;
        }
        ?? BooleanValue = bluetoothA2dp.getClass();
        boolean z = false;
        try {
            Class[] clsArr = new Class[1];
            clsArr[0] = BluetoothDevice.class;
            objInvoke = BooleanValue.getMethod("connect", clsArr).invoke(bluetoothA2dp, bluetoothDevice);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean b(Context context, BluetoothA2dp bluetoothA2dp, BluetoothDevice bluetoothDevice) {
        Object objInvoke;
        if (bluetoothA2dp == null || bluetoothDevice == null) {
            return false;
        }
        ?? BooleanValue = bluetoothA2dp;
        boolean z = false;
        try {
            Class<?> cls = BooleanValue.getClass();
            Class<?>[] clsArr = new Class[1];
            clsArr[0] = BluetoothDevice.class;
            Method method = cls.getMethod("disconnect", clsArr);
            method.setAccessible(true);
            objInvoke = method.invoke(bluetoothA2dp, bluetoothDevice);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean a(Context context, BluetoothHeadset bluetoothHeadset, BluetoothDevice bluetoothDevice) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        Object objInvoke;
        if (bluetoothHeadset == null || bluetoothDevice == null) {
            return false;
        }
        boolean z = false;
        ?? BooleanValue = bluetoothHeadset.getClass();
        try {
            Class[] clsArr = new Class[1];
            clsArr[0] = BluetoothDevice.class;
            Method method = BooleanValue.getMethod("connect", clsArr);
            method.setAccessible(true);
            objInvoke = method.invoke(bluetoothHeadset, bluetoothDevice);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean b(Context context, BluetoothHeadset bluetoothHeadset, BluetoothDevice bluetoothDevice) {
        Object objInvoke;
        if (bluetoothHeadset == null || bluetoothDevice == null) {
            return false;
        }
        ?? BooleanValue = bluetoothHeadset;
        boolean z = false;
        try {
            Class<?> cls = BooleanValue.getClass();
            Class<?>[] clsArr = new Class[1];
            clsArr[0] = BluetoothDevice.class;
            Method method = cls.getMethod("disconnect", clsArr);
            method.setAccessible(true);
            objInvoke = method.invoke(bluetoothHeadset, bluetoothDevice);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return false;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }

    public static int a(int i) {
        if (i < 20) {
            i = 20;
        }
        if (i > 509) {
            i = 509;
        }
        return i;
    }

    @SuppressLint({"MissingPermission"})
    public static List<BluetoothDevice> e(Context context) {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        if (defaultAdapter == null || !defaultAdapter.isEnabled()) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        if (defaultAdapter.getBondedDevices() != null) {
            arrayList.addAll(defaultAdapter.getBondedDevices());
        }
        return arrayList;
    }

    @SuppressLint({"MissingPermission"})
    public static List<BluetoothDevice> d(Context context) {
        List<BluetoothDevice> listE = e(context);
        if (listE == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (BluetoothDevice bluetoothDevice : listE) {
            int type = bluetoothDevice.getType();
            if (type == 2 || type == 3) {
                arrayList.add(bluetoothDevice);
            }
        }
        return arrayList;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    @SuppressLint({"MissingPermission"})
    public static boolean a(Context context, BluetoothGatt bluetoothGatt) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Object objInvoke;
        if (bluetoothGatt == null) {
            return false;
        }
        ?? BooleanValue = bluetoothGatt;
        boolean z = false;
        try {
            objInvoke = BooleanValue.getClass().getMethod("refresh", new Class[0]).invoke(bluetoothGatt, new Object[0]);
        } catch (Exception unused) {
            BooleanValue.printStackTrace();
        }
        if (!(objInvoke instanceof Boolean)) {
            return z;
        }
        BooleanValue = ((Boolean) objInvoke).booleanValue();
        z = BooleanValue;
        return z;
    }
}
