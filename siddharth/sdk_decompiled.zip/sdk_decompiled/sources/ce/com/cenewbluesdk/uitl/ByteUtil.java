package ce.com.cenewbluesdk.uitl;

import android.text.TextUtils;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/ByteUtil.class */
public class ByteUtil {
    public static final byte[] EMPTY_BYTES = new byte[0];
    private static ByteBuffer buffer = ByteBuffer.allocate(8);

    public static int byte4ToInt(byte[] bArr) {
        int i = bArr[0] & 255;
        int i2 = (bArr[1] & 255) << 8;
        return i + i2 + ((bArr[2] & 255) << 16) + ((bArr[3] & 255) << 24);
    }

    public static int byte3ToInt(byte[] bArr) {
        return (bArr[0] & 255) + ((bArr[1] & 255) << 8) + ((bArr[2] & 255) << 16);
    }

    public static int byte3ToIntB(byte[] bArr) {
        return ((bArr[0] & 255) << 16) | ((bArr[1] & 255) << 8) | (bArr[2] & 255);
    }

    public static int byteToInt(byte... bArr) {
        if (bArr.length > 4) {
            throw new IllegalArgumentException("bytes的长度不能大于4: " + Arrays.toString(bArr));
        }
        int i = 0;
        for (int i2 = 0; i2 < bArr.length; i2++) {
            i += (bArr[i2] & 255) << (i2 * 8);
        }
        return i;
    }

    public static byte[] intToByte4(int i) {
        return new byte[]{(byte) i, (byte) (i >>> 8), (byte) (i >>> 16), (byte) (i >>> 24)};
    }

    public static byte[] intToByte(int i, int i2) {
        if (i2 > 4) {
            throw new IllegalArgumentException(String.format("size(%s)不能大于4", Integer.valueOf(i2)));
        }
        byte[] bArr = new byte[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            bArr[i3] = (byte) (i >>> (i3 * 8));
        }
        return bArr;
    }

    public static byte[] subBytes(byte[] bArr, int i, int i2) {
        byte[] bArr2 = new byte[i2];
        System.arraycopy(bArr, i, bArr2, 0, i2);
        return bArr2;
    }

    public static boolean[] getBooleanArray(byte b) {
        boolean[] zArr = new boolean[7];
        if (b == 127) {
            zArr = new boolean[]{false, false, false, false, false, false, false};
        } else {
            for (int i = 0; i <= 6; i++) {
                zArr[i] = 1 == (b & 1);
                b = (byte) (b >> 1);
            }
        }
        return zArr;
    }

    public static int byte2ToInt(byte[] bArr) {
        return (bArr[0] & 255) + ((bArr[1] & 255) << 8);
    }

    public static int byte2ToBigInt(byte[] bArr) {
        return ((bArr[0] & 255) << 8) + (bArr[1] & 255);
    }

    public static int byte2ToInt2(byte[] bArr) {
        return (((bArr[0] & 255) << 16) + ((bArr[1] & 255) << 24)) >> 16;
    }

    public static int byteToInt(byte[] bArr, int i, int i2) {
        return byteToInt(subBytes(bArr, i, i2));
    }

    public static byte[] intToByte4BE(int i) {
        return new byte[]{(byte) (i >>> 24), (byte) (i >>> 16), (byte) (i >>> 8), (byte) i};
    }

    @Deprecated
    public static byte[] intToByte(int i) {
        byte[] bArr = new byte[4];
        for (int i2 = 0; i2 < 4; i2++) {
            bArr[i2] = (byte) ((i % 256) & 255);
            i /= 256;
        }
        return bArr;
    }

    public static byte[] int2byte2(int i) {
        return new byte[]{(byte) ((i >> 8) & 255), (byte) (i & 255)};
    }

    public static byte[] int2byte3(int i) {
        return new byte[]{(byte) ((i >> 16) & 255), (byte) ((i >> 8) & 255), (byte) (i & 255)};
    }

    public static byte[] int2byte3High(int i) {
        return new byte[]{(byte) (i & 255), (byte) ((i >> 8) & 255), (byte) ((i >> 16) & 15)};
    }

    @Deprecated
    public static String boolean2String(boolean z) {
        return z ? "1" : "0";
    }

    @Deprecated
    public static boolean string2Boolean(String str) {
        return !"0".equals(str);
    }

    public static short byteToShort3(byte[] bArr) {
        return (short) (((short) (bArr[0] & 255)) + ((short) ((bArr[1] & 255) << 8)));
    }

    @Deprecated
    public static byte[] shortToByteArray(short s) {
        return new byte[]{(byte) (s >>> 8), (byte) s};
    }

    public static byte[] int2bytes2(int i) {
        return new byte[]{(byte) (i & 255), (byte) ((i >>> 8) & 255)};
    }

    public static byte[] int2byte2High(int i) {
        return new byte[]{(byte) ((i >> 8) & 255), (byte) (i & 255)};
    }

    @Deprecated
    public static byte[] stringToByteArray(String str) {
        return str.getBytes();
    }

    @Deprecated
    public static byte[] addByteArray(byte[] bArr, byte[] bArr2) {
        byte[] bArr3 = new byte[bArr.length + bArr2.length];
        System.arraycopy(bArr, 0, bArr3, 0, bArr.length);
        System.arraycopy(bArr2, 0, bArr3, bArr.length, bArr2.length);
        return bArr3;
    }

    @Deprecated
    public static void parseint2ByteArr(byte[] bArr, long j) {
        for (int i = 0; i < 4; i++) {
            bArr[i] = (byte) ((j % 256) & 255);
            j /= 256;
        }
    }

    public static long unsigned4BytesToLong(byte[] bArr, int i) {
        int i2 = bArr[i] & 255;
        int i3 = bArr[i + 1] & 255;
        int i4 = bArr[i + 2] & 255;
        return ((i2 << 24) | (i3 << 16) | (i4 << 8) | (bArr[i + 3] & 255)) & 4294967295L;
    }

    public static byte[] longToBytes(long j) {
        buffer.putLong(0, j);
        return buffer.array();
    }

    public static long bytes2Long(byte[] bArr) {
        return (((bArr[0] << 24) & (-16777216)) | ((bArr[1] << 16) & 16711680) | ((bArr[2] << 8) & 65280) | (bArr[3] & 255)) * 1000;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:54:? A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String parseDeviceName(byte[] r5) {
        /*
            Method dump skipped, instructions count: 265
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.uitl.ByteUtil.parseDeviceName(byte[]):java.lang.String");
    }

    public static String byteToHexString(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bArr) {
            String hexString = Integer.toHexString(b & 255);
            if (hexString.length() == 1) {
                sb.append(0).append(hexString + ":");
            } else {
                sb.append(hexString + ":");
            }
        }
        return sb.toString().substring(0, sb.toString().length() - 1);
    }

    public static String byte2hex(byte[] bArr) {
        String str = "";
        if (bArr == null) {
            return "null";
        }
        for (int i = 0; i < bArr.length; i++) {
            if (i == 5 && bArr[0] == 0) {
                Logger.e("CEBC", "Data5-check=" + a.a(bArr[i] & 255));
            }
            String hexString = Integer.toHexString(bArr[i] & 255);
            String str2 = hexString;
            if (hexString.length() == 1) {
                str2 = "0" + str2;
            }
            str = str + " " + str2;
        }
        return str;
    }

    public static String truncateString(String str, int i) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        str.getBytes(StandardCharsets.UTF_8);
        if (str.getBytes(StandardCharsets.UTF_8).length <= i) {
            return str;
        }
        byte[] bArr = new byte[i];
        System.arraycopy(str.getBytes(), 0, bArr, 0, i);
        return new String(bArr) + "...";
    }
}
