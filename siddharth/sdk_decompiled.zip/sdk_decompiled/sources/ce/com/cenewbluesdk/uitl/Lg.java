package ce.com.cenewbluesdk.uitl;

import android.content.Context;
import android.util.Log;
import ce.com.cenewbluesdk.uitl.fileprint.FileLogPrint;
import ce.com.cenewbluesdk.uitl.fileprint.PRINT_PARAMS;
import java.io.IOException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/Lg.class */
public class Lg {
    public static boolean DEBUG = true;
    private static int LOG_MAXLENGTH = 2000;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/Lg$a.class */
    static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f46a;

        static {
            int[] iArr = new int[b.values().length];
            f46a = iArr;
            try {
                iArr[b.e.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f46a[b.w.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f46a[b.d.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f46a[b.i.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f46a[b.v.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/Lg$b.class */
    private enum b {
        e,
        w,
        d,
        i,
        v
    }

    public static void v(String str, Object obj) {
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog(str, obj + "", b.v, autoJumpLogInfos);
        }
    }

    public static void i(String str, Object obj) {
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog(str, obj + "", b.i, autoJumpLogInfos);
        }
    }

    public static void d(String str, Object obj) {
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog(str, obj + "", b.d, autoJumpLogInfos);
        }
    }

    public static void e(String str, Object obj) throws IOException {
        pFile(str, obj + "");
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog(str, obj + "", b.e, autoJumpLogInfos);
        }
    }

    public static void ee(Object obj) throws IOException {
        myPfile("long", obj + "");
        longLog("CE_BLUE", obj + "", b.e, getAutoJumpLogInfos());
    }

    public static void e(Object obj) {
        if (DEBUG) {
            pFile("long", obj + "");
            longLog("CE_BLUE", obj + "", b.e, getAutoJumpLogInfos());
        }
    }

    public static void e(String str, Object obj, boolean z) throws IOException {
        Logger.e(str, (String) obj);
        if (z) {
            printFile(str, obj + "");
        }
    }

    public static void e_file(String str, Object obj, String str2, boolean z) throws IOException {
        if (z) {
            printFile(str, obj + "", str2);
        }
    }

    public static void e_file(Context context, String str, Object obj, String str2, boolean z) throws IOException {
        if (z) {
            printFile(context, str, obj + "", str2);
        }
    }

    private static void myPfile(String str, Object obj) throws IOException {
        FileLogPrint.ee(str, obj + "");
    }

    private static void pFile(String str, Object obj) throws IOException {
        if (PRINT_PARAMS.MYLOG_SWITCH.booleanValue()) {
            FileLogPrint.e(str, obj + "");
        }
    }

    private static void printFile(String str, Object obj) throws IOException {
        FileLogPrint.writeLogToFile(String.valueOf('e'), str, obj + "");
    }

    private static void printFile(String str, Object obj, String str2) throws IOException {
        FileLogPrint.writeLogToFile(String.valueOf('e'), str, obj + "", str2);
    }

    private static void printFile(Context context, String str, Object obj, String str2) throws IOException {
        FileLogPrint.writeLogToFile(context, String.valueOf('e'), str, obj + "", str2);
    }

    public static void v(Object obj) {
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog("CE_BLUE", obj + "", b.v, autoJumpLogInfos);
        }
    }

    public static void i(Object obj) {
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog("CE_BLUE", obj + "", b.i, autoJumpLogInfos);
        }
    }

    public static void d(Object obj) {
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog("CE_BLUE", obj + "", b.d, autoJumpLogInfos);
        }
    }

    public static void w(Object obj) {
        String[] autoJumpLogInfos = getAutoJumpLogInfos();
        if (DEBUG) {
            longLog("CE_BLUE", obj + "", b.w, autoJumpLogInfos);
        }
    }

    private static String[] getAutoJumpLogInfos() {
        String[] strArr = {"", "", ""};
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        if (stackTrace.length < 5) {
            Log.e("log", "Stack is too shallow!!!");
            return strArr;
        }
        strArr[0] = stackTrace[4].getClassName().substring(stackTrace[4].getClassName().lastIndexOf(".") + 1);
        strArr[1] = stackTrace[4].getMethodName() + "";
        strArr[2] = stackTrace[4].getLineNumber() + "";
        return strArr;
    }

    public static void longLog(String str, String str2, b bVar, String[] strArr) {
        int length = str2.length();
        int i = 0;
        int i2 = LOG_MAXLENGTH;
        int i3 = 0;
        while (i3 < 100) {
            if (length <= i2) {
                switch (a.f46a[bVar.ordinal()]) {
                    case 1:
                        Log.e(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, length));
                        break;
                    case 2:
                        Log.w(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, length));
                        break;
                    case 3:
                        Log.d(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, length));
                        break;
                    case 4:
                        Log.i(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, length));
                        break;
                    case 5:
                        Log.v(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, length));
                        break;
                }
                return;
            }
            switch (a.f46a[bVar.ordinal()]) {
                case 1:
                    Log.e(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, i2));
                    break;
                case 2:
                    Log.w(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, i2));
                    break;
                case 3:
                    Log.d(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, i2));
                    break;
                case 4:
                    Log.i(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, i2));
                    break;
                case 5:
                    Log.v(str, "|* " + strArr[0] + " line:" + strArr[2] + " *| " + str2.substring(i, i2));
                    break;
            }
            i3++;
            i = i2;
            i2 += LOG_MAXLENGTH;
        }
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception, java.lang.String] */
    public static String getClassName(Object obj) {
        ?? simpleName;
        try {
            simpleName = obj.getClass().getSimpleName();
            return simpleName;
        } catch (Exception unused) {
            simpleName.printStackTrace();
            return "unknown";
        }
    }
}
