package ce.com.cenewbluesdk.uitl;

import android.text.TextUtils;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/h.class */
public class h {

    /* renamed from: a, reason: collision with root package name */
    public static final String[] f54a = {b.f56a};
    public static final String[] b = {a.f55a};

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/h$a.class */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public static String f55a = "M25SP";
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/h$b.class */
    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public static String f56a = "wave lite";
    }

    public static boolean b(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        for (String str2 : f54a) {
            if (str2.equalsIgnoreCase(str)) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:54:? A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a(byte[] r5) {
        /*
            Method dump skipped, instructions count: 265
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.uitl.h.a(byte[]):java.lang.String");
    }

    public static boolean a(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        for (String str2 : b) {
            if (str2.equalsIgnoreCase(str)) {
                return true;
            }
        }
        return false;
    }
}
