package ce.com.cenewbluesdk.uitl.fileprint;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Environment;
import android.os.Process;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/fileprint/PRINT_PARAMS.class */
public class PRINT_PARAMS {
    public static boolean USE_BLUE_LOCAL_PRINT = false;
    public static boolean SENDDATA_PRINT = false;
    public static final boolean CRASH_SWITH = true;
    public static Boolean MYLOG_SWITCH;
    public static Boolean MYLOG_WRITE_TO_FILE;
    public static String sdcardPath;
    public static String CRASH_PATH;
    private static SimpleDateFormat myLogSdf;
    public static String GPSLOG_PATH;
    public static String LOG_PATH;
    public static String LOG_PATH_TESTBLUETOOTHSLEEPDATA;
    public static String LOG_PATH_TESTBLUETOOTHECGDATA;
    public static boolean USE_BLUE_LOCAL_PRINT_FOR_ECG;

    public static String getCurProcessName(Context context) throws SecurityException {
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = activityManager.getRunningAppProcesses();
        int iMyPid = Process.myPid();
        if (runningAppProcesses != null) {
            for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
                if (runningAppProcessInfo.pid == iMyPid) {
                    return runningAppProcessInfo.processName;
                }
            }
        }
        List<ActivityManager.RunningServiceInfo> runningServices = activityManager.getRunningServices(Integer.MAX_VALUE);
        if (runningServices == null) {
            return "";
        }
        for (ActivityManager.RunningServiceInfo runningServiceInfo : runningServices) {
            if (runningServiceInfo.pid == iMyPid) {
                return runningServiceInfo.process;
            }
        }
        return "";
    }

    public static void init(Context context) {
        String str = "/" + getCurProcessName(context) + "/";
        CRASH_PATH += str;
        LOG_PATH += str + "/" + myLogSdf.format(new Date()) + "-";
        CrashHandler.getInstance().init(context);
        MYLOG_SWITCH = Boolean.FALSE;
        MYLOG_WRITE_TO_FILE = Boolean.TRUE;
        FileLogPrint.init();
    }

    public static void initBlueToothTest(Context context) {
        LOG_PATH_TESTBLUETOOTHSLEEPDATA += "testdata";
        USE_BLUE_LOCAL_PRINT = true;
        FileLogPrint.init();
    }

    public static void initECGGeneraTest() {
        LOG_PATH_TESTBLUETOOTHECGDATA += "testdata";
        USE_BLUE_LOCAL_PRINT_FOR_ECG = true;
        FileLogPrint.init();
    }

    static {
        Boolean bool = Boolean.TRUE;
        MYLOG_SWITCH = bool;
        MYLOG_WRITE_TO_FILE = bool;
        sdcardPath = Environment.getExternalStorageDirectory().getPath();
        CRASH_PATH = sdcardPath + "/CoolWear/crash/";
        myLogSdf = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss");
        LOG_PATH = sdcardPath + "/CoolWear/log/";
        LOG_PATH_TESTBLUETOOTHSLEEPDATA = sdcardPath + "/CoolWear/log/sleep/";
        LOG_PATH_TESTBLUETOOTHECGDATA = sdcardPath + "/CoolWear/log/ecg/";
        USE_BLUE_LOCAL_PRINT_FOR_ECG = false;
    }
}
