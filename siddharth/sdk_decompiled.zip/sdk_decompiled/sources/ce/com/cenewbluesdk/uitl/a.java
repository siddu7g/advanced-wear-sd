package ce.com.cenewbluesdk.uitl;

import ce.com.cenewbluesdk.CEBC;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/a.class */
public class a {
    public static String a(int i) {
        switch (i) {
            case 2:
                return "设备信息:2";
            case 3:
                return "电量:3";
            case 4:
                return "实时运动数据:4";
            case 5:
                return "历史运动数据：5";
            case 6:
                return "6";
            case 7:
                return "实时心率:7";
            case 8:
                return "8";
            case 9:
                return "同步数据：9";
            case 10:
                return "10";
            case 11:
                return "找设备:11";
            case 12:
                return "12";
            case 13:
                return "用户切换:13";
            case 14:
                return "14";
            case 15:
                return "电话控制:15";
            case 16:
                return "16";
            case 17:
                return "17";
            case 18:
                return "血压:18";
            case 19:
                return "19";
            case 20:
                return "20";
            case 21:
                return "停止测试心率血压血氧:21";
            case 22:
                return "功能控制:22";
            case 23:
                return "硬件信息:23";
            case 24:
                return "心率:24";
            case 25:
                return "通话蓝牙地址:25";
            default:
                switch (i) {
                    case 60:
                        return "60";
                    case 61:
                        return "61";
                    case 62:
                        return "62";
                    case 63:
                        return "63";
                    case 64:
                        return "64";
                    default:
                        switch (i) {
                            case 66:
                                return "66";
                            case 67:
                                return "67";
                            case 68:
                                return "68";
                            case 69:
                                return "69";
                            case 70:
                                return "70";
                            case 71:
                                return "71";
                            case 72:
                                return "72";
                            case 73:
                                return "73";
                            default:
                                switch (i) {
                                    case 102:
                                        return "102";
                                    case 103:
                                        return "语言:103";
                                    case 104:
                                        return "时间格式:104";
                                    case 105:
                                        return "天气：105";
                                    case 106:
                                        return "闹钟信息:106";
                                    case 107:
                                        return "推送信息:107";
                                    case 108:
                                        return "108";
                                    case 109:
                                        return "发送开启状态：109";
                                    case 110:
                                        return "混杂数据：110";
                                    case 111:
                                        return "111";
                                    case 112:
                                        return "112";
                                    case 113:
                                        return "音乐控制：113";
                                    case 114:
                                        return "久坐提醒:114";
                                    case 115:
                                        return "勿扰:115";
                                    case 116:
                                        return "智拍：116";
                                    case 117:
                                        return "117";
                                    case 118:
                                        return "118";
                                    case 119:
                                        return "119";
                                    case 120:
                                        return "120";
                                    case 121:
                                        return "单位:121";
                                    case 122:
                                        return "来电提醒:122";
                                    case 123:
                                        return "短信提醒:123";
                                    case 124:
                                        return "表盘设置信息:124";
                                    case 125:
                                        return "达标提醒:125";
                                    case 126:
                                        return "喝水提醒:126";
                                    case 127:
                                        return "抬腕亮屏:127";
                                    case 128:
                                        return "自动心率检测开关:128";
                                    case 129:
                                        return "129";
                                    case 130:
                                        return "App运动：130";
                                    case 131:
                                        return "表盘同步:131";
                                    case 132:
                                        return "表盘信息:132";
                                    case 133:
                                        return "生理周期提醒:133";
                                    case 134:
                                        return "134";
                                    case 135:
                                        return "135";
                                    case 136:
                                        return "136";
                                    case 137:
                                        return "137";
                                    case 138:
                                        return "138";
                                    case 139:
                                        return "实时天气:139";
                                    default:
                                        switch (i) {
                                            case 143:
                                                return "体感开关:143";
                                            case 144:
                                                return "体感Sensor数据:144";
                                            case 145:
                                                return "AI问答:145";
                                            case CEBC.K6.DATA_TYPE_AI_TR_CMD /* 146 */:
                                                return "AI翻译:146";
                                            case CEBC.K6.DATA_TYPE_AI_WATCHFACE_CMD /* 147 */:
                                                return "AI表盘:147";
                                            case CEBC.K6.DATA_TYPE_AI_CTRL_CMD /* 148 */:
                                                return "AI遥控:148";
                                            case CEBC.K6.DATA_TYPE_MAP_NAVIGATION_CMD /* 149 */:
                                                return "地图导航:149";
                                            default:
                                                switch (i) {
                                                    case CEBC.K6.DATA_TYPE_OTA_STATUS /* 201 */:
                                                        return "201";
                                                    case CEBC.K6.DATA_TYPE_OTA_DATA /* 202 */:
                                                        return "202";
                                                    case CEBC.K6.DATA_TYPE_TEST_DEBUG /* 203 */:
                                                        return "203";
                                                    default:
                                                        return "未知" + i;
                                                }
                                        }
                                }
                        }
                }
        }
    }
}
