package ce.com.cenewbluesdk.uitl;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.os.Build;
import android.os.LocaleList;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.app.ActivityCompat;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/BleSystemUtils.class */
public class BleSystemUtils {
    public static final String ROM_MIUI = "MIUI";
    public static final String ROM_EMUI = "EMUI";
    public static final String ROM_FLYME = "FLYME";
    public static final String ROM_OPPO = "OPPO";
    public static final String ROM_SMARTISAN = "SMARTISAN";
    public static final String ROM_VIVO = "VIVO";
    public static final String ROM_QIKU = "QIKU";
    public static final String ROM_SAMSUNG = "SAMSUNG";
    private static final String KEY_VERSION_MIUI = "ro.miui.ui.version.name";
    private static final String KEY_VERSION_EMUI = "ro.build.version.emui";
    private static final String KEY_VERSION_OPPO = "ro.build.version.opporom";
    private static final String KEY_VERSION_SMARTISAN = "ro.smartisan.version";
    private static final String KEY_VERSION_VIVO = "ro.vivo.os.version";
    private static String sName;
    private static String sVersion;
    static StringBuffer stringBuffer = new StringBuffer();

    /* JADX WARN: Not initialized variable reg: 0, insn: 0x001a: INVOKE (r0 I:java.lang.Exception) VIRTUAL call: java.lang.Exception.printStackTrace():void A[MD:():void (c)], block:B:8:0x001a */
    public static String getCountry() {
        Exception excPrintStackTrace;
        try {
            return Build.VERSION.SDK_INT >= 24 ? LocaleList.getDefault().get(0).getCountry() : Locale.getDefault().getCountry();
        } catch (Exception unused) {
            excPrintStackTrace.printStackTrace();
            return "";
        }
    }

    public static int getSystemLanguageStatus() {
        String language;
        String country;
        if (Build.VERSION.SDK_INT >= 24) {
            LocaleList localeList = LocaleList.getDefault();
            language = localeList.get(0).getLanguage();
            country = localeList.get(0).getCountry();
        } else {
            language = Locale.getDefault().getLanguage();
            country = Locale.getDefault().getCountry();
        }
        String string = Locale.getDefault().toString();
        Log.d("kun", "language=" + language + " country=" + country + " local=" + string);
        if (language.contains("zh")) {
            return string.contains("Hant") ? 10 : 1;
        }
        if (language.contains("es")) {
            return 2;
        }
        if (language.contains("it")) {
            return 3;
        }
        if (language.contains("pt")) {
            return 4;
        }
        if (language.contains("fr")) {
            return 5;
        }
        if (language.contains("ja")) {
            return 6;
        }
        if (language.contains("ru")) {
            return 7;
        }
        if (language.contains("ko")) {
            return 8;
        }
        if (language.contains("de")) {
            return 9;
        }
        if (language.contains("ar")) {
            return 11;
        }
        if (language.contains("in")) {
            return 12;
        }
        if (language.contains("tr")) {
            return 13;
        }
        if (language.contains("uk")) {
            return 14;
        }
        if (language.contains("iw")) {
            return 15;
        }
        if (language.contains("pl")) {
            return 16;
        }
        if (language.contains("hi")) {
            return 17;
        }
        if (language.contains("hr")) {
            return 18;
        }
        if (language.contains("el")) {
            return 19;
        }
        if (language.contains("th")) {
            return 20;
        }
        if (language.contains("vi")) {
            return 21;
        }
        if (language.contains("fa")) {
            return 22;
        }
        if (language.contains("nl")) {
            return 23;
        }
        if (language.contains("ro")) {
            return 24;
        }
        if (language.contains("gl")) {
            return 25;
        }
        if (language.contains("eu")) {
            return 26;
        }
        if (language.contains("ca")) {
            return 27;
        }
        if (language.contains("da")) {
            return 28;
        }
        if (language.contains("sv")) {
            return 29;
        }
        if (language.contains("nb")) {
            return 30;
        }
        if (language.contains("ur")) {
            return 31;
        }
        if (language.contains("bn")) {
            return 32;
        }
        if (language.contains("ms")) {
            return 33;
        }
        if (language.contains("ms")) {
            return 34;
        }
        if (language.contains("ms") || language.contains("ms") || language.contains("ms") || language.contains("ms")) {
            return 33;
        }
        if (language.contains("sk")) {
            return 39;
        }
        if (language.contains("cs")) {
            return 40;
        }
        if (language.contains("hu")) {
            return 41;
        }
        return language.contains("my") ? 42 : 0;
    }

    public static String getSystemLanguageStr() {
        String language;
        String country;
        if (Build.VERSION.SDK_INT >= 24) {
            LocaleList localeList = LocaleList.getDefault();
            language = localeList.get(0).getLanguage();
            country = localeList.get(0).getCountry();
        } else {
            language = Locale.getDefault().getLanguage();
            country = Locale.getDefault().getCountry();
        }
        String str = language;
        Log.d("kun", "language=" + language + " country=" + country + " local=" + Locale.getDefault().toString());
        return str;
    }

    public static boolean isChinese() {
        int systemLanguageStatus = getSystemLanguageStatus();
        return systemLanguageStatus == 1 || systemLanguageStatus == 10;
    }

    public static boolean isEmui() {
        return check(ROM_EMUI);
    }

    public static boolean isMiui() {
        return check(ROM_MIUI);
    }

    public static boolean isVivo() {
        return check(ROM_VIVO);
    }

    public static boolean isOppo() {
        return check(ROM_OPPO);
    }

    public static boolean isFlyme() {
        return check(ROM_FLYME);
    }

    public static boolean is360() {
        return check(ROM_QIKU) || check("360");
    }

    public static boolean isSmartisan() {
        return check(ROM_SMARTISAN);
    }

    public static boolean isSAMSUNG() {
        return check(ROM_SAMSUNG);
    }

    public static String getName() throws Throwable {
        if (sName == null) {
            check("");
        }
        return sName;
    }

    public static String getVersion() throws Throwable {
        if (sVersion == null) {
            check("");
        }
        return sVersion;
    }

    public static boolean check(String str) throws Throwable {
        String str2 = sName;
        if (str2 != null) {
            return str2.equals(str);
        }
        String prop = getProp(KEY_VERSION_MIUI);
        sVersion = prop;
        if (TextUtils.isEmpty(prop)) {
            String prop2 = getProp(KEY_VERSION_EMUI);
            sVersion = prop2;
            if (TextUtils.isEmpty(prop2)) {
                String prop3 = getProp(KEY_VERSION_OPPO);
                sVersion = prop3;
                if (TextUtils.isEmpty(prop3)) {
                    String prop4 = getProp(KEY_VERSION_VIVO);
                    sVersion = prop4;
                    if (TextUtils.isEmpty(prop4)) {
                        String prop5 = getProp(KEY_VERSION_SMARTISAN);
                        sVersion = prop5;
                        if (TextUtils.isEmpty(prop5)) {
                            String str3 = Build.DISPLAY;
                            sVersion = str3;
                            if (str3.toUpperCase().contains(ROM_FLYME)) {
                                sName = ROM_FLYME;
                            } else {
                                sVersion = "unknown";
                                sName = Build.MANUFACTURER.toUpperCase();
                            }
                        } else {
                            sName = ROM_SMARTISAN;
                        }
                    } else {
                        sName = ROM_VIVO;
                    }
                } else {
                    sName = ROM_OPPO;
                }
            } else {
                sName = ROM_EMUI;
            }
        } else {
            sName = ROM_MIUI;
        }
        return sName.equals(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.io.BufferedReader, java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.io.BufferedReader] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.io.BufferedReader] */
    public static String getProp(String str) throws Throwable {
        boolean z;
        ?? bufferedReader;
        try {
            z = bufferedReader;
            bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("getprop " + str).getInputStream()), 1024);
            try {
                String line = bufferedReader.readLine();
                bufferedReader.close();
                try {
                    bufferedReader.close();
                } catch (IOException unused) {
                    bufferedReader.printStackTrace();
                }
                return line;
            } catch (IOException unused2) {
                ?? r0 = z;
                if (r0 != 0) {
                    try {
                        r0 = z;
                        r0.close();
                    } catch (IOException unused3) {
                        r0.printStackTrace();
                    }
                }
                return null;
            } catch (Throwable th) {
                th = th;
                ?? r02 = z;
                if (r02 != 0) {
                    try {
                        r02 = z;
                        r02.close();
                    } catch (IOException unused4) {
                        r02.printStackTrace();
                    }
                }
                throw th;
            }
        } catch (IOException unused5) {
            z = false;
        } catch (Throwable th2) {
            th = th2;
            z = false;
        }
    }

    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception, java.lang.String] */
    public static String noContainsEmoji(String str) {
        ?? string;
        try {
            int length = str.length();
            stringBuffer.setLength(0);
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= length) {
                    string = stringBuffer.toString();
                    return string;
                }
                int i3 = i2 + 1;
                int i4 = i3;
                String strSubstring = str.substring(i2, i3);
                if (isEmojiCharacter(strSubstring.charAt(0))) {
                    stringBuffer.append("[Emoji]");
                } else {
                    stringBuffer.append(strSubstring);
                    i4 = i2;
                }
                i = i4 + 1;
            }
        } catch (Exception unused) {
            string.printStackTrace();
            return "";
        }
    }

    public static boolean isEmojiCharacter(char c) {
        return (c == 0 || c == '\t' || c == '\n' || c == '\r' || (c >= ' ' && c <= 55295) || ((c >= 57344 && c <= 65533) || (c >= 0 && c <= 65535))) ? false : true;
    }

    public static BluetoothAdapter getBluetoothAdapter(Context context) {
        return Build.VERSION.SDK_INT >= 31 ? ((BluetoothManager) context.getSystemService("bluetooth")).getAdapter() : BluetoothAdapter.getDefaultAdapter();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    public static boolean isBlePermission(Context context) {
        ?? CheckSelfPermission = Build.VERSION.SDK_INT;
        if (CheckSelfPermission < 31) {
            return true;
        }
        try {
            if (ActivityCompat.checkSelfPermission(context, "android.permission.BLUETOOTH_CONNECT") != 0) {
                return false;
            }
            CheckSelfPermission = ActivityCompat.checkSelfPermission(context, "android.permission.BLUETOOTH_SCAN");
            return CheckSelfPermission == 0;
        } catch (Exception unused) {
            CheckSelfPermission.printStackTrace();
            return true;
        }
    }
}
