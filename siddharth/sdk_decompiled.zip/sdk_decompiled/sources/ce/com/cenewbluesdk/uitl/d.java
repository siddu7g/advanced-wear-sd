package ce.com.cenewbluesdk.uitl;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/d.class */
public class d {

    /* renamed from: a, reason: collision with root package name */
    private byte[] f53a;
    private int b;

    public d(byte[] bArr) {
        this(bArr, 0);
    }

    public d(byte[] bArr, int i) {
        this.f53a = bArr;
        this.b = i;
    }

    public int a() {
        return this.b;
    }

    public void e(int i) {
        this.b = i;
    }

    public void a(int i) {
        this.b += i;
    }

    public int c(int i) {
        if (i < 1 && i > 4) {
            throw new RuntimeException("length取值只可为1, 2, 3, 4, length=" + i);
        }
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            i2 += (this.f53a[this.b + i3] & 255) << (i3 * 8);
        }
        int i4 = i2;
        a(i);
        return i4;
    }

    public byte[] b(int i) {
        byte[] bArr = new byte[i];
        System.arraycopy(this.f53a, this.b, bArr, 0, i);
        a(i);
        return bArr;
    }

    public String d(int i) {
        String str = new String(this.f53a, this.b, i);
        a(i);
        return str;
    }
}
