package ce.com.cenewbluesdk.uitl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/TimeUtil.class */
public class TimeUtil {
    public static final long ONE_HOUR_MS = 3600000;
    public static final long ONE_DAY_MS = 86400000;
    public static final long ONE_WEEK_MS = 604800000;
    public static final String TEMPLATE_DATETIME = "yyyy-MM-dd HH:mm:ss";
    public static final String TEMPLATE_DATE = "yyyy-MM-dd";
    public static final String TEMPLATE_TIME = "HH:mm:ss";
    public static final String TEMPLATE_SIMPLE_TIME = "yyyy-MM-dd HH:mm";
    public static final String TEMPLATE_DATETIME_MS = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String TEMPLATE_HH_MM = "HH:mm";
    public static final int SLEEP_TIME_OFFSET = 14400000;

    public static String getNowString() {
        return getNowString("yyyy-MM-dd HH:mm:ss");
    }

    public static String getNowString(String str) {
        return date2String(new Date(now()), str);
    }

    public static long getNowLongDaySleepTimeStart() {
        return getNowLongDayStart() - 14400000;
    }

    public static long getNowLongDayStart() {
        return long2longDayStart(now());
    }

    public static long getNowLongMonthStart() {
        return long2longMonthStart(now());
    }

    public static int[] getHourAndMin(int i) {
        return new int[]{i / 60, i % 60};
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.text.SimpleDateFormat] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.text.ParseException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.Date] */
    public static Date string2Date(String str, String str2) {
        ?? simpleDateFormat = new SimpleDateFormat(str2, Locale.getDefault());
        try {
            simpleDateFormat = simpleDateFormat.parse(str);
            return simpleDateFormat;
        } catch (ParseException unused) {
            simpleDateFormat.printStackTrace();
            return null;
        }
    }

    public static Date string2Date(String str) {
        return string2Date(str, "yyyy-MM-dd HH:mm:ss");
    }

    public static long string2Long(String str, String str2) {
        return string2Date(str, str2).getTime();
    }

    public static long string2Long(String str) {
        return string2Date(str).getTime();
    }

    public static int[] string2ymd(String str, String str2) {
        return date2ymd(string2Date(str, str2));
    }

    public static String date2String(Date date) {
        return date2String(date, "yyyy-MM-dd HH:mm:ss");
    }

    public static String date2String(Date date, String str) {
        return new SimpleDateFormat(str, Locale.getDefault()).format(date);
    }

    public static int[] date2ymd(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return c2ymd(calendar);
    }

    public static int[] c2ymd(Calendar calendar) {
        return new int[]{calendar.get(1), calendar.get(2), calendar.get(5)};
    }

    public static String long2String(long j, String str) {
        return date2String(new Date(j), str);
    }

    public static String long2String(long j) {
        return date2String(new Date(j));
    }

    public static Calendar long2C(long j) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(j);
        return calendar;
    }

    public static String ymd2String(int i, int i2, int i3, String str) {
        return date2String(ymd2Date(i, i2, i3), str);
    }

    public static String ymd2String(int i, int i2, int i3) {
        return date2String(ymd2Date(i, i2, i3));
    }

    private static Date c2DateNoHMS(Calendar calendar) {
        return c2CNoHMS(calendar).getTime();
    }

    public static Calendar c2CNoHMS(Calendar calendar) {
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
        calendar.set(14, 0);
        return calendar;
    }

    public static Calendar long2CNoHMS(long j) {
        return c2CNoHMS(long2C(j));
    }

    public static int[] s2hms(int i) {
        int i2 = i / 60;
        return new int[]{i2 / 60, i2 % 60, i % 60};
    }

    public static Date ymd2Date(int i, int i2, int i3) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(14, 0);
        calendar.set(i, i2, i3, 0, 0, 0);
        return calendar.getTime();
    }

    public static String ms2hhmmss(long j) {
        int i = (int) (j / 1000);
        int i2 = i % 60;
        int i3 = i / 60;
        return String.format("%02d:%02d:%02d", Integer.valueOf(i3 / 60), Integer.valueOf(i3 % 60), Integer.valueOf(i2));
    }

    public static int birthday2Age(String str) {
        int[] iArrString2ymd = string2ymd(str, "yyyy-MM-dd");
        int[] iArrC2ymd = c2ymd(Calendar.getInstance());
        return ((((iArrC2ymd[0] * 12) + iArrC2ymd[1]) + 1) - (((iArrString2ymd[0] * 12) + iArrString2ymd[1]) + 1)) / 12;
    }

    public static String age2Birthday(int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.get(1);
        calendar.add(1, -i);
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
        calendar.set(14, 0);
        return date2String(calendar.getTime(), "yyyy-MM-dd");
    }

    public static Calendar byte2C(byte[] bArr, boolean z) {
        return s2CForDev(ByteUtil.byte4ToInt(bArr), z);
    }

    public static Calendar s2CForDev(int i, boolean z) {
        long jRelativeTime2Timestamp = i * 1000;
        Calendar calendar = Calendar.getInstance();
        if (!z) {
            jRelativeTime2Timestamp = relativeTime2Timestamp(jRelativeTime2Timestamp, calendar.getTimeZone());
        }
        calendar.setTimeInMillis(jRelativeTime2Timestamp);
        return calendar;
    }

    public static long relativeTime2Timestamp(long j, TimeZone timeZone) {
        return timeZone.useDaylightTime() ? j - timeZone.getOffset(r1) : j - timeZone.getRawOffset();
    }

    public static long long2longDayStart(long j) {
        return long2CNoHMS(j).getTimeInMillis();
    }

    public static long long2longWeekStart(long j, int i) {
        return long2longWeekStart(j, null, i);
    }

    public static long long2longMonthStart(long j) {
        Calendar calendarLong2CNoHMS = long2CNoHMS(j);
        calendarLong2CNoHMS.set(5, 1);
        return calendarLong2CNoHMS.getTimeInMillis();
    }

    public static long long2longWeekStart(long j, TimeZone timeZone, int i) {
        Calendar calendarLong2C = long2C(j);
        if (timeZone != null) {
            calendarLong2C.setTimeZone(timeZone);
        }
        c2CNoHMS(calendarLong2C);
        if (i > 0) {
            calendarLong2C.setFirstDayOfWeek(i);
        }
        calendarLong2C.get(7);
        calendarLong2C.set(7, calendarLong2C.getFirstDayOfWeek());
        return calendarLong2C.getTimeInMillis();
    }

    public static long long2longGapStart(long j, long j2) {
        long jLong2longDayStart = long2longDayStart(j);
        return jLong2longDayStart + (((j - jLong2longDayStart) / j2) * j2);
    }

    public static long now() {
        return System.currentTimeMillis();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.text.SimpleDateFormat] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.text.ParseException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.Date] */
    public static long gmt2long(String str) {
        ?? simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        Date date = null;
        try {
            simpleDateFormat = simpleDateFormat.parse(str);
            date = simpleDateFormat;
        } catch (ParseException unused) {
            simpleDateFormat.printStackTrace();
        }
        return date.getTime();
    }

    public static String long2gmt(long j) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        return simpleDateFormat.format(new Date(j));
    }

    public static Calendar string2C(String str) {
        return string2C(str, "yyyy-MM-dd HH:mm:ss");
    }

    public static Calendar string2C(String str, String str2) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(string2Date(str, str2));
        return calendar;
    }

    public static String c2String(Calendar calendar) {
        return date2String(calendar.getTime(), "yyyy-MM-dd HH:mm:ss");
    }

    public static String c2String(Calendar calendar, String str) {
        return date2String(calendar.getTime(), str);
    }

    @Deprecated
    public static Calendar ymdhms2CForDev(byte b, byte b2, byte b3, byte b4, byte b5, byte b6) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(1, b + 2000);
        calendar.set(2, b2 - 1);
        calendar.set(5, b3);
        calendar.set(11, b4);
        calendar.set(12, b5);
        calendar.set(13, b6);
        calendar.set(14, 0);
        return calendar;
    }

    public static long getOneDaySleepTimeStart(long j) {
        return j - 14400000;
    }
}
