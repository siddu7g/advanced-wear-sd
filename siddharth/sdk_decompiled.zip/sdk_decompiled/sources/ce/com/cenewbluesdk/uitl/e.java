package ce.com.cenewbluesdk.uitl;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/e.class */
public class e {
    private e() {
    }

    public static int a(byte[] bArr) {
        if (bArr == null) {
            return 0;
        }
        int iA = 0;
        for (byte b : bArr) {
            iA = a(iA, b);
        }
        return iA & 65535;
    }

    public static int a(byte[] bArr, int i) {
        if (bArr == null) {
            return 0;
        }
        int iA = 0;
        while (i < bArr.length) {
            iA = a(iA, bArr[i]);
            i++;
        }
        return iA & 65535;
    }

    private static int a(int i, short s) {
        int i2;
        int i3 = 0;
        int i4 = i ^ (s << 8);
        do {
            int i5 = i4 & 32768;
            i4 <<= 1;
            if (i5 == 32768) {
                i4 ^= 32773;
            }
            i2 = i3 + 1;
            i3 = i2;
        } while (i2 < 8);
        return i4;
    }
}
