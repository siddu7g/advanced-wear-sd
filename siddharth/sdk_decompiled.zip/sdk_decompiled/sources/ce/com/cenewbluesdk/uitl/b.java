package ce.com.cenewbluesdk.uitl;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothDevice;
import java.lang.reflect.InvocationTargetException;

@TargetApi(19)
/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/b.class */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public static final int f51a = 3;
    public static final int b = 2;
    public static final int c = 0;

    /* JADX WARN: Type inference failed for: r0v3, types: [boolean, java.lang.Exception] */
    public static boolean c(BluetoothDevice bluetoothDevice) {
        ?? CreateBond;
        try {
            CreateBond = bluetoothDevice.createBond();
            return CreateBond;
        } catch (Exception unused) {
            CreateBond.printStackTrace();
            return false;
        }
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [boolean, java.lang.Exception] */
    public static boolean a(BluetoothDevice bluetoothDevice, byte[] bArr) {
        ?? pin;
        try {
            pin = bluetoothDevice.setPin(bArr);
            return pin;
        } catch (Exception unused) {
            pin.printStackTrace();
            return false;
        }
    }

    public static boolean a(BluetoothDevice bluetoothDevice, boolean z) {
        return false;
    }

    public static boolean d(BluetoothDevice bluetoothDevice) {
        return a(bluetoothDevice, "removeBond");
    }

    public static boolean b(BluetoothDevice bluetoothDevice) {
        return a(bluetoothDevice, "cancelPairingUserInput");
    }

    public static boolean a(BluetoothDevice bluetoothDevice) {
        return a(bluetoothDevice, "cancelBondProcess");
    }

    /* JADX WARN: Type inference failed for: r0v9, types: [boolean, java.lang.ReflectiveOperationException] */
    private static boolean a(BluetoothDevice bluetoothDevice, String str) {
        ?? BooleanValue;
        try {
            BooleanValue = ((Boolean) BluetoothDevice.class.getMethod(str, new Class[0]).invoke(bluetoothDevice, new Object[0])).booleanValue();
            return BooleanValue;
        } catch (IllegalAccessException unused) {
            BooleanValue.printStackTrace();
            return false;
        } catch (NoSuchMethodException unused2) {
            BooleanValue.printStackTrace();
            return false;
        } catch (InvocationTargetException unused3) {
            BooleanValue.printStackTrace();
            return false;
        }
    }
}
