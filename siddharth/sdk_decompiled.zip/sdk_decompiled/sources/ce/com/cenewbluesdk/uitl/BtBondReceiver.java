package ce.com.cenewbluesdk.uitl;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

@TargetApi(19)
/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/BtBondReceiver.class */
public abstract class BtBondReceiver extends BaseBroadcastReceiver {
    @Override // ce.com.cenewbluesdk.uitl.BaseBroadcastReceiver, android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        BluetoothDevice bluetoothDevice;
        String action = intent.getAction();
        if ("android.bluetooth.device.action.PAIRING_REQUEST".equals(action)) {
            BluetoothDevice bluetoothDevice2 = (BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE");
            int intExtra = intent.getIntExtra("android.bluetooth.device.extra.PAIRING_VARIANT", -1);
            int intExtra2 = intent.getIntExtra("android.bluetooth.device.extra.PAIRING_KEY", -1);
            if (bluetoothDevice2 == null) {
                return;
            }
            a(bluetoothDevice2, intExtra, intExtra2);
            Log.e("liu", "弹出匹配框  devMac:" + bluetoothDevice2.getAddress() + "   pairingVariant=" + intExtra + "   paringKey=" + intExtra2);
            return;
        }
        if (!"android.bluetooth.device.action.BOND_STATE_CHANGED".equals(action) || (bluetoothDevice = (BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE")) == null) {
            return;
        }
        int intExtra3 = intent.getIntExtra("android.bluetooth.device.extra.PREVIOUS_BOND_STATE", -1);
        int intExtra4 = intent.getIntExtra("android.bluetooth.device.extra.BOND_STATE", -1);
        Log.e("liu", "匹配状态改变  devMac:" + bluetoothDevice.getAddress() + "   pervState=" + intExtra3 + "   state=" + intExtra4);
        if (intExtra3 == 11 && intExtra4 == 12) {
            a(bluetoothDevice);
        } else if (intExtra3 == 12 && intExtra4 == 10) {
            b(bluetoothDevice);
        }
    }

    protected void b(BluetoothDevice bluetoothDevice) {
    }

    protected void a(BluetoothDevice bluetoothDevice) {
    }

    protected abstract void a(BluetoothDevice bluetoothDevice, int i, int i2);

    @Override // ce.com.cenewbluesdk.uitl.BaseBroadcastReceiver
    public IntentFilter createIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.device.action.PAIRING_REQUEST");
        intentFilter.addAction("android.bluetooth.device.action.BOND_STATE_CHANGED");
        return intentFilter;
    }
}
