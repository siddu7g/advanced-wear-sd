package ce.com.cenewbluesdk.uitl;

import android.text.TextUtils;
import ce.com.cenewbluesdk.entity.BaseBean;
import com.google.gson.Gson;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/JsonUtil.class */
public class JsonUtil {
    public static Gson gson = new Gson();

    /* JADX WARN: Type inference failed for: r0v5, types: [ce.com.cenewbluesdk.entity.BaseBean, ce.com.cenewbluesdk.entity.BaseBean<T>, java.lang.Exception] */
    public static <T> BaseBean<T> fromJsonObject(String str, Class<T> cls) {
        ?? r0;
        try {
            BaseBean baseBean = (BaseBean) gson.fromJson(str, new i(BaseBean.class, new Class[]{cls}));
            r0 = (BaseBean<T>) baseBean;
            return r0;
        } catch (Exception unused) {
            r0.printStackTrace();
            return null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.CharSequence] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Error] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Object] */
    public static <T> T jsonToBean(String str, Class<T> cls) {
        ?? FromJson = str;
        T t = null;
        try {
            if (!TextUtils.isEmpty(FromJson)) {
                FromJson = gson.fromJson(str, cls);
                t = FromJson;
            }
        } catch (Error unused) {
            FromJson.printStackTrace();
        } catch (Exception unused2) {
            FromJson.printStackTrace();
        }
        return t;
    }

    public static String beanToJson(Object obj) {
        return gson.toJson(obj);
    }
}
