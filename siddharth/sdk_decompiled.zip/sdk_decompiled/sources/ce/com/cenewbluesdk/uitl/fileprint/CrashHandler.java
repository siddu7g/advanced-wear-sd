package ce.com.cenewbluesdk.uitl.fileprint;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/fileprint/CrashHandler.class */
public class CrashHandler implements Thread.UncaughtExceptionHandler {
    private static final String TAG = "CrashHandler";
    private static final String uploadUrl = "http://3.saymagic.sinaapp.com/ReceiveCrash.php";
    private static String localFileUrl = "";
    private static CrashHandler instance = new CrashHandler();
    private Thread.UncaughtExceptionHandler defaultHandler;
    private Map<String, String> infos = new HashMap();
    private DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private Context context;

    private CrashHandler() {
    }

    public static CrashHandler getInstance() {
        if (instance == null) {
            instance = new CrashHandler();
        }
        return instance;
    }

    private boolean handleException(Throwable th) throws PackageManager.NameNotFoundException {
        if (th == null) {
            return false;
        }
        Log.d("TAG", "收到崩溃");
        collectDeviceInfo(this.context);
        writeCrashInfoToFile(th);
        return true;
    }

    private void writeCrashInfoToFile(Throwable th) {
        StringBuffer stringBuffer = new StringBuffer();
        for (Map.Entry<String, String> entry : this.infos.entrySet()) {
            stringBuffer.append(entry.getKey() + "=" + entry.getValue() + "\n");
        }
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        th.printStackTrace(printWriter);
        Throwable cause = th.getCause();
        while (true) {
            Throwable th2 = cause;
            if (th2 == null) {
                break;
            }
            th2.printStackTrace(printWriter);
            cause = th2.getCause();
        }
        printWriter.close();
        stringBuffer.append(stringWriter.toString());
        if (Environment.getExternalStorageState().equals("mounted")) {
            Environment.getExternalStorageDirectory().getPath();
            localFileUrl = writeLog(stringBuffer.toString(), PRINT_PARAMS.CRASH_PATH);
        }
    }

    private String writeLog(String str, String str2) throws IOException {
        String str3 = str2 + ((Object) new Date().toString().replace(" ", "")) + ".log";
        File file = new File(str3);
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        try {
            Log.d("TAG", "写入到SD卡里面");
            file.createNewFile();
            FileWriter fileWriter = new FileWriter(file, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(str);
            bufferedWriter.newLine();
            bufferedWriter.close();
            fileWriter.close();
            return str3;
        } catch (IOException e) {
            Log.e(TAG, "an error occured while writing file...", e);
            e.printStackTrace();
            return null;
        }
    }

    public void init(Context context) {
        this.context = context;
        this.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    @Override // java.lang.Thread.UncaughtExceptionHandler
    public void uncaughtException(Thread thread, Throwable th) throws PackageManager.NameNotFoundException {
        handleException(th);
        this.defaultHandler.uncaughtException(thread, th);
    }

    public void collectDeviceInfo(Context context) throws PackageManager.NameNotFoundException {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 1);
            if (packageInfo != null) {
                String str = packageInfo.versionName;
                String str2 = str;
                if (str == null) {
                    str2 = "null";
                }
                String str3 = packageInfo.versionCode + "";
                this.infos.put("versionName", str2);
                this.infos.put("versionCode", str3);
                this.infos.put("crashTime", this.formatter.format(new Date()));
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "an error occured when collect package info", e);
        }
        for (Field field : Build.class.getDeclaredFields()) {
            try {
                field.setAccessible(true);
                this.infos.put(field.getName(), field.get(null).toString());
                Log.d(TAG, field.getName() + " : " + field.get(null));
            } catch (Exception e2) {
                Log.e(TAG, "an error occured when collect crash info", e2);
            }
        }
    }
}
