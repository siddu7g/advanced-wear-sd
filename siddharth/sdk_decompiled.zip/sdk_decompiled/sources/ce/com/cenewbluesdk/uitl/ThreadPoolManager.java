package ce.com.cenewbluesdk.uitl;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/ThreadPoolManager.class */
public class ThreadPoolManager {
    private static ExecutorService THREAD_POOL_EXECUTOR;
    private static final int CPU_COUNT;
    private static final int CORE_POOL_SIZE;
    private static final int MAXIMUM_POOL_SIZE;
    private static final int KEEP_ALIVE_SECONDS = 60;
    private static final BlockingQueue<Runnable> sPoolWorkQueue;
    private static final ThreadFactory sThreadFactory;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/ThreadPoolManager$a.class */
    class a implements ThreadFactory {

        /* renamed from: a, reason: collision with root package name */
        private final AtomicInteger f48a = new AtomicInteger(1);

        a() {
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "MangoTask #" + this.f48a.getAndIncrement());
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/ThreadPoolManager$b.class */
    class b extends ThreadPoolExecutor {
        b(int i, int i2, long j, TimeUnit timeUnit, BlockingQueue blockingQueue, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler) {
            super(i, i2, j, timeUnit, blockingQueue, threadFactory, rejectedExecutionHandler);
        }

        @Override // java.util.concurrent.ThreadPoolExecutor, java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            super.execute(runnable);
            Logger.e("ActiveCount=" + getActiveCount());
            Logger.e("PoolSize=" + getPoolSize());
            Logger.e("Queue=" + getQueue().size());
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/ThreadPoolManager$c.class */
    private static class c {

        /* renamed from: a, reason: collision with root package name */
        private static final ThreadPoolManager f50a = new ThreadPoolManager(null);

        private c() {
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/uitl/ThreadPoolManager$d.class */
    private static class d implements RejectedExecutionHandler {
        private d() {
        }

        /* synthetic */ d(a aVar) {
            this();
        }

        @Override // java.util.concurrent.RejectedExecutionHandler
        public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
        }
    }

    private ThreadPoolManager() {
        initThreadPool();
    }

    private void initThreadPool() {
        THREAD_POOL_EXECUTOR = new b(CORE_POOL_SIZE, MAXIMUM_POOL_SIZE, 60L, TimeUnit.SECONDS, sPoolWorkQueue, sThreadFactory, new d(null));
    }

    public static ThreadPoolManager getInstance() {
        return c.f50a;
    }

    /* synthetic */ ThreadPoolManager(a aVar) {
        this();
    }

    static {
        int iAvailableProcessors = Runtime.getRuntime().availableProcessors();
        CPU_COUNT = iAvailableProcessors;
        CORE_POOL_SIZE = iAvailableProcessors;
        MAXIMUM_POOL_SIZE = iAvailableProcessors * 2;
        sPoolWorkQueue = new LinkedBlockingQueue(iAvailableProcessors);
        sThreadFactory = new a();
    }

    public void execute(Runnable runnable) {
        THREAD_POOL_EXECUTOR.execute(runnable);
    }
}
