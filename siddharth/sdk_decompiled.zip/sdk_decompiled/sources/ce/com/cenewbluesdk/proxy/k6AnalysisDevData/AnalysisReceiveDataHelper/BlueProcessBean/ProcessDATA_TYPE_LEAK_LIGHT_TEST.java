package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import android.text.TextUtils;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.k6_DATA_TYPE_LEAK_LIGHT_TEST_DATA;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_LEAK_LIGHT_TEST.class */
public final class ProcessDATA_TYPE_LEAK_LIGHT_TEST extends BaseK6AnalysiDevData {
    public ProcessDATA_TYPE_LEAK_LIGHT_TEST(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(CEBC.K6.DATA_TYPE_LEAKLIGHT_TEST);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_LEAK_LIGHT_TEST);
    }

    private String formatBelMac(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.setLength(0);
        for (int length = str.split(":").length - 1; length >= 0; length--) {
            sb.append(str.split(":")[length]).append(":");
        }
        return sb.substring(0, sb.length() - 1);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public k6_DATA_TYPE_LEAK_LIGHT_TEST_DATA realProcess(byte[] bArr) {
        k6_DATA_TYPE_LEAK_LIGHT_TEST_DATA k6_data_type_leak_light_test_data = new k6_DATA_TYPE_LEAK_LIGHT_TEST_DATA();
        int i = bArr[0] & 255;
        if (i == 0) {
            int iByte2ToInt2 = ByteUtil.byte2ToInt2(new byte[]{bArr[1], bArr[2], bArr[3], bArr[4]});
            int iByte2ToInt22 = ByteUtil.byte2ToInt2(new byte[]{bArr[5], bArr[6], bArr[7], bArr[8]});
            int iByte2ToInt23 = ByteUtil.byte2ToInt2(new byte[]{bArr[9], bArr[10], bArr[11], bArr[12]});
            k6_data_type_leak_light_test_data.setInfrared(iByte2ToInt2);
            k6_data_type_leak_light_test_data.setRedLight(iByte2ToInt22);
            k6_data_type_leak_light_test_data.setGreenLight(iByte2ToInt23);
        } else if (i == 1) {
            int iByte2ToInt24 = ByteUtil.byte2ToInt2(new byte[]{bArr[1], bArr[2], bArr[3], bArr[4]});
            int iByte2ToInt25 = ByteUtil.byte2ToInt2(new byte[]{bArr[5], bArr[6], bArr[7], bArr[8]});
            int iByte2ToInt26 = ByteUtil.byte2ToInt2(new byte[]{bArr[9], bArr[10], bArr[11], bArr[12]});
            k6_data_type_leak_light_test_data.setWearingThresholdHr(iByte2ToInt24);
            k6_data_type_leak_light_test_data.setWearingThresholdOb(iByte2ToInt25);
            k6_data_type_leak_light_test_data.setThresholdRelease(iByte2ToInt26);
        } else {
            int iByte2ToInt27 = ByteUtil.byte2ToInt2(new byte[]{bArr[1], bArr[2], bArr[3], bArr[4]});
            int iByte2ToInt28 = ByteUtil.byte2ToInt2(new byte[]{bArr[5], bArr[6], bArr[7], bArr[8]});
            k6_data_type_leak_light_test_data.setWearingThresholdOb(iByte2ToInt27);
            k6_data_type_leak_light_test_data.setThresholdRelease(iByte2ToInt28);
        }
        k6_data_type_leak_light_test_data.setLeakType(i);
        return k6_data_type_leak_light_test_data;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Object obj) {
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    protected boolean sendMsg(Object obj) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), 0));
        return false;
    }
}
