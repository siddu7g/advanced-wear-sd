package ce.com.cenewbluesdk.proxy;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.a.b;
import ce.com.cenewbluesdk.b.a;
import ce.com.cenewbluesdk.bluetooth.CEBlueTooth_5;
import ce.com.cenewbluesdk.entity.AllowWatchBean;
import ce.com.cenewbluesdk.entity.BaseBean;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_QR_CODE_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WATCH_FACE_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WATCH_FACE_START;
import ce.com.cenewbluesdk.entity.k6.K6_GpsArgument;
import ce.com.cenewbluesdk.entity.k6.K6_MessageNoticeStruct;
import ce.com.cenewbluesdk.entity.k6.K6_OTAStateInfo;
import ce.com.cenewbluesdk.fileTransmission.FileTransControl;
import ce.com.cenewbluesdk.ota.ota_modea.OtaK6Control;
import ce.com.cenewbluesdk.ota.ota_modea.OtaUtil;
import ce.com.cenewbluesdk.proxy.connectHelp.CEConnectManager;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.K6AnalysiDevRcvDataManager;
import ce.com.cenewbluesdk.proxy.k6AnalysisDevData.SendDataHelper.K6SendDataManager;
import ce.com.cenewbluesdk.proxy.sdkhelper.BluetoothHelper;
import ce.com.cenewbluesdk.queue.CEProtocolB;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.JsonUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import ce.com.cenewbluesdk.uitl.f;
import ce.com.cenewbluesdk.uitl.g;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDevK6Proxy.class */
public final class CEDevK6Proxy extends CEBluetoothProxyBase {
    public static final String UUID = "0000f618-0000-1000-8000-00805f9b34fb";
    public static final int devType = 1;
    private static final int PERIOD = 60000;
    private static int DELAY = 5000;
    private String devVersion;
    private K6_GpsArgument gpsArg;
    int gpsArgIndex;
    private OtaK6Control otaControl;
    private FileTransControl fileTransControl;
    private boolean isSpeedUp;
    K6AnalysiDevRcvDataManager mK6AnalysiDevManager;
    K6SendDataManager mIK6SendDataManager;
    CEConnectManager mCEConnectManager;
    public K6_MessageNoticeStruct newMsgNtf;
    private Timer mTimer;
    private TimerTask mTimerTask;

    protected CEDevK6Proxy(Context context) {
        super(context);
        this.devVersion = "";
        this.gpsArgIndex = 0;
        this.context = context;
    }

    /* JADX WARN: Not initialized variable reg: 0, insn: 0x0049: INVOKE (r0 I:java.lang.Exception) VIRTUAL call: java.lang.Exception.printStackTrace():void A[MD:():void (c)], block:B:9:0x0049 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Error, java.util.Timer] */
    private void timeLoop() {
        Exception excPrintStackTrace;
        ?? r0;
        try {
            try {
                if (this.mTimer == null) {
                    this.mTimer = new Timer();
                    this.mTimerTask = new TimerTask() { // from class: ce.com.cenewbluesdk.proxy.CEDevK6Proxy.1
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() throws IOException {
                            if (!BluetoothHelper.getInstance().isEnabled()) {
                                Logger.i("blueToothConnectStateChange YAN_k6连接状态发送改变：蓝牙已关闭，停止重连...");
                                CEDevK6Proxy.this.stopLoop();
                                return;
                            }
                            if (CEBlueSharedPreference.getkey_connect_states() == 1) {
                                Logger.i("blueToothConnectStateChange YAN_k6连接状态发送改变：已连接，停止连接...");
                                CEDevK6Proxy.this.blueToothConnectStateChange(1);
                                CEDevK6Proxy.this.stopLoop();
                                return;
                            }
                            if (CEBlueSharedPreference.getkey_connect_states() != 0) {
                                Logger.i("blueToothConnectStateChange YAN_k6连接状态发送改变：正在连接中...");
                                CEDevK6Proxy.this.blueToothConnectStateChange(2);
                                return;
                            }
                            Logger.i("blueToothConnectStateChange YAN_k6连接状态发送改变：断开重连中...");
                            if (!TextUtils.isEmpty(CEDevK6Proxy.this.getBlueAddress()) || !TextUtils.isEmpty(CEDevK6Proxy.this.connectUtil.getBlueAddress())) {
                                CEDevK6Proxy.lge("blueToothConnectStateChange YAN_k6连接状态发送改变：断开重连中2...");
                                Logger.i("bind", "开始绑定-connect12");
                                CEDevK6Proxy.this.reConnectDirect();
                            } else {
                                Logger.i("blueToothConnectStateChange YAN_k6连接状态发送改变：设备移除，停止连接2...");
                                Logger.i("blueToothConnectStateChange YAN_k6连接状态发送改变：设备移除，断开连接...");
                                CEDevK6Proxy.this.stopLoop();
                                Logger.i("blueToothConnectStateChange YAN_k6连接状态发送改变：设备移除，停止自动连接...");
                            }
                        }
                    };
                }
                r0 = this.mTimer;
                r0.schedule(this.mTimerTask, DELAY, 60000L);
            } catch (Exception unused) {
                excPrintStackTrace.printStackTrace();
                lge("blueToothConnectStateChange YAN_k6连接状态发送改变：轮询Exception...");
                this.connectUtil.mCEScanDev_4_android5.setScanFinish(true);
            }
        } catch (Error unused2) {
            r0.printStackTrace();
            lge("blueToothConnectStateChange YAN_k6连接状态发送改变：轮询Error...");
            this.connectUtil.mCEScanDev_4_android5.setScanFinish(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase, ce.com.cenewbluesdk.proxy.CEDevK6Proxy] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Error] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v5, types: [ce.com.cenewbluesdk.proxy.CEDevK6Proxy] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    public void stopLoop() {
        ?? r0 = this;
        DELAY = 5000;
        r0.connectUtil.mCEScanDev_4_android5.setScanFinish(true);
        try {
            try {
                Timer timer = r0.mTimer;
                r0 = timer;
                if (timer != null) {
                    r0 = this;
                    timer.cancel();
                    r0.mTimer = null;
                    r0 = r0;
                }
            } catch (Exception unused) {
                r0.printStackTrace();
            }
        } catch (Error unused2) {
            r0.printStackTrace();
            r0 = r0;
        }
    }

    private void sendResult(CEDevData cEDevData, int i) {
        K6SendDataManager k6SendDataManager;
        if (cEDevData == null || (k6SendDataManager = this.mIK6SendDataManager) == null) {
            return;
        }
        k6SendDataManager.processResult(cEDevData.getDataType(), i);
    }

    private void analysisCEDevData(CEDevData cEDevData) {
        K6AnalysiDevRcvDataManager k6AnalysiDevRcvDataManager = this.mK6AnalysiDevManager;
        if (k6AnalysiDevRcvDataManager != null) {
            k6AnalysiDevRcvDataManager.process(cEDevData);
        }
        if (cEDevData.getDataType() != 26) {
            return;
        }
        this.fileTransControl.sendQRInfoSendResult(cEDevData.getData()[0]);
    }

    private void dealPairFinish() {
        sendMeg(createMessage(K6_Action.RCVD.RCVD_PAIR_FINISH, 1));
        lge("接收到了配对的消息，表示连接成功");
    }

    public static void lge(String str) {
        Log.e("k6", str);
    }

    public void setDevVersion(String str) {
        this.devVersion = str;
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public IK6SendDataManager getSendHelper() {
        return this.mIK6SendDataManager;
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public K6AnalysiDevRcvDataManager getK6AnalysiDevManager() {
        return this.mK6AnalysiDevManager;
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void setMsg(K6_MessageNoticeStruct k6_MessageNoticeStruct) {
        this.newMsgNtf = k6_MessageNoticeStruct;
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    protected void dataSendSucceed(CEDevData cEDevData) {
        sendResult(cEDevData, 1);
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    protected void DataSendFailed(CEDevData cEDevData) {
        sendResult(cEDevData, 0);
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    protected void receiptData(CEDevData cEDevData) {
        analysisCEDevData(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    protected void blueToothConnectStateChange(int i) throws IOException {
        lge("blueToothConnectStateChange YAN_k6连接状态发送改变：" + i);
        Lg.e_file("Connection", "blueToothConnectStateChange_state =" + i, "connection.log", true);
        Logger.e("aaa", "ssss2=" + i);
        CEBlueSharedPreference.set_key_connect_states(i + "");
        getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_BLUE_CONNECT_STATE_CHANGE).preProcessResult(Integer.valueOf(i));
        if (i == 1) {
            this.otaControl.setOtaState(0);
            this.fileTransControl.setFileState(0);
            Logger.i("bind", "开始绑定-发送配对完成消息");
            Lg.e_file("Connection", "发送配对完成指令", "connection.log", true);
            dealPairFinish();
            Logger.e(Lg.getClassName(this), "连接状态发生改变：已连接");
            stopLoop();
            if (TextUtils.isEmpty(this.connectUtil.getBlueAddress())) {
                return;
            }
            setBlueAddress(this.connectUtil.getBlueAddress());
            return;
        }
        if (i == 2) {
            CEBlueSharedPreference.setScreenWidth("240");
            CEBlueSharedPreference.setScreenHigh("240");
            CEBlueSharedPreference.setScreenRGB("0");
            CEDevQueue cEDevQueue = this.devQueue;
            if (cEDevQueue != null) {
                cEDevQueue.clearDate();
            }
            CEDevQueue.devData = null;
            return;
        }
        if (i == 0) {
            this.otaControl.setOtaState(0);
            this.fileTransControl.setFileState(0);
            CEDevQueue cEDevQueue2 = this.devQueue;
            if (cEDevQueue2 != null) {
                cEDevQueue2.clearDate();
            }
            DELAY += 5000;
            CEBlueSharedPreference.setScreenWidth("240");
            CEBlueSharedPreference.setScreenHigh("240");
            CEBlueSharedPreference.setScreenRGB("0");
            stopLoop();
            timeLoop();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    protected void initProxy() {
        this.blueTooth = new CEBlueTooth_5(this.context, UUID);
        this.connectUtil = new CEConnectUtilForAndroid5(this.context, new b(), this, this.blueTooth);
        Log.i("YAN_registerBlue", "initProxy");
        this.devQueue = new CEDevQueue(this, new CEProtocolB(1), this.blueTooth);
        this.otaControl = new OtaK6Control(this, this.context);
        this.fileTransControl = new FileTransControl(this, this.context);
        this.mK6AnalysiDevManager = new K6AnalysiDevRcvDataManager(this);
        this.mIK6SendDataManager = new K6SendDataManager(this);
        this.mCEConnectManager = new CEConnectManager();
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    protected String getClassName() {
        return "CEDevK6Proxy";
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void connectDevice(final String str, final String str2) {
        if (TextUtils.isEmpty(str2)) {
            return;
        }
        HashMap map = new HashMap();
        map.put("customerId", "177");
        map.put("version", CEBlueSharedPreference.getInstance(this.context).getLegalWatchVersion() + "");
        a.a().a("http://coolwearapi.lizhui.net/YueDongService/app/appApi.do", map, new ce.com.cenewbluesdk.b.b() { // from class: ce.com.cenewbluesdk.proxy.CEDevK6Proxy.2
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Exception] */
            /* JADX WARN: Type inference failed for: r0v24 */
            /* JADX WARN: Type inference failed for: r0v25 */
            @Override // ce.com.cenewbluesdk.b.b
            public void onSuccess(String str3) {
                AnonymousClass2 anonymousClass2;
                String legalWatch;
                String str4;
                String str5;
                boolean zIsEmpty = TextUtils.isEmpty(str3);
                ?? r0 = zIsEmpty;
                if (!zIsEmpty) {
                    String string = str3.toString();
                    Logger.e(string);
                    r0 = string;
                }
                try {
                    BaseBean baseBeanFromJsonObject = JsonUtil.fromJsonObject(str3, AllowWatchBean.class);
                    if (baseBeanFromJsonObject == null) {
                        anonymousClass2 = this;
                        legalWatch = CEBlueSharedPreference.getInstance(CEDevK6Proxy.this.context).getLegalWatch();
                        str4 = str2;
                        str5 = str;
                    } else if (baseBeanFromJsonObject.getCode() == 0) {
                        checkWatch(((AllowWatchBean) baseBeanFromJsonObject.getResult()).getBtNames(), str2, str);
                        CEBlueSharedPreference.getInstance(CEDevK6Proxy.this.context).setLegalWatch(((AllowWatchBean) baseBeanFromJsonObject.getResult()).getBtNames());
                        CEBlueSharedPreference.getInstance(CEDevK6Proxy.this.context).setLegalWatchVersion(((AllowWatchBean) baseBeanFromJsonObject.getResult()).getVersion());
                        return;
                    } else if (baseBeanFromJsonObject.getCode() == 101) {
                        Logger.e(Lg.getClassName(CEDevK6Proxy.this), "不存在");
                        return;
                    } else {
                        if (baseBeanFromJsonObject.getCode() != 102) {
                            return;
                        }
                        anonymousClass2 = this;
                        Logger.i(Lg.getClassName(CEDevK6Proxy.this), "不更新");
                        legalWatch = CEBlueSharedPreference.getInstance(CEDevK6Proxy.this.context).getLegalWatch();
                        str4 = str2;
                        str5 = str;
                    }
                    anonymousClass2.checkWatch(legalWatch, str4, str5);
                } catch (Exception unused) {
                    r0.printStackTrace();
                    checkWatch(CEBlueSharedPreference.getInstance(CEDevK6Proxy.this.context).getLegalWatch(), str2, str);
                }
            }

            @Override // ce.com.cenewbluesdk.b.b
            public void onError(String str3) {
                if (!TextUtils.isEmpty(str3)) {
                    Logger.e(str3.toString());
                }
                checkWatch(CEBlueSharedPreference.getInstance(CEDevK6Proxy.this.context).getLegalWatch(), str2, str);
            }

            public void checkWatch(String str3, String str4, String str5) {
                if (TextUtils.isEmpty(str3)) {
                    CEDevK6Proxy.this.getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_ALLOW_WATCH).preProcessResult(-1);
                    return;
                }
                if (!str3.contains(str4)) {
                    Logger.e(Lg.getClassName(CEDevK6Proxy.this), "非法手表");
                    CEDevK6Proxy.this.getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_ALLOW_WATCH).preProcessResult(0);
                } else {
                    Logger.i("bind", "开始绑定-connect1");
                    CEDevK6Proxy.this.connectUtil.connect(str5);
                    CEDevK6Proxy.this.getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_ALLOW_WATCH).preProcessResult(1);
                }
            }
        });
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void clearDate() {
        this.devQueue.clearDate();
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void startPair() {
        this.mIK6SendDataManager.sendAynInfoDetail();
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void sendSynDevData() {
        this.mIK6SendDataManager.sendSynDevData();
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void setVolume(int i) {
        this.mIK6SendDataManager.setVolume(i);
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [ce.com.cenewbluesdk.ota.ota_modea.OtaK6Control, org.json.JSONException] */
    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void startOta(String str) throws JSONException {
        ?? r0;
        try {
            JSONObject jSONObject = new JSONObject(str);
            String string = jSONObject.getString("url");
            String string2 = jSONObject.getString("devVer");
            String string3 = jSONObject.getString("netVer");
            this.otaControl.setOtaState(0);
            r0 = this.otaControl;
            r0.startOtaFromFile(string3, string2, string);
        } catch (JSONException unused) {
            r0.printStackTrace();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void sendWatchFaceTimeOut(boolean z) {
        lge("WaitWatchFace超时" + z);
        K6_DATA_TYPE_WATCH_FACE_START k6_data_type_watch_face_start = new K6_DATA_TYPE_WATCH_FACE_START();
        k6_data_type_watch_face_start.setTimeOut(z);
        getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_K6_DATA_TYPE_WATCH_FACE_START).preProcessResult(k6_data_type_watch_face_start);
        sendMeg(createMessage(K6_Action.RCVD.RCVD_K6_DATA_TYPE_WATCH_FACE_START, k6_data_type_watch_face_start));
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void setSpeedUp(boolean z) {
        this.isSpeedUp = z;
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void stopFileTransfer() {
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public boolean isSpeedUp() {
        return this.isSpeedUp;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
        	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:44)
        */
    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void startFileTrans(
    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase] */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean, java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [org.json.JSONObject] */
    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public String modifyDial(int i, int i2, int i3, int i4, boolean z) throws JSONException, IOException {
        byte[] bArr = new byte[6];
        bArr[0] = (byte) i;
        bArr[1] = (byte) i2;
        bArr[2] = (byte) i3;
        System.arraycopy(ByteUtil.int2bytes2(f.e(i4)), 0, bArr, 3, 2);
        if (z) {
            bArr[5] = 1;
        } else {
            bArr[5] = 0;
        }
        File file = new File(this.context.getFilesDir(), "bin" + System.currentTimeMillis() + ".bin");
        ?? Exists = file.exists();
        if (Exists == 0) {
            try {
                file.createNewFile();
                g.a(bArr, file);
            } catch (IOException unused) {
                Exists.printStackTrace();
            }
        }
        JSONException jSONObject = new JSONObject();
        try {
            jSONObject.put("cmd", 2);
            jSONObject.put("index", 2);
            jSONObject.put("filePath", file.getAbsolutePath());
            jSONObject = BleFactory.getInstance().getK6Proxy();
            jSONObject.startFileTrans(jSONObject.toString());
        } catch (JSONException unused2) {
            jSONObject.printStackTrace();
        }
        return file.getAbsolutePath();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r0v22, types: [ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase] */
    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public String modifyDial(String str, int i, int i2, int i3, int i4, int i5, int i6) throws JSONException, IOException {
        Bitmap bitmapA = g.a(str, i, i2);
        Bitmap bitmapA2 = bitmapA;
        if (bitmapA == null) {
            return modifyDial(i3, i4, i5, i6, true);
        }
        if (bitmapA2.getWidth() != i || bitmapA2.getHeight() != i2) {
            bitmapA2 = g.a(bitmapA2, i, i2);
        }
        int i7 = i * i2;
        int[] iArr = new int[i7];
        bitmapA2.getPixels(iArr, 0, i, 0, 0, i, i2);
        byte[] bArr = new byte[(i7 * 2) + 10];
        bArr[0] = (byte) i3;
        bArr[1] = (byte) i4;
        bArr[2] = (byte) i5;
        System.arraycopy(ByteUtil.int2bytes2(f.e(i6)), 0, bArr, 3, 2);
        bArr[5] = 2;
        System.arraycopy(ByteUtil.int2bytes2(i), 0, bArr, 6, 2);
        System.arraycopy(ByteUtil.int2bytes2(i2), 0, bArr, 8, 2);
        int i8 = 10;
        for (int i9 = 0; i9 < i7; i9++) {
            System.arraycopy(ByteUtil.int2byte2(f.b(iArr[i9])), 0, bArr, i8, 2);
            i8 += 2;
        }
        File file = new File(this.context.getFilesDir(), "bin" + System.currentTimeMillis() + ".bin");
        ?? Exists = file.exists();
        if (Exists == 0) {
            try {
                file.createNewFile();
                g.a(bArr, file);
            } catch (IOException unused) {
                Exists.printStackTrace();
            }
        }
        JSONException jSONObject = new JSONObject();
        try {
            jSONObject.put("cmd", 2);
            jSONObject.put("index", 2);
            jSONObject.put("filePath", file.getAbsolutePath());
            jSONObject = BleFactory.getInstance().getK6Proxy();
            jSONObject.startFileTrans(jSONObject.toString());
        } catch (JSONException unused2) {
            jSONObject.printStackTrace();
        }
        return file.getAbsolutePath();
    }

    public void dealFileInfo(K6_DATA_TYPE_WATCH_FACE_INFO k6_data_type_watch_face_info) {
        this.fileTransControl.fileStateResult(k6_data_type_watch_face_info);
    }

    public void dealFileData(byte[] bArr) {
        byte b = bArr[0];
        Log.e("CEDevK6Proxy", "OneOTADataOver:" + ((int) bArr[0]));
        this.fileTransControl.fileDataSendResult(b);
    }

    public void dealOtaInfo(byte[] bArr) {
        K6_OTAStateInfo k6_OTAStateInfo = new K6_OTAStateInfo(bArr);
        OtaUtil.otaLog("2请求设备侧的OTA状态设备响应=" + k6_OTAStateInfo.toString());
        sendMeg(createMessage(K6_Action.RCVD.RCVD_OTA_INFO, k6_OTAStateInfo));
        this.otaControl.otaStateResult(k6_OTAStateInfo);
    }

    public void dealOtaData(byte[] bArr) {
        byte b = bArr[0];
        Log.e("CEDevK6Proxy", "OneOTADataOver:" + ((int) bArr[0]));
        this.otaControl.otaDataSendResult(b);
    }

    public void deal_RCVD_DATA_TYPE_DEV_SYNC() {
        sendMeg(createMessage(K6_Action.RCVD.RCVD_DATA_TYPE_DEV_SYNC, 0));
        lge("发送界面展示命令");
    }

    @Override // ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase
    public void sendQRInfo(K6_DATA_TYPE_QR_CODE_INFO k6_data_type_qr_code_info) {
        FileTransControl fileTransControl = new FileTransControl(this, this.context);
        this.fileTransControl = fileTransControl;
        fileTransControl.sendQRInfo(k6_data_type_qr_code_info);
    }
}
