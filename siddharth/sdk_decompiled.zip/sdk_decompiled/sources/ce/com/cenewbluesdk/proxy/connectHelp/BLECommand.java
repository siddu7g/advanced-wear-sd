package ce.com.cenewbluesdk.proxy.connectHelp;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/connectHelp/BLECommand.class */
class BLECommand implements Runnable {
    private int delay;
    private int threadType;
    private BleCommandCallBack mBleCommandCallBack;

    public BLECommand(BleCommandCallBack bleCommandCallBack) {
        this.mBleCommandCallBack = bleCommandCallBack;
    }

    public BLECommand(BleCommandCallBack bleCommandCallBack, int i, int i2) {
    }

    public boolean processOk() {
        return true;
    }

    @Override // java.lang.Runnable
    public void run() {
    }
}
