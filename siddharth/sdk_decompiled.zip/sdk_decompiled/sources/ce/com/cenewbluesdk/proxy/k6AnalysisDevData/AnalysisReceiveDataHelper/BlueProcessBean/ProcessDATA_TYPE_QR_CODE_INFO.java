package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_QR_CODE_INFO;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_QR_CODE_INFO.class */
public class ProcessDATA_TYPE_QR_CODE_INFO extends BaseK6AnalysiDevData<K6_DATA_TYPE_QR_CODE_INFO> {
    public ProcessDATA_TYPE_QR_CODE_INFO(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(26);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_QR_CODE_INFO);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_QR_CODE_INFO realProcess(byte[] bArr) {
        return null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_QR_CODE_INFO k6_data_type_qr_code_info) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_QR_CODE_INFO k6_data_type_qr_code_info) {
        return false;
    }
}
