package ce.com.cenewbluesdk.proxy.interfaces;

import ce.com.cenewbluesdk.entity.k6.K6_CESyncTime;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_AI_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_CONTACT_SYNC;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_DRINK_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_FIND_PHONE_OR_DEVICE;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_HAND_RISE_SWITCH;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_HEART_AUTO_SWITCH;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_MUSIC_CONTROL;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_NAVIGATION;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_TARGET_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WOMAN_STAGE_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_ExerciseState;
import ce.com.cenewbluesdk.entity.k6.K6_MessageNoticeStruct;
import ce.com.cenewbluesdk.entity.k6.K6_MixInfoStruct;
import ce.com.cenewbluesdk.entity.k6.K6_MusicInfo;
import ce.com.cenewbluesdk.entity.k6.K6_NoDisturb;
import ce.com.cenewbluesdk.entity.k6.K6_PairStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SEND_APP_SPORT_STRUCT;
import ce.com.cenewbluesdk.entity.k6.K6_SendAlarmInfoStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SendCurrentLocationInfo;
import ce.com.cenewbluesdk.entity.k6.K6_SendDevSettingStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SendGoal;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeather;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeatherExtra;
import ce.com.cenewbluesdk.entity.k6.K6_SendUserInfo;
import ce.com.cenewbluesdk.entity.k6.K6_SendWeatherStruct;
import ce.com.cenewbluesdk.entity.k6.K6_Send_Watch_Face_And_Notification_Set;
import ce.com.cenewbluesdk.entity.k6.K6_SittingRemind;
import ce.com.cenewbluesdk.entity.k6.K6_UnitSettingStruct;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/interfaces/IK6SendDataManager.class */
public interface IK6SendDataManager {
    void addSendDataResultListener(String str, K6BleDataResult<Integer> k6BleDataResult);

    void sendAsynInfo();

    void sendUserInfo(K6_SendUserInfo k6_SendUserInfo);

    void sendTime(K6_CESyncTime k6_CESyncTime);

    void sendLanguageSetting();

    void sendSetting(K6_SendDevSettingStruct k6_SendDevSettingStruct);

    void sendUnitSetting(K6_UnitSettingStruct k6_UnitSettingStruct);

    void getDevInfo();

    void sendAlarmInfo(ArrayList<K6_SendAlarmInfoStruct> arrayList);

    void sendMessage_notice(long j, String str, String str2, byte b);

    void sendMessage_notice(K6_MessageNoticeStruct k6_MessageNoticeStruct);

    void sendWeatherInfo(K6_SendWeatherStruct k6_SendWeatherStruct);

    void sendGoal(K6_SendGoal k6_SendGoal);

    void sendMusicInfo(K6_MusicInfo k6_MusicInfo);

    void setEnableGsDataTrans(boolean z);

    void setEnableGsDataTrans();

    void sendMixInfo(K6_MixInfoStruct k6_MixInfoStruct);

    void sendGetMixInfo();

    void sendGetSittingRemind();

    void sendWatchFace(K6_Send_Watch_Face_And_Notification_Set k6_Send_Watch_Face_And_Notification_Set);

    void sendPairStart(K6_PairStruct k6_PairStruct);

    void sendOTAData(int i, int i2, int i3, byte[] bArr);

    void sendWatchFileData(byte[] bArr, int i, int i2, byte[] bArr2);

    void sendOTAFinish();

    void getOTAState();

    void getFileDownloadInfo();

    void sendSittingRemind(K6_SittingRemind k6_SittingRemind);

    void sendDATA_TARGET_ALARM(K6_DATA_TYPE_TARGET_ALARM k6_data_type_target_alarm);

    void sendK6_DATA_TYPE_DRINK_ALARM(K6_DATA_TYPE_DRINK_ALARM k6_data_type_drink_alarm);

    void sendK6_DATA_TYPE_WOMAN_STAGE_INFO(K6_DATA_TYPE_WOMAN_STAGE_INFO k6_data_type_woman_stage_info);

    void sendK6_SEND_DATA_TYPE_FIND_PHONE(K6_DATA_TYPE_FIND_PHONE_OR_DEVICE k6_data_type_find_phone_or_device);

    void sendK6_DATA_TYPE_HAND_RISE_SWITCH(K6_DATA_TYPE_HAND_RISE_SWITCH k6_data_type_hand_rise_switch);

    void sendK6_DATA_TYPE_HEART_AUTO_SWITCH(K6_DATA_TYPE_HEART_AUTO_SWITCH k6_data_type_heart_auto_switch);

    void sendPhotoSwitch(boolean z);

    void sendCall();

    void sendCall(int i);

    void sendNoDisturb(List<K6_NoDisturb> list, int i);

    void sendDeviceRestart();

    void sendDevicePairFinish(byte b);

    void sendExerciseCmd(K6_ExerciseState k6_ExerciseState);

    void getDevExerciseState();

    void sendAppSport(K6_SEND_APP_SPORT_STRUCT k6_send_app_sport_struct);

    void sendK6_DATA_TYPE_REAL_BP(int i);

    void sendK6_DATA_TYPE_REAL_O2(int i);

    void sendK6_DATA_TYPE_REAL_HR_SWITCH(int i);

    void sendK6_DATA_TYPE_REAL_HRV_SWITCH(int i);

    void sendK6_DATA_TYPE_REAL_ECG(int i);

    void sendK6_DATA_TYPE_WATCH_FACE_SYNC(int i);

    void sendK6_DATA_TYPE_MUSIC_CONTROL(K6_DATA_TYPE_MUSIC_CONTROL k6_data_type_music_control);

    void sendWatchFaceStart();

    void sendAddContacts(K6_DATA_TYPE_CONTACT_SYNC k6_data_type_contact_sync);

    void sendContactsSync(int i);

    void sendDelContacts(int i);

    void sendClearContacts();

    void sendRealTimeWeather(K6_SendRealTimeWeather k6_SendRealTimeWeather);

    void sendRealTimeWeatherExtra(K6_SendRealTimeWeatherExtra k6_SendRealTimeWeatherExtra);

    void sendCurrentLocation(K6_SendCurrentLocationInfo k6_SendCurrentLocationInfo);

    void sendK6_SEND_DATA_TYPE_BTEDR_ADDR();

    void sendQRInfo(byte[] bArr, int i, int i2);

    void sendQRCodeClear();

    void sendQRCodeDel(int i);

    void sendDelPhotoWatchLogo(int i);

    void sendDelPhotoWatchFace(int i);

    void sendAlData(byte[] bArr);

    void sendSwitchGSensor(int i);

    void sendAiData(K6_DATA_TYPE_AI_INFO k6_data_type_ai_info);

    void sendNavigation(K6_DATA_TYPE_NAVIGATION k6_data_type_navigation);

    void sendPhoneEdrToDev(int i, byte[] bArr);

    void sendSleepMonitor();

    void sendFactoryTest();

    void sendShutDown();

    void sendLeakLightTest(int i);

    void sendChangeName(String str);

    void sendGestureConfig(int i);

    void sendClearData();
}
