package ce.com.cenewbluesdk.proxy.interfaces;

import java.util.HashMap;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/interfaces/OnPushAppListListener.class */
public interface OnPushAppListListener {
    void onPushAppList(List<HashMap> list);

    void onPushAppError(Exception exc);
}
