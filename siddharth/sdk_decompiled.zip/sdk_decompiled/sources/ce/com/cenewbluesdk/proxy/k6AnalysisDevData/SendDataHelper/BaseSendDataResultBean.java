package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.SendDataHelper;

import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.proxy.interfaces.K6BleDataResult;
import ce.com.cenewbluesdk.uitl.Logger;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/SendDataHelper/BaseSendDataResultBean.class */
public class BaseSendDataResultBean {
    int dataType;
    String dataTypeStr;
    CEDevK6Proxy ceDevK6Proxy;
    K6BleDataResult mK6BleDataResult;

    public BaseSendDataResultBean(int i, String str, CEDevK6Proxy cEDevK6Proxy) {
        this.dataType = i;
        this.dataTypeStr = str;
        this.ceDevK6Proxy = cEDevK6Proxy;
    }

    protected String getDataTypeStr() {
        return this.dataTypeStr;
    }

    protected void setDataType(int i) {
        this.dataType = i;
    }

    protected void setDataTypeStr(String str) {
        this.dataTypeStr = str;
    }

    protected boolean isMy(int i) {
        return i == this.dataType;
    }

    protected boolean isMyStr(String str) {
        String str2;
        if (str == null || (str2 = this.dataTypeStr) == null) {
            return false;
        }
        return str.equals(str2);
    }

    public void setK6BleDataResult(K6BleDataResult<Integer> k6BleDataResult) {
        this.mK6BleDataResult = k6BleDataResult;
    }

    protected boolean processResult(int i, int i2) {
        if (!isMy(i)) {
            return false;
        }
        if (this.mK6BleDataResult != null) {
            Logger.i("CHENGUIRUI", "c-8");
            this.mK6BleDataResult.bleDataResult(Integer.valueOf(i2));
        }
        Logger.i("CHENGUIRUI", "c1-8");
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), i2));
        return true;
    }
}
