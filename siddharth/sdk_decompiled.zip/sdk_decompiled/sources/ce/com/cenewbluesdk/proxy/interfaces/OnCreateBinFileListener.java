package ce.com.cenewbluesdk.proxy.interfaces;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/interfaces/OnCreateBinFileListener.class */
public interface OnCreateBinFileListener {
    void onCreateBinFile(String str);
}
