package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.content.Context;
import ce.com.cenewbluesdk.entity.WeatherData;
import ce.com.cenewbluesdk.entity.k6.K6_CESyncTime;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_AI_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_MUSIC_CONTROL;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_NAVIGATION;
import ce.com.cenewbluesdk.entity.k6.K6_SendAlarmInfoStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SendCurrentLocationInfo;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeather;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeatherExtra;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/ISendBlueToothData.class */
public interface ISendBlueToothData {
    void setContext(Context context);

    void sendWatchInfo();

    void sendFindDevice();

    void sendTimeFormat(int i);

    void sendDateFormat(int i);

    void sendCall(int i);

    void sendIncomingCall(String str, String str2);

    void sendSyncInfo();

    void sendPushMessage(String str, byte b, String str2);

    void sendDialSwitch(int i);

    void sendBloodOxygenDetection(int i);

    void sendBloodPressureDetection(int i);

    void sendWeatherInfo(List<WeatherData> list);

    void sendSystemLanguage();

    void sendSwitchLanguage(int i);

    void sendUnitSetting(int i, int i2, int i3);

    void sendDailyGoals(int i, int i2, int i3, int i4, int i5);

    void sendHeartAutoSwitch(int i, int i2);

    void sendHeartAutoSwitch(int i, int i2, int i3);

    void sendPhotoSwitch(boolean z);

    void sendDateTimeFormat(K6_CESyncTime k6_CESyncTime);

    void sendMusicControl(K6_DATA_TYPE_MUSIC_CONTROL k6_data_type_music_control);

    void setVolume(int i);

    void sendNoDisturb(int i, int i2, int i3, int i4, int i5);

    void sendHandRiseWitch(int i, int i2, int i3, int i4, int i5);

    void sendDevInfo();

    void sendAlarmInfo(ArrayList<K6_SendAlarmInfoStruct> arrayList);

    void sendAddContacts(String str, String str2);

    void sendContactsSync(int i);

    void sendDelContacts(int i);

    void sendClearContacts();

    void sendAppSport(int i, int i2, int i3, int i4);

    void sendDeviceRestart();

    void sendTargetRemind(int i);

    void sendDrinkRemind(int i, int i2, int i3, int i4, int i5, int i6);

    void sendSittingRemind(int i, int i2, int i3, int i4, int i5, int i6, int i7);

    void sendHeartRateSwitch(Integer num);

    void sendHRVSwitch(Integer num);

    void sendRealTimeWeather(K6_SendRealTimeWeather k6_SendRealTimeWeather);

    void sendRealTimeWeatherExtra(K6_SendRealTimeWeatherExtra k6_SendRealTimeWeatherExtra);

    void sendCurrentLocation(K6_SendCurrentLocationInfo k6_SendCurrentLocationInfo);

    void sendOpenSysBle();

    void sendQRCodeDel(int i);

    void sendQRCodeClear();

    void sendDelPhotoWatchLogo(int i);

    void sendDelPhotoWatchFace(int i);

    void sendSwitchGSensor(int i);

    void sendAiData(K6_DATA_TYPE_AI_INFO k6_data_type_ai_info);

    void sendNavigation(K6_DATA_TYPE_NAVIGATION k6_data_type_navigation);

    void sendPhoneEdrToDev(int i, byte[] bArr);

    void sendSleepMonitor();

    void sendFactoryTest();

    void sendShutDown();

    void sendLeakLightTest(int i);

    void sendChangeName(String str);

    void sendGestureConfig(int i);

    void sendClearData();
}
