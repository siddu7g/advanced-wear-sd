package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.bluetooth.a.a;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_BTEDR_ADDR.class */
public class ProcessDATA_TYPE_BTEDR_ADDR extends BaseK6AnalysiDevData<String> {
    private byte[] belMac;
    private byte[] bleName;
    private String belMacStr;
    private String belNameStr;
    private StringBuilder stringBuilder;
    a bleConnectTool;

    public ProcessDATA_TYPE_BTEDR_ADDR(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        this.belMac = new byte[6];
        this.bleName = new byte[24];
        this.stringBuilder = new StringBuilder();
        addDataType(25);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_BTEDR_ADDR);
    }

    private void testBle(String str) {
        Log.i("BleConnectTool", "创建bleConnectTool");
        if (this.bleConnectTool == null) {
            this.bleConnectTool = new a();
        }
        this.bleConnectTool.a(str, true);
    }

    private String formatBelMac(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        this.stringBuilder.setLength(0);
        for (int length = str.split(":").length - 1; length >= 0; length--) {
            this.stringBuilder.append(str.split(":")[length]).append(":");
        }
        StringBuilder sb = this.stringBuilder;
        return sb.substring(0, sb.length() - 1);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public String realProcess(byte[] bArr) {
        System.arraycopy(bArr, 0, this.belMac, 0, 6);
        String belMac = formatBelMac(ByteUtil.byteToHexString(this.belMac));
        this.belMacStr = belMac;
        CEBlueSharedPreference.setA2dpMac(belMac.toUpperCase());
        System.arraycopy(bArr, 6, this.bleName, 0, bArr.length - 6);
        this.belNameStr = new String(this.bleName).trim();
        Logger.i(Lg.getClassName(this), "音频蓝牙地址：" + CEBlueSharedPreference.getA2dpMac() + " 蓝牙名称：" + this.belNameStr);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(String str) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(String str) {
        return false;
    }
}
