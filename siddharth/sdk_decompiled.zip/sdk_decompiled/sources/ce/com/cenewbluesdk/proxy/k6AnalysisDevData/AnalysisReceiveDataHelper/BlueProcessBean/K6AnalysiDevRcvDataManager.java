package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.K6BleDataResult;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/K6AnalysiDevRcvDataManager.class */
public class K6AnalysiDevRcvDataManager implements IK6AnalysiDevRcvDataManager {
    List<BaseK6AnalysiDevData> allProcess;

    public K6AnalysiDevRcvDataManager(CEDevK6Proxy cEDevK6Proxy) {
        this.allProcess = new ArrayList();
        ArrayList arrayList = new ArrayList();
        arrayList.add(new ProcessDATA_TYPE_ALARM(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_APP_SPORT(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_BATTERY_INFO(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_CALL_CONTROL_TO_APP(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_DEVINFO(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_DRINK_ALARM(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_FIND_PHONE(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_FORGET_DISTURB(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HAND_RISE_SWITCH(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HEART_EXERCISE(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HEART_HISTORY(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HEART_REAL(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HEART_AUTO_SWITCH(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_MESSAGE_DISPLAY(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_MIX_SPORT(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_OTA_DATA(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_OTA_STATUS(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_PHOTOGRAPH_ONOFF(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_REAL_BP(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_SITTING_REMIND(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_SLEEP_NEW(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_SLEEP(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_SPORT(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_TARGET_ALARM(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_TIME(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_UNIT_SETTING(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_REAL_O2(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_REAL_O2_HISTORY(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_REAL_ECG(cEDevK6Proxy));
        arrayList.add(new ProcessRCVD_BLUE_CONNECT_STATE_CHANGE(cEDevK6Proxy));
        arrayList.add(new PROCESSDATA_TYPE_MUSIC_CONTROL(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HR_CONTROL(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_WATCH_FACE_SYNC(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_WATCH_FACE_INFO(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_FUNCTION_CONTROL(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_WOMAN_STAGE_INFO(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_WATCH_FACE_START(cEDevK6Proxy));
        arrayList.add(new PROCESSDATA_TYPE_PROGRESS(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HARDWARE_INFO(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_PAIR_FINISH(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_CONTACT_SYNC(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_OTA_PROGRESS(cEDevK6Proxy));
        arrayList.add(new PROCESSDATA_TYPE_ALLOW_WATCH(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_BTEDR_ADDR(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_QR_CODE_INFO(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_SMS_REPLY(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_ALIPAY_RAW_DATA(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_MOTION_GAME(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_MOTION_DATA(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_MAP_NAVIGATION_CMD(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_AI_QA_CMD(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_AI_TR_CMD(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_AI_WATCHFACE_CMD(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_AI_START_CREAT_DIAL(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_AI_TR_CMD2(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_MAP_NAVIGATION_QUIT(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_ANDROID_BTEDR_ADDR(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_SlEEP_MONITOR(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_LEAK_LIGHT_TEST(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HEART_REAL_V(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HISTORY_HEART_REAL_V(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_GESTURE_CONTROL(cEDevK6Proxy));
        arrayList.add(new ProcessDATA_TYPE_HISTORY_REAL_TEMP(cEDevK6Proxy));
        this.allProcess = arrayList;
        arrayList.add(new ProcessDATA_TYPE_DEV_SYNC(cEDevK6Proxy, this));
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager
    public void process(CEDevData cEDevData) {
        List<BaseK6AnalysiDevData> list = this.allProcess;
        if (list == null || list.size() == 0) {
            return;
        }
        Iterator<BaseK6AnalysiDevData> it = this.allProcess.iterator();
        while (it.hasNext()) {
            it.next().process(cEDevData);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager
    public <M> void addBleDataResultListener(String str, K6BleDataResult<M> k6BleDataResult) {
        for (BaseK6AnalysiDevData baseK6AnalysiDevData : this.allProcess) {
            if (baseK6AnalysiDevData.isMyStr(str)) {
                baseK6AnalysiDevData.setMK6BleDataResult(k6BleDataResult);
            }
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager
    public BaseK6AnalysiDevData getResultListenerByDataTypeStr(String str) {
        for (BaseK6AnalysiDevData baseK6AnalysiDevData : this.allProcess) {
            if (baseK6AnalysiDevData.isMyStr(str)) {
                return baseK6AnalysiDevData;
            }
        }
        return null;
    }
}
