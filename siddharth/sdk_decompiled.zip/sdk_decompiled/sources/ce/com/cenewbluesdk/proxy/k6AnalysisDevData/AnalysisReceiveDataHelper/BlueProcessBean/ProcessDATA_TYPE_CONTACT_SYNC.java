package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import android.text.TextUtils;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_CONTACT_SYNC;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_CONTACT_SYNC.class */
public class ProcessDATA_TYPE_CONTACT_SYNC extends BaseK6AnalysiDevData<K6_DATA_TYPE_CONTACT_SYNC> {
    private List<K6_DATA_TYPE_CONTACT_SYNC> list;

    public ProcessDATA_TYPE_CONTACT_SYNC(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        this.list = new ArrayList();
        addDataType(138);
        setDataTypeStr(K6_Action.RCVD.RCVD_CONTACT_SYNC_TYPE);
    }

    private boolean isLongName() {
        String deviceName = CEBlueSharedPreference.getDeviceName();
        return !TextUtils.isEmpty(deviceName) && deviceName.equalsIgnoreCase("DM10Pro");
    }

    public static String Bytes2HexString(byte[] bArr) {
        String str = "";
        for (byte b : bArr) {
            String hexString = Integer.toHexString(b & 255);
            String str2 = hexString;
            if (hexString.length() == 1) {
                str2 = '0' + str2;
            }
            str = str + str2.toUpperCase();
        }
        return str;
    }

    public static byte[] subBytes(byte[] bArr, int i, int i2) {
        byte[] bArr2 = new byte[i2];
        for (int i3 = i; i3 < i + i2; i3++) {
            bArr2[i3 - i] = bArr[i3];
        }
        return bArr2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [byte[], java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.String] */
    public static String toStringHex(String str) {
        ?? str2;
        String str3;
        int length = str.length() / 2;
        ?? r0 = new byte[length];
        int i = 0;
        while (true) {
            str2 = i;
            if (str2 < length) {
                int i2 = i * 2;
                try {
                    r0[i] = (byte) (Integer.parseInt(str.substring(i2, i2 + 2), 16) & 255);
                } catch (Exception unused) {
                    r0.printStackTrace();
                }
                i++;
            } else {
                try {
                    break;
                } catch (Exception unused2) {
                    str2.printStackTrace();
                    str3 = str;
                }
            }
        }
        str3 = str2;
        str2 = new String((byte[]) r0, "utf-8");
        return str3;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_CONTACT_SYNC realProcess(byte[] bArr) {
        int i = bArr[0] & 255;
        byte[] bArrSubBytes = subBytes(bArr, 1, isLongName() ? 50 : 20);
        int i2 = isLongName() ? 51 : 21;
        byte[] bArrSubBytes2 = subBytes(bArr, i2, bArr.length - i2);
        String str = new String(bArrSubBytes);
        String str2 = new String(bArrSubBytes2);
        K6_DATA_TYPE_CONTACT_SYNC k6_data_type_contact_sync = new K6_DATA_TYPE_CONTACT_SYNC();
        k6_data_type_contact_sync.setPhoneName(str.trim());
        k6_data_type_contact_sync.setPhoneNumber(str2.trim());
        k6_data_type_contact_sync.setPosition(i);
        return k6_data_type_contact_sync;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_CONTACT_SYNC k6_data_type_contact_sync) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_CONTACT_SYNC k6_data_type_contact_sync) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_data_type_contact_sync));
        return false;
    }
}
