package ce.com.cenewbluesdk.proxy;

import android.os.Handler;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.bluetooth.CEBlueToothBase;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.QueueSendData;
import ce.com.cenewbluesdk.queue.CEProtocolBase;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDevQueue.class */
public class CEDevQueue implements CEBlueToothBase.b {
    public static final String LOG_TAG = "COOL_WEAR";
    private static final int maxSendFailTime = 0;
    private static final int timeOutTime = 20000;
    private static final int watchFaceOutTime = 3000;
    private static final int sendFree = 0;
    private static final int sending = 1;
    private static final int sendwaitAck = 2;
    public static CEDevData devData;
    private byte[] currSendData;
    private CEBlueToothBase bluetooth;
    private CEProtocolBase protocol;
    private CEBluetoothProxyBase proxyBase;
    private CEDeQueueRemoveDuplicateHelper mCEDeQueueRemoveDuplicateHelper;
    private CEDevQueueHelper mCEDevQueueHelper;
    private int byteSendFailTimes = 0;
    protected ArrayBlockingQueue<CEDevData> sendQueue = new ArrayBlockingQueue<>(2000, true);
    Handler sendTimeoutH = new Handler();
    private DataSendTimeoutR dataSendTimeoutR = new DataSendTimeoutR();
    private WaitAckSendTimeoutR waitAckSendTimeoutR = new WaitAckSendTimeoutR();
    private WaitWatchFaceTimeOut waitWatchFaceTimeOut = new WaitWatchFaceTimeOut();

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDevQueue$DataSendTimeoutR.class */
    class DataSendTimeoutR implements Runnable {
        DataSendTimeoutR() {
        }

        @Override // java.lang.Runnable
        public void run() {
            CEDevQueue cEDevQueue = CEDevQueue.this;
            cEDevQueue.dataSendFail(cEDevQueue.currSendData);
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDevQueue$WaitAckSendTimeoutR.class */
    class WaitAckSendTimeoutR implements Runnable {
        WaitAckSendTimeoutR() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Logger.e("TAG_GATT", "WaitAckSendTimeoutR");
            CEDevQueue.this.ackEreOrWaitTimeOut(Boolean.FALSE);
        }
    }

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDevQueue$WaitWatchFaceTimeOut.class */
    class WaitWatchFaceTimeOut implements Runnable {
        WaitWatchFaceTimeOut() {
        }

        @Override // java.lang.Runnable
        public void run() {
            CEDevQueue.this.proxyBase.setSpeedUp(false);
            CEDevQueue.this.proxyBase.sendWatchFaceTimeOut(true);
        }
    }

    public CEDevQueue(CEBluetoothProxyBase cEBluetoothProxyBase, CEProtocolBase cEProtocolBase, CEBlueToothBase cEBlueToothBase) {
        this.bluetooth = cEBlueToothBase;
        this.protocol = cEProtocolBase;
        this.proxyBase = cEBluetoothProxyBase;
        cEBlueToothBase.setBlueReceiptDataListen(this);
        this.mCEDeQueueRemoveDuplicateHelper = new CEDeQueueRemoveDuplicateHelper();
        this.mCEDevQueueHelper = new CEDevQueueHelper(this);
    }

    private boolean filterCmd(CEDevData cEDevData) {
        if (cEDevData.getDataType() == 131 || cEDevData.getDataType() == 134 || cEDevData.getDataType() == 147) {
            return false;
        }
        Log.i("CEDevQueue", "正在传表盘，需要过滤" + cEDevData.getDataType());
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dataSendFail(byte[] bArr) {
        CEDevData cEDevData = this.mCEDevQueueHelper.curCeDevData;
        Logger.i(LOG_TAG, "发送的数据类型失败 type = " + cEDevData.getDataType() + "||CMD = " + cEDevData.getCmd());
        if (!this.proxyBase.isConnectOK()) {
            Log.e("CEDevQueue", "dataSendFail current ble status connectfail");
            return;
        }
        int i = this.byteSendFailTimes;
        if (i < 0) {
            this.byteSendFailTimes = i + 1;
            this.bluetooth.sendData(bArr);
        } else {
            Log.e("CEDevQueue", "dataSendFail current ble status connectOk");
            Logger.e("TAG_GATT", "dataSendFail");
            this.proxyBase.forceDisConnect();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ackEreOrWaitTimeOut(Boolean bool) {
        if (!bool.booleanValue()) {
            Log.e("CEDevQueue", "ackEreOrWaitTimeOut ack超时");
            Logger.e("TAG_GATT", "ack超时直接");
            this.proxyBase.forceDisConnect();
        } else {
            if (!this.proxyBase.isConnectOK()) {
                Log.e("CEDevQueue", "ackEreOrWaitTimeOut current ble status connectfailed");
                return;
            }
            Log.e("CEDevQueue", "ackEreOrWaitTimeOut current ble status connectOk");
            Logger.e("TAG_GATT", "ackEreOrWaitTimeOut");
            this.proxyBase.forceDisConnect();
        }
    }

    private void addN() {
    }

    private void startSendDataTimeout() {
        this.sendTimeoutH.removeCallbacks(this.dataSendTimeoutR);
        this.sendTimeoutH.postDelayed(this.dataSendTimeoutR, 20000L);
    }

    private void endSendDataTimeout() {
        this.sendTimeoutH.removeCallbacks(this.dataSendTimeoutR);
    }

    private void startWatchFaceTimeOut() {
        this.sendTimeoutH.removeCallbacks(this.waitWatchFaceTimeOut);
        this.sendTimeoutH.postDelayed(this.waitWatchFaceTimeOut, 3000L);
    }

    private void endWatchFaceTimeOut() {
        this.sendTimeoutH.removeCallbacks(this.waitWatchFaceTimeOut);
    }

    public void setBluetooth(CEBlueToothBase cEBlueToothBase) {
        this.bluetooth = cEBlueToothBase;
    }

    public void setProtocol(CEProtocolBase cEProtocolBase) {
        this.protocol = cEProtocolBase;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v22, types: [ce.com.cenewbluesdk.proxy.CEDeQueueRemoveDuplicateHelper] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    public synchronized void push(CEDevData cEDevData) {
        if (cEDevData == null) {
            return;
        }
        CEDevData cEDevData2 = devData;
        if (cEDevData2 != null && cEDevData2.getDataType() == 134 && filterCmd(cEDevData)) {
            return;
        }
        devData = cEDevData;
        ArrayBlockingQueue<CEDevData> arrayBlockingQueue = this.sendQueue;
        ?? r0 = arrayBlockingQueue;
        if (arrayBlockingQueue == null) {
            CEDevQueue cEDevQueue = this;
            Logger.i("初始化队列");
            cEDevQueue.sendQueue = new ArrayBlockingQueue<>(2000, true);
            r0 = cEDevQueue;
        }
        try {
            if (this.mCEDeQueueRemoveDuplicateHelper == null) {
                this.mCEDeQueueRemoveDuplicateHelper = new CEDeQueueRemoveDuplicateHelper();
            }
            r0 = this.mCEDeQueueRemoveDuplicateHelper;
            r0.process(this.sendQueue, cEDevData);
        } catch (Exception unused) {
            r0.printStackTrace();
        }
        Log.e("CEDevQueue", "push size " + this.sendQueue.size());
        this.sendQueue.offer(cEDevData);
        Log.e("CEDevQueue", "push size " + this.sendQueue.size() + " dataType: " + cEDevData.getDataType() + " sendstatus=" + this.mCEDevQueueHelper.sendState);
    }

    public void clearDate() {
        Log.e("CEDevQueue", "sendqueue clear data ");
        ArrayBlockingQueue<CEDevData> arrayBlockingQueue = this.sendQueue;
        if (arrayBlockingQueue != null) {
            arrayBlockingQueue.clear();
        }
        CEDevQueueHelper cEDevQueueHelper = this.mCEDevQueueHelper;
        if (cEDevQueueHelper != null) {
            cEDevQueueHelper.clear();
        }
        endSendDataTimeout();
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase.b
    public void blueToothReceiptData(byte[] bArr) {
        CEDevData cEDevDataAnalysis = this.protocol.Analysis(bArr);
        if (cEDevDataAnalysis != null) {
            Log.i(LOG_TAG, "接受数据类型 type = " + cEDevDataAnalysis.getDataType());
            CEDevData cEDevData = devData;
            if (cEDevData != null && cEDevData.getDataType() == 131 && (cEDevDataAnalysis.getDataType() == 3 || cEDevDataAnalysis.getDataType() == 5 || cEDevDataAnalysis.getDataType() == 105 || cEDevDataAnalysis.getDataType() == 150)) {
                Log.e("CEDevQueue", "正在传表盘，不处理电量,运动，天气等指令" + cEDevDataAnalysis.getDataType());
                return;
            }
        }
        if (cEDevDataAnalysis != null && cEDevDataAnalysis.getDataType() == 202 && cEDevDataAnalysis.getCmd() == -99) {
            Log.e("CEDevQueue", "OneOTADataOver:" + cEDevDataAnalysis.toString());
            this.proxyBase.receiptData(cEDevDataAnalysis);
        }
        if (cEDevDataAnalysis != null && cEDevDataAnalysis.getDataType() == 26) {
            this.proxyBase.receiptData(cEDevDataAnalysis);
        }
        if (cEDevDataAnalysis != null && cEDevDataAnalysis.getDataType() == 131 && cEDevDataAnalysis.getCmd() == -99) {
            Log.e("CEDevQueue", "FileDownLoadOver:" + cEDevDataAnalysis.toString());
            this.proxyBase.receiptData(cEDevDataAnalysis);
        }
        if (cEDevDataAnalysis != null && cEDevDataAnalysis.getDataType() == 134 && cEDevDataAnalysis.getCmd() == -99) {
            startWatchFaceTimeOut();
        }
        if (cEDevDataAnalysis != null) {
            if (cEDevDataAnalysis.getCmd() != -99) {
                if (cEDevDataAnalysis.getCmd() != -10001) {
                    if (cEDevDataAnalysis.getCmd() == -10002) {
                        Logger.i("无需回复ACK");
                        this.proxyBase.receiptData(cEDevDataAnalysis);
                        return;
                    }
                    return;
                }
                cEDevDataAnalysis.setPriority(1);
                push(cEDevDataAnalysis);
                if (cEDevDataAnalysis.getDataCrc16() == cEDevDataAnalysis.figureCrc16()) {
                    this.proxyBase.receiptData(cEDevDataAnalysis);
                }
                if (cEDevDataAnalysis.getDataType() == 134) {
                    Log.e("CEDevQueue", "data5-开始高速传输表盘");
                    endWatchFaceTimeOut();
                    this.proxyBase.setSpeedUp(true);
                    this.proxyBase.sendWatchFaceTimeOut(false);
                    return;
                }
                return;
            }
            byte b = cEDevDataAnalysis.getData()[0];
            CEDevData cEDevData2 = this.mCEDevQueueHelper.curCeDevData;
            if (cEDevData2 == null || cEDevData2.getDataType() != cEDevDataAnalysis.getDataType()) {
                if (this.proxyBase.isSpeedUp() && cEDevDataAnalysis.getDataType() == 131) {
                    Logger.i("传表盘出错，进行重新传");
                    devData = null;
                    BleFactory.getInstance().getK6Proxy().getSendHelper().sendWatchFaceStart();
                    return;
                }
                return;
            }
            this.sendTimeoutH.removeCallbacks(this.waitAckSendTimeoutR);
            if (b == -101) {
                this.proxyBase.dataSendSucceed(cEDevData2);
                Log.e("CEDevQueue", "data5 命令：正确应答" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis())));
                this.mCEDevQueueHelper.sendBleData();
                if (cEDevDataAnalysis.getDataType() == 120) {
                    this.proxyBase.receiptData(cEDevDataAnalysis);
                    return;
                }
                return;
            }
            Log.e("CEDevQueue", "data5 错误应答： " + ((int) b));
            int dataType = cEDevDataAnalysis.getDataType();
            Log.e("CEDevQueue", "data25 错误应答： " + dataType);
            if (113 == dataType) {
                Log.e("CEDevQueue", "data5音乐控制命令：113");
                this.proxyBase.dataSendSucceed(cEDevData2);
                this.mCEDevQueueHelper.sendBleData();
                return;
            }
            if (cEDevDataAnalysis.getDataType() == 134) {
                Log.e("CEDevQueue", "data5-start等待传输指令");
                clearDate();
                return;
            }
            if (cEDevDataAnalysis.getDataType() == 138) {
                clearDate();
                return;
            }
            Log.e("CEDevQueue", "isSpeedUp=" + this.proxyBase.isSpeedUp() + " getDataType" + cEDevDataAnalysis.getDataType());
            if (this.proxyBase.isSpeedUp() && cEDevDataAnalysis.getDataType() == 131) {
                devData = null;
                this.proxyBase.sendWatchFaceTimeOut(true);
            } else if (cEDevDataAnalysis.getDataType() == 139) {
                Logger.e(Lg.getClassName(this), "无实时天气功能");
                clearDate();
            } else {
                Logger.e("TAG_GATT", "ack 错误应答" + ((int) b));
                this.bluetooth.blueToothConnectStateChange(0);
                this.bluetooth.connect(CEBlueSharedPreference.getDevAddress());
            }
        }
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase.b
    public void dataSendSucceed(byte[] bArr) {
        endSendDataTimeout();
        this.byteSendFailTimes = 0;
        CEDevData cEDevData = this.mCEDevQueueHelper.curCeDevData;
        if (cEDevData != null) {
            Logger.i(LOG_TAG, "发送的数据类型成功 type = " + cEDevData.getDataType() + "||CMD = " + cEDevData.getCmd());
            if (cEDevData.getCmd() == -10001) {
                Log.e("CEDevQueue", "data5  命令：app回复设备侧的APC命令");
                this.mCEDevQueueHelper.sendBleData();
                return;
            }
            if (cEDevData.getCurrentIndex() < cEDevData.getTotalIndex()) {
                cEDevData.setCurrentIndex(cEDevData.getCurrentIndex() + 1);
                QueueSendData sendData = this.protocol.getSendData(cEDevData);
                if (cEDevData.getDataType() != 131) {
                    this.currSendData = sendData.getSendData();
                    startSendDataTimeout();
                    this.bluetooth.sendData(sendData.index, sendData.getSendData());
                    return;
                } else if (sendData.getCurrentPackage() <= cEDevData.getTotalIndex()) {
                    this.currSendData = sendData.getSendData();
                    startSendDataTimeout();
                    this.bluetooth.sendData(sendData.index, this.currSendData);
                    return;
                }
            }
            this.sendTimeoutH.removeCallbacks(this.waitAckSendTimeoutR);
            this.sendTimeoutH.postDelayed(this.waitAckSendTimeoutR, 20000L);
        }
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase.b
    public synchronized void dataSendFailed(byte[] bArr) {
        endSendDataTimeout();
        dataSendFail(bArr);
        Logger.i(Arrays.toString(bArr));
    }

    protected void sendDevData(CEDevData cEDevData) {
        if (cEDevData == null) {
            Log.e("CEDevQueue", "topDevData为空");
            return;
        }
        cEDevData.setPriority(10);
        QueueSendData sendData = this.protocol.getSendData(cEDevData);
        this.currSendData = sendData.getSendData();
        startSendDataTimeout();
        this.bluetooth.sendData(sendData.index, this.currSendData);
    }
}
