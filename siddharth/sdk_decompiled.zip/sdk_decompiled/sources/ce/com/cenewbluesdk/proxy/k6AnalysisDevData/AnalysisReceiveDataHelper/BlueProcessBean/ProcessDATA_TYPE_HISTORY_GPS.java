package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_GPS;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import java.util.ArrayList;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_HISTORY_GPS.class */
public final class ProcessDATA_TYPE_HISTORY_GPS extends BaseK6AnalysiDevData<ArrayList<K6_GPS>> {
    public ProcessDATA_TYPE_HISTORY_GPS(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(73);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_GPS> realProcess(byte[] bArr) {
        CEDevK6Proxy.lge("DATA_TYPE_HISTORY_GPS");
        int itemSize = 3;
        int i = bArr[2] & 255;
        if (i * K6_GPS.getItemSize() != bArr.length - 3) {
            return null;
        }
        ArrayList<K6_GPS> arrayList = new ArrayList<>();
        for (int i2 = 0; i2 < i; i2++) {
            byte[] bArr2 = new byte[K6_GPS.getItemSize()];
            System.arraycopy(bArr, itemSize, bArr2, 0, K6_GPS.getItemSize());
            arrayList.add(new K6_GPS(bArr2));
            itemSize += K6_GPS.getItemSize();
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(ArrayList<K6_GPS> arrayList) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(ArrayList<K6_GPS> arrayList) {
        return false;
    }
}
