package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.IOException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessRCVD_BLUE_CONNECT_STATE_CHANGE.class */
public final class ProcessRCVD_BLUE_CONNECT_STATE_CHANGE extends BaseK6AnalysiDevData<Integer> {
    public ProcessRCVD_BLUE_CONNECT_STATE_CHANGE(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(60);
        setDataTypeStr(K6_Action.RCVD.RCVD_BLUE_CONNECT_STATE_CHANGE);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Integer realProcess(byte[] bArr) {
        return 1;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Integer num) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(Integer num) throws IOException {
        Lg.d("发送链接状态retuslt = " + num);
        Lg.e_file("Connection", "DATA_TYPE_NOUSE_result =" + num, "connection.log", true);
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), num));
        return false;
    }
}
