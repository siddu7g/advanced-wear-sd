package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DevInfoStruct;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_DEVINFO.class */
public final class ProcessDATA_TYPE_DEVINFO extends BaseK6AnalysiDevData<K6_DevInfoStruct> {
    public ProcessDATA_TYPE_DEVINFO(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(2);
        setDataTypeStr(K6_Action.RCVD.RCVD_DEVINFO);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DevInfoStruct realProcess(byte[] bArr) {
        if (bArr[0] == 12) {
            K6_DevInfoStruct.devInfoByteLen = 7;
        } else {
            K6_DevInfoStruct.devInfoByteLen = 6;
        }
        int i = K6_DevInfoStruct.devInfoByteLen;
        byte[] bArr2 = new byte[i];
        System.arraycopy(bArr, 0, bArr2, 0, i);
        K6_DevInfoStruct devInfo = K6_DevInfoStruct.parseDevInfo(bArr2);
        this.ceDevK6Proxy.setDevVersion(devInfo.getSoftwareVer());
        CEBlueSharedPreference.setCustomerId(devInfo.getCustomer_id() + "");
        CEBlueSharedPreference.setSoftwareVersion(devInfo.getSoftwareVer());
        CEDevK6Proxy.lge("设备信息" + devInfo.toString() + "devVersion=" + devInfo.getSoftwareVer());
        return devInfo;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DevInfoStruct k6_DevInfoStruct) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DevInfoStruct k6_DevInfoStruct) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_DevInfoStruct));
        return false;
    }
}
