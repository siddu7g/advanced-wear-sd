package ce.com.cenewbluesdk.proxy.connectHelp;

import android.os.Handler;
import android.os.Looper;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/connectHelp/CEConnectManager.class */
public class CEConnectManager {
    Handler mHandler = new Handler(Looper.getMainLooper());
    BLECommand curBleCommand;

    public void putQueueCmd(BLECommand bLECommand) {
    }

    public void runQueueCmd() {
    }
}
