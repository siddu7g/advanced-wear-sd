package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_ALIPAY_RAW_DATA;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_ALIPAY_RAW_DATA.class */
public final class ProcessDATA_TYPE_ALIPAY_RAW_DATA extends BaseK6AnalysiDevData<K6_DATA_TYPE_ALIPAY_RAW_DATA> {
    public ProcessDATA_TYPE_ALIPAY_RAW_DATA(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(31);
        setDataTypeStr(K6_Action.RCVD.RCVD_ALIPAY_RAW_DATA);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_ALIPAY_RAW_DATA realProcess(byte[] bArr) {
        K6_DATA_TYPE_ALIPAY_RAW_DATA k6_data_type_alipay_raw_data = new K6_DATA_TYPE_ALIPAY_RAW_DATA();
        k6_data_type_alipay_raw_data.setBytes(bArr);
        return k6_data_type_alipay_raw_data;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_ALIPAY_RAW_DATA k6_data_type_alipay_raw_data) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_ALIPAY_RAW_DATA k6_data_type_alipay_raw_data) {
        return false;
    }
}
