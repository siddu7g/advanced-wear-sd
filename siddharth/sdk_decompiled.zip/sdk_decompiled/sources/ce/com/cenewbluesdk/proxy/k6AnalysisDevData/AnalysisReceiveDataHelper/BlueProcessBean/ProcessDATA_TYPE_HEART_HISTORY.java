package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_HeartStruct;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_HEART_HISTORY.class */
public final class ProcessDATA_TYPE_HEART_HISTORY extends BaseK6AnalysiDevData<ArrayList<K6_HeartStruct>> {
    public ProcessDATA_TYPE_HEART_HISTORY(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(8);
        setDataTypeStr(K6_Action.RCVD.RCVD_DAILY_HEART);
    }

    private ArrayList<K6_HeartStruct> dealHeart(CEDevData cEDevData, int i) throws IOException {
        byte[] data = cEDevData.getData();
        Lg.e("接收到自动心率数据:", "自动心率原始数据：" + Arrays.toString(data), true);
        int length = data.length - 3;
        byte[] bArr = new byte[length];
        System.arraycopy(data, 3, bArr, 0, data.length - 3);
        if (length <= 0) {
            return null;
        }
        ArrayList<K6_HeartStruct> arrayList = K6_HeartStruct.parse(bArr);
        Lg.e("心率数据:", "自动心率：" + arrayList, true);
        return arrayList;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_HeartStruct> realProcess(byte[] bArr) {
        return null;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_HeartStruct> realProcess(CEDevData cEDevData) {
        return dealHeart(cEDevData, cEDevData.getDataType());
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(ArrayList<K6_HeartStruct> arrayList) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(ArrayList<K6_HeartStruct> arrayList) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), arrayList));
        return false;
    }
}
