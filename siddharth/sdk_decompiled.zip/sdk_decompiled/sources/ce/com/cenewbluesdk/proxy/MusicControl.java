package ce.com.cenewbluesdk.proxy;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.MusicDatas;
import ce.com.cenewbluesdk.entity.k6.K6_MusicInfo;
import ce.com.cenewbluesdk.proxy.sdkhelper.BluetoothHelper;
import ce.com.cenewbluesdk.pushmessage.NtfCollector;
import ce.com.cenewbluesdk.uitl.Lg;
import com.example.cenewbluesdk.R;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/MusicControl.class */
public class MusicControl {
    private static final boolean FLAG_SEND_MUSIC_STATE = true;
    private static final boolean FLAG_SEND_EMPTY_MUSIC_INFO = false;
    private static Set<String> sNoMusicPlayerAppSet;
    private static Set<String> sNoMusicPlayerClassSet;
    private static List<String> sPreferentialMusicPlayerAppList;
    private static ResolveInfo sPrevMusicPlayer;
    public static String MusicName = "";
    private static List<String> musicAppPgs = new ArrayList();
    private Context context;
    private Handler handler = new Handler(Looper.getMainLooper()) { // from class: ce.com.cenewbluesdk.proxy.MusicControl.1
        @Override // android.os.Handler
        public void handleMessage(Message message) {
            super.handleMessage(message);
        }
    };
    private Runnable mSendMusicStateRunnable = new Runnable() { // from class: ce.com.cenewbluesdk.proxy.MusicControl.2
        @Override // java.lang.Runnable
        public void run() {
            AudioManager audioManager = (AudioManager) MusicControl.this.context.getApplicationContext().getSystemService("audio");
            if (BluetoothHelper.getInstance().isConnectOk()) {
                MusicControl.this.sMusicInfo.setMusicstatus(audioManager.isMusicActive() ? 1 : 2);
                Log.e("rd95", "run: mSendMusicStateRunnable");
            }
        }
    };
    private K6_MusicInfo sMusicInfo = new K6_MusicInfo();
    private Runnable sSendEmptyMusicInfoRunnable = new Runnable() { // from class: ce.com.cenewbluesdk.proxy.MusicControl.3
        @Override // java.lang.Runnable
        public void run() {
            Log.e("rd95", " sSendEmptyMusicInfoRunnable");
            MusicControl.this.setAndSendMusicInfo(new K6_MusicInfo());
        }
    };

    public MusicControl(Context context) {
        musicAppPgs.add("com.jio.media.jiobeats");
        musicAppPgs.add("com.bsbportal.music");
        musicAppPgs.add("com.gaana");
        this.context = context;
    }

    public static List<String> getPreferentialMusicPlayerAppList() {
        if (sPreferentialMusicPlayerAppList == null) {
            ArrayList arrayList = new ArrayList();
            sPreferentialMusicPlayerAppList = arrayList;
            arrayList.add("com.google.android.music");
            sPreferentialMusicPlayerAppList.add("com.sonyericsson.music");
            sPreferentialMusicPlayerAppList.add("com.miui.player");
            sPreferentialMusicPlayerAppList.add("com.htc.music");
            sPreferentialMusicPlayerAppList.add("com.sec.android.app.music");
            sPreferentialMusicPlayerAppList.add("com.huawei.hwvplayer");
            sPreferentialMusicPlayerAppList.add("com.coolpad.music");
            sPreferentialMusicPlayerAppList.add("com.android.bbkmusic");
            sPreferentialMusicPlayerAppList.add("com.samsung.android.app.music.chn");
            sPreferentialMusicPlayerAppList.add("com.netease.cloudmusic");
            sPreferentialMusicPlayerAppList.add(CEBC.MUSICPACKAGE.music_qq);
            sPreferentialMusicPlayerAppList.add(CEBC.MUSICPACKAGE.music_joox);
            sPreferentialMusicPlayerAppList.add("com.kugou.android");
            sPreferentialMusicPlayerAppList.add("cn.kuwo.player");
            sPreferentialMusicPlayerAppList.add("com.spotify.music");
            sPreferentialMusicPlayerAppList.add("cmccwm.mobilemusic");
            sPreferentialMusicPlayerAppList.add("com.jio.media.jiobeats");
            sPreferentialMusicPlayerAppList.add("com.bsbportal.music");
            sPreferentialMusicPlayerAppList.add("com.gaana");
            sPreferentialMusicPlayerAppList.add("com.google.android.apps.youtube.music");
        }
        for (int i = 0; i < musicAppPgs.size(); i++) {
            if (sPreferentialMusicPlayerAppList.indexOf(musicAppPgs.get(i)) == -1) {
                sPreferentialMusicPlayerAppList.add(musicAppPgs.get(i));
            }
        }
        return sPreferentialMusicPlayerAppList;
    }

    public static Set<String> getNoMusicPlayerAppSet() {
        if (sNoMusicPlayerAppSet == null) {
            sNoMusicPlayerAppSet = new HashSet();
        }
        sNoMusicPlayerAppSet.add("com.google.android.apps.magazines");
        sNoMusicPlayerAppSet.add("com.netflix.mediaclient");
        sNoMusicPlayerAppSet.add("com.amazon.kindle");
        sNoMusicPlayerAppSet.add("net.flixster.android");
        sNoMusicPlayerAppSet.add("air.com.vudu.air.DownloaderTablet");
        sNoMusicPlayerAppSet.add("com.espn.score_center");
        sNoMusicPlayerAppSet.add("org.coursera.android");
        sNoMusicPlayerAppSet.add("com.sec.android.app.mv.player");
        sNoMusicPlayerAppSet.add("cn.wps.moffice_eng");
        sNoMusicPlayerAppSet.add("cn.xuexi.android");
        sNoMusicPlayerAppSet.add("com.alibaba.android.rimet");
        sNoMusicPlayerAppSet.add("com.xiaomi.smarthome");
        sNoMusicPlayerAppSet.add("com.alicloud.databox");
        sNoMusicPlayerAppSet.add("com.netease.newsreader.activity");
        sNoMusicPlayerAppSet.add("com.pingan.paces.ccms");
        sNoMusicPlayerAppSet.add("com.ss.android.article.news");
        sNoMusicPlayerAppSet.add("com.xiachufang");
        sNoMusicPlayerAppSet.add("com.youdao.dict");
        sNoMusicPlayerAppSet.add("com.google.android.apps.docs");
        sNoMusicPlayerAppSet.add("com.estrongs.android.pop");
        sNoMusicPlayerAppSet.add("org.autojs.autojspro");
        sNoMusicPlayerAppSet.add("com.baidu.searchbox");
        sNoMusicPlayerAppSet.add("com.baidu.netdisk");
        sNoMusicPlayerAppSet.add("com.sec.android.app.ve.vebgm");
        sNoMusicPlayerAppSet.add("org.telegram.messenger");
        sNoMusicPlayerAppSet.add("com.ss.android.ugc.aweme");
        sNoMusicPlayerAppSet.add("com.alibaba.ailabs.tg");
        sNoMusicPlayerAppSet.add("tv.danmaku.bili");
        sNoMusicPlayerAppSet.add("com.google.android.youtube");
        sNoMusicPlayerAppSet.add("com.facebook.katana");
        sNoMusicPlayerAppSet.add("com.sec.android.app.vepreload");
        return sNoMusicPlayerAppSet;
    }

    private static Set<String> getNoMusicPlayerClassSet() {
        if (sNoMusicPlayerClassSet == null) {
            HashSet hashSet = new HashSet();
            sNoMusicPlayerClassSet = hashSet;
            hashSet.add("com.sec.android.app.music.common.player.soundplayer.SoundPlayer$MediaButtonReceiver");
        }
        return sNoMusicPlayerClassSet;
    }

    private boolean equals(ResolveInfo resolveInfo, ResolveInfo resolveInfo2) {
        if (resolveInfo == resolveInfo2) {
            return true;
        }
        return (resolveInfo == null || resolveInfo2 == null || !resolveInfo.activityInfo.packageName.equals(resolveInfo2.activityInfo.packageName)) ? false : true;
    }

    public static List<String> getMyMusicList() {
        if (musicAppPgs == null) {
            musicAppPgs = new ArrayList();
        }
        return musicAppPgs;
    }

    public static List<ResolveInfo> getMyMusicAppList(Context context) {
        ArrayList arrayList = new ArrayList();
        List<String> myMusicList = getMyMusicList();
        for (int i = 0; i < myMusicList.size(); i++) {
            ResolveInfo resolveInfoFindAppByPackageName = findAppByPackageName(myMusicList.get(i), context);
            if (resolveInfoFindAppByPackageName != null) {
                arrayList.add(resolveInfoFindAppByPackageName);
            }
        }
        if (arrayList.size() > 0) {
            return arrayList;
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r0v11, types: [android.content.pm.ResolveInfo, java.lang.Exception] */
    public static ResolveInfo findAppByPackageName(String str, Context context) {
        ResolveInfo resolveInfo;
        try {
            PackageManager packageManager = context.getPackageManager();
            Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
            intent.addCategory("android.intent.category.LAUNCHER");
            intent.setPackage(str);
            List<ResolveInfo> listQueryIntentActivities = packageManager.queryIntentActivities(intent, 0);
            if (listQueryIntentActivities == null || listQueryIntentActivities.size() <= 0) {
                return null;
            }
            resolveInfo = listQueryIntentActivities.get(0);
            return resolveInfo;
        } catch (Exception unused) {
            resolveInfo.printStackTrace();
            return null;
        }
    }

    @Nullable
    public static ResolveInfo getPrefMusicPlayer(Context context) {
        List<ResolveInfo> mediaButtonReceiver = getMediaButtonReceiver(context.getPackageManager(), context);
        if (getMyMusicAppList(context) != null) {
            mediaButtonReceiver.addAll(getMyMusicAppList(context));
        }
        String musicPackageName = CEBlueSharedPreference.getMusicPackageName();
        if (mediaButtonReceiver.size() == 0) {
            return null;
        }
        if (!TextUtils.isEmpty(musicPackageName)) {
            for (ResolveInfo resolveInfo : mediaButtonReceiver) {
                if (resolveInfo.activityInfo.packageName.equals(musicPackageName)) {
                    return resolveInfo;
                }
            }
        }
        return mediaButtonReceiver.get(0);
    }

    public static List<ResolveInfo> getMediaButtonReceiver(PackageManager packageManager, Context context) {
        List<ResolveInfo> listQueryBroadcastReceivers = packageManager.queryBroadcastReceivers(new Intent("android.intent.action.MEDIA_BUTTON"), 0);
        TreeMap treeMap = new TreeMap();
        Iterator<ResolveInfo> it = listQueryBroadcastReceivers.iterator();
        while (it.hasNext()) {
            ResolveInfo next = it.next();
            String str = next.activityInfo.packageName;
            if (getNoMusicPlayerAppSet().contains(str) || getNoMusicPlayerClassSet().contains(next.activityInfo.name)) {
                it.remove();
            } else {
                int iIndexOf = getPreferentialMusicPlayerAppList().indexOf(str);
                if (iIndexOf != -1) {
                    treeMap.put(Integer.valueOf(iIndexOf), next);
                    it.remove();
                }
            }
        }
        int i = 0;
        Iterator it2 = treeMap.entrySet().iterator();
        while (it2.hasNext()) {
            int i2 = i;
            i++;
            listQueryBroadcastReceivers.add(i2, (ResolveInfo) ((Map.Entry) it2.next()).getValue());
        }
        List<ResolveInfo> myMusicAppList = getMyMusicAppList(context);
        if (myMusicAppList != null && myMusicAppList.size() > 0) {
            listQueryBroadcastReceivers.addAll(0, myMusicAppList);
        }
        return listQueryBroadcastReceivers;
    }

    public static List<MusicDatas> getControlMusic() {
        ArrayList arrayList = new ArrayList();
        MusicDatas musicDatas = new MusicDatas(CEBC.MUSICPACKAGE.music_qq, R.mipmap.icon_qqmusic);
        MusicDatas musicDatas2 = new MusicDatas(CEBC.MUSICPACKAGE.music_joox, R.mipmap.icon_joox);
        MusicDatas musicDatas3 = new MusicDatas("", R.mipmap.icon_othermusic);
        arrayList.add(musicDatas);
        arrayList.add(musicDatas2);
        arrayList.add(musicDatas3);
        return arrayList;
    }

    public static void playOrPause(String str, @NonNull Context context) {
        List<MediaController> activeSessions = ((MediaSessionManager) context.getSystemService("media_session")).getActiveSessions(new ComponentName(context, (Class<?>) NtfCollector.class));
        MediaController mediaController = null;
        if (activeSessions == null || activeSessions.size() <= 0) {
            Toast.makeText(context, "打不开该app", 0).show();
            return;
        }
        if (TextUtils.isEmpty(str)) {
            for (MediaController mediaController2 : activeSessions) {
                MediaController mediaController3 = mediaController2;
                if (CEBC.MUSICPACKAGE.music_qq.equals(mediaController2.getPackageName()) || CEBC.MUSICPACKAGE.music_joox.equals(mediaController3.getPackageName())) {
                    mediaController3 = mediaController;
                }
                mediaController = mediaController3;
            }
        } else {
            for (MediaController mediaController4 : activeSessions) {
                MediaController mediaController5 = mediaController4;
                if (!mediaController4.getPackageName().equals(str)) {
                    mediaController5 = mediaController;
                }
                mediaController = mediaController5;
            }
        }
        if (mediaController == null) {
            mediaController = activeSessions.get(0);
        }
        playOrPause(mediaController);
    }

    public static void playOrPause(MediaController mediaController) {
        mediaController.getPackageName();
        if (mediaController.getPlaybackState() == null || mediaController.getPlaybackState().getState() != 3) {
            mediaController.getTransportControls().play();
        } else {
            mediaController.getTransportControls().pause();
        }
    }

    public static void playNext(String str, Context context) throws IOException {
        List<MediaController> activeSessions = ((MediaSessionManager) context.getSystemService("media_session")).getActiveSessions(new ComponentName(context, (Class<?>) NtfCollector.class));
        Lg.e("kkkkkk", "onCreate listener: controllers size = " + activeSessions.size());
        if (activeSessions.size() > 0) {
            Lg.e("kkkkkk", "MediaController:" + activeSessions.get(0).getPackageName());
            if (Build.VERSION.SDK_INT > 29 || activeSessions.get(0).getPackageName().equals(str)) {
                activeSessions.get(0).getTransportControls().skipToNext();
            }
        }
    }

    public static void playPrevious(String str, Context context) throws IOException {
        List<MediaController> activeSessions = ((MediaSessionManager) context.getSystemService("media_session")).getActiveSessions(new ComponentName(context, (Class<?>) NtfCollector.class));
        Lg.e("kkkkkk", "onCreate listener: controllers size = " + activeSessions.size());
        if (activeSessions.size() > 0) {
            Lg.e("kkkkkk", "MediaController = " + activeSessions.get(0).getPackageName());
            if (Build.VERSION.SDK_INT > 29 || activeSessions.get(0).getPackageName().equals(str)) {
                activeSessions.get(0).getTransportControls().skipToPrevious();
            }
        }
    }

    public static boolean isHarmonyOs() {
        try {
            Class<?> cls = Class.forName("com.huawei.system.BuildEx");
            return "harmony".equalsIgnoreCase(cls.getMethod("getOsBrand", new Class[0]).invoke(cls, new Object[0]).toString());
        } catch (Throwable unused) {
            return false;
        }
    }

    public static boolean isOnlyHuaweiMusic(Context context) {
        int i;
        List<ResolveInfo> listQueryBroadcastReceivers = context.getPackageManager().queryBroadcastReceivers(new Intent("android.intent.action.MEDIA_BUTTON"), 0);
        if (isHarmonyOs()) {
            i = 0;
            while (i < listQueryBroadcastReceivers.size()) {
                if ("com.huawei.music".equalsIgnoreCase(listQueryBroadcastReceivers.get(i).activityInfo.packageName)) {
                    break;
                }
                i++;
            }
            i = -1;
        } else {
            i = -1;
        }
        return listQueryBroadcastReceivers.size() == 1 && i != -1;
    }

    public void setAndSendMusicInfo(K6_MusicInfo k6_MusicInfo) {
        Log.e("rd95", " setAndSendMusicInfo ----1 info = " + k6_MusicInfo + ";sMusicInfo =" + this.sMusicInfo);
        if (k6_MusicInfo.equals(this.sMusicInfo)) {
            return;
        }
        this.sMusicInfo = k6_MusicInfo;
        if (BluetoothHelper.getInstance().isConnectOk()) {
            postSendMusicState(500);
        }
    }

    public void postSendMusicState(int i) {
        this.handler.removeCallbacks(this.mSendMusicStateRunnable);
        this.handler.postDelayed(this.mSendMusicStateRunnable, i);
    }

    public void addNoMusicPlayer(Set<String> set) {
        if (sNoMusicPlayerAppSet == null) {
            sNoMusicPlayerAppSet = new HashSet();
        }
        if (set == null || set.size() <= 0) {
            return;
        }
        sNoMusicPlayerAppSet.addAll(set);
    }

    public Boolean isNoSupportRemoteController(String str) {
        if (TextUtils.isEmpty(str)) {
            return Boolean.FALSE;
        }
        getPreferentialMusicPlayerAppList();
        if (sPreferentialMusicPlayerAppList.contains(str) && !"com.netease.cloudmusic".equals(str)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public Boolean isExistMusicApp(String str) {
        getPreferentialMusicPlayerAppList();
        return Boolean.valueOf(sPreferentialMusicPlayerAppList.contains(str));
    }

    public int getKeyCodeByCmd(int i) {
        int i2 = -1;
        switch (i) {
            case 1:
                i2 = 126;
                break;
            case 2:
                i2 = 127;
                break;
            case 3:
                i2 = 86;
                break;
            case 4:
                i2 = 88;
                break;
            case 5:
                i2 = 87;
                break;
            case 6:
                i2 = 85;
                break;
        }
        return i2;
    }

    public void openMusicApplication() {
        ResolveInfo prefMusicPlayer = getPrefMusicPlayer(this.context);
        if (prefMusicPlayer != null) {
            ActivityInfo activityInfo = prefMusicPlayer.activityInfo;
            Intent launchIntentForPackage = this.context.getPackageManager().getLaunchIntentForPackage(new ComponentName(activityInfo.packageName, activityInfo.name).getPackageName());
            if (launchIntentForPackage != null) {
                launchIntentForPackage.setFlags(268435456);
                this.context.startActivity(launchIntentForPackage);
            }
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v11 ??, still in use, count: 1, list:
          (r1v11 ?? I:android.content.Intent) from 0x0116: INVOKE (r1v11 ?? I:android.content.Intent), (r1v10 ?? I:android.content.ComponentName) VIRTUAL call: android.content.Intent.setComponent(android.content.ComponentName):android.content.Intent A[MD:(android.content.ComponentName):android.content.Intent (c)]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public void sendMusicControlBroadcastFortest(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v11 ??, still in use, count: 1, list:
          (r1v11 ?? I:android.content.Intent) from 0x0116: INVOKE (r1v11 ?? I:android.content.Intent), (r1v10 ?? I:android.content.ComponentName) VIRTUAL call: android.content.Intent.setComponent(android.content.ComponentName):android.content.Intent A[MD:(android.content.ComponentName):android.content.Intent (c)]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */

    public void postSendEmptyMusicInfo() {
        Log.e("rd95", " postSendEmptyMusicInfo ----1");
    }

    public void addMusicApp(List<String> list) {
        if (musicAppPgs == null) {
            musicAppPgs = new ArrayList();
        }
        if (musicAppPgs.size() <= 0) {
            if (list == null || list.size() <= 0) {
                return;
            }
            musicAppPgs.addAll(list);
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            if (musicAppPgs.indexOf(list.get(i)) == -1) {
                musicAppPgs.add(list.get(i));
            }
        }
    }
}
