package ce.com.cenewbluesdk.proxy.interfaces;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/interfaces/K6BleDataResult.class */
public interface K6BleDataResult<M> {
    boolean bleDataResult(M m);
}
