package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.proxy.interfaces.K6BleDataResult;
import ce.com.cenewbluesdk.uitl.Lg;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/BaseK6AnalysiDevData.class */
public abstract class BaseK6AnalysiDevData<M> {
    protected CEDevK6Proxy ceDevK6Proxy;
    List<Integer> myDataType = new ArrayList();
    protected String dataTypeStr;
    protected K6BleDataResult<M> mMK6BleDataResult;

    public BaseK6AnalysiDevData(CEDevK6Proxy cEDevK6Proxy) {
        this.ceDevK6Proxy = cEDevK6Proxy;
    }

    protected void setDataTypeStr(String str) {
        this.dataTypeStr = str;
    }

    protected String getDataTypeStr() {
        return this.dataTypeStr;
    }

    protected void addDataType(int i) {
        this.myDataType.add(Integer.valueOf(i));
    }

    protected abstract M realProcess(byte[] bArr);

    protected M realProcess(CEDevData cEDevData) {
        return null;
    }

    protected boolean process(CEDevData cEDevData) {
        if (cEDevData == null || cEDevData.getData() == null || cEDevData.getData().length == 0 || !isMy(cEDevData.getDataType()) || this.ceDevK6Proxy == null) {
            return false;
        }
        try {
            if (preProcessResult(realProcess(cEDevData.getData()))) {
                return true;
            }
            return preProcessResult(realProcess(cEDevData));
        } catch (Exception e) {
            e.printStackTrace();
            Lg.e("AnalysiDevData exception" + e.getMessage());
            return false;
        }
    }

    public boolean isMy(int i) {
        Iterator<Integer> it = this.myDataType.iterator();
        while (it.hasNext()) {
            if (i == it.next().intValue()) {
                return true;
            }
        }
        return false;
    }

    public boolean isMyStr(String str) {
        String str2;
        if (str == null || (str2 = this.dataTypeStr) == null) {
            return false;
        }
        return str2.equals(str);
    }

    public void setMK6BleDataResult(K6BleDataResult<M> k6BleDataResult) {
        this.mMK6BleDataResult = k6BleDataResult;
    }

    protected abstract boolean processResult(M m);

    protected abstract boolean sendMsg(M m);

    public boolean preProcessResult(M m) {
        if (m == null) {
            return false;
        }
        K6BleDataResult<M> k6BleDataResult = this.mMK6BleDataResult;
        if (k6BleDataResult == null) {
            processResult(m);
        } else {
            k6BleDataResult.bleDataResult(m);
        }
        sendMsg(m);
        return true;
    }
}
