package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.content.Context;
import ce.com.cenewbluesdk.entity.ModifyWatchInfo;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_QR_CODE_INFO;
import ce.com.cenewbluesdk.proxy.interfaces.OnCreateBinFileListener;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/ITransfer.class */
public interface ITransfer {
    void setContext(Context context);

    void getModifyDial(ModifyWatchInfo modifyWatchInfo, int i, int i2, OnCreateBinFileListener onCreateBinFileListener);

    String getModifyDial(ModifyWatchInfo modifyWatchInfo, int i, int i2);

    void sendPrepareDial();

    void startMoreFileTrans(String str);

    void startFileTrans(String str);

    void otaUpgrade(String str, String str2, String str3);

    void sendQRInfo(K6_DATA_TYPE_QR_CODE_INFO k6_data_type_qr_code_info);
}
