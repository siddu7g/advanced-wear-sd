package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import android.text.TextUtils;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import java.io.IOException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_ANDROID_BTEDR_ADDR.class */
public final class ProcessDATA_TYPE_ANDROID_BTEDR_ADDR extends BaseK6AnalysiDevData {
    private byte[] edrMac;

    public ProcessDATA_TYPE_ANDROID_BTEDR_ADDR(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        this.edrMac = new byte[6];
        addDataType(39);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_ANDROID_BTEDR_ADDR);
    }

    private String formatBelMac(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.setLength(0);
        for (int length = str.split(":").length - 1; length >= 0; length--) {
            sb.append(str.split(":")[length]).append(":");
        }
        return sb.substring(0, sb.length() - 1);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Object realProcess(byte[] bArr) throws IOException {
        Lg.e("edr_地址原数据", bArr);
        int i = bArr[0] & 255;
        if (i != 1) {
            return null;
        }
        System.arraycopy(bArr, 1, this.edrMac, 0, 6);
        formatBelMac(ByteUtil.byteToHexString(this.edrMac));
        String jSONObject = new JSONObject();
        try {
            jSONObject.put("status", Integer.valueOf(i));
            jSONObject.put("edrMacStr", this.edrMac);
            jSONObject = jSONObject.toString();
            CEBlueSharedPreference.setPhoneEdrMac(jSONObject);
            return null;
        } catch (JSONException unused) {
            jSONObject.printStackTrace();
            return null;
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Object obj) {
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    protected boolean sendMsg(Object obj) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), 0));
        return false;
    }
}
