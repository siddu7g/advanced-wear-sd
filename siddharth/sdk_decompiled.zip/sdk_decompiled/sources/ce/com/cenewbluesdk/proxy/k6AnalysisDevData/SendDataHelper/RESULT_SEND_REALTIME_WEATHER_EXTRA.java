package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.SendDataHelper;

import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/SendDataHelper/RESULT_SEND_REALTIME_WEATHER_EXTRA.class */
public class RESULT_SEND_REALTIME_WEATHER_EXTRA extends BaseSendDataResultBean {
    public RESULT_SEND_REALTIME_WEATHER_EXTRA(CEDevK6Proxy cEDevK6Proxy) {
        super(CEBC.K6.DATA_TYPE_EXTERN_WEATHER, K6_Action.SEND_R.SEND_REAL_TIME_WEATHER_EXTRA, cEDevK6Proxy);
    }
}
