package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import android.util.Log;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Logger;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_WATCH_FACE_SYNC.class */
public final class ProcessDATA_TYPE_WATCH_FACE_SYNC extends BaseK6AnalysiDevData {
    byte[] payload;

    public ProcessDATA_TYPE_WATCH_FACE_SYNC(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(131);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_WATCH_FACE_SYNC);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Object realProcess(byte[] bArr) {
        Log.e("WATCH_FACE_SYNC", "同步表盘数据");
        this.payload = bArr;
        Logger.i("FileTransControl", "传输设备回复ACK =  " + ((int) bArr[0]));
        this.ceDevK6Proxy.dealFileData(bArr);
        return Boolean.TRUE;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Object obj) {
        return false;
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase, ce.com.cenewbluesdk.proxy.CEDevK6Proxy, java.lang.Exception] */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    protected boolean sendMsg(Object obj) {
        ?? r2;
        try {
            r2 = this.ceDevK6Proxy;
            String dataTypeStr = getDataTypeStr();
            byte[] bArr = this.payload;
            r2.sendMeg(r2.createMessage(dataTypeStr, bArr != null ? bArr[0] : (byte) 0));
            return false;
        } catch (Exception unused) {
            r2.printStackTrace();
            return false;
        }
    }
}
