package ce.com.cenewbluesdk.proxy.interfaces;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/interfaces/OnBlueScanCompleteListener.class */
public interface OnBlueScanCompleteListener {
    void onBlueScanComplete();
}
