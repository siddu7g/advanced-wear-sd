package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_Sleep;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import java.util.ArrayList;
import java.util.Arrays;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_SLEEP.class */
public final class ProcessDATA_TYPE_SLEEP extends BaseK6AnalysiDevData<ArrayList<K6_Sleep>> {
    private static final String TAG = "ProcessDATA_TYPE_SLEEP";

    public ProcessDATA_TYPE_SLEEP(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(6);
        setDataTypeStr(K6_Action.RCVD.RCVD_SLEEP_DATA);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_Sleep> realProcess(byte[] bArr) {
        int i = bArr[2] & 255;
        int i2 = 3;
        byte[] bArr2 = new byte[4];
        ArrayList<K6_Sleep> arrayList = new ArrayList<>();
        for (int i3 = 0; i3 < i; i3++) {
            int i4 = i2;
            i2 = i4 + 1;
            int i5 = bArr[i4] & 255;
            Lg.e("sleep12 睡眠总段数:" + i + "items" + i5 + "当前段数:" + i3 + "设备睡眠数据:" + arrayList.toString() + " datas=" + Arrays.toString(bArr));
            for (int i6 = 0; i6 < 15; i6++) {
                int i7 = i6;
                int i8 = i2;
                int i9 = i8 + 1;
                int i10 = bArr[i8] & 255;
                System.arraycopy(bArr, i9, bArr2, 0, 4);
                K6_Sleep k6_Sleep = new K6_Sleep(i10, ByteUtil.byte4ToInt(bArr2));
                i2 = i9 + 4;
                if (i7 < i5) {
                    arrayList.add(k6_Sleep);
                }
            }
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(ArrayList<K6_Sleep> arrayList) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(ArrayList<K6_Sleep> arrayList) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), arrayList));
        return false;
    }
}
