package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.fileprint.FileLogPrint;

@Deprecated
/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_TEST_DEBUG.class */
public final class ProcessDATA_TYPE_TEST_DEBUG extends BaseK6AnalysiDevData {
    public ProcessDATA_TYPE_TEST_DEBUG(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(CEBC.K6.DATA_TYPE_TEST_DEBUG);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Object realProcess(byte[] bArr) {
        CEDevK6Proxy.lge("dealDATA_TYPE_TEST_DEBUG");
        byte[] bArr2 = new byte[20];
        int i = bArr[2] & 255;
        int i2 = 3;
        for (int i3 = 0; i3 < i; i3++) {
            for (int i4 = 0; i4 < 20; i4++) {
                System.arraycopy(bArr, i2, bArr2, 0, 20);
            }
            i2 += 20;
            FileLogPrint.PrintBlueTestData(bArr2);
        }
        return Boolean.TRUE;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Object obj) {
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    protected boolean sendMsg(Object obj) {
        return false;
    }
}
