package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WATCH_FACE_START;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_WATCH_FACE_START.class */
public class ProcessDATA_TYPE_WATCH_FACE_START extends BaseK6AnalysiDevData<K6_DATA_TYPE_WATCH_FACE_START> {
    public ProcessDATA_TYPE_WATCH_FACE_START(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(134);
        setDataTypeStr(K6_Action.RCVD.RCVD_K6_DATA_TYPE_WATCH_FACE_START);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_WATCH_FACE_START realProcess(byte[] bArr) {
        K6_DATA_TYPE_WATCH_FACE_START k6_data_type_watch_face_start = new K6_DATA_TYPE_WATCH_FACE_START();
        k6_data_type_watch_face_start.setTimeOut(false);
        return k6_data_type_watch_face_start;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_WATCH_FACE_START k6_data_type_watch_face_start) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_WATCH_FACE_START k6_data_type_watch_face_start) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_data_type_watch_face_start));
        return false;
    }
}
