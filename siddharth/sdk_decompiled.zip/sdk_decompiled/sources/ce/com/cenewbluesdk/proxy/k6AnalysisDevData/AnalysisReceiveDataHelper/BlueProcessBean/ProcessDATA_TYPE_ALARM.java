package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_SendAlarmInfoStruct;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_ALARM.class */
public final class ProcessDATA_TYPE_ALARM extends BaseK6AnalysiDevData<ArrayList<K6_SendAlarmInfoStruct>> {
    protected ProcessDATA_TYPE_ALARM(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(106);
        setDataTypeStr(K6_Action.RCVD.RCVD_ALARM);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_SendAlarmInfoStruct> realProcess(byte[] bArr) {
        CEDevK6Proxy.lge("DATA_TYPE_ALARM");
        byte b = bArr[0];
        CEDevK6Proxy.lge("闹钟信息 num=" + ((int) b));
        ArrayList<K6_SendAlarmInfoStruct> arrayList = new ArrayList<>();
        for (int i = 0; i < b; i++) {
            int i2 = (i * 5) + 1;
            arrayList.add(new K6_SendAlarmInfoStruct(bArr[i2 + 1] & 255, bArr[i2 + 2] & 255, bArr[i2 + 3] & 255, bArr[i2 + 4] & 255, ""));
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(ArrayList<K6_SendAlarmInfoStruct> arrayList) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(ArrayList<K6_SendAlarmInfoStruct> arrayList) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), arrayList));
        return true;
    }
}
