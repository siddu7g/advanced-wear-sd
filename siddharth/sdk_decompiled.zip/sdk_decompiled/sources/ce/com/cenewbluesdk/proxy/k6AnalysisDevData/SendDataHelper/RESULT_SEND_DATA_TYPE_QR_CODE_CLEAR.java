package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.SendDataHelper;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/SendDataHelper/RESULT_SEND_DATA_TYPE_QR_CODE_CLEAR.class */
public class RESULT_SEND_DATA_TYPE_QR_CODE_CLEAR extends BaseSendDataResultBean {
    public RESULT_SEND_DATA_TYPE_QR_CODE_CLEAR(CEDevK6Proxy cEDevK6Proxy) {
        super(28, K6_Action.SEND_R.SEND_K6_DATA_TYPE_QR_CODE_CLEAR, cEDevK6Proxy);
    }
}
