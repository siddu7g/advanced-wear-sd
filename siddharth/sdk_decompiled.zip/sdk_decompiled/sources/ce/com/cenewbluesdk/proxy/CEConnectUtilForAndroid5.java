package ce.com.cenewbluesdk.proxy;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.a.a;
import ce.com.cenewbluesdk.bluetooth.CEBlueToothBase;
import ce.com.cenewbluesdk.bluetooth.a.c;
import ce.com.cenewbluesdk.entity.MyBleDevice;
import ce.com.cenewbluesdk.scan.CEScanDevBase;
import ce.com.cenewbluesdk.scan.CEScanDev_4_Android5;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import ce.com.cenewbluesdk.uitl.TimeUtil;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEConnectUtilForAndroid5.class */
public class CEConnectUtilForAndroid5 extends BroadcastReceiver implements CEBlueToothBase.a {
    public static String Action_Reconnect = "reconnect_dev_action";
    public static boolean offScreen = false;
    public static int SCAN_INTERVAL_TIME = 60000;
    private int currConnectState;
    private Context context;
    private CEBlueToothBase blueTooth;
    private CEBluetoothProxyBase proxyBase;
    private String blueAddress;
    boolean blueListenerIsOpened;
    CEScanDev_4_Android5 mCEScanDev_4_android5;
    JobScheduler scheduler;
    private boolean broadHaveregister = false;
    boolean blueSwitch = true;
    CEScanDevBase.FindBlueTooth5 mFindBlueTooth5 = new CEScanDevBase.FindBlueTooth5() { // from class: ce.com.cenewbluesdk.proxy.CEConnectUtilForAndroid5.1
        @Override // ce.com.cenewbluesdk.scan.CEScanDevBase.FindBlueTooth5
        public void findDev(int i, final ScanResult scanResult) {
            CEConnectUtilForAndroid5.this.unRegistScan();
            CEBlueSharedPreference.getInstance(CEConnectUtilForAndroid5.this.context).setScanStartTime(0L);
            Lg.e("扫描结果:" + scanResult.getDevice());
            CEConnectUtilForAndroid5.this.mHandler.postDelayed(new Runnable() { // from class: ce.com.cenewbluesdk.proxy.CEConnectUtilForAndroid5.1.1
                @Override // java.lang.Runnable
                public void run() {
                    CEConnectUtilForAndroid5.this.connect(scanResult.getDevice());
                }
            }, 500L);
        }

        @Override // ce.com.cenewbluesdk.scan.CEScanDevBase.FindBlueTooth5
        public void findDevList(int i, ScanResult scanResult, List<MyBleDevice> list, MyBleDevice myBleDevice) {
        }
    };
    Handler mHandler = new Handler(Looper.getMainLooper()) { // from class: ce.com.cenewbluesdk.proxy.CEConnectUtilForAndroid5.2
        @Override // android.os.Handler
        public void handleMessage(@NonNull Message message) {
            super.handleMessage(message);
            CEConnectUtilForAndroid5 cEConnectUtilForAndroid5 = CEConnectUtilForAndroid5.this;
            cEConnectUtilForAndroid5.reconnectDev(cEConnectUtilForAndroid5.blueAddress);
        }
    };
    int id = 1222;
    public BroadcastReceiver mReceiver = new BroadcastReceiver() { // from class: ce.com.cenewbluesdk.proxy.CEConnectUtilForAndroid5.3
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) throws IOException {
            String action = intent.getAction();
            action.hashCode();
            if (action.equals("android.bluetooth.adapter.action.STATE_CHANGED")) {
                int intExtra = intent.getIntExtra("android.bluetooth.adapter.extra.STATE", 0);
                if (intExtra != 10) {
                    if (intExtra != 12) {
                        return;
                    }
                    Lg.e("蓝牙打开le");
                    CEConnectUtilForAndroid5.this.mHandler.postDelayed(new Runnable() { // from class: ce.com.cenewbluesdk.proxy.CEConnectUtilForAndroid5.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Logger.i("bind", "开始绑定-connect2");
                            CEConnectUtilForAndroid5.this.connect(CEBlueSharedPreference.getDevAddress());
                        }
                    }, 500L);
                    return;
                }
                Lg.e("蓝牙关闭了");
                CEConnectUtilForAndroid5.this.mCEScanDev_4_android5.setScanFinish(true);
                BleFactory.getInstance().getK6Proxy().disConnect();
                CEConnectUtilForAndroid5.this.blueToothConnectStateChange(0);
                CEConnectUtilForAndroid5.this.mHandler.removeCallbacksAndMessages(null);
                CEConnectUtilForAndroid5.this.unRegistScan();
            }
        }
    };

    /* JADX WARN: Type inference failed for: r0v0, types: [int, java.lang.Exception] */
    private void reconnectRegist() {
        ?? r0 = Build.VERSION.SDK_INT;
        if (r0 >= 21) {
            try {
                JobInfo.Builder builder = new JobInfo.Builder(this.id, new ComponentName(this.context, (Class<?>) JobSchedulerService.class));
                builder.setPeriodic(SCAN_INTERVAL_TIME);
                if (r0 >= 24) {
                    builder.setPeriodic(JobInfo.getMinPeriodMillis(), JobInfo.getMinFlexMillis());
                }
                builder.setPersisted(true);
                this.scheduler.schedule(builder.build());
            } catch (Exception unused) {
                r0.printStackTrace();
            }
        }
    }

    public CEConnectUtilForAndroid5(Context context, a aVar, CEBluetoothProxyBase cEBluetoothProxyBase, CEBlueToothBase cEBlueToothBase) {
        this.blueListenerIsOpened = false;
        this.context = context;
        this.proxyBase = cEBluetoothProxyBase;
        this.blueTooth = cEBlueToothBase;
        cEBlueToothBase.setBlueStateChangeListen(this);
        this.mCEScanDev_4_android5 = new CEScanDev_4_Android5(context, this.mFindBlueTooth5);
        registerRece();
        if (context != null) {
            this.scheduler = (JobScheduler) context.getSystemService("jobscheduler");
        }
        reconnectRegist();
        if (this.blueListenerIsOpened) {
            return;
        }
        if (context != null) {
            if (Build.VERSION.SDK_INT >= 26) {
                context.registerReceiver(this.mReceiver, makeFilter(), 2);
            } else {
                context.registerReceiver(this.mReceiver, makeFilter());
            }
        }
        this.blueListenerIsOpened = true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    private void registerRece() {
        ?? RegisterReceiver;
        try {
            boolean z = this.broadHaveregister;
            RegisterReceiver = z;
            if (!z) {
                this.broadHaveregister = true;
                IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction(Action_Reconnect + this.proxyBase.getClassName());
                intentFilter.addAction("android.intent.action.SCREEN_ON");
                intentFilter.addAction("android.intent.action.SCREEN_OFF");
                intentFilter.addAction("android.intent.action.PACKAGE_CHANGED");
                intentFilter.addAction("android.bluetooth.device.action.BOND_STATE_CHANGED");
                RegisterReceiver = Build.VERSION.SDK_INT >= 26 ? this.context.registerReceiver(this, intentFilter, 2) : this.context.registerReceiver(this, intentFilter);
            }
        } catch (Exception unused) {
            RegisterReceiver.printStackTrace();
        }
    }

    private void registScan() {
        Lg.e("registScan" + TimeUtil.c2String(Calendar.getInstance()));
        if (this.currConnectState != 0 || this.mCEScanDev_4_android5.isScan()) {
            return;
        }
        Lg.e("registScan ok" + TimeUtil.c2String(Calendar.getInstance()));
        CEBlueSharedPreference.getInstance(this.context).setScanStartTime(System.currentTimeMillis());
        this.mCEScanDev_4_android5.startScan(this.blueAddress);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void unRegistScan() {
        Lg.e("unRegistScan" + TimeUtil.c2String(Calendar.getInstance()));
        if (this.mCEScanDev_4_android5.isScan()) {
            Lg.e("unRegistScan ok" + TimeUtil.c2String(Calendar.getInstance()));
            this.mCEScanDev_4_android5.stopScan();
        }
    }

    public void connect(BluetoothDevice bluetoothDevice) {
        this.blueTooth.connect(bluetoothDevice);
    }

    protected void setCurrConnectState(int i) {
        this.currConnectState = i;
        this.proxyBase.blueToothConnectStateChange(i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [android.app.job.JobScheduler] */
    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase.a
    public void blueToothConnectStateChange(int i) throws IOException {
        if (!this.blueListenerIsOpened) {
            if (Build.VERSION.SDK_INT >= 26) {
                this.context.registerReceiver(this.mReceiver, makeFilter(), 2);
            } else {
                this.context.registerReceiver(this.mReceiver, makeFilter());
            }
            this.blueListenerIsOpened = true;
        }
        this.blueSwitch = BleSystemUtils.getBluetoothAdapter(this.context).isEnabled();
        setCurrConnectState(i);
        Lg.e("YAN_BlueAddressK6对比：", this.currConnectState + ":1");
        int i2 = this.currConnectState;
        if (i2 != 0) {
            ?? r0 = i2;
            if (r0 == 1) {
                try {
                    r0 = this.scheduler;
                    r0.cancel(this.id);
                    return;
                } catch (Exception unused) {
                    r0.printStackTrace();
                    return;
                }
            }
            return;
        }
        if (TextUtils.isEmpty(this.blueAddress)) {
            Lg.e("当前没有绑定设备");
            return;
        }
        reconnectRegist();
        if (!this.blueSwitch) {
            Lg.e("YAN_blueIsClosed", "蓝牙关闭状态  地址不为空");
        } else {
            Lg.e("YAN_blueIsOpened", "蓝牙开启状态 地址不为空");
            reconnectDev(this.blueAddress);
        }
    }

    public CEScanDevBase.FindBlueTooth5 getFindBlueTooth5() {
        return this.mFindBlueTooth5;
    }

    public String getBlueAddress() {
        return this.blueAddress;
    }

    public void setBlueAddress(String str) {
        this.blueAddress = str;
    }

    public void connect(String str) {
        if (this.context == null) {
            this.context = BleFactory.context;
        }
        if (this.currConnectState == 0 || CEBlueSharedPreference.getkey_connect_states() == 0) {
            Logger.i("bind", "开始绑定-connectDev3");
            Lg.e_file("Connection", "CEConnectUtilForAndroid5-connect", "connection.log", true);
            unRegistScan();
            this.blueAddress = str;
            this.blueTooth.connect(str);
            startAlarmTasks();
            registerRece();
        }
    }

    /* JADX WARN: Type inference failed for: r0v8, types: [android.content.Context, java.lang.Throwable] */
    public void disConnect() {
        ?? r0;
        try {
            Lg.e("CEConnectUtil disConnect ");
            this.blueAddress = "";
            unRegistScan();
            if (this.broadHaveregister) {
                this.broadHaveregister = false;
                r0 = this.context;
                if (r0 != 0) {
                    r0.unregisterReceiver(this);
                }
            }
        } catch (Error unused) {
            r0.printStackTrace();
            this.blueTooth.disConnect();
        } catch (Exception unused2) {
            r0.printStackTrace();
            this.blueTooth.disConnect();
        }
        this.blueTooth.disConnect();
    }

    public void forceTestDisConnect() {
        Lg.e("CEConnectUtil forceTestDisConnect ");
        this.blueTooth.disConnect();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [ce.com.cenewbluesdk.proxy.CEConnectUtilForAndroid5] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v12, types: [ce.com.cenewbluesdk.scan.CEScanDev_4_Android5] */
    public void reconnectDev(String str) {
        ?? r0 = this;
        Lg.e("CEConnectUtil reconnectDev mac:" + str + " blueAddress:" + this.blueAddress);
        r0.blueAddress = str;
        try {
            if (!BleSystemUtils.getBluetoothAdapter(r0.context).isEnabled() || TextUtils.isEmpty(this.blueAddress)) {
                return;
            }
            registScan();
            if (this.mCEScanDev_4_android5.isScan()) {
                r0 = this.mCEScanDev_4_android5;
                r0.reset(this.blueAddress);
            }
        } catch (Exception unused) {
            r0.printStackTrace();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v29, types: [android.content.Context] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v31, types: [ce.com.cenewbluesdk.bluetooth.a.c] */
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) throws SecurityException, IOException {
        offScreen = false;
        if (!intent.getAction().equals("android.intent.action.TIME_TICK")) {
            if (!intent.getAction().equals("android.intent.action.SCREEN_ON")) {
                if (!intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
                    if (!intent.getAction().equals("android.intent.action.BATTERY_CHANGED")) {
                        if (!intent.getAction().equals("android.intent.action.PACKAGE_CHANGED")) {
                            if (!intent.getAction().equals(Action_Reconnect + this.proxyBase.getClassName())) {
                                if (intent.getAction().equals("android.bluetooth.device.action.BOND_STATE_CHANGED")) {
                                    Logger.e("BleConnectToolBOND_STATE_CHANGED");
                                    BluetoothDevice bluetoothDevice = (BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE");
                                    int bondState = bluetoothDevice.getBondState();
                                    blueToothConnectStateChange(getCurrConnectState());
                                    switch (bondState) {
                                        case 10:
                                            Logger.e("BleConnectTool已解除配对");
                                            Lg.e("edr_连接", "edr_连接 已解除配对", true);
                                            break;
                                        case 11:
                                            Logger.e("BleConnectTool正在配对...");
                                            Lg.e("edr_连接", "edr_连接 正在配对...", true);
                                            break;
                                        case 12:
                                            ?? A = context;
                                            Logger.e("BleConnectTool已配对");
                                            Lg.e("edr_连接", "edr_连接 已配对", true);
                                            try {
                                                A = c.a((Context) A);
                                                A.a(bluetoothDevice, c.a(context).c());
                                                break;
                                            } catch (Exception unused) {
                                                Logger.d("BleConnectTool", "连接HID exception");
                                                A.printStackTrace();
                                                break;
                                            }
                                    }
                                }
                            } else {
                                Logger.e("Action_Reconnect" + Action_Reconnect);
                                startAlarmTasks();
                                connect(CEBlueSharedPreference.getDevAddress());
                            }
                        } else {
                            Logger.e("ACTION_PACKAGE_CHANGED");
                        }
                    } else {
                        Logger.e("timeBroad", "电量改变了");
                    }
                } else {
                    Logger.e("timeBroad", "屏幕关闭了");
                    offScreen = true;
                    ce.com.cenewbluesdk.pushmessage.a.b(context);
                }
            } else {
                Logger.e("timeBroad", "屏幕解锁了");
                ce.com.cenewbluesdk.pushmessage.a.b(context);
            }
        } else {
            Logger.e("timeBroad", "时间变化了");
        }
        if (this.mCEScanDev_4_android5.isScan()) {
            this.mCEScanDev_4_android5.reset(this.blueAddress);
        }
    }

    public int getCurrConnectState() {
        return this.currConnectState;
    }

    public IntentFilter makeFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.adapter.action.STATE_CHANGED");
        return intentFilter;
    }

    public void startAlarmTasks() {
    }
}
