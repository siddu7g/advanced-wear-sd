package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_SMS_REPLY;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_SMS_REPLY.class */
public final class ProcessDATA_TYPE_SMS_REPLY extends BaseK6AnalysiDevData<K6_DATA_TYPE_SMS_REPLY> {
    private K6_DATA_TYPE_SMS_REPLY smsReply;

    public ProcessDATA_TYPE_SMS_REPLY(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(30);
        setDataTypeStr(K6_Action.RCVD.RCVD_SMS_REPLY);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_SMS_REPLY realProcess(byte[] bArr) {
        K6_DATA_TYPE_SMS_REPLY k6_data_type_sms_reply = new K6_DATA_TYPE_SMS_REPLY(bArr[0]);
        this.smsReply = k6_data_type_sms_reply;
        return k6_data_type_sms_reply;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_SMS_REPLY k6_data_type_sms_reply) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_SMS_REPLY k6_data_type_sms_reply) {
        return false;
    }
}
