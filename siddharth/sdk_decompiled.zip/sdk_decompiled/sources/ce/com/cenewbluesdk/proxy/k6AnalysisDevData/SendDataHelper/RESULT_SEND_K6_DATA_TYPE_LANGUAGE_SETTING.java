package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.SendDataHelper;

import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/SendDataHelper/RESULT_SEND_K6_DATA_TYPE_LANGUAGE_SETTING.class */
public class RESULT_SEND_K6_DATA_TYPE_LANGUAGE_SETTING extends BaseSendDataResultBean {
    public RESULT_SEND_K6_DATA_TYPE_LANGUAGE_SETTING(CEDevK6Proxy cEDevK6Proxy) {
        super(105, "SEND_K6_DATA_TYPE_REAL_ECG", cEDevK6Proxy);
    }
}
