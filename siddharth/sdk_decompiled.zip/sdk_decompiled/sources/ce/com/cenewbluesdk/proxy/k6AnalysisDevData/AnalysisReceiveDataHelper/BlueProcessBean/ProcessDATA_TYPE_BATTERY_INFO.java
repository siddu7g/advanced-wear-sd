package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_BATTERY_INFO;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.IOException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_BATTERY_INFO.class */
public final class ProcessDATA_TYPE_BATTERY_INFO extends BaseK6AnalysiDevData<K6_DATA_TYPE_BATTERY_INFO> {
    private boolean chargerStatus;

    public ProcessDATA_TYPE_BATTERY_INFO(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(3);
        setDataTypeStr(K6_Action.RCVD.RCVD_BATTERY);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_BATTERY_INFO realProcess(byte[] bArr) throws IOException {
        Lg.e("ProcessDATA_TYPE_BATTERY_INFO", "电量：" + (bArr[0] & 255), true);
        CEBlueSharedPreference.setKEY_DEVICEBATTERY((bArr[0] & 255) + "");
        int i = bArr[0] & 255;
        if (bArr.length > 1) {
            this.chargerStatus = (bArr[1] & 255) == 1;
        }
        return new K6_DATA_TYPE_BATTERY_INFO(i, this.chargerStatus);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_BATTERY_INFO k6_data_type_battery_info) {
        CEBlueSharedPreference.setKEY_DEVICEBATTERY(k6_data_type_battery_info + "");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_BATTERY_INFO k6_data_type_battery_info) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_data_type_battery_info));
        return false;
    }
}
