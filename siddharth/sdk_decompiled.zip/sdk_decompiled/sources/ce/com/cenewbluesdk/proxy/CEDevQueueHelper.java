package ce.com.cenewbluesdk.proxy;

import android.util.Log;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDevQueueHelper.class */
public class CEDevQueueHelper {
    private static final int SEND_WAIT_DATA_COME = 0;
    private static final int SEND_COMPLETE = 1;
    private static final int sendWaitAck = 2;
    CEDevQueue ceDevQueue;
    public int sendState;
    CEDevData curCeDevData;
    ExecutorService executorService;
    TackAndSendBle tackAndSendBle;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDevQueueHelper$TackAndSendBle.class */
    static class TackAndSendBle implements Runnable {
        CEDevQueue ceDevQueue;
        CEDevQueueHelper ceDevQueueHelper;

        public TackAndSendBle(CEDevQueue cEDevQueue, CEDevQueueHelper cEDevQueueHelper) {
            this.ceDevQueue = cEDevQueue;
            this.ceDevQueueHelper = cEDevQueueHelper;
        }

        public void setCeDevQueue(CEDevQueue cEDevQueue) {
            this.ceDevQueue = cEDevQueue;
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            InterruptedException interruptedExceptionE;
            try {
                CEDevQueueHelper cEDevQueueHelper = this.ceDevQueueHelper;
                if (cEDevQueueHelper.sendState == 1) {
                    cEDevQueueHelper.sendState = 0;
                    cEDevQueueHelper.curCeDevData = this.ceDevQueue.sendQueue.take();
                    Logger.i("CHENGUIRUI", "c-68=" + this.ceDevQueueHelper.curCeDevData.getDataType());
                    this.ceDevQueue.sendDevData(this.ceDevQueueHelper.curCeDevData);
                    this.ceDevQueueHelper.sendState = 1;
                    CEDevQueue cEDevQueue = this.ceDevQueue;
                    interruptedExceptionE = cEDevQueue;
                    if (cEDevQueue != null) {
                        ArrayBlockingQueue<CEDevData> arrayBlockingQueue = cEDevQueue.sendQueue;
                        interruptedExceptionE = arrayBlockingQueue;
                        if (arrayBlockingQueue != null) {
                            String className = Lg.getClassName(this);
                            Logger.e(className, "push size " + this.ceDevQueue.sendQueue.size());
                            interruptedExceptionE = className;
                        }
                    }
                } else {
                    interruptedExceptionE = Log.e("CEDevQueueHelper", "TackAndSendBle current is SEND_WAIT_DATA_COME");
                }
            } catch (InterruptedException unused) {
                interruptedExceptionE.printStackTrace();
                Lg.e("获取消息队列消息出错");
            } catch (Exception unused2) {
                interruptedExceptionE.printStackTrace();
                Lg.e("获取消息队列消息出错2");
            }
        }
    }

    private TackAndSendBle getTackAndSWendBle(CEDevQueue cEDevQueue) {
        TackAndSendBle tackAndSendBle = this.tackAndSendBle;
        if (tackAndSendBle != null) {
            tackAndSendBle.setCeDevQueue(cEDevQueue);
            return this.tackAndSendBle;
        }
        TackAndSendBle tackAndSendBle2 = new TackAndSendBle(cEDevQueue, this);
        this.tackAndSendBle = tackAndSendBle2;
        return tackAndSendBle2;
    }

    public CEDevQueueHelper(CEDevQueue cEDevQueue) {
        this.sendState = 1;
        this.ceDevQueue = cEDevQueue;
        ExecutorService executorServiceNewSingleThreadExecutor = Executors.newSingleThreadExecutor();
        this.executorService = executorServiceNewSingleThreadExecutor;
        this.sendState = 1;
        executorServiceNewSingleThreadExecutor.execute(getTackAndSWendBle(cEDevQueue));
    }

    public void clear() {
        if (!this.executorService.isShutdown()) {
            this.executorService.shutdownNow();
        }
        ExecutorService executorServiceNewSingleThreadExecutor = Executors.newSingleThreadExecutor();
        this.executorService = executorServiceNewSingleThreadExecutor;
        this.sendState = 1;
        this.curCeDevData = null;
        this.tackAndSendBle = null;
        executorServiceNewSingleThreadExecutor.execute(getTackAndSWendBle(this.ceDevQueue));
    }

    public void sendBleData() {
        this.executorService.execute(getTackAndSWendBle(this.ceDevQueue));
    }
}
