package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6NoDisturbSummary;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_NoDisturb;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import java.io.Serializable;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_FORGET_DISTURB.class */
public final class ProcessDATA_TYPE_FORGET_DISTURB extends BaseK6AnalysiDevData<K6NoDisturbSummary> {
    int swit;

    public ProcessDATA_TYPE_FORGET_DISTURB(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(115);
        setDataTypeStr(K6_Action.RCVD.RCVD_NO_DISTURB);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6NoDisturbSummary realProcess(byte[] bArr) {
        int i = bArr[1] & 255;
        this.swit = bArr[0] & 255;
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < i; i2++) {
            byte[] bArr2 = new byte[4];
            System.arraycopy(bArr, (i2 * 4) + 2, bArr2, 0, 4);
            arrayList.add(new K6_NoDisturb(bArr2));
        }
        return new K6NoDisturbSummary(this.swit, arrayList);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6NoDisturbSummary k6NoDisturbSummary) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6NoDisturbSummary k6NoDisturbSummary) {
        if (k6NoDisturbSummary == null || k6NoDisturbSummary.getList().size() <= 0) {
            CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
            cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), (Serializable) null, this.swit));
            return false;
        }
        CEDevK6Proxy cEDevK6Proxy2 = this.ceDevK6Proxy;
        cEDevK6Proxy2.sendMeg(cEDevK6Proxy2.createMessage(getDataTypeStr(), k6NoDisturbSummary.getList().get(0), this.swit));
        return false;
    }
}
