package ce.com.cenewbluesdk.proxy.connectHelp;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/connectHelp/CECONECT_CMD.class */
public class CECONECT_CMD {
    public static final int CONNECT = 1;
    public static final int RE_CONNECT = 2;
    public static final int DISCONNECT = 3;
    public static final int FIND_SERVICE = 4;
    public static final int READ_CHARACTOR = 5;
    public static final int SCAN = 6;
}
