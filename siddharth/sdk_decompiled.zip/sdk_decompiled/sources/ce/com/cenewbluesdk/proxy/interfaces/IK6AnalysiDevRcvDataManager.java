package ce.com.cenewbluesdk.proxy.interfaces;

import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/interfaces/IK6AnalysiDevRcvDataManager.class */
public interface IK6AnalysiDevRcvDataManager {
    void process(CEDevData cEDevData);

    <M> void addBleDataResultListener(String str, K6BleDataResult<M> k6BleDataResult);

    BaseK6AnalysiDevData getResultListenerByDataTypeStr(String str);
}
