package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_MixInfoStruct;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_DEV_SYNC.class */
public final class ProcessDATA_TYPE_DEV_SYNC extends BaseK6AnalysiDevData {
    List<BaseK6AnalysiDevData> list;

    public ProcessDATA_TYPE_DEV_SYNC(CEDevK6Proxy cEDevK6Proxy, K6AnalysiDevRcvDataManager k6AnalysiDevRcvDataManager) {
        super(cEDevK6Proxy);
        this.list = new ArrayList();
        addDataType(9);
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_ALARM));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_DEV_UNITSET));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_DEVINFO));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_BATTERY));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_WATCH_FACE_AND_NOTIFICATION_SET));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_OTA_INFO));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_NO_DISTURB));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_SITTING_REMIND));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_K6_DATA_TYPE_HEART_AUTO_SWITCH));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_TYPE_TARGET_ALARM));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_K6_DATA_TYPE_DRINK_ALARM));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_TIME_TYPE));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_K6_DATA_TYPE_HAND_RISE_SWITCH));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_FUNCTION_CONTROL));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_K6_DATA_TYPE_WOMAN_STAGE_INFO));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_HARDWARE_INFO));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_BTEDR_ADDR));
        this.list.add(k6AnalysiDevRcvDataManager.getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_GESTURE_DATA));
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Object realProcess(byte[] bArr) {
        for (K6_MixInfoStruct.Property property : K6_MixInfoStruct.parse(bArr).getList()) {
            int date_type = property.getDate_type() & 255;
            for (BaseK6AnalysiDevData baseK6AnalysiDevData : this.list) {
                if (baseK6AnalysiDevData.isMy(date_type)) {
                    baseK6AnalysiDevData.preProcessResult(baseK6AnalysiDevData.realProcess(property.getData()));
                }
            }
        }
        this.ceDevK6Proxy.deal_RCVD_DATA_TYPE_DEV_SYNC();
        return Boolean.TRUE;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Object obj) {
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    protected boolean sendMsg(Object obj) {
        this.ceDevK6Proxy.deal_RCVD_DATA_TYPE_DEV_SYNC();
        return false;
    }
}
