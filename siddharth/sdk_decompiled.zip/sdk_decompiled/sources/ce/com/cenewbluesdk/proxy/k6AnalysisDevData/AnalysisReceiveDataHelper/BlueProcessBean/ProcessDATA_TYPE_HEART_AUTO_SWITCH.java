package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_HEART_AUTO_SWITCH;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.IOException;
import java.util.Arrays;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_HEART_AUTO_SWITCH.class */
public final class ProcessDATA_TYPE_HEART_AUTO_SWITCH extends BaseK6AnalysiDevData<K6_DATA_TYPE_HEART_AUTO_SWITCH> {
    public ProcessDATA_TYPE_HEART_AUTO_SWITCH(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(128);
        setDataTypeStr(K6_Action.RCVD.RCVD_K6_DATA_TYPE_HEART_AUTO_SWITCH);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_HEART_AUTO_SWITCH realProcess(byte[] bArr) throws IOException {
        Lg.e("心率自动检测:", "自动检测开关状态源数据：" + Arrays.toString(bArr), true);
        K6_DATA_TYPE_HEART_AUTO_SWITCH k6_data_type_heart_auto_switch = new K6_DATA_TYPE_HEART_AUTO_SWITCH(bArr);
        Lg.e("心率自动检测:", "自动检测开关状态：" + k6_data_type_heart_auto_switch, true);
        return k6_data_type_heart_auto_switch;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_HEART_AUTO_SWITCH k6_data_type_heart_auto_switch) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_HEART_AUTO_SWITCH k6_data_type_heart_auto_switch) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_data_type_heart_auto_switch));
        return false;
    }
}
