package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_Mix_sport_Struct;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.d;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_MIX_SPORT.class */
public final class ProcessDATA_TYPE_MIX_SPORT extends BaseK6AnalysiDevData<ArrayList<K6_Mix_sport_Struct>> {
    public ProcessDATA_TYPE_MIX_SPORT(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(10);
        setDataTypeStr(K6_Action.RCVD.RCVD_MIX_SPORT_DATA);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_Mix_sport_Struct> realProcess(byte[] bArr) {
        int i = bArr[2] & 255;
        int length = bArr.length - 3;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 3, bArr2, 0, bArr.length - 3);
        d dVar = new d(bArr2);
        ArrayList<K6_Mix_sport_Struct> arrayList = new ArrayList<>();
        short s = 0;
        while (true) {
            short s2 = s;
            if (s2 >= i) {
                break;
            }
            try {
                arrayList.add(K6_Mix_sport_Struct.parse(dVar.b(length / i)));
                s = (short) (s2 + 1);
            } catch (Exception unused) {
            }
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(ArrayList<K6_Mix_sport_Struct> arrayList) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(ArrayList<K6_Mix_sport_Struct> arrayList) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), arrayList));
        return false;
    }
}
