package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_SEND_APP_SPORT_STRUCT;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.IOException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_APP_SPORT.class */
public final class ProcessDATA_TYPE_APP_SPORT extends BaseK6AnalysiDevData<K6_SEND_APP_SPORT_STRUCT> {
    public ProcessDATA_TYPE_APP_SPORT(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(130);
        setDataTypeStr(K6_Action.RCVD.RCVD_APP_SPORT);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_SEND_APP_SPORT_STRUCT realProcess(byte[] bArr) {
        return new K6_SEND_APP_SPORT_STRUCT(bArr);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_SEND_APP_SPORT_STRUCT k6_send_app_sport_struct) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_SEND_APP_SPORT_STRUCT k6_send_app_sport_struct) throws IOException {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_send_app_sport_struct));
        Lg.e("liu", "收到设备运动状态 ceDevData=" + k6_send_app_sport_struct);
        if (BleFactory.getInstance().appIsRunning()) {
            return false;
        }
        Lg.e("liu", "主进程已被杀死，发送停止运动指令");
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendAppSport(new K6_SEND_APP_SPORT_STRUCT(k6_send_app_sport_struct.getType(), 0, k6_send_app_sport_struct.getTime(), k6_send_app_sport_struct.getDistance()));
        return false;
    }
}
