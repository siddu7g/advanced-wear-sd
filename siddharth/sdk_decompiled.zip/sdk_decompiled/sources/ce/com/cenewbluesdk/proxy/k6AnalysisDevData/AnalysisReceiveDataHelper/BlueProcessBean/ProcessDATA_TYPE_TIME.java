package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_CESyncTime;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import java.util.Arrays;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_TIME.class */
public final class ProcessDATA_TYPE_TIME extends BaseK6AnalysiDevData<K6_CESyncTime> {
    public ProcessDATA_TYPE_TIME(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(104);
        setDataTypeStr(K6_Action.RCVD.RCVD_TIME_TYPE);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_CESyncTime realProcess(byte[] bArr) {
        CEDevK6Proxy.lge("接收到了时间类型" + Arrays.toString(bArr));
        if (bArr.length < 9) {
            return null;
        }
        K6_CESyncTime k6_CESyncTime = new K6_CESyncTime(bArr);
        CEBlueSharedPreference.setAppTimeDisplay(k6_CESyncTime.getFormat() + "");
        CEBlueSharedPreference.setAppDateDisplay(k6_CESyncTime.getMdFormat() + "");
        return k6_CESyncTime;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_CESyncTime k6_CESyncTime) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_CESyncTime k6_CESyncTime) {
        CEDevK6Proxy.lge("接收到了时间类型 sendMsg" + k6_CESyncTime);
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_CESyncTime));
        return false;
    }
}
