package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_FUNCTION_CONTROL;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_FUNCTION_CONTROL.class */
public final class ProcessDATA_TYPE_FUNCTION_CONTROL extends BaseK6AnalysiDevData<K6_DATA_TYPE_FUNCTION_CONTROL> {
    public ProcessDATA_TYPE_FUNCTION_CONTROL(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(22);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_FUNCTION_CONTROL);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_DATA_TYPE_FUNCTION_CONTROL realProcess(byte[] bArr) {
        K6_DATA_TYPE_FUNCTION_CONTROL k6_data_type_function_control = new K6_DATA_TYPE_FUNCTION_CONTROL(bArr);
        CEBlueSharedPreference.setNewWeatherType(k6_data_type_function_control.getWeatherType() + "");
        CEBlueSharedPreference.setEdrBackConnect(k6_data_type_function_control.isSupportEdrBackConnect() + "");
        return k6_data_type_function_control;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_DATA_TYPE_FUNCTION_CONTROL k6_data_type_function_control) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_DATA_TYPE_FUNCTION_CONTROL k6_data_type_function_control) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_data_type_function_control));
        return false;
    }
}
