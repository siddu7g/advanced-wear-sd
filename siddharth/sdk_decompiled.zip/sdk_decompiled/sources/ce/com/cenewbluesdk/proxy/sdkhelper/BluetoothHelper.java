package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Handler;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.MusicControl;
import ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.OnBlueScanCompleteListener;
import ce.com.cenewbluesdk.proxy.interfaces.OnScanDevListener;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/BluetoothHelper.class */
public class BluetoothHelper implements IBluetoothProcessor {
    private static BluetoothHelper bluetoothHelper;
    private static IBluetoothProcessor mIBluetoothProcessor;

    public static BluetoothHelper getInstance() {
        if (bluetoothHelper == null) {
            bluetoothHelper = new BluetoothHelper();
        }
        return bluetoothHelper;
    }

    public void init() {
        if (mIBluetoothProcessor == null) {
            mIBluetoothProcessor = new Bluetooth_5SDK_Processor();
        }
    }

    public void init(Context context) {
        if (mIBluetoothProcessor == null) {
            mIBluetoothProcessor = new Bluetooth_5SDK_Processor(context);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void onDestroy() {
        BleFactory.getInstance().init(null);
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.onDestroy();
        }
        mIBluetoothProcessor = null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void initProxy(Context context) {
        BleFactory.getInstance().init(context);
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.initProxy(context);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Context getContext() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getContext();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void startPairSynData() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.startPairSynData();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void synDevData() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.synDevData();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void devicePairFinish(int i) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.devicePairFinish(i);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Persistent getPersistent() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getPersistent();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Transfer getTransfer() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getTransfer();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public SendBlueToothData getSendBlueData() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getSendBlueData();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public IK6AnalysiDevRcvDataManager getRcvDataManager() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getRcvDataManager();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public IK6SendDataManager getSendDataManager() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getSendDataManager();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public boolean isEnabled() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.isEnabled();
        }
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setHandler(Handler handler) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.setHandler(handler);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Handler getBlueHandler() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getBlueHandler();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setBlueScanComplete(OnBlueScanCompleteListener onBlueScanCompleteListener) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.setBlueScanComplete(onBlueScanCompleteListener);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void scanningDeviceInit(Context context, OnScanDevListener onScanDevListener) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.scanningDeviceInit(context, onScanDevListener);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setScanTimeOut(int i) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.setScanTimeOut(i);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void stopScan() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.stopScan();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void startScan() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.startScan();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void startScan(String str) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.startScan(str);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    @Deprecated
    public void connectDev(String str) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.connectDev(str);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void connectDev(String str, String str2) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.connectDev(str, str2);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void disConnect() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.disConnect();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public boolean isConnectOk() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.isConnectOk();
        }
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setEnableGsDataTrans(boolean z) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.setEnableGsDataTrans(z);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setEnableGsDataTrans() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.setEnableGsDataTrans();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public boolean reConnectDirect() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.reConnectDirect();
        }
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public MusicControl getMusicControl() {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            return iBluetoothProcessor.getMusicControl();
        }
        return null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void connectDevice(String str, String str2) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.connectDevice(str, str2);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void removeBond(BluetoothDevice bluetoothDevice) {
        IBluetoothProcessor iBluetoothProcessor = mIBluetoothProcessor;
        if (iBluetoothProcessor != null) {
            iBluetoothProcessor.removeBond(bluetoothDevice);
        }
    }
}
