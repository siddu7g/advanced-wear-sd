package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WATCH_FACE_INFO;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.Lg;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_WATCH_FACE_INFO.class */
public final class ProcessDATA_TYPE_WATCH_FACE_INFO extends BaseK6AnalysiDevData {
    public ProcessDATA_TYPE_WATCH_FACE_INFO(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(132);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_WATCH_FACE_INFO);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Object realProcess(byte[] bArr) {
        K6_DATA_TYPE_WATCH_FACE_INFO k6_data_type_watch_face_info = null;
        if (bArr != null) {
            k6_data_type_watch_face_info = k6_data_type_watch_face_info;
            K6_DATA_TYPE_WATCH_FACE_INFO k6_data_type_watch_face_info2 = new K6_DATA_TYPE_WATCH_FACE_INFO(bArr);
        }
        K6_DATA_TYPE_WATCH_FACE_INFO k6_data_type_watch_face_info3 = k6_data_type_watch_face_info;
        Lg.d("接收到表盘同步信息" + k6_data_type_watch_face_info);
        this.ceDevK6Proxy.dealFileInfo(k6_data_type_watch_face_info);
        return k6_data_type_watch_face_info3;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Object obj) {
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    protected boolean sendMsg(Object obj) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), (K6_DATA_TYPE_WATCH_FACE_INFO) obj));
        return false;
    }
}
