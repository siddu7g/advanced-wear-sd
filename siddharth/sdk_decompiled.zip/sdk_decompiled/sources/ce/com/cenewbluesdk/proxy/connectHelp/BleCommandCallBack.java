package ce.com.cenewbluesdk.proxy.connectHelp;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/connectHelp/BleCommandCallBack.class */
public interface BleCommandCallBack<M> {
    boolean bleDataResult(M m);
}
