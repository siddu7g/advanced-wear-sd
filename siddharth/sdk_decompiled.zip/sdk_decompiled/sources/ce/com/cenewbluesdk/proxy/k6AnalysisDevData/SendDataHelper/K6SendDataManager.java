package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.SendDataHelper;

import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_CESyncTime;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_AI_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_CALL_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_CONTACT_SYNC;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_DRINK_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_FIND_PHONE_OR_DEVICE;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_HAND_RISE_SWITCH;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_HEART_AUTO_SWITCH;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_LANGUAGE_SETTING;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_MESSAGE_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_MUSIC_CONTROL;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_NAVIGATION;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_REAL_BP;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_REAL_ECG;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_REAL_HR;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_REAL_HRV;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_REAL_O2;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_TARGET_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_TEST_TOOL;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WATCH_FACE_START;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WATCH_FACE_SYN_NNNOMAL_CHOICE;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_WOMAN_STAGE_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_ExerciseState;
import ce.com.cenewbluesdk.entity.k6.K6_MessageNoticeStruct;
import ce.com.cenewbluesdk.entity.k6.K6_MixInfoStruct;
import ce.com.cenewbluesdk.entity.k6.K6_MusicInfo;
import ce.com.cenewbluesdk.entity.k6.K6_NoDisturb;
import ce.com.cenewbluesdk.entity.k6.K6_PairStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SEND_APP_SPORT_STRUCT;
import ce.com.cenewbluesdk.entity.k6.K6_SendAlarmInfoStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SendCurrentLocationInfo;
import ce.com.cenewbluesdk.entity.k6.K6_SendDevSettingStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SendGoal;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeather;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeatherExtra;
import ce.com.cenewbluesdk.entity.k6.K6_SendUserInfo;
import ce.com.cenewbluesdk.entity.k6.K6_SendWeatherStruct;
import ce.com.cenewbluesdk.entity.k6.K6_Send_Watch_Face_And_Notification_Set;
import ce.com.cenewbluesdk.entity.k6.K6_SittingRemind;
import ce.com.cenewbluesdk.entity.k6.K6_UnitSettingStruct;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.K6BleDataResult;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import ce.com.cenewbluesdk.uitl.TimeUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/SendDataHelper/K6SendDataManager.class */
public class K6SendDataManager implements IK6SendDataManager {
    private ArrayList<BaseSendDataResultBean> resultSendDataList;
    CEDevK6Proxy mCEDevK6Proxy;
    private int volumeNum;

    public K6SendDataManager(CEDevK6Proxy cEDevK6Proxy) {
        ArrayList<BaseSendDataResultBean> arrayList = new ArrayList<>();
        this.resultSendDataList = arrayList;
        this.mCEDevK6Proxy = cEDevK6Proxy;
        arrayList.add(new RESULT_REQUEST_SEND_ASYN_INFO(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_ALARM(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_APP_SPORT_STRUCT(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_FIND_PHONE(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_HAND_RISE_SWITCH(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DEV_GOAL(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DEV_UNITSET(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_FORGET_DISTURB(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_DRINK_ALARM(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_HEART_AUTO_SWITCH(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_REAL_BP(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_REAL_ECG(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_REAL_O2(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_MESSAGE_NOTICE(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_MUSIC_CONTROLL_SET(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_PAIR_FINISH(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_RESTART_SET(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_SET_DATA_SWITCH(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_SET_PHOTO_SWITCH(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_SITTING_REMIND(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_TIME(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_TYPE_TARGET_ALARM(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_USER_INFO(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_WEATHER_STRUCT(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_MIX_INFO(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_LANGUAGE_SETTING(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_WOMAN_STAGE_INFO(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_CONTACT_SYNC(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_CONTACT_DELETE(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_CONTACT_ADD(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_REALTIME_WEATHER(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_REALTIME_WEATHER_EXTRA(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_QR_CODE_INFO(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_QR_CODE_DEL(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_QR_CODE_CLEAR(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_PHOTO_WATCHFACE_DEL(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_K6_DATA_TYPE_POWER_LOGO_DEL(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_ALARMCLOCK(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_CURRENT_LOCATION(cEDevK6Proxy));
        this.resultSendDataList.add(new RESULT_SEND_DATA_TYPE_CHECK_HEART_RATE_V(cEDevK6Proxy));
    }

    private void push(CEDevData cEDevData) {
        CEDevK6Proxy cEDevK6Proxy = this.mCEDevK6Proxy;
        if (cEDevK6Proxy != null) {
            cEDevK6Proxy.sendData(cEDevData);
        }
    }

    public void processResult(int i, int i2) {
        Iterator<BaseSendDataResultBean> it = this.resultSendDataList.iterator();
        while (it.hasNext()) {
            it.next().processResult(i, i2);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void addSendDataResultListener(String str, K6BleDataResult<Integer> k6BleDataResult) {
        Iterator<BaseSendDataResultBean> it = this.resultSendDataList.iterator();
        while (it.hasNext()) {
            BaseSendDataResultBean next = it.next();
            if (next.isMyStr(str)) {
                next.setK6BleDataResult(k6BleDataResult);
                return;
            }
        }
    }

    public void setVolume(int i) {
        this.volumeNum = i;
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception, java.util.ArrayList, java.util.List] */
    public void sendAynInfoDetail() {
        if (this.mCEDevK6Proxy.newMsgNtf != null) {
            long jNow = TimeUtil.now();
            CEDevK6Proxy cEDevK6Proxy = this.mCEDevK6Proxy;
            if (jNow - cEDevK6Proxy.newMsgNtf.absTimeValue > 180000) {
                cEDevK6Proxy.getSendHelper().sendMessage_notice(this.mCEDevK6Proxy.newMsgNtf);
            }
        }
        this.mCEDevK6Proxy.newMsgNtf = null;
        ?? arrayList = new ArrayList();
        try {
            HashMap appDeviceUserInfo = CEBlueSharedPreference.getAppDeviceUserInfo();
            if (appDeviceUserInfo != null) {
                int iIntValue = ((Integer) appDeviceUserInfo.get("userId")).intValue();
                int i = ((Integer) appDeviceUserInfo.get("userSex")).intValue() == 1 ? 0 : 1;
                int iIntValue2 = ((Integer) appDeviceUserInfo.get("userAge")).intValue();
                int i2 = iIntValue2;
                if (iIntValue2 < 1) {
                    i2 = 20;
                }
                int iIntValue3 = ((Integer) appDeviceUserInfo.get("userHeight")).intValue();
                int iIntValue4 = ((Integer) appDeviceUserInfo.get("userWeight")).intValue();
                Lg.e("qob", "userID: " + iIntValue + " sex: " + i + " age: " + i2 + " height: " + iIntValue3 + " weight: " + iIntValue4);
                arrayList.add(new K6_MixInfoStruct.Property((byte) 102, new K6_SendUserInfo(iIntValue, i, i2, iIntValue3, iIntValue4, 0).getBytes()));
            }
            arrayList.add(new K6_MixInfoStruct.Property((byte) 104, K6_CESyncTime.getCurrentTime().getBytes()));
            byte[] bArr = new byte[5];
            bArr[0] = 1;
            bArr[1] = -1;
            bArr[2] = -1;
            bArr[3] = 0;
            bArr[4] = 0;
            arrayList.add(new K6_MixInfoStruct.Property((byte) 124, bArr));
            arrayList.add(new K6_MixInfoStruct.Property((byte) 122, new K6_DATA_TYPE_CALL_ALARM(1).getBytes()));
            arrayList.add(new K6_MixInfoStruct.Property((byte) 123, new K6_DATA_TYPE_MESSAGE_ALARM(1).getBytes()));
            CEDevData cEDevData = new CEDevData(1, 103);
            byte[] bArr2 = new byte[1];
            bArr2[0] = (byte) (BleSystemUtils.getSystemLanguageStatus() & 255);
            cEDevData.setData(bArr2);
            arrayList.add(new K6_MixInfoStruct.Property((byte) 103, cEDevData.getData()));
            Log.e("qob", "AppFront: " + CEBlueSharedPreference.getAppFrontState());
            CEDevData cEDevData2 = new CEDevData(1, 109);
            cEDevData2.setData(new byte[]{1});
            arrayList.add(new K6_MixInfoStruct.Property((byte) 109, cEDevData2.getData()));
            arrayList.add(new K6_MixInfoStruct.Property((byte) 111, new K6_SendGoal(CEBlueSharedPreference.getTargetStep(), CEBlueSharedPreference.getTargetDistance(), CEBlueSharedPreference.getTargetCalorie(), CEBlueSharedPreference.getTargetSleep(), CEBlueSharedPreference.getTargetDuration()).getBytes()));
        } catch (Exception unused) {
            arrayList.printStackTrace();
        }
        byte[] bArr3 = {0, 0};
        if (TextUtils.isEmpty(BleFactory.getInstance().getK6Proxy().getBlueAddress()) || CEBlueSharedPreference.getAppPairFinish() == 0) {
            bArr3[0] = 1;
            CEBlueSharedPreference.setAppPairFinish("1");
        }
        arrayList.add(new K6_MixInfoStruct.Property((byte) 120, bArr3));
        this.mCEDevK6Proxy.getSendHelper().sendMixInfo(new K6_MixInfoStruct(arrayList));
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendAsynInfo() {
        sendAynInfoDetail();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Exception, java.util.ArrayList, java.util.List] */
    public void sendSynDevData() {
        ?? arrayList = new ArrayList();
        try {
            HashMap appDeviceUserInfo = CEBlueSharedPreference.getAppDeviceUserInfo();
            if (appDeviceUserInfo != null) {
                int iIntValue = ((Integer) appDeviceUserInfo.get("userId")).intValue();
                int i = ((Integer) appDeviceUserInfo.get("userSex")).intValue() == 1 ? 0 : 1;
                int iIntValue2 = ((Integer) appDeviceUserInfo.get("userAge")).intValue();
                int i2 = iIntValue2;
                if (iIntValue2 < 1) {
                    i2 = 20;
                }
                int iIntValue3 = ((Integer) appDeviceUserInfo.get("userHeight")).intValue();
                int iIntValue4 = ((Integer) appDeviceUserInfo.get("userWeight")).intValue();
                Lg.e("qob", "userID: " + iIntValue + " sex: " + i + " age: " + i2 + " height: " + iIntValue3 + " weight: " + iIntValue4);
                arrayList.add(new K6_MixInfoStruct.Property((byte) 102, new K6_SendUserInfo(iIntValue, i, i2, iIntValue3, iIntValue4, 0).getBytes()));
            }
            arrayList.add(new K6_MixInfoStruct.Property((byte) 104, K6_CESyncTime.getCurrentTime().getBytes()));
            byte[] bArr = new byte[5];
            bArr[0] = 1;
            bArr[1] = -1;
            bArr[2] = -1;
            bArr[3] = 0;
            bArr[4] = 0;
            arrayList.add(new K6_MixInfoStruct.Property((byte) 124, bArr));
            arrayList.add(new K6_MixInfoStruct.Property((byte) 122, new K6_DATA_TYPE_CALL_ALARM(1).getBytes()));
            arrayList.add(new K6_MixInfoStruct.Property((byte) 123, new K6_DATA_TYPE_MESSAGE_ALARM(1).getBytes()));
            CEDevData cEDevData = new CEDevData(1, 103);
            byte[] bArr2 = new byte[1];
            bArr2[0] = (byte) (BleSystemUtils.getSystemLanguageStatus() & 255);
            cEDevData.setData(bArr2);
            arrayList.add(new K6_MixInfoStruct.Property((byte) 103, cEDevData.getData()));
            int appFrontState = CEBlueSharedPreference.getAppFrontState();
            Log.e("qob", "AppFront: " + appFrontState);
            CEDevData cEDevData2 = new CEDevData(1, 109);
            byte b = 0;
            if (appFrontState == 1) {
                b = 1;
            }
            cEDevData2.setData(new byte[]{b});
            arrayList.add(new K6_MixInfoStruct.Property((byte) 109, cEDevData2.getData()));
            arrayList.add(new K6_MixInfoStruct.Property((byte) 111, new K6_SendGoal(CEBlueSharedPreference.getTargetStep(), CEBlueSharedPreference.getTargetDistance(), CEBlueSharedPreference.getTargetCalorie(), CEBlueSharedPreference.getTargetSleep(), CEBlueSharedPreference.getTargetDuration()).getBytes()));
        } catch (Exception unused) {
            arrayList.printStackTrace();
        }
        this.mCEDevK6Proxy.getSendHelper().sendMixInfo(new K6_MixInfoStruct(arrayList));
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendUserInfo(K6_SendUserInfo k6_SendUserInfo) {
        push(k6_SendUserInfo.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendTime(K6_CESyncTime k6_CESyncTime) {
        Log.e("YAN_SEND_DATA", "Send_Time!!");
        push(k6_CESyncTime.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendLanguageSetting() {
        Log.e("YAN_SEND_DATA", "Send_Time!!");
        push(new K6_DATA_TYPE_LANGUAGE_SETTING().toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendSetting(K6_SendDevSettingStruct k6_SendDevSettingStruct) {
        push(k6_SendDevSettingStruct.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendUnitSetting(K6_UnitSettingStruct k6_UnitSettingStruct) {
        push(k6_UnitSettingStruct.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void getDevInfo() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(3);
        cEDevData.setDataType(2);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendAlarmInfo(ArrayList<K6_SendAlarmInfoStruct> arrayList) {
        int itemSize = (K6_SendAlarmInfoStruct.getItemSize() * arrayList.size()) + 1;
        byte[] bArr = new byte[itemSize];
        CEDevK6Proxy.lge("发送闹钟设置信息,共" + arrayList.size() + "组闹钟");
        bArr[0] = (byte) arrayList.size();
        for (int i = 0; i < arrayList.size(); i++) {
            K6_SendAlarmInfoStruct k6_SendAlarmInfoStruct = arrayList.get(i);
            System.arraycopy(k6_SendAlarmInfoStruct.getBytes(), 0, bArr, (i * K6_SendAlarmInfoStruct.getItemSize()) + 1, K6_SendAlarmInfoStruct.getItemSize());
            CEDevK6Proxy.lge("发送闹钟设置信息, 第" + i + "组 hour: " + ((int) k6_SendAlarmInfoStruct.getHour()) + " min " + ((int) k6_SendAlarmInfoStruct.getMin()));
        }
        CEDevK6Proxy.lge("发送闹钟设置信息,payload : " + Arrays.toString(bArr));
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(106);
        cEDevData.setItemL(itemSize);
        cEDevData.setItemNumber(1);
        cEDevData.setData(bArr);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendAddContacts(K6_DATA_TYPE_CONTACT_SYNC k6_data_type_contact_sync) {
        push(k6_data_type_contact_sync.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendContactsSync(int i) {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(138);
        cEDevData.setItemL((i + "").getBytes().length);
        cEDevData.setItemNumber(1);
        cEDevData.setData((i + "").getBytes());
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendDelContacts(int i) {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(136);
        cEDevData.setItemL((i + "").getBytes().length);
        cEDevData.setItemNumber(1);
        cEDevData.setData((i + "").getBytes());
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendClearContacts() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(137);
        cEDevData.setItemL("0".getBytes().length);
        cEDevData.setItemNumber(1);
        cEDevData.setData("0".getBytes());
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendMessage_notice(long j, String str, String str2, byte b) throws IOException {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        Lg.e("liu", "通知类信息开始发送给设备侧了。");
        K6_MessageNoticeStruct k6_MessageNoticeStruct = new K6_MessageNoticeStruct(j, b);
        k6_MessageNoticeStruct.setSendContext(str, (byte) 2, str2);
        if (this.mCEDevK6Proxy != null) {
            sendMessage_notice(k6_MessageNoticeStruct);
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendMessage_notice(K6_MessageNoticeStruct k6_MessageNoticeStruct) {
        if (this.mCEDevK6Proxy != null) {
            push(k6_MessageNoticeStruct.toCEDevData());
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendWeatherInfo(K6_SendWeatherStruct k6_SendWeatherStruct) {
        Logger.i("CHENGUIRUI", "c-4");
        push(k6_SendWeatherStruct.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendGoal(K6_SendGoal k6_SendGoal) {
        push(k6_SendGoal.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendMusicInfo(K6_MusicInfo k6_MusicInfo) {
        push(k6_MusicInfo.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void setEnableGsDataTrans(boolean z) {
        CEDevK6Proxy.lge("YAN_SEND_DATA Data_Switch!! =" + z);
        CEBlueSharedPreference.setAppFrontState(z ? "1" : "0");
        CEDevData cEDevData = new CEDevData(1, 109);
        cEDevData.setData(new byte[]{z ? (byte) 1 : (byte) 0});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void setEnableGsDataTrans() {
        int appFrontState = CEBlueSharedPreference.getAppFrontState();
        CEDevK6Proxy.lge("zhou   AppFront: " + appFrontState);
        CEDevData cEDevData = new CEDevData(1, 109);
        byte b = 0;
        if (appFrontState == 1) {
            b = 1;
        }
        cEDevData.setData(new byte[]{b});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendMixInfo(K6_MixInfoStruct k6_MixInfoStruct) {
        byte[] bytes = k6_MixInfoStruct.getBytes();
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(110);
        cEDevData.setItemL(bytes.length);
        cEDevData.setItemNumber(1);
        cEDevData.setData(bytes);
        push(k6_MixInfoStruct.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendGetMixInfo() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new K6_MixInfoStruct.Property((byte) 124, new byte[]{1, -1, -1, 0, 0}));
        arrayList.add(new K6_MixInfoStruct.Property((byte) 122, new K6_DATA_TYPE_CALL_ALARM(1).getBytes()));
        arrayList.add(new K6_MixInfoStruct.Property((byte) 123, new K6_DATA_TYPE_MESSAGE_ALARM(1).getBytes()));
        sendMixInfo(new K6_MixInfoStruct(arrayList));
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendGetSittingRemind() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(3);
        cEDevData.setDataType(114);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendWatchFace(K6_Send_Watch_Face_And_Notification_Set k6_Send_Watch_Face_And_Notification_Set) {
        push(k6_Send_Watch_Face_And_Notification_Set.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendPairStart(K6_PairStruct k6_PairStruct) {
        push(k6_PairStruct.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public synchronized void sendWatchFileData(byte[] bArr, int i, int i2, byte[] bArr2) {
        int i3 = (int) ((i2 / i) * 100.0f);
        Logger.i("FileTransControl", "传输进度 p = " + i3);
        CEDevK6Proxy cEDevK6Proxy = this.mCEDevK6Proxy;
        if (cEDevK6Proxy != null) {
            if (i2 + bArr2.length == i) {
                cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(-325001435, i3));
                this.mCEDevK6Proxy.getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_BLE_FILE_DOWNLOAD_PROGRESS).preProcessResult(100);
            } else {
                cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(-325001435, i3));
                this.mCEDevK6Proxy.getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_BLE_FILE_DOWNLOAD_PROGRESS).preProcessResult(Integer.valueOf(i3));
            }
        }
        CEDevData cEDevData = new CEDevData(1, 131);
        cEDevData.setItemNumber(1);
        cEDevData.setItemL(bArr2.length + 9);
        byte[] bArr3 = new byte[9];
        System.arraycopy(bArr, 0, bArr3, 0, bArr.length);
        System.arraycopy(ByteUtil.intToByte4(i), 0, bArr3, 1, 4);
        System.arraycopy(ByteUtil.intToByte4(i2), 0, bArr3, 5, 4);
        byte[] bArr4 = new byte[bArr2.length + 9];
        System.arraycopy(bArr3, 0, bArr4, 0, 9);
        System.arraycopy(bArr2, 0, bArr4, 9, bArr2.length);
        cEDevData.setData(bArr4);
        cEDevData.setPriority(-1);
        Logger.i("FileTransControl", "传输data =  " + Arrays.toString(bArr4));
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendOTAData(int i, int i2, int i3, byte[] bArr) {
        CEDevK6Proxy.lge("ota index=" + i3);
        int i4 = (int) ((i3 / i2) * 100.0f);
        CEDevK6Proxy.lge("ota_progress---" + i4);
        if (this.mCEDevK6Proxy != null) {
            if (i3 + bArr.length == i2) {
                i4 = 100;
            }
            CEDevK6Proxy.lge("ota_progress===" + i4);
            CEDevK6Proxy cEDevK6Proxy = this.mCEDevK6Proxy;
            cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(908292122, i4));
            this.mCEDevK6Proxy.getK6AnalysiDevManager().getResultListenerByDataTypeStr(K6_Action.RCVD.RCVD_OTA_PROGRESS).preProcessResult(Integer.valueOf(i4));
        }
        CEDevData cEDevData = new CEDevData(1, CEBC.K6.DATA_TYPE_OTA_DATA);
        cEDevData.setItemNumber(1);
        cEDevData.setItemL(bArr.length + 10);
        byte[] bArr2 = new byte[10];
        System.arraycopy(ByteUtil.int2bytes2(i), 0, bArr2, 0, 2);
        System.arraycopy(ByteUtil.intToByte4(i2), 0, bArr2, 2, 4);
        System.arraycopy(ByteUtil.intToByte4(i3), 0, bArr2, 6, 4);
        byte[] bArr3 = new byte[bArr.length + 10];
        System.arraycopy(bArr2, 0, bArr3, 0, 10);
        System.arraycopy(bArr, 0, bArr3, 10, bArr.length);
        cEDevData.setData(bArr3);
        cEDevData.setPriority(-1);
        Log.e("YAN_OTA", "发送OTA数据");
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendOTAFinish() {
        CEDevK6Proxy cEDevK6Proxy = this.mCEDevK6Proxy;
        if (cEDevK6Proxy != null) {
            cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(908292122, 100));
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void getOTAState() {
        push(new CEDevData(3, CEBC.K6.DATA_TYPE_OTA_STATUS));
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void getFileDownloadInfo() {
        push(new CEDevData(3, 132));
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendSittingRemind(K6_SittingRemind k6_SittingRemind) {
        push(k6_SittingRemind.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendDATA_TARGET_ALARM(K6_DATA_TYPE_TARGET_ALARM k6_data_type_target_alarm) {
        push(k6_data_type_target_alarm.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_DRINK_ALARM(K6_DATA_TYPE_DRINK_ALARM k6_data_type_drink_alarm) {
        push(k6_data_type_drink_alarm.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_WOMAN_STAGE_INFO(K6_DATA_TYPE_WOMAN_STAGE_INFO k6_data_type_woman_stage_info) {
        push(k6_data_type_woman_stage_info.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_SEND_DATA_TYPE_FIND_PHONE(K6_DATA_TYPE_FIND_PHONE_OR_DEVICE k6_data_type_find_phone_or_device) {
        push(k6_data_type_find_phone_or_device.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_HAND_RISE_SWITCH(K6_DATA_TYPE_HAND_RISE_SWITCH k6_data_type_hand_rise_switch) {
        push(k6_data_type_hand_rise_switch.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_HEART_AUTO_SWITCH(K6_DATA_TYPE_HEART_AUTO_SWITCH k6_data_type_heart_auto_switch) {
        push(k6_data_type_heart_auto_switch.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendPhotoSwitch(boolean z) {
        CEDevData cEDevData = new CEDevData(1, 116);
        cEDevData.setData(new byte[]{z ? (byte) 1 : (byte) 0});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    @Deprecated
    public void sendCall() {
        CEDevData cEDevData = new CEDevData(1, 117);
        cEDevData.setData(new byte[]{1});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendCall(int i) {
        CEDevData cEDevData = new CEDevData(1, 117);
        byte[] bArr = new byte[1];
        if (i == 1) {
            bArr[0] = 1;
            Log.e("rd95", "sendCall: state = 1");
        } else if (i == 2) {
            bArr[0] = 2;
            Log.e("rd95", "sendCall: state = 2");
        } else if (i == 0) {
            bArr[0] = 0;
            Log.e("rd95", "sendCall: state = 0");
        } else if (i == 3) {
            bArr[0] = 3;
            Log.e("rd95", "sendCall: state = 3");
        }
        cEDevData.setData(bArr);
        CEDevK6Proxy cEDevK6Proxy = this.mCEDevK6Proxy;
        if (cEDevK6Proxy == null || TextUtils.isEmpty(cEDevK6Proxy.getBlueAddress())) {
            return;
        }
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendNoDisturb(List<K6_NoDisturb> list, int i) {
        int itemSize = (K6_NoDisturb.getItemSize() * list.size()) + 2;
        byte[] bArr = new byte[itemSize];
        CEDevK6Proxy.lge("发送勿扰模式设置信息,共" + list.size() + "组勿扰时间段");
        bArr[0] = (byte) i;
        bArr[1] = (byte) list.size();
        for (int i2 = 0; i2 < list.size(); i2++) {
            System.arraycopy(list.get(i2).getBytes(), 0, bArr, (i2 * K6_NoDisturb.getItemSize()) + 2, K6_NoDisturb.getItemSize());
        }
        CEDevK6Proxy.lge("发送勿扰模式设置信息,payload : " + Arrays.toString(bArr));
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(115);
        cEDevData.setItemL(itemSize);
        cEDevData.setItemNumber(1);
        cEDevData.setData(bArr);
        push(cEDevData);
    }

    public void sendRequestAlarmList() {
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendDeviceRestart() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(118);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendDevicePairFinish(byte b) {
        Lg.e("sendDevicePairFinish");
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(120);
        cEDevData.setData(new byte[]{b, 0});
        cEDevData.setDataCrc16(0);
        cEDevData.setItemL(1);
        push(cEDevData);
    }

    public void sendDeviceSiwmLane(int i) {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(1);
        cEDevData.setDataType(66);
        cEDevData.setData(new byte[]{(byte) i});
        cEDevData.setDataCrc16(0);
        cEDevData.setItemL(1);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendExerciseCmd(K6_ExerciseState k6_ExerciseState) {
        CEDevData cEDevData = new CEDevData(1, 63);
        cEDevData.setData(k6_ExerciseState.getSendByte());
        cEDevData.setDataCrc16(0);
        cEDevData.setItemL(2);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void getDevExerciseState() {
        CEDevData cEDevData = new CEDevData();
        cEDevData.setCmd(3);
        cEDevData.setDataType(64);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendAppSport(K6_SEND_APP_SPORT_STRUCT k6_send_app_sport_struct) {
        push(k6_send_app_sport_struct.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_REAL_BP(int i) {
        push(new K6_DATA_TYPE_REAL_BP(i).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_MUSIC_CONTROL(K6_DATA_TYPE_MUSIC_CONTROL k6_data_type_music_control) {
        push(k6_data_type_music_control.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendWatchFaceStart() {
        push(new K6_DATA_TYPE_WATCH_FACE_START().toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_REAL_O2(int i) {
        push(new K6_DATA_TYPE_REAL_O2(i).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_REAL_HR_SWITCH(int i) {
        push(new K6_DATA_TYPE_REAL_HR(i).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_REAL_HRV_SWITCH(int i) {
        push(new K6_DATA_TYPE_REAL_HRV(i).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_REAL_ECG(int i) {
        push(new K6_DATA_TYPE_REAL_ECG(i).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_DATA_TYPE_WATCH_FACE_SYNC(int i) {
        push(new K6_DATA_TYPE_WATCH_FACE_SYN_NNNOMAL_CHOICE(i).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendRealTimeWeather(K6_SendRealTimeWeather k6_SendRealTimeWeather) {
        push(k6_SendRealTimeWeather.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendRealTimeWeatherExtra(K6_SendRealTimeWeatherExtra k6_SendRealTimeWeatherExtra) {
        push(k6_SendRealTimeWeatherExtra.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendCurrentLocation(K6_SendCurrentLocationInfo k6_SendCurrentLocationInfo) {
        push(k6_SendCurrentLocationInfo.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendK6_SEND_DATA_TYPE_BTEDR_ADDR() {
        push(new CEDevData(3, 25));
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendQRInfo(byte[] bArr, int i, int i2) {
        CEDevData cEDevData = new CEDevData(1, 26);
        cEDevData.setItemNumber(1);
        cEDevData.setItemL(bArr.length + 6);
        byte[] bArr2 = new byte[6];
        System.arraycopy(ByteUtil.int2bytes2(i2), 0, bArr2, 0, 2);
        System.arraycopy(ByteUtil.int2bytes2(i), 0, bArr2, 2, 2);
        System.arraycopy(ByteUtil.int2bytes2(bArr.length), 0, bArr2, 4, 2);
        byte[] bArr3 = new byte[bArr.length + 6];
        System.arraycopy(bArr2, 0, bArr3, 0, 6);
        System.arraycopy(bArr, 0, bArr3, 6, bArr.length);
        cEDevData.setData(bArr3);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendQRCodeDel(int i) {
        CEDevData cEDevData = new CEDevData(1, 27);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{(byte) (i & 255)});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendQRCodeClear() {
        CEDevData cEDevData = new CEDevData(1, 28);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{1});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendDelPhotoWatchLogo(int i) {
        CEDevData cEDevData = new CEDevData(1, 141);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{(byte) (i & 255)});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendDelPhotoWatchFace(int i) {
        CEDevData cEDevData = new CEDevData(1, 140);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{(byte) (i & 255)});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendAlData(byte[] bArr) {
        CEDevData cEDevData = new CEDevData(1, 31);
        cEDevData.setItemL(bArr.length);
        cEDevData.setItemNumber(1);
        cEDevData.setData(bArr);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendSwitchGSensor(int i) {
        CEDevData cEDevData = new CEDevData(1, 143);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{(byte) i});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendAiData(K6_DATA_TYPE_AI_INFO k6_data_type_ai_info) {
        push(k6_data_type_ai_info.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendNavigation(K6_DATA_TYPE_NAVIGATION k6_data_type_navigation) {
        push(k6_data_type_navigation.toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendPhoneEdrToDev(int i, byte[] bArr) {
        CEDevData cEDevData = new CEDevData(1, 39);
        byte[] bArr2 = new byte[7];
        cEDevData.setItemL(7);
        cEDevData.setItemNumber(1);
        bArr2[0] = (byte) i;
        System.arraycopy(bArr, 0, bArr2, 1, 6);
        cEDevData.setData(bArr2);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendSleepMonitor() {
        CEDevData cEDevData = new CEDevData(1, 43);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{1});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendFactoryTest() {
        CEDevData cEDevData = new CEDevData(1, CEBC.K6.DATA_TYPE_FACTORY_TEST);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{1});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendShutDown() {
        CEDevData cEDevData = new CEDevData(1, 119);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{1});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendLeakLightTest(int i) {
        CEDevData cEDevData = new CEDevData(1, CEBC.K6.DATA_TYPE_LEAKLIGHT_TEST);
        byte[] bArr = new byte[13];
        bArr[0] = (byte) (i & 255);
        cEDevData.setItemL(13);
        cEDevData.setItemNumber(1);
        cEDevData.setData(bArr);
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendChangeName(String str) {
        push(new K6_DATA_TYPE_TEST_TOOL(str).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendGestureConfig(int i) {
        CEDevData cEDevData = new CEDevData(1, 44);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{(byte) i});
        push(cEDevData);
    }

    @Override // ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager
    public void sendClearData() {
        CEDevData cEDevData = new CEDevData(1, CEBC.K6.DATA_TYPE_CLEAN_DATA);
        cEDevData.setItemL(1);
        cEDevData.setItemNumber(1);
        cEDevData.setData(new byte[]{1});
        push(cEDevData);
    }
}
