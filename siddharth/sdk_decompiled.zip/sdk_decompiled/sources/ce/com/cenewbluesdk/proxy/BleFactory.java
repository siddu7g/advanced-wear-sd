package ce.com.cenewbluesdk.proxy;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import ce.com.cenewbluesdk.bluetooth.a.c;
import ce.com.cenewbluesdk.uitl.Lg;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/BleFactory.class */
public class BleFactory {
    private static BleFactory bleFactory;
    public static Context context;
    private String TAG = BleFactory.class.getSimpleName();
    private CEBluetoothProxyBase k6Proxy;

    public static BleFactory getInstance() {
        if (bleFactory == null) {
            bleFactory = new BleFactory();
        }
        return bleFactory;
    }

    public static BleFactory getInstance(Context context2) {
        if (bleFactory == null) {
            Lg.e("BleFactory getInstance new");
            bleFactory = new BleFactory();
            Context context3 = context;
            if (context3 != null) {
                context = context3.getApplicationContext();
            } else {
                context = context2.getApplicationContext();
            }
        }
        if (context == null) {
            context = context2.getApplicationContext();
        }
        return bleFactory;
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception, java.lang.String] */
    public static synchronized String getPackageName(Context context2) {
        ?? r0;
        try {
            r0 = context2.getApplicationContext().getPackageManager().getPackageInfo(context2.getPackageName(), 0).packageName;
            return r0;
        } catch (Exception unused) {
            r0.printStackTrace();
            return null;
        }
    }

    public void init(Context context2) {
        context = context2;
    }

    public CEBluetoothProxyBase getK6Proxy() {
        if (this.k6Proxy == null) {
            this.k6Proxy = new CEDevK6Proxy(context);
            if (context == null) {
                Lg.e("BleFactory context == null");
            }
        }
        return this.k6Proxy;
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    public boolean appIsRunning() throws IOException {
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = ((ActivityManager) context.getSystemService("activity")).getRunningAppProcesses();
        int i = 0;
        while (true) {
            ?? r0 = i;
            if (r0 >= runningAppProcesses.size()) {
                Lg.e("ProcessDATA_TYPE_APP_SPORT", "app关闭");
                return false;
            }
            try {
                if (getPackageName(context).equals(runningAppProcesses.get(0).processName)) {
                    Lg.e("ProcessDATA_TYPE_APP_SPORT", "app运行中");
                    return true;
                }
                i++;
            } catch (Exception unused) {
                r0.printStackTrace();
                return true;
            }
        }
    }

    @SuppressLint({"MissingPermission"})
    public int isConnectedByProfile(BluetoothDevice bluetoothDevice) {
        if (bluetoothDevice == null) {
            return 0;
        }
        if (c.a(context).b() == null || c.a(context).a() == null) {
            c.b(context).c(context);
            return 0;
        }
        if (bluetoothDevice.getType() == 2) {
            return 0;
        }
        List<BluetoothDevice> connectedDevices = c.a(context).a().getConnectedDevices();
        if (connectedDevices != null) {
            Iterator<BluetoothDevice> it = connectedDevices.iterator();
            while (it.hasNext()) {
                if (it.next().getAddress().equals(bluetoothDevice.getAddress())) {
                    return 2;
                }
            }
        }
        List<BluetoothDevice> connectedDevices2 = c.a(context).b().getConnectedDevices();
        if (connectedDevices2 == null) {
            return 0;
        }
        Iterator<BluetoothDevice> it2 = connectedDevices2.iterator();
        while (it2.hasNext()) {
            if (it2.next().getAddress().equals(bluetoothDevice.getAddress())) {
                return 2;
            }
        }
        return 0;
    }

    @SuppressLint({"MissingPermission"})
    public boolean disconnectByProfiles(BluetoothDevice bluetoothDevice) throws IOException {
        if (bluetoothDevice == null) {
            Lg.e("edr_连接", "edr_连接 -disconnectByProfiles- device is null ", true);
            return false;
        }
        boolean zDisconnectFromHfp = false;
        if (bluetoothDevice.getType() != 2) {
            int iIsConnectedByA2dp = isConnectedByA2dp(bluetoothDevice);
            if (iIsConnectedByA2dp == 2) {
                zDisconnectFromHfp = disconnectFromA2dp(bluetoothDevice);
                Lg.e("edr_连接", "edr_连接 -disconnectByProfiles- disconnectFromA2dp ret : " + zDisconnectFromHfp, true);
            }
            int iIsConnectedByHfp = isConnectedByHfp(bluetoothDevice);
            if (iIsConnectedByHfp == 2) {
                zDisconnectFromHfp = disconnectFromHfp(bluetoothDevice);
                Lg.e("edr_连接", "edr_连接 -disconnectByProfiles- disconnectFromHfp ret : " + zDisconnectFromHfp, true);
            }
            if (iIsConnectedByA2dp == 0 && iIsConnectedByHfp == 0) {
                zDisconnectFromHfp = true;
            }
        }
        return zDisconnectFromHfp;
    }

    @SuppressLint({"MissingPermission"})
    public int isConnectedByA2dp(BluetoothDevice bluetoothDevice) {
        if (bluetoothDevice == null || c.a(context).a() == null) {
            return 0;
        }
        List<BluetoothDevice> connectedDevices = c.a(context).a().getConnectedDevices();
        if (connectedDevices != null) {
            Iterator<BluetoothDevice> it = connectedDevices.iterator();
            while (it.hasNext()) {
                if (it.next().getAddress().equals(bluetoothDevice.getAddress())) {
                    return 2;
                }
            }
        }
        return c.a(context).a().getConnectionState(bluetoothDevice);
    }

    public boolean disconnectFromA2dp(BluetoothDevice bluetoothDevice) {
        if (bluetoothDevice == null || c.a(context).a() == null) {
            return false;
        }
        boolean zB = false;
        int iIsConnectedByA2dp = isConnectedByA2dp(bluetoothDevice);
        if (iIsConnectedByA2dp == 0) {
            return true;
        }
        if (iIsConnectedByA2dp == 2) {
            Context context2 = context;
            zB = ce.com.cenewbluesdk.uitl.c.b(context2, c.a(context2).a(), bluetoothDevice);
        }
        return zB;
    }

    @SuppressLint({"MissingPermission"})
    public int isConnectedByHfp(BluetoothDevice bluetoothDevice) {
        if (bluetoothDevice == null || c.a(context).b() == null || !ce.com.cenewbluesdk.uitl.c.c(context, bluetoothDevice)) {
            return 0;
        }
        List<BluetoothDevice> connectedDevices = c.a(context).b().getConnectedDevices();
        if (connectedDevices != null) {
            Iterator<BluetoothDevice> it = connectedDevices.iterator();
            while (it.hasNext()) {
                if (it.next().getAddress().equals(bluetoothDevice.getAddress())) {
                    return 2;
                }
            }
        }
        return c.a(context).b().getConnectionState(bluetoothDevice);
    }

    public boolean disconnectFromHfp(BluetoothDevice bluetoothDevice) {
        if (bluetoothDevice == null || c.a(context).b() == null) {
            return false;
        }
        boolean zB = false;
        int iIsConnectedByHfp = isConnectedByHfp(bluetoothDevice);
        if (iIsConnectedByHfp == 0) {
            return true;
        }
        if (iIsConnectedByHfp == 2) {
            Context context2 = context;
            zB = ce.com.cenewbluesdk.uitl.c.b(context2, c.a(context2).b(), bluetoothDevice);
        }
        return zB;
    }
}
