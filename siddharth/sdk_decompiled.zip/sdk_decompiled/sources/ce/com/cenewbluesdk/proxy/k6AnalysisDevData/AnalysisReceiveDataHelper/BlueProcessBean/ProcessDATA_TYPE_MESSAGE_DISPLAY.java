package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_Send_Watch_Face_And_Notification_Set;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_MESSAGE_DISPLAY.class */
public final class ProcessDATA_TYPE_MESSAGE_DISPLAY extends BaseK6AnalysiDevData<K6_Send_Watch_Face_And_Notification_Set> {
    public ProcessDATA_TYPE_MESSAGE_DISPLAY(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(124);
        setDataTypeStr(K6_Action.RCVD.RCVD_WATCH_FACE_AND_NOTIFICATION_SET);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_Send_Watch_Face_And_Notification_Set realProcess(byte[] bArr) {
        byte[] bArr2 = new byte[K6_Send_Watch_Face_And_Notification_Set.getItemSize()];
        System.arraycopy(bArr, 0, bArr2, 0, K6_Send_Watch_Face_And_Notification_Set.getItemSize());
        K6_Send_Watch_Face_And_Notification_Set k6_Send_Watch_Face_And_Notification_Set = new K6_Send_Watch_Face_And_Notification_Set(bArr2);
        CEDevK6Proxy.lge("表盘设置信息：" + k6_Send_Watch_Face_And_Notification_Set.toString());
        return k6_Send_Watch_Face_And_Notification_Set;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_Send_Watch_Face_And_Notification_Set k6_Send_Watch_Face_And_Notification_Set) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_Send_Watch_Face_And_Notification_Set k6_Send_Watch_Face_And_Notification_Set) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_Send_Watch_Face_And_Notification_Set));
        return false;
    }
}
