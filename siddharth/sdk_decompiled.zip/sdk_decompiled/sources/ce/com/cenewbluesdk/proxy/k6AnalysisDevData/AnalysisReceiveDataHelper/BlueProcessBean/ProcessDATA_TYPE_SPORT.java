package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_Sport;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_SPORT.class */
public final class ProcessDATA_TYPE_SPORT extends BaseK6AnalysiDevData<ArrayList<K6_Sport>> {
    public ProcessDATA_TYPE_SPORT(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(5);
        addDataType(4);
        setDataTypeStr(K6_Action.RCVD.RCVD_SPORT_DATA);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_Sport> realProcess(byte[] bArr) {
        int iByte2ToInt = ByteUtil.byte2ToInt(new byte[]{bArr[0], bArr[1]});
        int i = bArr[2] & 255;
        CEDevK6Proxy.lge("运动数据条目：allItem=" + iByte2ToInt + "   item= " + i + " thread = " + Thread.currentThread().getName());
        int itemSize = 3;
        ArrayList<K6_Sport> arrayList = new ArrayList<>();
        for (int i2 = 0; i2 < i; i2++) {
            byte[] bArr2 = new byte[K6_Sport.getItemSize()];
            System.arraycopy(bArr, itemSize, bArr2, 0, K6_Sport.getItemSize());
            K6_Sport k6_Sport = new K6_Sport(bArr2);
            CEDevK6Proxy.lge("接收到运动数据:" + k6_Sport.toString());
            arrayList.add(k6_Sport);
            itemSize += K6_Sport.getItemSize();
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(ArrayList<K6_Sport> arrayList) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(ArrayList<K6_Sport> arrayList) {
        if (arrayList.size() <= 0) {
            return false;
        }
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), arrayList));
        return false;
    }
}
