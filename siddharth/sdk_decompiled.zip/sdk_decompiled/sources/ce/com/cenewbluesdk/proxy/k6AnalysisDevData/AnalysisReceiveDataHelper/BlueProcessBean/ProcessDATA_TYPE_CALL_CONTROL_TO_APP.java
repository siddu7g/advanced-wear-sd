package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_CALL_CONTROL_TO_APP.class */
public final class ProcessDATA_TYPE_CALL_CONTROL_TO_APP extends BaseK6AnalysiDevData<Integer> {
    public ProcessDATA_TYPE_CALL_CONTROL_TO_APP(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(15);
        setDataTypeStr(K6_Action.RCVD.RCVD_PHONE_CONTROL);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Integer realProcess(byte[] bArr) {
        CEDevK6Proxy.lge("接收到了设备侧发送过来的电话信息！！！！");
        return Integer.valueOf(bArr[0]);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Integer num) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(Integer num) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), num));
        return false;
    }
}
