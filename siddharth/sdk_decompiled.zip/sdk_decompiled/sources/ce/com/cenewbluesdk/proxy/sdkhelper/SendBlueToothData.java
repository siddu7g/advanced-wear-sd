package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.text.TextUtils;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.bluetooth.a.a;
import ce.com.cenewbluesdk.bluetooth.a.b;
import ce.com.cenewbluesdk.entity.WeatherData;
import ce.com.cenewbluesdk.entity.k6.K6_CESyncTime;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_AI_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_CONTACT_SYNC;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_DRINK_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_FIND_PHONE_OR_DEVICE;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_HAND_RISE_SWITCH;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_HEART_AUTO_SWITCH;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_LANGUAGE_SETTING;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_MUSIC_CONTROL;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_NAVIGATION;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_TARGET_ALARM;
import ce.com.cenewbluesdk.entity.k6.K6_MessageNoticeStruct;
import ce.com.cenewbluesdk.entity.k6.K6_NoDisturb;
import ce.com.cenewbluesdk.entity.k6.K6_SEND_APP_SPORT_STRUCT;
import ce.com.cenewbluesdk.entity.k6.K6_SendAlarmInfoStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SendCurrentLocationInfo;
import ce.com.cenewbluesdk.entity.k6.K6_SendGoal;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeather;
import ce.com.cenewbluesdk.entity.k6.K6_SendRealTimeWeatherExtra;
import ce.com.cenewbluesdk.entity.k6.K6_SendWeatherStruct;
import ce.com.cenewbluesdk.entity.k6.K6_SittingRemind;
import ce.com.cenewbluesdk.entity.k6.K6_UnitSettingStruct;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.uitl.TimeUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/SendBlueToothData.class */
public class SendBlueToothData implements ISendBlueToothData {
    private static long pairTime;
    private Context mContext;
    private ArrayList<K6_SendWeatherStruct.K6WeatherInfoItem> weathers = new ArrayList<>();
    private ArrayList<K6_NoDisturb> noDisturbs = new ArrayList<>();

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/SendBlueToothData$Holder.class */
    private static class Holder {
        private static final SendBlueToothData INSTANCE = new SendBlueToothData();

        private Holder() {
        }
    }

    public static SendBlueToothData getInstance() {
        return Holder.INSTANCE;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void setContext(Context context) {
        this.mContext = context;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendFindDevice() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_SEND_DATA_TYPE_FIND_PHONE(new K6_DATA_TYPE_FIND_PHONE_OR_DEVICE(1));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendTimeFormat(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendTime(new K6_CESyncTime(TimeUtil.now(), TimeZone.getDefault().getOffset(TimeUtil.now()), (byte) i, (byte) CEBlueSharedPreference.getAppDateDisplay()));
        CEBlueSharedPreference.setAppTimeDisplay(i + "");
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDateFormat(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendTime(new K6_CESyncTime(TimeUtil.now(), TimeZone.getDefault().getOffset(TimeUtil.now()), (byte) CEBlueSharedPreference.getAppTimeDisplay(), (byte) i));
        CEBlueSharedPreference.setAppDateDisplay(i + "");
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDateTimeFormat(K6_CESyncTime k6_CESyncTime) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendTime(k6_CESyncTime);
        CEBlueSharedPreference.setAppTimeDisplay(k6_CESyncTime.getFormat() + "");
        CEBlueSharedPreference.setAppDateDisplay(k6_CESyncTime.getMdFormat() + "");
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendCall(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendCall(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendIncomingCall(String str, String str2) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendMessage_notice(TimeUtil.now(), str, str2, (byte) 1);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendSyncInfo() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendAsynInfo();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendPushMessage(String str, byte b, String str2) {
        K6_MessageNoticeStruct k6_MessageNoticeStruct = new K6_MessageNoticeStruct(TimeUtil.now(), b);
        k6_MessageNoticeStruct.setSendContext(str, (byte) 2, str2);
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendMessage_notice(k6_MessageNoticeStruct);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDialSwitch(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_WATCH_FACE_SYNC(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendWatchInfo() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().getFileDownloadInfo();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendBloodOxygenDetection(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_REAL_O2(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendBloodPressureDetection(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_REAL_BP(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendWeatherInfo(List<WeatherData> list) {
        this.weathers.clear();
        if (list == null) {
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            this.weathers.add(new K6_SendWeatherStruct.K6WeatherInfoItem(list.get(i).getWeatherType(), list.get(i).getLowTemperature(), list.get(i).getHighTemperature(), 0));
        }
        ArrayList<K6_SendWeatherStruct.K6WeatherInfoItem> arrayList = this.weathers;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendWeatherInfo(new K6_SendWeatherStruct((int) (TimeUtil.now() / 1000), this.weathers));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendSystemLanguage() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendLanguageSetting();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendSwitchLanguage(int i) {
        if (i < 0) {
            return;
        }
        BleFactory.getInstance().getK6Proxy().sendData(new K6_DATA_TYPE_LANGUAGE_SETTING(Integer.valueOf(i)).toCEDevData());
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendUnitSetting(int i, int i2, int i3) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendUnitSetting(new K6_UnitSettingStruct(i, i2, i3));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDailyGoals(int i, int i2, int i3, int i4, int i5) {
        K6_SendGoal k6_SendGoal = new K6_SendGoal(i, i2, i3, i4, i5);
        CEBlueSharedPreference.setTargetStep(i + "");
        CEBlueSharedPreference.setTargetDistance(i2 + "");
        CEBlueSharedPreference.setTargetCalorie(i3 + "");
        CEBlueSharedPreference.setTargetSleep(i4 + "");
        CEBlueSharedPreference.setTargetDuration(i5 + "");
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendGoal(k6_SendGoal);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendHeartAutoSwitch(int i, int i2) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_HEART_AUTO_SWITCH(new K6_DATA_TYPE_HEART_AUTO_SWITCH(i, 0));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendHeartAutoSwitch(int i, int i2, int i3) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_HEART_AUTO_SWITCH(new K6_DATA_TYPE_HEART_AUTO_SWITCH(i, i2, i3));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendPhotoSwitch(boolean z) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendPhotoSwitch(z);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendMusicControl(K6_DATA_TYPE_MUSIC_CONTROL k6_data_type_music_control) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_MUSIC_CONTROL(k6_data_type_music_control);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void setVolume(int i) {
        BleFactory.getInstance().getK6Proxy().setVolume(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendNoDisturb(int i, int i2, int i3, int i4, int i5) {
        if (this.noDisturbs == null) {
            this.noDisturbs = new ArrayList<>();
        }
        this.noDisturbs.clear();
        this.noDisturbs.add(new K6_NoDisturb((byte) i, (byte) i2, (byte) i3, (byte) i4));
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendNoDisturb(this.noDisturbs, i5);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendHandRiseWitch(int i, int i2, int i3, int i4, int i5) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_HAND_RISE_SWITCH(new K6_DATA_TYPE_HAND_RISE_SWITCH(i5, i, i2, i3, i4));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDevInfo() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().getDevInfo();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendAlarmInfo(ArrayList<K6_SendAlarmInfoStruct> arrayList) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendAlarmInfo(arrayList);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendAddContacts(String str, String str2) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendAddContacts(new K6_DATA_TYPE_CONTACT_SYNC(str, str2));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendContactsSync(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendContactsSync(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDelContacts(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendDelContacts(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendClearContacts() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendClearContacts();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendAppSport(int i, int i2, int i3, int i4) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendAppSport(new K6_SEND_APP_SPORT_STRUCT(i, i2, i3, i4));
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDeviceRestart() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendDeviceRestart();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendTargetRemind(int i) {
        K6_DATA_TYPE_TARGET_ALARM k6_data_type_target_alarm = new K6_DATA_TYPE_TARGET_ALARM();
        k6_data_type_target_alarm.setOnoff(i);
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendDATA_TARGET_ALARM(k6_data_type_target_alarm);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDrinkRemind(int i, int i2, int i3, int i4, int i5, int i6) {
        K6_DATA_TYPE_DRINK_ALARM k6_data_type_drink_alarm = new K6_DATA_TYPE_DRINK_ALARM();
        k6_data_type_drink_alarm.setStart_hour(i);
        k6_data_type_drink_alarm.setStart_min(i2);
        k6_data_type_drink_alarm.setEnd_hour(i3);
        k6_data_type_drink_alarm.setEnd_min(i4);
        k6_data_type_drink_alarm.setInterval(i5);
        k6_data_type_drink_alarm.setOnoff(i6);
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_DRINK_ALARM(k6_data_type_drink_alarm);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendSittingRemind(int i, int i2, int i3, int i4, int i5, int i6, int i7) {
        K6_SittingRemind k6_SittingRemind = new K6_SittingRemind();
        k6_SittingRemind.setStart_time_hour(i);
        k6_SittingRemind.setStart_time_min(i2);
        k6_SittingRemind.setEnd_time_hour(i3);
        k6_SittingRemind.setEnd_time_min(i4);
        k6_SittingRemind.setRepeat(i5);
        k6_SittingRemind.setSwitch_flag(i6);
        k6_SittingRemind.setNoon_onoff(i7);
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendSittingRemind(k6_SittingRemind);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendHeartRateSwitch(Integer num) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_REAL_HR_SWITCH(num.intValue());
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendHRVSwitch(Integer num) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_DATA_TYPE_REAL_HRV_SWITCH(num.intValue());
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendRealTimeWeather(K6_SendRealTimeWeather k6_SendRealTimeWeather) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendRealTimeWeather(k6_SendRealTimeWeather);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendRealTimeWeatherExtra(K6_SendRealTimeWeatherExtra k6_SendRealTimeWeatherExtra) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendRealTimeWeatherExtra(k6_SendRealTimeWeatherExtra);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendCurrentLocation(K6_SendCurrentLocationInfo k6_SendCurrentLocationInfo) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendCurrentLocation(k6_SendCurrentLocationInfo);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendOpenSysBle() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendK6_SEND_DATA_TYPE_BTEDR_ADDR();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendQRCodeDel(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendQRCodeDel(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendQRCodeClear() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendQRCodeClear();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDelPhotoWatchLogo(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendDelPhotoWatchLogo(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendDelPhotoWatchFace(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendDelPhotoWatchFace(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendSwitchGSensor(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendSwitchGSensor(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendAiData(K6_DATA_TYPE_AI_INFO k6_data_type_ai_info) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendAiData(k6_data_type_ai_info);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendNavigation(K6_DATA_TYPE_NAVIGATION k6_data_type_navigation) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendNavigation(k6_data_type_navigation);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendPhoneEdrToDev(int i, byte[] bArr) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendPhoneEdrToDev(i, bArr);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendSleepMonitor() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendSleepMonitor();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendFactoryTest() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendFactoryTest();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendShutDown() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendShutDown();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendLeakLightTest(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendLeakLightTest(i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendChangeName(String str) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendChangeName(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendClearData() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendClearData();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ISendBlueToothData
    public void sendGestureConfig(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendGestureConfig(i);
    }

    public void createBond(String str) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        BluetoothDevice remoteDevice = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(str.toUpperCase());
        if (System.currentTimeMillis() - pairTime > 5000 && !b.a(remoteDevice)) {
            a aVar = new a();
            aVar.a(BleFactory.context);
            aVar.a(str, false);
        }
        pairTime = System.currentTimeMillis();
    }

    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
        	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:44)
        */
    public void removeBond(
    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r4v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */
}
