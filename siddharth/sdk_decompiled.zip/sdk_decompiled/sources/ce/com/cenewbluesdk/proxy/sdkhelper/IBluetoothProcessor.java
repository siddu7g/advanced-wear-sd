package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Handler;
import ce.com.cenewbluesdk.proxy.MusicControl;
import ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.OnBlueScanCompleteListener;
import ce.com.cenewbluesdk.proxy.interfaces.OnScanDevListener;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/IBluetoothProcessor.class */
public interface IBluetoothProcessor {
    void initProxy(Context context);

    void scanningDeviceInit(Context context, OnScanDevListener onScanDevListener);

    void stopScan();

    void startScan();

    void startScan(String str);

    void setScanTimeOut(int i);

    void connectDev(String str);

    void connectDev(String str, String str2);

    void disConnect();

    boolean isConnectOk();

    void setEnableGsDataTrans(boolean z);

    void setEnableGsDataTrans();

    boolean reConnectDirect();

    Context getContext();

    void startPairSynData();

    void synDevData();

    void devicePairFinish(int i);

    SendBlueToothData getSendBlueData();

    Persistent getPersistent();

    Transfer getTransfer();

    IK6AnalysiDevRcvDataManager getRcvDataManager();

    IK6SendDataManager getSendDataManager();

    boolean isEnabled();

    void setHandler(Handler handler);

    Handler getBlueHandler();

    void setBlueScanComplete(OnBlueScanCompleteListener onBlueScanCompleteListener);

    MusicControl getMusicControl();

    void onDestroy();

    void connectDevice(String str, String str2);

    void removeBond(BluetoothDevice bluetoothDevice);
}
