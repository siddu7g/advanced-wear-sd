package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_UnitSettingStruct;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_UNIT_SETTING.class */
public final class ProcessDATA_TYPE_UNIT_SETTING extends BaseK6AnalysiDevData<K6_UnitSettingStruct> {
    public ProcessDATA_TYPE_UNIT_SETTING(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(121);
        setDataTypeStr(K6_Action.RCVD.RCVD_DEV_UNITSET);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_UnitSettingStruct realProcess(byte[] bArr) {
        byte[] bArr2 = new byte[8];
        System.arraycopy(bArr, 0, bArr2, 0, 8);
        K6_UnitSettingStruct k6_UnitSettingStruct = new K6_UnitSettingStruct(bArr2);
        CEDevK6Proxy.lge("单位设置信息" + k6_UnitSettingStruct.toString());
        return k6_UnitSettingStruct;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_UnitSettingStruct k6_UnitSettingStruct) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_UnitSettingStruct k6_UnitSettingStruct) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_UnitSettingStruct));
        return false;
    }
}
