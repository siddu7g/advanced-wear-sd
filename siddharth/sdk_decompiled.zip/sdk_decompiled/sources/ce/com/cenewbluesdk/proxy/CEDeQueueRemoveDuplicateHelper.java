package ce.com.cenewbluesdk.proxy;

import ce.com.cenewbluesdk.entity.CEDevData;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEDeQueueRemoveDuplicateHelper.class */
public class CEDeQueueRemoveDuplicateHelper {
    public ArrayList<Integer> datatypes;

    public CEDeQueueRemoveDuplicateHelper() {
        ArrayList<Integer> arrayList = new ArrayList<>();
        this.datatypes = arrayList;
        arrayList.add(130);
        this.datatypes.add(114);
        this.datatypes.add(125);
        this.datatypes.add(126);
        this.datatypes.add(127);
        this.datatypes.add(128);
        this.datatypes.add(130);
        this.datatypes.add(11);
        this.datatypes.add(109);
        this.datatypes.add(18);
        this.datatypes.add(20);
        this.datatypes.add(19);
        this.datatypes.add(131);
    }

    public void process(ArrayBlockingQueue<CEDevData> arrayBlockingQueue, CEDevData cEDevData) {
        if (arrayBlockingQueue == null || cEDevData == null || arrayBlockingQueue.size() <= 1 || this.datatypes.indexOf(Integer.valueOf(cEDevData.getDataType())) == -1) {
            return;
        }
        CEDevData[] cEDevDataArr = (CEDevData[]) arrayBlockingQueue.toArray(new CEDevData[0]);
        for (int i = 1; i < cEDevDataArr.length; i++) {
            if (cEDevData.getDataType() == cEDevDataArr[i].getDataType() && cEDevData.getCmd() == 1) {
                arrayBlockingQueue.remove(cEDevDataArr[i]);
            }
        }
    }
}
