package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.K6_sleepData;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_Sleep;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.TimeUtil;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_SLEEP_NEW.class */
public final class ProcessDATA_TYPE_SLEEP_NEW extends BaseK6AnalysiDevData<K6_sleepData> {
    private static final String TAG = "ProcessDATA_TYPE_SLEEP";
    private K6_sleepData k6_sleepData;

    public ProcessDATA_TYPE_SLEEP_NEW(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        this.k6_sleepData = new K6_sleepData();
        addDataType(6);
        setDataTypeStr(K6_Action.RCVD.RCVD_K6_SLEEP_DATA);
    }

    private void processSleepData(ArrayList<K6_Sleep> arrayList) throws JSONException {
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        K6_sleepData k6_sleepData = new K6_sleepData();
        k6_sleepData.setUploadTime(0L);
        int i = 0;
        int i2 = 0;
        int sleepTime = 0;
        int i3 = 0;
        long sleepTime2 = 0;
        long sleepTime3 = 0;
        long sleepTime4 = 0;
        K6_Sleep k6_Sleep = null;
        JSONArray jSONArray = new JSONArray();
        JSONArray jSONArray2 = new JSONArray();
        Iterator<K6_Sleep> it = arrayList.iterator();
        while (it.hasNext()) {
            K6_Sleep k6_Sleep2 = k6_Sleep;
            K6_Sleep next = it.next();
            if (k6_Sleep2 == null) {
                sleepTime2 = next.getSleepTime() * 1000;
                sleepTime3 = next.getSleepTime();
                k6_Sleep = next;
            } else {
                int sleepType = k6_Sleep.getSleepType();
                int i4 = sleepType;
                if (sleepType == 1) {
                    i4 = 3;
                }
                int i5 = i4;
                int sleepTime5 = (next.getSleepTime() - k6_Sleep.getSleepTime()) / 60;
                if (i5 == 3) {
                    i += sleepTime5;
                } else if (i4 == 2) {
                    i2 += sleepTime5;
                } else if (i4 == 5) {
                    i3 += sleepTime5;
                }
                JSONObject jSONObject = new JSONObject();
                try {
                    jSONObject.put(i4 + "", sleepTime5);
                    jSONArray.put(jSONObject);
                } catch (JSONException unused) {
                }
                if (next.getSleepType() == 4) {
                    sleepTime4 = next.getSleepTime();
                    sleepTime = (int) ((((next.getSleepTime() * 1000) - sleepTime2) / 1000) / 60);
                }
                JSONObject jSONObject2 = new JSONObject();
                try {
                    jSONObject2.put(i4 + "", next.getSleepTime() * 1000);
                    jSONArray2.put(jSONObject2);
                } catch (JSONException unused2) {
                }
                k6_Sleep = next;
            }
        }
        k6_sleepData.setDeepTime(i2);
        k6_sleepData.setLightTime(i);
        k6_sleepData.setMovementTime(i3);
        k6_sleepData.setStartTime(sleepTime3);
        k6_sleepData.setEndTime(sleepTime4);
        k6_sleepData.setSleepTime(sleepTime);
        k6_sleepData.setSleepDetail(jSONArray.toString());
        if (k6_sleepData.getEndTime() * 1000 < TimeUtil.long2longDayStart(k6_sleepData.getEndTime() * 1000) + 72000000 && k6_sleepData.getEndTime() * 1000 >= TimeUtil.long2longDayStart(k6_sleepData.getEndTime() * 1000) - 14400000) {
            k6_sleepData.setSleepDay(TimeUtil.long2longDayStart(k6_sleepData.getEndTime() * 1000) / 1000);
        } else if (k6_sleepData.getEndTime() * 1000 >= TimeUtil.long2longDayStart(k6_sleepData.getEndTime() * 1000) + 72000000) {
            k6_sleepData.setSleepDay(TimeUtil.long2longDayStart((k6_sleepData.getEndTime() * 1000) + TimeUtil.ONE_DAY_MS) / 1000);
        }
        k6_sleepData.setDevId(BleFactory.getInstance().getK6Proxy().getBlueAddress());
        this.k6_sleepData.getK6SleepData().add(k6_sleepData);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v32, types: [ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.ProcessDATA_TYPE_SLEEP_NEW] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.util.List] */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public K6_sleepData realProcess(byte[] bArr) throws JSONException {
        ?? r0;
        int i = bArr[2] & 255;
        int i2 = 3;
        try {
            Lg.e("TYPE_SLEEP", "设备端上报的睡眠源数据=" + Arrays.toString(bArr), true);
        } catch (Exception unused) {
            "TYPE_SLEEP".printStackTrace();
        }
        byte[] bArr2 = new byte[4];
        ArrayList arrayList = new ArrayList();
        for (int i3 = 0; i3 < i; i3++) {
            int i4 = i2;
            i2 = i4 + 1;
            int i5 = bArr[i4] & 255;
            for (int i6 = 0; i6 < 15; i6++) {
                int i7 = i2;
                int i8 = i7 + 1;
                int i9 = bArr[i7] & 255;
                System.arraycopy(bArr, i8, bArr2, 0, 4);
                i2 = i8 + 4;
                arrayList.add(new K6_Sleep(i9, ByteUtil.byte4ToInt(bArr2)));
            }
            try {
                Lg.e("TYPE_SLEEP", "sleep 睡眠总段数:" + i + "  items:" + i5 + "  当前段数:" + i3 + "  设备睡眠数据:" + arrayList.toString() + "  datas=" + Arrays.toString(bArr), true);
            } catch (Exception unused2) {
                "TYPE_SLEEP".printStackTrace();
            }
        }
        try {
            Lg.e("TYPE_SLEEP", "睡眠数据：" + new Gson().toJson(arrayList), true);
        } catch (Exception unused3) {
            "TYPE_SLEEP".printStackTrace();
        }
        this.k6_sleepData.getK6SleepData().clear();
        ArrayList arrayList2 = arrayList;
        ArrayList arrayList3 = new ArrayList();
        int i10 = 0;
        while (true) {
            r0 = i10;
            if (r0 < arrayList.size()) {
                K6_Sleep k6_Sleep = (K6_Sleep) arrayList.get(i10);
                if (k6_Sleep.getSleepType() == 1) {
                    arrayList2 = arrayList;
                    ArrayList arrayList4 = new ArrayList();
                    arrayList4.add(k6_Sleep);
                } else if (k6_Sleep.getSleepType() == 4) {
                    ?? k6SleepData = this;
                    ArrayList arrayList5 = arrayList2;
                    arrayList5.add(k6_Sleep);
                    k6SleepData.processSleepData(arrayList5);
                    try {
                        k6SleepData = k6SleepData.k6_sleepData.getK6SleepData();
                        if (k6SleepData != 0 && this.k6_sleepData.getK6SleepData().size() > 0) {
                            this.k6_sleepData.getK6SleepData().get(this.k6_sleepData.getK6SleepData().size() - 1).setK6_sleeps(arrayList2);
                        }
                    } catch (Exception unused4) {
                        k6SleepData.printStackTrace();
                    }
                } else {
                    arrayList2.add(k6_Sleep);
                }
                i10++;
            } else {
                try {
                    break;
                } catch (Exception unused5) {
                    r0.printStackTrace();
                }
            }
        }
        r0 = "睡眠数据2：" + new Gson().toJson(this.k6_sleepData);
        Lg.e(r0);
        return this.k6_sleepData;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(K6_sleepData k6_sleepData) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(K6_sleepData k6_sleepData) {
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), k6_sleepData));
        return false;
    }
}
