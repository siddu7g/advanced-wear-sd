package ce.com.cenewbluesdk.proxy.interfaces;

import android.bluetooth.le.ScanResult;
import ce.com.cenewbluesdk.entity.MyBleDevice;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/interfaces/OnScanDevListener.class */
public interface OnScanDevListener {
    void onFindDev(ScanResult scanResult);

    void onFindDevList(ScanResult scanResult, List<MyBleDevice> list, MyBleDevice myBleDevice);
}
