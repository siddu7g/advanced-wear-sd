package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_OTA_STATUS.class */
public final class ProcessDATA_TYPE_OTA_STATUS extends BaseK6AnalysiDevData {
    public ProcessDATA_TYPE_OTA_STATUS(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(CEBC.K6.DATA_TYPE_OTA_STATUS);
        setDataTypeStr(K6_Action.RCVD.RCVD_OTA_INFO);
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public Object realProcess(byte[] bArr) {
        this.ceDevK6Proxy.dealOtaInfo(bArr);
        return Boolean.TRUE;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(Object obj) {
        return false;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    protected boolean sendMsg(Object obj) {
        return false;
    }
}
