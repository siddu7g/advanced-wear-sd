package ce.com.cenewbluesdk.proxy;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.bluetooth.CEBlueToothBase;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_QR_CODE_INFO;
import ce.com.cenewbluesdk.entity.k6.K6_MessageNoticeStruct;
import ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.uitl.h;
import java.io.Serializable;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEBluetoothProxyBase.class */
public abstract class CEBluetoothProxyBase {
    Handler handler;
    public Context context;
    protected CEBlueToothBase blueTooth;
    protected CEConnectUtilForAndroid5 connectUtil;
    protected CEDevQueue devQueue;

    protected CEBluetoothProxyBase(Context context) {
        this.context = context;
        initProxy();
    }

    public Handler setHandler(Handler handler) {
        this.handler = handler;
        return handler;
    }

    public void sendMeg(Message message) {
        Handler handler = this.handler;
        if (handler != null) {
            handler.sendMessage(message);
        }
    }

    public abstract void startOta(String str);

    public abstract void startFileTrans(String str);

    public abstract void sendSynDevData();

    public abstract String modifyDial(int i, int i2, int i3, int i4, boolean z);

    public abstract String modifyDial(String str, int i, int i2, int i3, int i4, int i5, int i6);

    public abstract IK6SendDataManager getSendHelper();

    public abstract IK6AnalysiDevRcvDataManager getK6AnalysiDevManager();

    public abstract void setMsg(K6_MessageNoticeStruct k6_MessageNoticeStruct);

    public Handler getHandler() {
        return this.handler;
    }

    public Message createMessage(int i, Serializable serializable) {
        Message messageObtain = Message.obtain();
        messageObtain.what = i;
        Bundle bundle = new Bundle();
        bundle.putSerializable("data", serializable);
        messageObtain.setData(bundle);
        return messageObtain;
    }

    public Message createMessage(int i, Serializable serializable, int i2) {
        Message messageObtain = Message.obtain();
        messageObtain.what = i;
        Bundle bundle = new Bundle();
        bundle.putSerializable("data", serializable);
        messageObtain.setData(bundle);
        messageObtain.arg1 = i2;
        return messageObtain;
    }

    public Message createMessage(int i, Parcelable parcelable) {
        Message messageObtain = Message.obtain();
        messageObtain.what = i;
        Bundle bundle = new Bundle();
        bundle.putParcelable("data", parcelable);
        messageObtain.setData(bundle);
        return messageObtain;
    }

    public Message createMessage(int i, ArrayList<Parcelable> arrayList) {
        Message messageObtain = Message.obtain();
        messageObtain.what = i;
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("data", arrayList);
        messageObtain.setData(bundle);
        return messageObtain;
    }

    protected abstract void dataSendSucceed(CEDevData cEDevData);

    protected abstract void DataSendFailed(CEDevData cEDevData);

    protected abstract void receiptData(CEDevData cEDevData);

    protected abstract void blueToothConnectStateChange(int i);

    protected abstract void initProxy();

    protected abstract String getClassName();

    public void sendData(CEDevData cEDevData) {
        this.devQueue.push(cEDevData);
    }

    @Deprecated
    public void connectDev(String str) {
    }

    public boolean connectDev(String str, String str2) {
        if (!h.a(str2) && !TextUtils.isEmpty(str2)) {
            return false;
        }
        this.connectUtil.connect(str);
        return true;
    }

    public void disConnect() {
        this.connectUtil.disConnect();
    }

    public CEConnectUtilForAndroid5 getConnectUtil() {
        return this.connectUtil;
    }

    public abstract void startPair();

    public void reConnectWithNtf() {
        Log.e("qob", "reConnectWithNtf");
        String blueAddress = getBlueAddress();
        if (blueAddress == null || blueAddress.length() <= 0 || isConnectOK()) {
            return;
        }
        this.connectUtil.reconnectDev(blueAddress);
    }

    public boolean reConnectDirect() {
        Log.e("qob", "reConnectWithNtf");
        String blueAddress = getBlueAddress();
        String blueAddress2 = blueAddress;
        if (TextUtils.isEmpty(blueAddress)) {
            blueAddress2 = this.connectUtil.getBlueAddress();
        } else {
            this.connectUtil.setBlueAddress(blueAddress2);
        }
        String str = blueAddress2;
        Log.e("qob", "tMacAdress=" + blueAddress2 + isConnectOK());
        if (str == null || blueAddress2.length() <= 0 || isConnectOK()) {
            return false;
        }
        this.connectUtil.connect(blueAddress2);
        return true;
    }

    public void forceDisConnect() {
        this.connectUtil.forceTestDisConnect();
    }

    public boolean isConnectOK() {
        return this.connectUtil.getCurrConnectState() == 1;
    }

    public boolean isDisconnect() {
        return this.connectUtil.getCurrConnectState() == 0;
    }

    public String getBlueAddress() {
        return CEBlueSharedPreference.getDevAddress();
    }

    public void setBlueAddress(String str) {
        this.connectUtil.setBlueAddress(str);
        CEBlueSharedPreference.setDevAddress(str);
    }

    public Message createMessage(int i, int i2) {
        Message messageObtain = Message.obtain();
        messageObtain.arg1 = i2;
        messageObtain.what = i;
        return messageObtain;
    }

    public Message createMessage(String str, int i) {
        return createMessage(str.hashCode(), i);
    }

    public Message createMessage(String str, Integer num) {
        return num != null ? createMessage(str.hashCode(), num.intValue()) : createMessage(str.hashCode(), num);
    }

    public Message createMessage(String str, Parcelable parcelable) {
        return createMessage(str.hashCode(), parcelable);
    }

    public Message createMessage(String str, ArrayList<Parcelable> arrayList) {
        return createMessage(str.hashCode(), arrayList);
    }

    public Message createMessage(String str, Serializable serializable) {
        return createMessage(str.hashCode(), serializable);
    }

    public Message createMessage(String str, Serializable serializable, int i) {
        return createMessage(str.hashCode(), serializable, i);
    }

    public abstract void sendWatchFaceTimeOut(boolean z);

    public abstract void setSpeedUp(boolean z);

    public abstract void stopFileTransfer();

    public abstract boolean isSpeedUp();

    public abstract void clearDate();

    public abstract void setVolume(int i);

    public abstract void connectDevice(String str, String str2);

    public abstract void sendQRInfo(K6_DATA_TYPE_QR_CODE_INFO k6_data_type_qr_code_info);
}
