package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.content.Context;
import ce.com.cenewbluesdk.entity.MusicControlInfo;
import ce.com.cenewbluesdk.proxy.interfaces.OnPushAppListListener;
import java.util.HashMap;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/IPersistent.class */
public interface IPersistent {
    void setBlueAddress(String str);

    String getBlueAddress();

    void getSdkPushSetting(Context context, OnPushAppListListener onPushAppListListener);

    void setAppDevicePushMessage(List<HashMap> list);

    String getAppDevicePushMessage();

    void setPhonePushMessage(String str);

    int getPhonePushMessage();

    void setContext(Context context);

    String getDeviceId();

    int getTargetStep();

    int getTargetDistance();

    int getTargetCalorie();

    int getTargetSleep();

    int getTargetDuration();

    int getAppPairFinish();

    void setAppPairFinish(String str);

    void setAppDeviceUserInfo(String str);

    int getAppDevicePushPhone();

    void setAppDevicePushPhone(String str);

    void setDevName(String str);

    String getDevName();

    void setUserId(String str);

    String getUserId();

    int getConnectStatue();

    void setConnectStatue(int i);

    void setAppFrontState(String str);

    int getAppFrontState();

    void setAppTimeDisplay(String str);

    void setAppDateDisplay(String str);

    String getDeviceBattery();

    void setGoalStep(int i);

    String getSoftwareVersion();

    int getAppTimeDisplay();

    int getAppDateDisplay();

    int getScreenHigh();

    int getScreenWidth();

    int getScreenRGB();

    void setMusicPackageName(String str);

    String getMusicPackageName();

    List<MusicControlInfo> getMusicAppList(Context context);

    List<HashMap> loadPushAppList(Context context);

    void setDeviceId(String str);
}
