package ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean;

import ce.com.cenewbluesdk.entity.k6.K6_Action;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_REAL_O2;
import ce.com.cenewbluesdk.proxy.CEDevK6Proxy;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import java.util.ArrayList;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/k6AnalysisDevData/AnalysisReceiveDataHelper/BlueProcessBean/ProcessDATA_TYPE_REAL_O2.class */
public final class ProcessDATA_TYPE_REAL_O2 extends BaseK6AnalysiDevData<ArrayList<K6_DATA_TYPE_REAL_O2>> {
    public ProcessDATA_TYPE_REAL_O2(CEDevK6Proxy cEDevK6Proxy) {
        super(cEDevK6Proxy);
        addDataType(20);
        setDataTypeStr(K6_Action.RCVD.RCVD_DATA_TYPE_REAL_O2);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public ArrayList<K6_DATA_TYPE_REAL_O2> realProcess(byte[] bArr) {
        int iByte2ToInt = ByteUtil.byte2ToInt(new byte[]{bArr[0], bArr[1]});
        int i = bArr[2] & 255;
        CEDevK6Proxy.lge("血氧：allItem=" + iByte2ToInt + "   item= " + i);
        int itemSize = 3;
        ArrayList<K6_DATA_TYPE_REAL_O2> arrayList = new ArrayList<>();
        for (int i2 = 0; i2 < i; i2++) {
            byte[] bArr2 = new byte[K6_DATA_TYPE_REAL_O2.getItemSize()];
            System.arraycopy(bArr, itemSize, bArr2, 0, K6_DATA_TYPE_REAL_O2.getItemSize());
            K6_DATA_TYPE_REAL_O2 k6_data_type_real_o2 = new K6_DATA_TYPE_REAL_O2(bArr2);
            CEDevK6Proxy.lge("接收到血氧数据:" + k6_data_type_real_o2.toString());
            arrayList.add(k6_data_type_real_o2);
            itemSize += K6_DATA_TYPE_REAL_O2.getItemSize();
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean processResult(ArrayList<K6_DATA_TYPE_REAL_O2> arrayList) {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ce.com.cenewbluesdk.proxy.k6AnalysisDevData.AnalysisReceiveDataHelper.BlueProcessBean.BaseK6AnalysiDevData
    public boolean sendMsg(ArrayList<K6_DATA_TYPE_REAL_O2> arrayList) {
        if (arrayList.size() <= 0) {
            return false;
        }
        CEDevK6Proxy cEDevK6Proxy = this.ceDevK6Proxy;
        cEDevK6Proxy.sendMeg(cEDevK6Proxy.createMessage(getDataTypeStr(), arrayList));
        return false;
    }
}
