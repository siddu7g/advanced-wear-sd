package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.entity.ModifyWatchInfo;
import ce.com.cenewbluesdk.entity.k6.K6_DATA_TYPE_QR_CODE_INFO;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.interfaces.OnCreateBinFileListener;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.f;
import ce.com.cenewbluesdk.uitl.g;
import com.example.cenewbluesdk.R;
import java.io.File;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/Transfer.class */
public class Transfer implements ITransfer {
    private Context mContext;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/Transfer$Holder.class */
    private static class Holder {
        private static final Transfer INSTANCE = new Transfer();

        private Holder() {
        }
    }

    public static Transfer getInstance() {
        return Holder.INSTANCE;
    }

    /* JADX WARN: Type inference failed for: r0v25, types: [java.io.File, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v53, types: [java.io.File, java.lang.Exception] */
    private String cBinFile(ModifyWatchInfo modifyWatchInfo, int i) throws IOException {
        if (i <= 1) {
            byte[] bArr = new byte[6];
            bArr[0] = (byte) modifyWatchInfo.getTime_pos();
            bArr[1] = (byte) modifyWatchInfo.getTime_up();
            bArr[2] = (byte) modifyWatchInfo.getTime_down();
            System.arraycopy(ByteUtil.int2bytes2(f.e(modifyWatchInfo.getColor())), 0, bArr, 3, 2);
            if (i == 0) {
                bArr[5] = 0;
            } else {
                bArr[5] = 1;
            }
            File file = new File(modifyWatchInfo.getSavePath(), "customDefault.bin");
            ?? file2 = new File(modifyWatchInfo.getSavePath());
            try {
                if (!file2.exists()) {
                    file2.mkdirs();
                }
                g.a(file);
                file.createNewFile();
                g.a(bArr, file);
            } catch (Exception unused) {
                file2.printStackTrace();
            }
            return file.getAbsolutePath();
        }
        g.a(new File(modifyWatchInfo.getSavePath(), "customImg.bin"));
        int screenWidth = CEBlueSharedPreference.getScreenWidth();
        int i2 = screenWidth;
        int screenHigh = CEBlueSharedPreference.getScreenHigh();
        int screenRGB = CEBlueSharedPreference.getScreenRGB();
        if (screenWidth <= 0 || screenHigh <= 0) {
            i2 = 240;
            screenHigh = 240;
        }
        Bitmap bitmapA = g.a(modifyWatchInfo.getFilePath(), i2, screenHigh, screenRGB);
        Bitmap bitmapA2 = bitmapA;
        Log.d("SDK", "width=" + bitmapA2.getWidth() + " height =" + bitmapA2.getHeight());
        if (bitmapA.getWidth() != i2 || bitmapA2.getHeight() != screenHigh) {
            bitmapA2 = g.a(bitmapA2, i2, screenHigh);
        }
        Bitmap bitmap = bitmapA2;
        int i3 = i2 * screenHigh;
        int[] iArr = new int[i3];
        bitmap.setHasAlpha(false);
        bitmap.getPixels(iArr, 0, i2, 0, 0, i2, screenHigh);
        bitmap.setHasAlpha(false);
        byte[] bArr2 = screenRGB == 0 ? new byte[(i3 * 2) + 10] : new byte[(i3 * 3) + 10];
        bArr2[0] = (byte) modifyWatchInfo.getTime_pos();
        bArr2[1] = (byte) modifyWatchInfo.getTime_up();
        bArr2[2] = (byte) modifyWatchInfo.getTime_down();
        System.arraycopy(ByteUtil.int2bytes2(f.e(modifyWatchInfo.getColor())), 0, bArr2, 3, 2);
        if (i == 0) {
            bArr2[5] = 0;
        } else {
            bArr2[5] = 2;
        }
        System.arraycopy(ByteUtil.int2bytes2(i2), 0, bArr2, 6, 2);
        System.arraycopy(ByteUtil.int2bytes2(screenHigh), 0, bArr2, 8, 2);
        int i4 = 10;
        for (int i5 = 0; i5 < i3; i5++) {
            if (screenRGB == 0) {
                System.arraycopy(ByteUtil.int2byte2(f.b(iArr[i5])), 0, bArr2, i4, 2);
                i4 += 2;
            } else {
                byte[] bArrInt2byte3 = ByteUtil.int2byte3(iArr[i5]);
                byte b = bArrInt2byte3[0];
                bArrInt2byte3[0] = bArrInt2byte3[2];
                bArrInt2byte3[2] = b;
                System.arraycopy(bArrInt2byte3, 0, bArr2, i4, 3);
                i4 += 3;
            }
        }
        File file3 = new File(modifyWatchInfo.getSavePath(), "customImg.bin");
        ?? file4 = new File(modifyWatchInfo.getSavePath());
        try {
            if (!file4.exists()) {
                file4.mkdirs();
            }
            byte[] bArr3 = bArr2;
            g.a(file3);
            file3.createNewFile();
            g.a(bArr3, file3);
        } catch (Exception unused2) {
            file4.printStackTrace();
        }
        return file3.getAbsolutePath();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public void setContext(Context context) {
        this.mContext = context;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [org.json.JSONException, org.json.JSONObject] */
    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public String getModifyDial(ModifyWatchInfo modifyWatchInfo, int i, int i2) throws JSONException, IOException {
        String strCBinFile = cBinFile(modifyWatchInfo, i2);
        ?? jSONObject = new JSONObject();
        try {
            jSONObject.put("cmd", 2);
            jSONObject.put("index", 2);
            jSONObject.put("filePath", strCBinFile);
            jSONObject.put("imgPath", modifyWatchInfo.getFilePath());
            jSONObject.put("faceType", i);
            jSONObject.put("time_pos", modifyWatchInfo.getTime_pos());
            jSONObject.put("time_up", modifyWatchInfo.getTime_up());
            jSONObject.put("time_down", modifyWatchInfo.getTime_down());
            jSONObject.put("color", modifyWatchInfo.getColor());
        } catch (JSONException unused) {
            jSONObject.printStackTrace();
        }
        return jSONObject.toString();
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [org.json.JSONException, org.json.JSONObject] */
    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public void getModifyDial(ModifyWatchInfo modifyWatchInfo, int i, int i2, OnCreateBinFileListener onCreateBinFileListener) throws JSONException, Resources.NotFoundException, IOException {
        String strCBinFile = cBinFile(modifyWatchInfo, i2);
        ?? jSONObject = new JSONObject();
        try {
            jSONObject.put("cmd", 2);
            jSONObject.put("index", 2);
            jSONObject.put("filePath", strCBinFile);
            jSONObject.put("imgPath", modifyWatchInfo.getFilePath());
            jSONObject.put("faceType", i);
            jSONObject.put("time_pos", modifyWatchInfo.getTime_pos());
            jSONObject.put("time_up", modifyWatchInfo.getTime_up());
            jSONObject.put("time_down", modifyWatchInfo.getTime_down());
            jSONObject.put("color", modifyWatchInfo.getColor());
        } catch (JSONException unused) {
            jSONObject.printStackTrace();
        }
        if (!BluetoothHelper.getInstance().isConnectOk()) {
            Toast.makeText(BluetoothHelper.getInstance().getContext(), R.string.disconnect, 0);
            return;
        }
        if (onCreateBinFileListener != null) {
            onCreateBinFileListener.onCreateBinFile(jSONObject.toString());
        }
        if (!TextUtils.isEmpty(modifyWatchInfo.getFilePath()) || TextUtils.isEmpty(jSONObject.toString())) {
            sendPrepareDial();
        } else {
            BleFactory.getInstance().getK6Proxy().startFileTrans(jSONObject.toString());
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public void sendPrepareDial() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendWatchFaceStart();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public void startFileTrans(String str) {
        BleFactory.getInstance().getK6Proxy().startFileTrans(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase] */
    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public void startMoreFileTrans(String str) throws JSONException {
        JSONException jSONObject = new JSONObject();
        try {
            jSONObject.put("cmd", 3);
            jSONObject.put("index", 3);
            jSONObject.put("filePath", str);
            Log.d("KK", "ota =$o");
            jSONObject = BleFactory.getInstance().getK6Proxy();
            jSONObject.startFileTrans(jSONObject.toString());
        } catch (JSONException unused) {
            jSONObject.printStackTrace();
        }
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase, org.json.JSONException] */
    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public void otaUpgrade(String str, String str2, String str3) throws JSONException {
        ?? k6Proxy;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("url", str);
            jSONObject.put("netVer", str2);
            jSONObject.put("devVer", str3);
            k6Proxy = BleFactory.getInstance().getK6Proxy();
            k6Proxy.startOta(jSONObject.toString());
        } catch (JSONException unused) {
            k6Proxy.printStackTrace();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.ITransfer
    public void sendQRInfo(K6_DATA_TYPE_QR_CODE_INFO k6_data_type_qr_code_info) {
        BleFactory.getInstance().getK6Proxy().sendQRInfo(k6_data_type_qr_code_info);
    }
}
