package ce.com.cenewbluesdk.proxy;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import ce.com.cenewbluesdk.a.a;
import ce.com.cenewbluesdk.bluetooth.CEBlueToothBase;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import ce.com.cenewbluesdk.uitl.Lg;
import ce.com.cenewbluesdk.uitl.Logger;
import java.io.IOException;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/CEConnectUtil.class */
public class CEConnectUtil extends BroadcastReceiver implements CEBlueToothBase.a {
    public static String Action_Reconnect = "reconnect_dev_action";
    private int currConnectState;
    private Context context;
    private CEBlueToothBase blueTooth;
    private CEBluetoothProxyBase proxyBase;
    private String blueAddress;
    private a reconnectMode;
    private boolean broadHaveregister = false;
    boolean blueSwitch = true;

    public CEConnectUtil(Context context, a aVar, CEBluetoothProxyBase cEBluetoothProxyBase, CEBlueToothBase cEBlueToothBase) {
        this.context = context;
        this.reconnectMode = aVar;
        this.proxyBase = cEBluetoothProxyBase;
        this.blueTooth = cEBlueToothBase;
        cEBlueToothBase.setBlueStateChangeListen(this);
        Log.e("rd60", "Action_Reconnect: " + Action_Reconnect + " proxyBase.getClassName() " + cEBluetoothProxyBase.getClassName());
    }

    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: PHI empty after try-catch fix!
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiInTryCatch(SSATransform.java:222)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixLastAssignInTry(SSATransform.java:202)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:58)
        	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:44)
        */
    private void registerRece() {
        /*
            r8 = this;
            r0 = r8
            boolean r0 = r0.broadHaveregister     // Catch: java.lang.Exception -> L4f
            if (r0 != 0) goto L52
            r0 = r8
            r1 = r0
            r2 = 1
            r1.broadHaveregister = r2     // Catch: java.lang.Exception -> L4f
            android.content.IntentFilter r1 = new android.content.IntentFilter     // Catch: java.lang.Exception -> L4f
            r2 = r1
            r3 = r1; r4 = r2; 
            r5 = r3; r6 = r4; 
            r9 = r6
            r5.<init>()     // Catch: java.lang.Exception -> L4f
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L4f
            r6 = r5
            r6.<init>()     // Catch: java.lang.Exception -> L4f
            java.lang.String r6 = ce.com.cenewbluesdk.proxy.CEConnectUtil.Action_Reconnect     // Catch: java.lang.Exception -> L4f
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch: java.lang.Exception -> L4f
            r6 = r8
            ce.com.cenewbluesdk.proxy.CEBluetoothProxyBase r6 = r6.proxyBase     // Catch: java.lang.Exception -> L4f
            java.lang.String r6 = r6.getClassName()     // Catch: java.lang.Exception -> L4f
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch: java.lang.Exception -> L4f
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Exception -> L4f
            r4.addAction(r5)     // Catch: java.lang.Exception -> L4f
            java.lang.String r4 = "android.intent.action.SCREEN_ON"
            r3.addAction(r4)     // Catch: java.lang.Exception -> L4f
            java.lang.String r3 = "android.intent.action.SCREEN_OFF"
            r2.addAction(r3)     // Catch: java.lang.Exception -> L4f
            java.lang.String r2 = "android.intent.action.PACKAGE_CHANGED"
            r1.addAction(r2)     // Catch: java.lang.Exception -> L4f
            android.content.Context r0 = r0.context     // Catch: java.lang.Exception -> L4f
            r1 = r8
            r2 = r9
            android.content.Intent r0 = r0.registerReceiver(r1, r2)     // Catch: java.lang.Exception -> L4f
            goto L52
        L4f:
            r0.printStackTrace()
        L52:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.proxy.CEConnectUtil.registerRece():void");
    }

    private void reConnect(String str) throws IOException {
        Lg.e("qob", "reConnect");
        this.blueAddress = str;
        this.blueTooth.connect(str);
        registerRece();
    }

    @Override // ce.com.cenewbluesdk.bluetooth.CEBlueToothBase.a
    public void blueToothConnectStateChange(int i) throws IOException {
        this.blueSwitch = BleSystemUtils.getBluetoothAdapter(this.context).isEnabled();
        this.currConnectState = i;
        this.proxyBase.blueToothConnectStateChange(i);
        Lg.e("YAN_BlueAddressK6对比：", this.currConnectState + ":1");
        int i2 = this.currConnectState;
        if (i2 != 0) {
            if (i2 == 1) {
                this.reconnectMode.b();
                this.reconnectMode.f();
                return;
            }
            return;
        }
        if (!TextUtils.isEmpty(this.proxyBase.getBlueAddress())) {
            if (!this.blueSwitch) {
                Lg.e("YAN_blueIsClosed", "蓝牙关闭状态  地址不为空");
                return;
            } else {
                Lg.e("YAN_blueIsOpened", "蓝牙开启状态 地址不为空");
                reconnectDev();
                return;
            }
        }
        if (this.reconnectMode.a()) {
            if (!this.blueSwitch) {
                Lg.e("YAN_blueIsClosed", "蓝牙关闭状态 地址2为空");
            } else {
                reconnectDev();
                Lg.e("YAN_blueIsOpened", "蓝牙开启状态 地址为空");
            }
        }
    }

    public void connect(String str) throws IOException {
        Lg.e("qob", "connect");
        this.reconnectMode.g();
        this.reconnectMode.b();
        this.blueAddress = str;
        this.blueTooth.connect(str);
        registerRece();
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [android.content.Context, java.lang.Exception] */
    public void disConnect() {
        ?? r0;
        try {
            Logger.e("TAG_GATT", "disConnect_1");
            Lg.e("CEConnectUtil disConnect ");
            this.blueAddress = "";
            if (this.broadHaveregister) {
                this.broadHaveregister = false;
                r0 = this.context;
                r0.unregisterReceiver(this);
            }
        } catch (Exception unused) {
            r0.printStackTrace();
        }
        this.blueTooth.disConnect();
    }

    public void forceTestDisConnect() {
        Lg.e("CEConnectUtil forceTestDisConnect ");
        this.blueTooth.disConnect();
    }

    public int getConnectTimes() {
        return this.reconnectMode.d();
    }

    public void reconnectDev() {
        Lg.e("CEConnectUtil reconnectDev " + this.reconnectMode.c());
        Intent intent = new Intent(Action_Reconnect + this.proxyBase.getClassName());
        AlarmManager alarmManager = (AlarmManager) this.context.getSystemService("alarm");
        PendingIntent broadcast = PendingIntent.getBroadcast(this.context, 0, intent, 67108864);
        int i = Build.VERSION.SDK_INT;
        if (i >= 23) {
            alarmManager.setExactAndAllowWhileIdle(2, SystemClock.elapsedRealtime() + this.reconnectMode.c(), PendingIntent.getBroadcast(this.context, 0, intent, 67108864));
        } else if (i >= 19) {
            alarmManager.setExact(2, SystemClock.elapsedRealtime() + this.reconnectMode.c(), broadcast);
        } else {
            alarmManager.setRepeating(2, SystemClock.elapsedRealtime(), this.reconnectMode.c(), broadcast);
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) throws IOException, SecurityException {
        Lg.e("rd60", "onReceive: " + intent);
        Logger.i("TAG_GATT", "rd60");
        if (intent.getAction().equals("android.intent.action.TIME_TICK")) {
            Lg.e("timeBroad", "时间变化了");
        } else if (intent.getAction().equals("android.intent.action.SCREEN_ON")) {
            Lg.e("timeBroad", "屏幕解锁了");
            ce.com.cenewbluesdk.pushmessage.a.b(context);
        } else if (intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
            Lg.e("timeBroad", "屏幕关闭了");
            ce.com.cenewbluesdk.pushmessage.a.b(context);
        } else if (intent.getAction().equals("android.intent.action.BATTERY_CHANGED")) {
            Lg.e("timeBroad", "电量改变了");
        } else if (intent.getAction().equals("android.intent.action.PACKAGE_CHANGED")) {
            Lg.e("ACTION_PACKAGE_CHANGED");
        }
        reConnect(this.blueAddress);
        this.reconnectMode.e();
    }

    public int getCurrConnectState() {
        return this.currConnectState;
    }
}
