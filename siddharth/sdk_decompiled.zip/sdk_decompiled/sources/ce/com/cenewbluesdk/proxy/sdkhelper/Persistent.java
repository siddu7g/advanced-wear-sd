package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.MusicControlInfo;
import ce.com.cenewbluesdk.proxy.MusicControl;
import ce.com.cenewbluesdk.proxy.interfaces.OnPushAppListListener;
import ce.com.cenewbluesdk.pushmessage.b;
import ce.com.cenewbluesdk.uitl.Lg;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/Persistent.class */
public class Persistent implements IPersistent {
    private Context mContext;

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/Persistent$Holder.class */
    private static class Holder {
        private static final Persistent INSTANCE = new Persistent();

        private Holder() {
        }
    }

    public static Persistent getInstance() {
        return Holder.INSTANCE;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setContext(Context context) {
        this.mContext = context;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getDeviceId() {
        return CEBlueSharedPreference.getDeviceId();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setBlueAddress(String str) {
        CEBlueSharedPreference.setDevAddress(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getBlueAddress() {
        return CEBlueSharedPreference.getDevAddress();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void getSdkPushSetting(Context context, OnPushAppListListener onPushAppListListener) {
        b.a().a(context, onPushAppListListener);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public List<HashMap> loadPushAppList(Context context) {
        return b.a().b(context);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setAppDevicePushMessage(List<HashMap> list) {
        if (list != null) {
            StringBuilder sb = new StringBuilder();
            for (HashMap map : list) {
                String str = (String) map.get(CEBC.PACKAGEINFO.KEYAPPPACKAGENAME);
                if (((Boolean) map.get(CEBC.PACKAGEINFO.KEYAPPISOPEN)).booleanValue()) {
                    if (sb.length() == 0) {
                        sb.append(str);
                    } else {
                        sb.append("|" + str);
                    }
                }
            }
            if (sb.length() > 0) {
                CEBlueSharedPreference.setAppDevicePushMessage(sb.toString());
                return;
            }
        }
        CEBlueSharedPreference.setAppDevicePushMessage("");
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getAppDevicePushMessage() {
        return CEBlueSharedPreference.getAppDevicePushMessage();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setPhonePushMessage(String str) {
        CEBlueSharedPreference.setAppDevicePushPhone(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getPhonePushMessage() {
        return CEBlueSharedPreference.getAppDevicePushPhone();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getTargetStep() {
        return CEBlueSharedPreference.getTargetStep();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getTargetDistance() {
        return CEBlueSharedPreference.getTargetDistance();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getTargetCalorie() {
        return CEBlueSharedPreference.getTargetCalorie();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getTargetSleep() {
        return CEBlueSharedPreference.getTargetSleep();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getTargetDuration() {
        return CEBlueSharedPreference.getTargetDuration();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getAppPairFinish() {
        return CEBlueSharedPreference.getAppPairFinish();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setAppPairFinish(String str) {
        CEBlueSharedPreference.setAppPairFinish(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setAppDeviceUserInfo(String str) {
        CEBlueSharedPreference.setAppDeviceUserInfo(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getAppDevicePushPhone() {
        return CEBlueSharedPreference.getAppDevicePushPhone();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setAppDevicePushPhone(String str) {
        CEBlueSharedPreference.setAppDevicePushPhone(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setDevName(String str) {
        CEBlueSharedPreference.setDeviceName(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getDevName() {
        return CEBlueSharedPreference.getDeviceName();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setUserId(String str) {
        CEBlueSharedPreference.setUserId(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getUserId() {
        return CEBlueSharedPreference.getUserId();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getConnectStatue() {
        return CEBlueSharedPreference.getkey_connect_states();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setConnectStatue(int i) {
        CEBlueSharedPreference.set_key_connect_states(i + "");
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setAppFrontState(String str) {
        CEBlueSharedPreference.setAppFrontState(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getAppFrontState() {
        return CEBlueSharedPreference.getAppFrontState();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setAppTimeDisplay(String str) {
        CEBlueSharedPreference.setAppTimeDisplay(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setAppDateDisplay(String str) {
        CEBlueSharedPreference.setAppDateDisplay(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getAppDateDisplay() {
        return CEBlueSharedPreference.getAppDateDisplay();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getScreenHigh() {
        return CEBlueSharedPreference.getScreenHigh();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getScreenWidth() {
        return CEBlueSharedPreference.getScreenWidth();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getScreenRGB() {
        return CEBlueSharedPreference.getScreenRGB();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setMusicPackageName(String str) {
        CEBlueSharedPreference.setMusicPackageName(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getMusicPackageName() {
        return CEBlueSharedPreference.getMusicPackageName();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public int getAppTimeDisplay() {
        return CEBlueSharedPreference.getAppTimeDisplay();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getDeviceBattery() {
        return CEBlueSharedPreference.getKEY_DEVICEBATTERY();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setGoalStep(int i) {
        CEBlueSharedPreference.setTargetStep(i + "");
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public String getSoftwareVersion() {
        return CEBlueSharedPreference.getSoftwareVersion();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public List<MusicControlInfo> getMusicAppList(Context context) {
        PackageManager packageManager = context.getPackageManager();
        BluetoothHelper.getInstance().getMusicControl();
        ResolveInfo prefMusicPlayer = MusicControl.getPrefMusicPlayer(context);
        BluetoothHelper.getInstance().getMusicControl();
        List<ResolveInfo> mediaButtonReceiver = MusicControl.getMediaButtonReceiver(packageManager, context);
        if (mediaButtonReceiver == null || mediaButtonReceiver.size() == 0) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (ResolveInfo resolveInfo : mediaButtonReceiver) {
            boolean z = false;
            Iterator it = arrayList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                if (((MusicControlInfo) it.next()).getPkgName().equals(resolveInfo.activityInfo.packageName)) {
                    z = true;
                    break;
                }
            }
            if (!z) {
                MusicControlInfo musicControlInfo = new MusicControlInfo();
                musicControlInfo.setIcon(resolveInfo.loadIcon(packageManager));
                musicControlInfo.setAppName(resolveInfo.loadLabel(packageManager).toString());
                musicControlInfo.setPkgName(resolveInfo.activityInfo.packageName);
                if (prefMusicPlayer == null || !musicControlInfo.getPkgName().equals(prefMusicPlayer.activityInfo.packageName)) {
                    musicControlInfo.setChoice(false);
                } else {
                    musicControlInfo.setChoice(true);
                }
                Lg.d("music event =" + musicControlInfo.getAppName() + " pkg =" + musicControlInfo.getPkgName());
                arrayList.add(musicControlInfo);
            }
        }
        return arrayList;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IPersistent
    public void setDeviceId(String str) {
        CEBlueSharedPreference.setDeviceId(str);
    }
}
