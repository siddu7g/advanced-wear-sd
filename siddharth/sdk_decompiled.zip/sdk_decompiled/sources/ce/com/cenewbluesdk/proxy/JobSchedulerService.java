package ce.com.cenewbluesdk.proxy;

import android.app.job.JobParameters;
import android.app.job.JobService;
import ce.com.cenewbluesdk.uitl.Lg;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/JobSchedulerService.class */
public class JobSchedulerService extends JobService {
    @Override // android.app.job.JobService
    public boolean onStartJob(JobParameters jobParameters) {
        Lg.e("JobSchedulerService");
        try {
            BleFactory.getInstance().getK6Proxy().reConnectWithNtf();
            Lg.e("JobSchedulerService OK");
            return true;
        } catch (Error unused) {
            return true;
        } catch (Exception unused2) {
            Lg.e("JobSchedulerService Exception");
            return true;
        }
    }

    @Override // android.app.job.JobService
    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }
}
