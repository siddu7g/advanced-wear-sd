package ce.com.cenewbluesdk.proxy.sdkhelper;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import ce.com.cenewbluesdk.BleContentProvider.CEBlueSharedPreference;
import ce.com.cenewbluesdk.bluetooth.a.b;
import ce.com.cenewbluesdk.entity.MyBleDevice;
import ce.com.cenewbluesdk.proxy.BleFactory;
import ce.com.cenewbluesdk.proxy.MusicControl;
import ce.com.cenewbluesdk.proxy.interfaces.IK6AnalysiDevRcvDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.IK6SendDataManager;
import ce.com.cenewbluesdk.proxy.interfaces.OnBlueScanCompleteListener;
import ce.com.cenewbluesdk.proxy.interfaces.OnScanDevListener;
import ce.com.cenewbluesdk.scan.CEScanDevBase;
import ce.com.cenewbluesdk.scan.CEScanDev_4_Android5;
import ce.com.cenewbluesdk.uitl.BleSystemUtils;
import ce.com.cenewbluesdk.uitl.Logger;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

/* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/Bluetooth_5SDK_Processor.class */
public class Bluetooth_5SDK_Processor implements IBluetoothProcessor {
    private CEScanDevBase scanDev4Android5;
    private OnScanDevListener onScanDevListener;
    private Context context;
    private Handler blueToothHandler;
    private MusicControl musicControl;
    private OnBlueScanCompleteListener onBlueScanCompleteListener;
    private int scanTimeOut = 3000;
    private Handler timeOutHandler = new Handler();
    private ScanTimeoutRunnable scanTimeoutR = new ScanTimeoutRunnable();
    CEScanDevBase.FindBlueTooth5 onFindDevListener = new CEScanDevBase.FindBlueTooth5() { // from class: ce.com.cenewbluesdk.proxy.sdkhelper.Bluetooth_5SDK_Processor.1
        @Override // ce.com.cenewbluesdk.scan.CEScanDevBase.FindBlueTooth5
        public void findDev(int i, ScanResult scanResult) {
            if (Bluetooth_5SDK_Processor.this.onScanDevListener != null) {
                Bluetooth_5SDK_Processor.this.onScanDevListener.onFindDev(scanResult);
            }
        }

        @Override // ce.com.cenewbluesdk.scan.CEScanDevBase.FindBlueTooth5
        public void findDevList(int i, ScanResult scanResult, List<MyBleDevice> list, MyBleDevice myBleDevice) {
            if (Bluetooth_5SDK_Processor.this.onScanDevListener != null) {
                Bluetooth_5SDK_Processor.this.onScanDevListener.onFindDevList(scanResult, list, myBleDevice);
            }
        }
    };

    /* loaded from: classes.jar:ce/com/cenewbluesdk/proxy/sdkhelper/Bluetooth_5SDK_Processor$ScanTimeoutRunnable.class */
    class ScanTimeoutRunnable implements Runnable {
        ScanTimeoutRunnable() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Bluetooth_5SDK_Processor.this.stopScan();
            if (Bluetooth_5SDK_Processor.this.onBlueScanCompleteListener != null) {
                Bluetooth_5SDK_Processor.this.onBlueScanCompleteListener.onBlueScanComplete();
            }
        }
    }

    public Bluetooth_5SDK_Processor() {
    }

    public Bluetooth_5SDK_Processor(Context context) {
        this.context = context.getApplicationContext();
    }

    private void startScanTimeOut() {
        this.timeOutHandler.removeCallbacks(this.scanTimeoutR);
        this.timeOutHandler.postDelayed(this.scanTimeoutR, this.scanTimeOut);
    }

    private void endScanTimeOut() {
        this.timeOutHandler.removeCallbacks(this.scanTimeoutR);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void initProxy(Context context) {
        this.context = context.getApplicationContext();
        BleFactory.getInstance().init(context);
        BleFactory.getInstance().getK6Proxy();
        CEBlueSharedPreference.getInstance(context);
        Persistent.getInstance().setContext(context);
        Transfer.getInstance().setContext(context);
        SendBlueToothData.getInstance().setContext(context);
        this.musicControl = new MusicControl(context);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void onDestroy() {
        this.context = null;
        this.musicControl = null;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Context getContext() {
        return this.context;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public MusicControl getMusicControl() {
        if (this.musicControl == null) {
            this.musicControl = new MusicControl(this.context);
        }
        return this.musicControl;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void startPairSynData() {
        BleFactory.getInstance().getK6Proxy().startPair();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void devicePairFinish(int i) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().sendDevicePairFinish((byte) i);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void synDevData() {
        BleFactory.getInstance().getK6Proxy().sendSynDevData();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Persistent getPersistent() {
        return Persistent.getInstance();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Transfer getTransfer() {
        return Transfer.getInstance();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public SendBlueToothData getSendBlueData() {
        return SendBlueToothData.getInstance();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public IK6AnalysiDevRcvDataManager getRcvDataManager() {
        return BleFactory.getInstance().getK6Proxy().getK6AnalysiDevManager();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public IK6SendDataManager getSendDataManager() {
        return BleFactory.getInstance().getK6Proxy().getSendHelper();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public boolean isEnabled() {
        return BleSystemUtils.getBluetoothAdapter(this.context).isEnabled();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setHandler(Handler handler) {
        this.blueToothHandler = BleFactory.getInstance().getK6Proxy().setHandler(handler);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public Handler getBlueHandler() {
        return this.blueToothHandler;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void scanningDeviceInit(Context context, OnScanDevListener onScanDevListener) {
        this.onScanDevListener = onScanDevListener;
        this.scanDev4Android5 = new CEScanDev_4_Android5(context, this.onFindDevListener);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void stopScan() {
        endScanTimeOut();
        CEScanDevBase cEScanDevBase = this.scanDev4Android5;
        if (cEScanDevBase != null) {
            cEScanDevBase.stopScan();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void startScan() {
        CEScanDevBase cEScanDevBase = this.scanDev4Android5;
        if (cEScanDevBase != null) {
            cEScanDevBase.startScan();
            startScanTimeOut();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void startScan(String str) {
        CEScanDevBase cEScanDevBase = this.scanDev4Android5;
        if (cEScanDevBase != null) {
            cEScanDevBase.startScan_filter(str);
            startScanTimeOut();
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setScanTimeOut(int i) {
        this.scanTimeOut = i;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setBlueScanComplete(OnBlueScanCompleteListener onBlueScanCompleteListener) {
        if (onBlueScanCompleteListener != null) {
            this.onBlueScanCompleteListener = onBlueScanCompleteListener;
        }
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    @Deprecated
    public void connectDev(String str) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        BleFactory.getInstance().getK6Proxy().connectDev(str);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void connectDev(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        BleFactory.getInstance().getK6Proxy().connectDev(str, str2);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void connectDevice(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        BleFactory.getInstance().getK6Proxy().connectDevice(str, str2);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void removeBond(BluetoothDevice bluetoothDevice) throws IllegalAccessException, IOException, IllegalArgumentException, InvocationTargetException {
        Logger.d("BleConnectTool", "removeBond");
        if (BleFactory.getInstance().isConnectedByProfile(bluetoothDevice) == 2) {
            BleFactory.getInstance().disconnectByProfiles(bluetoothDevice);
        }
        b.b(bluetoothDevice);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void disConnect() {
        BleFactory.getInstance().getK6Proxy().disConnect();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public boolean isConnectOk() {
        return CEBlueSharedPreference.getkey_connect_states() == 1;
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setEnableGsDataTrans(boolean z) {
        BleFactory.getInstance().getK6Proxy().getSendHelper().setEnableGsDataTrans(z);
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public void setEnableGsDataTrans() {
        BleFactory.getInstance().getK6Proxy().getSendHelper().setEnableGsDataTrans();
    }

    @Override // ce.com.cenewbluesdk.proxy.sdkhelper.IBluetoothProcessor
    public boolean reConnectDirect() {
        return BleFactory.getInstance().getK6Proxy().reConnectDirect();
    }
}
