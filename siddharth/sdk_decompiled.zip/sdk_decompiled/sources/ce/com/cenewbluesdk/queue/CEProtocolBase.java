package ce.com.cenewbluesdk.queue;

import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.QueueSendData;
import java.util.HashMap;

/* loaded from: classes.jar:ce/com/cenewbluesdk/queue/CEProtocolBase.class */
public abstract class CEProtocolBase {
    protected HashMap<Integer, CEDevData> dataHashMap = new HashMap<>();
    public int pageL = 20;

    public abstract QueueSendData getSendData(CEDevData cEDevData);

    public abstract CEDevData Analysis(byte[] bArr);

    public abstract void removeMapData(Integer num);

    public abstract byte[] convertACK(byte b);
}
