package ce.com.cenewbluesdk.queue;

import android.util.Log;
import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.uitl.ByteUtil;

/* loaded from: classes.jar:ce/com/cenewbluesdk/queue/CEProtocolB.class */
public class CEProtocolB extends CEProtocolBase {
    private static final int headpageL = 10;
    public static int MTU = 20;
    public static int slDataL = 20;
    private int mtu;
    private int devType;
    private CEDevData currDevData;
    private int totalPage;
    private int currentIndex;
    private int count = 0;
    int currentPackage = 0;

    public CEProtocolB(int i) {
        this.devType = i;
    }

    private byte[] getSendSubData(CEDevData cEDevData) {
        int i;
        byte[] bArr = new byte[slDataL];
        if (cEDevData.getDataType() != 131 || (i = this.totalPage) <= 255) {
            bArr[0] = (byte) cEDevData.getCurrentIndex();
        } else {
            int i2 = this.currentPackage;
            if (i2 >= i) {
                bArr[0] = -1;
            } else if (i2 >= 254) {
                bArr[0] = -2;
            } else {
                bArr[0] = (byte) cEDevData.getCurrentIndex();
            }
        }
        int currentIndex = ((cEDevData.getCurrentIndex() - 1) * 19) + 10;
        if (cEDevData.getData().length >= currentIndex + 19) {
            System.arraycopy(cEDevData.getData(), currentIndex, bArr, 1, 19);
        } else {
            System.arraycopy(cEDevData.getData(), currentIndex, bArr, 1, cEDevData.getData().length - currentIndex);
        }
        return bArr;
    }

    private int getPageNumber(int i, int i2) {
        if (i <= 10) {
            return 0;
        }
        int i3 = i - 10;
        int i4 = i3 / 19;
        if (i3 % 19 > 0) {
            i4++;
        }
        if (i2 != 131 && i4 > 255) {
            i4 = 255;
        }
        return i4;
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x0246  */
    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public ce.com.cenewbluesdk.entity.QueueSendData getSendData(ce.com.cenewbluesdk.entity.CEDevData r16) {
        /*
            Method dump skipped, instructions count: 781
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: ce.com.cenewbluesdk.queue.CEProtocolB.getSendData(ce.com.cenewbluesdk.entity.CEDevData):ce.com.cenewbluesdk.entity.QueueSendData");
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public CEDevData Analysis(byte[] bArr) {
        if (bArr[0] != 0) {
            CEDevData cEDevData = this.currDevData;
            if (cEDevData == null) {
                Log.e("CEProtocolB", "设备侧给的数据异常  3  没有收到头包 :" + ByteUtil.byte2hex(bArr));
                return null;
            }
            if (cEDevData.getCurrentIndex() + 1 != bArr[0]) {
                Log.e("CEProtocolB", "设备侧给的数据异常  4  收到了跳变的字节数组 curr=" + this.currDevData.getCurrentIndex() + "设备侧给的：" + ((int) bArr[0]));
                return null;
            }
            this.currDevData.setCurrentIndex(bArr[0]);
            byte[] data = this.currDevData.getData();
            int currentIndex = ((this.currDevData.getCurrentIndex() - 1) * 19) + 10;
            if (data.length >= currentIndex + 19) {
                System.arraycopy(bArr, 1, data, currentIndex, 19);
            } else {
                System.arraycopy(bArr, 1, data, currentIndex, data.length - currentIndex);
            }
            if (this.currDevData.getCurrentIndex() < this.currDevData.getTotalIndex()) {
                return null;
            }
            this.currDevData.setCmd(CEBC.CMD_APP_ACK_TYPE);
            if (this.currDevData.getDataType() == 144) {
                this.currDevData.setCmd(CEBC.CMD_APP_NO_ACK_TYPE);
            }
            return this.currDevData;
        }
        this.devType = bArr[1];
        bArr[4] = (byte) (bArr[4] & 15);
        if (bArr[4] == 4) {
            CEDevData cEDevData2 = new CEDevData();
            cEDevData2.setPid(this.devType);
            cEDevData2.setCmd(-99);
            cEDevData2.setDataType(bArr[5] & 255);
            cEDevData2.setN(bArr[3] & 255);
            cEDevData2.setData(convertACK(bArr[10]));
            return cEDevData2;
        }
        CEDevData cEDevData3 = new CEDevData();
        this.currDevData = cEDevData3;
        cEDevData3.setCurrentIndex(0);
        this.currDevData.setPid(this.devType);
        this.currDevData.setTotalIndex(bArr[2]);
        this.currDevData.setCmd(bArr[4]);
        this.currDevData.setDataType(bArr[5] & 255);
        this.currDevData.setN(bArr[3] & 255);
        this.currDevData.setDataCrc16(0);
        this.currDevData.setData(new byte[ByteUtil.byte2ToInt(new byte[]{bArr[8], bArr[9]})]);
        byte[] data2 = this.currDevData.getData();
        if (this.currDevData.getTotalIndex() != 0) {
            if (data2.length > 10) {
                System.arraycopy(bArr, 10, data2, 0, slDataL - 10);
                return null;
            }
            Log.e("CEProtocolB", "设备侧给的数据异常  2  :" + ByteUtil.byte2hex(bArr));
            return null;
        }
        if (data2.length > 10) {
            Log.e("CEProtocolB", "设备侧给的数据异常  1  :" + ByteUtil.byte2hex(bArr));
            return null;
        }
        System.arraycopy(bArr, 10, data2, 0, data2.length);
        this.currDevData.setCmd(CEBC.CMD_APP_ACK_TYPE);
        if (this.currDevData.getDataType() == 144) {
            this.currDevData.setCmd(CEBC.CMD_APP_NO_ACK_TYPE);
        }
        return this.currDevData;
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public void removeMapData(Integer num) {
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public byte[] convertACK(byte b) {
        byte b2 = -100;
        switch (b) {
            case 1:
                b2 = -101;
                break;
            case 2:
                b2 = -102;
                break;
            case 3:
                b2 = -103;
                break;
            case 4:
                b2 = -104;
                break;
        }
        return new byte[]{b2};
    }
}
