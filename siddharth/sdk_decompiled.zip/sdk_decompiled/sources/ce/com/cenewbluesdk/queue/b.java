package ce.com.cenewbluesdk.queue;

import ce.com.cenewbluesdk.CEBC;
import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.QueueSendData;
import ce.com.cenewbluesdk.uitl.ByteUtil;
import ce.com.cenewbluesdk.uitl.Lg;

/* loaded from: classes.jar:ce/com/cenewbluesdk/queue/b.class */
public class b extends CEProtocolBase {

    /* renamed from: a, reason: collision with root package name */
    private static final int f45a = 10;
    public static int b = 20;
    public static int c = 20;
    private int d;
    private CEDevData e;
    private int f;
    private int g = 0;
    private int h;

    public b(int i) {
        this.d = i;
    }

    private byte[] getSendSubData(CEDevData cEDevData) {
        byte[] bArr = new byte[c];
        bArr[0] = (byte) cEDevData.getCurrentIndex();
        int currentIndex = ((cEDevData.getCurrentIndex() - 1) * 19) + 10;
        if (cEDevData.getData().length >= currentIndex + 19) {
            System.arraycopy(cEDevData.getData(), currentIndex, bArr, 1, 19);
        } else {
            System.arraycopy(cEDevData.getData(), currentIndex, bArr, 1, cEDevData.getData().length - currentIndex);
        }
        return bArr;
    }

    private int a(int i) {
        if (i <= 10) {
            return 0;
        }
        int i2 = i - 10;
        int i3 = i2 / 19;
        if (i2 % 19 > 0) {
            i3++;
        }
        if (i3 > 255) {
            i3 = 255;
        }
        return i3;
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public QueueSendData getSendData(CEDevData cEDevData) {
        int i = c;
        byte[] bArr = new byte[i];
        byte[] bArr2 = new byte[b];
        byte[] bArr3 = new byte[0];
        if (cEDevData.getCmd() == -10001) {
            bArr[0] = 0;
            bArr[1] = (byte) this.d;
            bArr[2] = 0;
            bArr[3] = (byte) cEDevData.getN();
            bArr[4] = 4;
            bArr[5] = (byte) cEDevData.getDataType();
            bArr[8] = 1;
            bArr[9] = 0;
            if (cEDevData.getDataCrc16() == cEDevData.figureCrc16()) {
                bArr[10] = 1;
            } else {
                bArr[10] = 3;
            }
            System.arraycopy(ByteUtil.int2bytes2(0), 0, bArr, 6, 2);
            byte[] bArr4 = new byte[c];
            System.arraycopy(bArr, 0, bArr4, 0, i);
            bArr3 = bArr4;
        } else if (cEDevData.getCurrentIndex() == 0) {
            this.g = 0;
            bArr[0] = 0;
            bArr[1] = (byte) this.d;
            int length = cEDevData.getData() != null ? cEDevData.getData().length : 0;
            int i2 = length;
            int iA = a(length);
            this.f = iA;
            cEDevData.setTotalIndex(iA);
            bArr[2] = (byte) this.f;
            bArr[3] = (byte) cEDevData.getN();
            bArr[4] = (byte) cEDevData.getCmd();
            bArr[5] = (byte) cEDevData.getDataType();
            Lg.e("liu  tCrcSum= 0");
            System.arraycopy(ByteUtil.int2bytes2(0), 0, bArr, 6, 2);
            System.arraycopy(ByteUtil.int2bytes2(i2), 0, bArr, 8, 2);
            if (i2 > 0 && length <= 10) {
                System.arraycopy(cEDevData.getData(), 0, bArr, 10, length);
                int i3 = this.g + c;
                this.g = i3;
                bArr3 = new byte[i3];
                System.arraycopy(bArr, 0, bArr3, 0, i);
            } else if (length > 10) {
                System.arraycopy(cEDevData.getData(), 0, bArr, 10, c - 10);
                System.arraycopy(bArr, 0, bArr2, 0, i);
                int i4 = this.g + c;
                this.g = i4;
                if (i4 < b) {
                    int i5 = 0;
                    while (i5 < this.f) {
                        int i6 = i5 + 1;
                        i5 = i6;
                        cEDevData.setCurrentIndex(i6);
                        byte[] sendSubData = getSendSubData(cEDevData);
                        int i7 = i5 * c;
                        this.h = i7;
                        System.arraycopy(sendSubData, 0, bArr2, i7, sendSubData.length);
                        int i8 = this.g + c;
                        this.g = i8;
                        if (i8 >= b) {
                            break;
                        }
                    }
                }
                int i9 = this.g;
                bArr3 = new byte[i9];
                System.arraycopy(bArr2, 0, bArr3, 0, i9);
            }
        } else {
            this.g = 0;
            for (int i10 = 0; i10 < this.f && cEDevData.getCurrentIndex() <= this.f; i10++) {
                byte[] sendSubData2 = getSendSubData(cEDevData);
                int i11 = i10 * c;
                this.h = i11;
                System.arraycopy(sendSubData2, 0, bArr2, i11, sendSubData2.length);
                int i12 = this.g + c;
                this.g = i12;
                if (i12 >= b) {
                    break;
                }
                cEDevData.setCurrentIndex(cEDevData.getCurrentIndex() + 1);
            }
            int i13 = this.g;
            bArr3 = new byte[i13];
            System.arraycopy(bArr2, 0, bArr3, 0, i13);
        }
        if (bArr3.length <= 0) {
            int i14 = c;
            bArr3 = new byte[i14];
            System.arraycopy(bArr, 0, bArr3, 0, i14);
        }
        QueueSendData queueSendData = new QueueSendData();
        queueSendData.setSendData(bArr3);
        return queueSendData;
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public CEDevData Analysis(byte[] bArr) {
        if (bArr[0] != 0) {
            CEDevData cEDevData = this.e;
            if (cEDevData == null) {
                Lg.e("设备侧给的数据异常  3  没有收到头包 :" + ByteUtil.byte2hex(bArr));
                return null;
            }
            if (cEDevData.getCurrentIndex() + 1 != bArr[0]) {
                Lg.e("设备侧给的数据异常  4  收到了跳变的字节数组 curr=" + this.e.getCurrentIndex() + "设备侧给的：" + ((int) bArr[0]));
                return null;
            }
            this.e.setCurrentIndex(bArr[0]);
            byte[] data = this.e.getData();
            int currentIndex = ((this.e.getCurrentIndex() - 1) * 19) + 10;
            if (data.length >= currentIndex + 19) {
                System.arraycopy(bArr, 1, data, currentIndex, 19);
            } else {
                System.arraycopy(bArr, 1, data, currentIndex, data.length - currentIndex);
            }
            if (this.e.getCurrentIndex() < this.e.getTotalIndex()) {
                return null;
            }
            this.e.setCmd(CEBC.CMD_APP_ACK_TYPE);
            return this.e;
        }
        this.d = bArr[1];
        if (bArr[4] == 4) {
            CEDevData cEDevData2 = new CEDevData();
            cEDevData2.setPid(this.d);
            cEDevData2.setCmd(-99);
            cEDevData2.setDataType(bArr[5] & 255);
            cEDevData2.setN(bArr[3] & 255);
            cEDevData2.setData(convertACK(bArr[10]));
            return cEDevData2;
        }
        CEDevData cEDevData3 = new CEDevData();
        this.e = cEDevData3;
        cEDevData3.setCurrentIndex(0);
        this.e.setPid(this.d);
        this.e.setTotalIndex(bArr[2]);
        this.e.setCmd(bArr[4]);
        this.e.setDataType(bArr[5] & 255);
        this.e.setN(bArr[3] & 255);
        this.e.setDataCrc16(0);
        this.e.setData(new byte[ByteUtil.byte2ToInt(new byte[]{bArr[8], bArr[9]})]);
        byte[] data2 = this.e.getData();
        if (this.e.getTotalIndex() != 0) {
            if (data2.length > 10) {
                System.arraycopy(bArr, 10, data2, 0, c - 10);
                return null;
            }
            Lg.e("设备侧给的数据异常  2  :" + ByteUtil.byte2hex(bArr));
            return null;
        }
        if (data2.length > 10) {
            Lg.e("设备侧给的数据异常  1  :" + ByteUtil.byte2hex(bArr));
            return null;
        }
        System.arraycopy(bArr, 10, data2, 0, data2.length);
        this.e.setCmd(CEBC.CMD_APP_ACK_TYPE);
        return this.e;
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public void removeMapData(Integer num) {
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public byte[] convertACK(byte b2) {
        byte b3 = -100;
        switch (b2) {
            case 1:
                b3 = -101;
                break;
            case 2:
                b3 = -102;
                break;
            case 3:
                b3 = -103;
                break;
            case 4:
                b3 = -104;
                break;
        }
        return new byte[]{b3};
    }
}
