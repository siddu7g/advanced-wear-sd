package ce.com.cenewbluesdk.queue;

import ce.com.cenewbluesdk.entity.CEDevData;
import ce.com.cenewbluesdk.entity.QueueSendData;

/* loaded from: classes.jar:ce/com/cenewbluesdk/queue/a.class */
public class a extends CEProtocolBase {

    /* renamed from: a, reason: collision with root package name */
    private int f44a;

    public a(int i) {
        this.f44a = i;
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public QueueSendData getSendData(CEDevData cEDevData) {
        byte[] bArr = new byte[20];
        bArr[0] = (byte) this.f44a;
        bArr[1] = (byte) cEDevData.getCmd();
        bArr[2] = (byte) cEDevData.getDataType();
        int length = 0;
        if (cEDevData.getData() != null) {
            length = cEDevData.getData().length;
        }
        int i = length;
        int i2 = i / 16;
        if (i % 16 != 0) {
            i2++;
        }
        if (cEDevData.getCmd() == -10001) {
            i2 = 0;
            cEDevData.setTotalIndex(0);
        } else {
            cEDevData.setTotalIndex(i2);
        }
        bArr[3] = (byte) ((i2 << 4) | (cEDevData.getCurrentIndex() & 15));
        QueueSendData queueSendData = new QueueSendData();
        if (cEDevData.getCmd() != 4) {
            if (cEDevData.getCmd() == 2) {
                if (cEDevData.getCurrentIndex() == 0) {
                    bArr[4] = (byte) cEDevData.getItemNumber();
                    bArr[5] = (byte) cEDevData.getItemL();
                    int iFigureCrc16 = cEDevData.figureCrc16();
                    bArr[6] = (byte) (iFigureCrc16 & 255);
                    bArr[7] = (byte) (iFigureCrc16 >> 8);
                    if (cEDevData.getOtherData() != null) {
                        System.arraycopy(cEDevData.getOtherData(), 0, bArr, 8, cEDevData.getOtherData().length > 12 ? 12 : cEDevData.getOtherData().length);
                    }
                } else {
                    int length2 = 16;
                    if (cEDevData.getCurrentIndex() * 16 > cEDevData.getData().length) {
                        length2 = cEDevData.getData().length - ((cEDevData.getCurrentIndex() - 1) * 16);
                    }
                    System.arraycopy(cEDevData.getData(), (cEDevData.getCurrentIndex() - 1) * 16, bArr, 4, length2);
                }
            } else if (cEDevData.getCmd() == -10001) {
                bArr[1] = 5;
                queueSendData.setIndex(5);
            }
        }
        queueSendData.setSendData(bArr);
        return queueSendData;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v33 ??, still in use, count: 1, list:
          (r1v33 ?? I:ce.com.cenewbluesdk.entity.CEDevData) from 0x0079: INVOKE (r1v33 ?? I:ce.com.cenewbluesdk.entity.CEDevData), (r1v3 ?? I:int) VIRTUAL call: ce.com.cenewbluesdk.entity.CEDevData.setTotalIndex(int):void A[MD:(int):void (m)]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public ce.com.cenewbluesdk.entity.CEDevData Analysis(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v33 ??, still in use, count: 1, list:
          (r1v33 ?? I:ce.com.cenewbluesdk.entity.CEDevData) from 0x0079: INVOKE (r1v33 ?? I:ce.com.cenewbluesdk.entity.CEDevData), (r1v3 ?? I:int) VIRTUAL call: ce.com.cenewbluesdk.entity.CEDevData.setTotalIndex(int):void A[MD:(int):void (m)]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r12v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:405)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:258)
        */

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public void removeMapData(Integer num) {
        this.dataHashMap.remove(num);
    }

    @Override // ce.com.cenewbluesdk.queue.CEProtocolBase
    public byte[] convertACK(byte b) {
        byte b2 = -100;
        if (b == 0) {
            b2 = -101;
        } else if (b == 2) {
            b2 = -102;
        } else if (b == 3) {
            b2 = -103;
        } else if (b == 4) {
            b2 = -104;
        }
        return new byte[]{b2};
    }
}
