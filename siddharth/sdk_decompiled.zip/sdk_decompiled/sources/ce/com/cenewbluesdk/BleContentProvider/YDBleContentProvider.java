package ce.com.cenewbluesdk.BleContentProvider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import ce.com.cenewbluesdk.CEBC;

/* loaded from: classes.jar:ce/com/cenewbluesdk/BleContentProvider/YDBleContentProvider.class */
public class YDBleContentProvider extends ContentProvider {

    /* renamed from: a, reason: collision with root package name */
    private static final UriMatcher f2a = new UriMatcher(-1);
    private static final int b = 1;
    private static final int c = 8;
    private static final int d = 2;
    private static final int e = 3;
    private static final int f = 4;
    private static final int g = 5;
    private static final int h = 6;
    private static final int i = 7;
    private static final int j = 9;
    private static final int k = 10;
    private static final int l = 11;
    private static final int m = 12;
    private static final int n = 13;
    private static final int o = 14;
    private static final int p = 15;
    private static final int q = 16;
    private static final int r = 17;
    private static final int s = 18;
    private static final int t = 19;
    private static final int u = 20;
    private static final int v = 21;
    private static final int w = 22;
    private static final int x = 23;
    private static final int y = 24;
    private static final int z = 25;
    private static final int A = 26;
    private static final int B = 27;
    private static final int C = 28;
    private static final int D = 29;
    private static final int E = 30;
    private static final int F = 31;
    private static final int G = 32;
    private static final int H = 33;
    private static final String I = "key_connect_states";
    private static final String J = "key_pairfinish";
    private static final String K = "key_enterfront";
    private static final String L = "key_timedisplay";
    private static final String M = "key_datedisplay";
    private static final String N = "key_rrightScreen";
    private static final String O = "key_pushphone";
    private static final String P = "key_pushmessage";
    private static final String Q = "key_userinfo";
    public static final String R = "KEY_SLEEP_DATA";
    public static final String S = "KEY_SCREEN_WIDTH";
    public static final String T = "KEY_SCREEN_HIGH";
    public static final String U = "KEY_SCREEN_RGB";
    public static final String V = "key_deviceId";
    private SharedPreferences W;
    public String X;

    private SharedPreferences z() {
        if (this.W == null) {
            this.W = getContext().getSharedPreferences("BLE_DATA_INFO_ContentProvider", 0);
        }
        return this.W;
    }

    private void u(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_DEVMACADDRESS, str).apply();
    }

    private String s() {
        return z().getString(CEBC.URIKEY.KEY_DEVMACADDRESS, "");
    }

    private void x(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_UUID, str).apply();
    }

    private String v() {
        return z().getString(CEBC.URIKEY.KEY_UUID, "");
    }

    private void w(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_USERID, str).apply();
    }

    private String u() {
        return z().getString(CEBC.URIKEY.KEY_USERID, "");
    }

    private void v(String str) {
        z().edit().putString(R, str).apply();
    }

    private void t(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_DEVICEBATTERY, str).apply();
    }

    private String r() {
        return z().getString(CEBC.URIKEY.KEY_DEVICEBATTERY, "");
    }

    private void s(String str) {
        z().edit().putString("key_connect_states", str).apply();
    }

    private String q() {
        return z().getString("key_connect_states", "0");
    }

    private void b(String str) {
        z().edit().putString(J, str).apply();
    }

    private void z(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_NEWWEATHER_TYPE, str).apply();
    }

    private void r(String str) {
        z().edit().putString(K, str).apply();
    }

    private void m(String str) {
        z().edit().putString("key_timedisplay", str).apply();
    }

    private void f(String str) {
        z().edit().putString("key_datedisplay", str).apply();
    }

    private void e(String str) {
        z().edit().putString(N, str).apply();
    }

    private void k(String str) {
        z().edit().putString(O, str).apply();
    }

    private void j(String str) {
        z().edit().putString("key_pushmessage", str).apply();
    }

    private void n(String str) {
        z().edit().putString(Q, str).apply();
    }

    private void i(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_DEVNAME, str).apply();
    }

    private void o(String str) {
        z().edit().putString("KEY_SCREEN_WIDTH", str).apply();
    }

    private void g(String str) {
        z().edit().putString("KEY_SCREEN_HIGH", str).apply();
    }

    private void l(String str) {
        z().edit().putString("KEY_SCREEN_RGB", str).apply();
    }

    private void h(String str) {
        z().edit().putString("key_deviceId", str).apply();
    }

    private void G(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_STEP, str).apply();
    }

    private void D(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_DISTANCE, str).apply();
    }

    private void C(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_CALORIES, str).apply();
    }

    private void F(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_SLEEP, str).apply();
    }

    private void E(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_DURATION, str).apply();
    }

    private void B(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_SOFTWARE_VERSION, str).apply();
    }

    private void y(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_MUSIC_PACKAGE, str).apply();
    }

    private void a(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_A2DAMAC, str).apply();
    }

    private void A(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_PHONE_EDR_MAC, str).apply();
    }

    private void q(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_EDR_BACK_CONNECT, str).apply();
    }

    private void d(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_CUSTOMER_ID, str).apply();
    }

    private void c(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_BT_CONNECT_STATUS, str).apply();
    }

    private void p(String str) {
        z().edit().putString(CEBC.URIKEY.KEY_DIAL_SIZE, str).apply();
    }

    private String b() {
        return z().getString(J, "0");
    }

    private String p() {
        return z().getString(K, "1");
    }

    private String l() {
        return z().getString("key_timedisplay", "1");
    }

    private String f() {
        return z().getString("key_datedisplay", "0");
    }

    private String e() {
        return z().getString(N, "1");
    }

    private String j() {
        return z().getString(O, "1");
    }

    private String i() {
        return z().getString("key_pushmessage", "");
    }

    private String h() {
        return z().getString(CEBC.URIKEY.KEY_DEVNAME, "");
    }

    private String m() {
        return z().getString(Q, "");
    }

    private String n() {
        return z().getString("KEY_SCREEN_WIDTH", "240");
    }

    private String g() {
        return z().getString("KEY_SCREEN_HIGH", "240");
    }

    private String k() {
        return z().getString("KEY_SCREEN_RGB", "0");
    }

    private String H() {
        return z().getString("key_deviceId", "0");
    }

    private String G() {
        return z().getString(CEBC.URIKEY.KEY_STEP, "10000");
    }

    private String D() {
        return z().getString(CEBC.URIKEY.KEY_DISTANCE, "5000");
    }

    private String C() {
        return z().getString(CEBC.URIKEY.KEY_CALORIES, "1200");
    }

    private String F() {
        return z().getString(CEBC.URIKEY.KEY_SLEEP, "27000");
    }

    private String E() {
        return z().getString(CEBC.URIKEY.KEY_DURATION, "10800");
    }

    private String A() {
        return z().getString(CEBC.URIKEY.KEY_SOFTWARE_VERSION, "");
    }

    private String w() {
        return z().getString(CEBC.URIKEY.KEY_MUSIC_PACKAGE, "");
    }

    private String x() {
        return z().getString(CEBC.URIKEY.KEY_NEWWEATHER_TYPE, "1");
    }

    private String a() {
        return z().getString(CEBC.URIKEY.KEY_A2DAMAC, "");
    }

    private String y() {
        return z().getString(CEBC.URIKEY.KEY_PHONE_EDR_MAC, "");
    }

    private String B() {
        return z().getString(CEBC.URIKEY.KEY_EDR_BACK_CONNECT, "");
    }

    private String t() {
        return z().getString(R, "");
    }

    private String d() {
        return z().getString(CEBC.URIKEY.KEY_CUSTOMER_ID, "");
    }

    private String c() {
        return z().getString(CEBC.URIKEY.KEY_BT_CONNECT_STATUS, "-1");
    }

    private String o() {
        return z().getString(CEBC.URIKEY.KEY_DIAL_SIZE, "0");
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        Log.e("qob", "YDBleContentProvider onCreate ");
        String packageName = getContext().getPackageName();
        this.X = packageName;
        UriMatcher uriMatcher = f2a;
        uriMatcher.addURI(packageName, "key_connect_states", 8);
        uriMatcher.addURI(this.X, R, 9);
        uriMatcher.addURI(this.X, J, 1);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_DEVICEBATTERY, 10);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_USERID, 11);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_DEVMACADDRESS, 12);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_DEVNAME, 13);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_MUSIC_PACKAGE, 25);
        uriMatcher.addURI(this.X, K, 2);
        uriMatcher.addURI(this.X, "key_timedisplay", 3);
        uriMatcher.addURI(this.X, "key_datedisplay", 14);
        uriMatcher.addURI(this.X, N, 4);
        uriMatcher.addURI(this.X, O, 5);
        uriMatcher.addURI(this.X, "key_pushmessage", 6);
        uriMatcher.addURI(this.X, Q, 7);
        uriMatcher.addURI(this.X, "KEY_SCREEN_WIDTH", 15);
        uriMatcher.addURI(this.X, "KEY_SCREEN_HIGH", 16);
        uriMatcher.addURI(this.X, "KEY_SCREEN_RGB", 17);
        uriMatcher.addURI(this.X, "key_deviceId", 18);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_STEP, 19);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_DISTANCE, 20);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_CALORIES, 21);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_SLEEP, 22);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_DURATION, 23);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_SOFTWARE_VERSION, 24);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_NEWWEATHER_TYPE, 26);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_A2DAMAC, 27);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_CUSTOMER_ID, 28);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_UUID, 29);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_BT_CONNECT_STATUS, 30);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_DIAL_SIZE, 31);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_PHONE_EDR_MAC, 32);
        uriMatcher.addURI(this.X, CEBC.URIKEY.KEY_EDR_BACK_CONNECT, 33);
        return false;
    }

    @Override // android.content.ContentProvider
    @Nullable
    public Cursor query(@NonNull Uri uri, @Nullable String[] strArr, @Nullable String str, @Nullable String[] strArr2, @Nullable String str2) {
        Log.e("qob", "YDBleContentProvider query ");
        return null;
    }

    @Override // android.content.ContentProvider
    @Nullable
    public String getType(@NonNull Uri uri) {
        Log.e("qob", "YDBleContentProvider getType " + uri);
        switch (f2a.match(uri)) {
            case 1:
                return b();
            case 2:
                return p();
            case 3:
                return l();
            case 4:
                return e();
            case 5:
                Log.e("qob", "CODE_PUSH_PHONE uri " + uri);
                return j();
            case 6:
                return i();
            case 7:
                return m();
            case 8:
                return q();
            case 9:
                return t();
            case 10:
                return r();
            case 11:
                return u();
            case 12:
                return s();
            case 13:
                return h();
            case 14:
                return f();
            case 15:
                return n();
            case 16:
                return g();
            case 17:
                return k();
            case 18:
                return H();
            case 19:
                return G();
            case 20:
                return D();
            case 21:
                return C();
            case 22:
                return F();
            case 23:
                return E();
            case 24:
                return A();
            case 25:
                return w();
            case 26:
                return x();
            case 27:
                return a();
            case 28:
                return d();
            case 29:
                return v();
            case 30:
                return c();
            case 31:
                return o();
            case 32:
                return y();
            case 33:
                return B();
            default:
                return null;
        }
    }

    @Override // android.content.ContentProvider
    @Nullable
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    @Override // android.content.ContentProvider
    public int delete(@NonNull Uri uri, @Nullable String str, @Nullable String[] strArr) {
        return 0;
    }

    @Override // android.content.ContentProvider
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String str, @Nullable String[] strArr) {
        switch (f2a.match(uri)) {
            case 1:
                b(contentValues.getAsString(J));
                return 1;
            case 2:
                r(contentValues.getAsString(K));
                return 1;
            case 3:
                m(contentValues.getAsString("key_timedisplay"));
                return 1;
            case 4:
                e(contentValues.getAsString(N));
                return 1;
            case 5:
                k(contentValues.getAsString(O));
                return 1;
            case 6:
                j(contentValues.getAsString("key_pushmessage"));
                return 1;
            case 7:
                n(contentValues.getAsString(Q));
                return 1;
            case 8:
                s(contentValues.getAsString("key_connect_states"));
                return 1;
            case 9:
                v(contentValues.getAsString(R));
                return 1;
            case 10:
                t(contentValues.getAsString(CEBC.URIKEY.KEY_DEVICEBATTERY));
                return 1;
            case 11:
                w(contentValues.getAsString(CEBC.URIKEY.KEY_USERID));
                return 1;
            case 12:
                u(contentValues.getAsString(CEBC.URIKEY.KEY_DEVMACADDRESS));
                return 1;
            case 13:
                i(contentValues.getAsString(CEBC.URIKEY.KEY_DEVNAME));
                return 1;
            case 14:
                f(contentValues.getAsString("key_datedisplay"));
                return 1;
            case 15:
                o(contentValues.getAsString("KEY_SCREEN_WIDTH"));
                return 1;
            case 16:
                g(contentValues.getAsString("KEY_SCREEN_HIGH"));
                return 1;
            case 17:
                l(contentValues.getAsString("KEY_SCREEN_RGB"));
                return 1;
            case 18:
                h(contentValues.getAsString("key_deviceId"));
                return 1;
            case 19:
                G(contentValues.getAsString(CEBC.URIKEY.KEY_STEP));
                return 1;
            case 20:
                D(contentValues.getAsString(CEBC.URIKEY.KEY_DISTANCE));
                return 1;
            case 21:
                C(contentValues.getAsString(CEBC.URIKEY.KEY_CALORIES));
                return 1;
            case 22:
                F(contentValues.getAsString(CEBC.URIKEY.KEY_SLEEP));
                return 1;
            case 23:
                E(contentValues.getAsString(CEBC.URIKEY.KEY_DURATION));
                return 1;
            case 24:
                B(contentValues.getAsString(CEBC.URIKEY.KEY_SOFTWARE_VERSION));
                return 1;
            case 25:
                y(contentValues.getAsString(CEBC.URIKEY.KEY_MUSIC_PACKAGE));
                return 1;
            case 26:
                z(contentValues.getAsString(CEBC.URIKEY.KEY_NEWWEATHER_TYPE));
                break;
            case 27:
                break;
            case 28:
                d(contentValues.getAsString(CEBC.URIKEY.KEY_CUSTOMER_ID));
                return 1;
            case 29:
                x(contentValues.getAsString(CEBC.URIKEY.KEY_UUID));
                return 1;
            case 30:
                c(contentValues.getAsString(CEBC.URIKEY.KEY_BT_CONNECT_STATUS));
                return 1;
            case 31:
                p(contentValues.getAsString(CEBC.URIKEY.KEY_DIAL_SIZE));
                return 1;
            case 32:
                A(contentValues.getAsString(CEBC.URIKEY.KEY_PHONE_EDR_MAC));
                return 1;
            case 33:
                q(contentValues.getAsString(CEBC.URIKEY.KEY_EDR_BACK_CONNECT));
                return 1;
            default:
                return 0;
        }
        a(contentValues.getAsString(CEBC.URIKEY.KEY_A2DAMAC));
        return 1;
    }
}
