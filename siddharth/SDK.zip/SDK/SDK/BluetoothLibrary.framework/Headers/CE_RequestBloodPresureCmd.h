//
//  CERequestBloodPresureCmd.h
//  Moosh
//
//  Created by kwan on 2018/12/15.
//  Copyright © 2018 celink. All rights reserved.
//

#import <BluetoothLibrary/CE_Cmd.h>

NS_ASSUME_NONNULL_BEGIN

@interface CE_RequestBloodPresureCmd : CE_Cmd

@end

NS_ASSUME_NONNULL_END
