//
//  CE_RequestDevInfoCmd.h
//  K2SDKDemo
//
//  Created by cxq on 2016/12/26.
//  Copyright © 2016年 celink. All rights reserved.
//

#import <BluetoothLibrary/CE_Cmd.h>


/**
  获取设备信息时，需要向设备侧发送的数据
 */
@interface CE_RequestDevInfoCmd : CE_Cmd

@end
