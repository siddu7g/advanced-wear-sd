//
//  YD_RequestCleanData.h
//
//  Created by wpr on 2024/10/24.
//  Copyright © 2024年 coolwear. All rights reserved.
//

#import <BluetoothLibrary/CE_Cmd.h>

NS_ASSUME_NONNULL_BEGIN

@interface YD_RequestCleanData : CE_Cmd

+ (void)send;

@end

NS_ASSUME_NONNULL_END
