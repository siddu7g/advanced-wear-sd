//
//  CE_SyncWeatherCmd518.h
//  Moosh
//
//  Created by ledong on 2019/1/11.
//  Copyright © 2019年 celink. All rights reserved.
//

#import <BluetoothLibrary/CE_Cmd.h>

NS_ASSUME_NONNULL_BEGIN

@interface CE_SyncWeatherCmd518 : CE_Cmd

@end

NS_ASSUME_NONNULL_END
