//
//  CE_K6Protocol.h
//  CE_BleSDK
//
//  Created by cxq on 2016/12/30.
//  Copyright © 2016年 celink. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BluetoothLibrary/CE_ProductProtocol.h>


/**
 
*/
@interface CE_K6Protocol : NSObject <CE_Protocol>


@end
