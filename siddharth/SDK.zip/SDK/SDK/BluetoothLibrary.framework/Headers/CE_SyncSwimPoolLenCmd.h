//
//  CE_SyncSwimPoolLenCmd.h
//  Moosh
//
//  Created by ledong on 2018/3/30.
//  Copyright © 2018年 celink. All rights reserved.
//

#import <BluetoothLibrary/CE_Cmd.h>

@interface CE_SyncSwimPoolLenCmd : CE_Cmd

@property (nonatomic,assign) uint8_t pool_length;

@end
