#!/bin/bash

# Script to push SDK project to GitHub private repo
# Usage: ./push_to_github.sh YOUR_GITHUB_USERNAME YOUR_REPO_NAME

cd "/Users/meghanas/Downloads/SdkDemo_ios/SDK/coolwearsdkdemo-main 6"

echo "📦 Preparing SDK files for commit..."

# Add .gitignore
git add .gitignore

# Add SDK project files only
git add sdkdemo/
git add *.md
git add *.h
git add *.m 2>/dev/null
git add *.py 2>/dev/null
git add *.xcodeproj/ 2>/dev/null
git add *.xcworkspace/ 2>/dev/null
git add Podfile 2>/dev/null
git add plot_heart_rate.py 2>/dev/null

echo "✅ Files staged"

# Commit
echo "💾 Committing changes..."
git commit -m "Add BLE Protocol Analyzer and reverse engineering tools

- Added BLEProtocolAnalyzer for protocol reverse engineering
- Added manual parameter testing for debug commands (0xCB-0xCE)
- Added systematic exploration of opcodes 200-255
- Enhanced data collection for ECG, O2, and HR waveforms
- Added comprehensive documentation and analysis guides
- Implemented raw signal extraction attempts
- Added JSON export for all waveform data"

echo "✅ Committed"

# Set remote (if provided)
if [ ! -z "$1" ] && [ ! -z "$2" ]; then
    echo "🔗 Setting up remote repository..."
    git remote remove origin 2>/dev/null
    git remote add origin "https://github.com/$1/$2.git"
    echo "✅ Remote set to: https://github.com/$1/$2.git"
    echo ""
    echo "🚀 Ready to push! Run:"
    echo "   git push -u origin main"
    echo ""
    echo "Or if main branch doesn't exist:"
    echo "   git push -u origin master"
else
    echo ""
    echo "⚠️  No remote URL provided"
    echo "To set up remote, run:"
    echo "   git remote remove origin"
    echo "   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git"
    echo "   git push -u origin main"
fi

echo ""
echo "📋 Current git status:"
git status --short | head -20
