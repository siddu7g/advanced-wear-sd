# BLE Protocol Reverse Engineering Guide

## Overview

This guide explains how to use the **BLE Protocol Analyzer** to reverse engineer the Bluetooth Low Energy protocol and potentially find undocumented commands for raw sensor data access.

## What We've Built

### 1. BLE Protocol Analyzer
- **Raw packet capture**: Captures all TX (sent) and RX (received) BLE packets
- **Protocol structure analysis**: Identifies packet patterns and byte structures
- **Command testing**: Tests custom commands with various opcodes
- **Systematic exploration**: Automatically tests all command opcodes (200-255)
- **Statistics and reporting**: Provides detailed analysis of captured packets

### 2. Key Features

#### Packet Logging
- Captures all BLE communication in real-time
- Logs to Xcode console with detailed analysis
- Exports to JSON for offline analysis

#### Protocol Analysis
- Identifies common packet patterns
- Maps byte positions (headers, opcodes, parameters)
- Detects packet length patterns
- Finds command structure

#### Command Testing
- **Test Known Patterns**: Tests debug/test commands (203-206) that might give raw data
- **Custom Commands**: Send any opcode with custom parameters
- **Systematic Exploration**: Tests all opcodes 200-255 automatically

### 3. Focus Areas

Based on the SDK's `FuncType.h`, we're focusing on:

- **Test/Debug Commands (203-206)**:
  - `DATA_TYPE_TEST_DEBUG = 203` - Debug/test mode
  - `DATA_TYPE_APP_TEST = 204` - App test mode
  - `DATA_TYPE_FACTORY_TEST = 205` - Factory test mode
  - `DATA_TYPE_LEAKLIGHT_TEST = 206` - Hardware test

These commands are most likely to:
- Provide raw sensor data access
- Enable debug/diagnostic modes
- Expose firmware-level capabilities
- Give direct hardware access

## How to Use

### Step 1: Start Packet Logging

1. Open the app
2. Tap **"BLE Protocol Analyzer"** in the function list
3. Tap **"Start Logging"**
4. Check Xcode console - you'll see all BLE packets being logged

### Step 2: Capture Baseline Communication

1. While logging is active, use normal features:
   - Start heart rate measurement
   - Start O2 measurement
   - Start ECG measurement
   - Send any other commands

2. This captures known command patterns for reference

### Step 3: Test Known Patterns

1. With logging active, tap **"🔬 Test Known Patterns"**
2. This tests debug/test commands (203-206)
3. Check Xcode console for responses
4. Look for:
   - New packets received (indicates response)
   - Different data structures
   - Raw sensor data patterns

### Step 4: Systematic Exploration

1. With logging active, tap **"🚀 Systematic Exploration"**
2. This automatically tests ALL opcodes from 200-255
3. Takes ~3 minutes (3 seconds per command)
4. Monitor Xcode console for:
   - Commands that generate responses
   - Unusual packet structures
   - Potential raw data access

### Step 5: Analyze Results

1. Tap **"📊 View Statistics"** to see:
   - Total packets captured
   - Commands tested
   - Commands that generated responses
   - Successful opcodes

2. Tap **"Export Packets"** to save:
   - All captured packets
   - Protocol structure analysis
   - Test results
   - Statistics

### Step 6: Review Exported Data

The exported JSON includes:
- **Packets**: All captured TX/RX packets with hex dumps
- **Statistics**: Packet counts, lengths, patterns
- **Protocol Structure**: Identified byte patterns
- **Test Results**: All command tests and responses

## What to Look For

### 1. Successful Command Responses

When testing commands, look for:
```
✅ Custom command 0xXX sent - RESPONSE RECEIVED! (N new packets)
```

This indicates the device:
- Recognized the command
- Processed it
- Sent a response

### 2. Unusual Packet Structures

Look for packets with:
- Different lengths than normal
- Different byte patterns
- Arrays of numbers (possible raw sensor data)
- Larger payloads (possible waveform data)

### 3. Debug/Test Mode Indicators

Responses that might indicate debug mode:
- Larger data packets
- Continuous data streams
- Different data types in responses
- New notification types

### 4. Raw Sensor Data Patterns

Raw sensor data typically:
- Contains arrays of numbers
- Has high frequency updates (>1Hz)
- Shows waveform-like patterns
- Has ADC-like values (0-4095 for 12-bit ADC)

## Protocol Structure Analysis

### Understanding Packet Structure

Based on `CE_HRControlCmd` and other commands:

1. **Command Structure**:
   - SDK uses `funcType` to identify command type
   - `cmdData:` returns the payload
   - SDK handles packet framing (headers, checksums, etc.)

2. **Data Types**:
   - `K6_DataFuncType` enum defines all known types
   - Range 0-255, with gaps
   - Test/debug range: 200-206

3. **Response Structure**:
   - Device sends back `K6_DataFuncType` in response
   - Contains data dictionary
   - May include nested arrays for sensor data

### Byte Pattern Analysis

The analyzer identifies:
- **First Byte**: Often header/type indicator
- **Second Byte**: Often length or opcode
- **Subsequent Bytes**: Parameters or payload
- **Last Byte**: Often checksum

## Example Workflow

### Scenario: Finding Raw PPG Data Access

1. **Start Logging**
   ```
   Tap "BLE Protocol Analyzer" → "Start Logging"
   ```

2. **Capture Known Patterns**
   ```
   Use normal heart rate → captures standard BPM packets
   Use O2 measurement → captures standard SpO2 packets
   ```

3. **Test Debug Commands**
   ```
   Tap "🔬 Test Known Patterns"
   → Tests 203 (TEST_DEBUG), 204 (APP_TEST), 205 (FACTORY_TEST), 206 (LEAKLIGHT_TEST)
   ```

4. **Check Console**
   ```
   Look for: "✅ Custom command 0xCB sent - RESPONSE RECEIVED!"
   ```

5. **Analyze Response**
   ```
   Check exported JSON for:
   - Packet structure
   - Data format
   - Array patterns (possible raw sensor data)
   ```

6. **Systematic Exploration**
   ```
   If no luck, run "🚀 Systematic Exploration"
   → Tests all opcodes 200-255
   → Takes ~3 minutes
   → May find undocumented commands
   ```

## Expected Findings

### Low Probability (But Possible)
- Direct raw PPG waveform access
- ADC sensor values
- Unfiltered light intensity data

### Medium Probability
- Debug mode that enables raw data
- Test commands that return sensor data
- Factory test mode with detailed diagnostics

### High Probability
- Protocol structure mapping
- Command opcode identification
- Response pattern analysis
- Undocumented command discovery

## Next Steps

After finding responsive commands:

1. **Analyze Response Data**
   - Export packets to JSON
   - Look for data arrays
   - Identify sensor data patterns

2. **Modify Command Parameters**
   - Try different parameter values
   - Test enable/disable flags
   - Experiment with data request types

3. **Integrate into App**
   - Create custom command classes
   - Parse response data
   - Extract raw sensor values

4. **Contact Manufacturer**
   - Share findings
   - Request documentation
   - Get official raw data support

## Troubleshooting

### No Packets Captured
- Ensure device is connected
- Check logging is active (🟡 LOGGING status)
- Verify BLE connection in iOS settings

### No Responses to Commands
- Commands may be valid but device doesn't respond
- Try different parameter values
- Test during active sensor measurement

### Exploration Stuck
- Stop and restart exploration
- Check device connection
- Review Xcode console for errors

## Safety Notes

- **Device Safety**: Testing unknown commands is safe - worst case is no response
- **Data Safety**: All packets are logged, nothing is deleted on device
- **Performance**: Systematic exploration may slow down device temporarily

## Summary

The BLE Protocol Analyzer provides a systematic approach to:
1. **Discover** undocumented commands
2. **Analyze** protocol structure
3. **Test** debug/test modes
4. **Find** raw sensor data access

Start with known patterns (203-206), then use systematic exploration to find hidden capabilities!

---

**Good luck with the reverse engineering!** 🚀

The manufacturer told you to figure it out through the SDK - this tool gives you the best chance of finding hidden capabilities.
