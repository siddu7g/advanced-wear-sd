# How to See Console Logs in Xcode - Visual Guide

## ⚠️ IMPORTANT: Build Log ≠ Console Output

You're currently looking at the **BUILD LOG** (compilation messages). 
You need to see the **CONSOLE OUTPUT** (runtime logs from your app).

## Step-by-Step Instructions:

### Step 1: Run Your App First
1. Connect your iPhone
2. Click the **Play button** (▶️) at the top left of Xcode
3. Wait for the app to launch on your iPhone

### Step 2: Open the Debug Area (Console)
**Option A - Keyboard Shortcut:**
- Press **Cmd + Shift + Y** (this toggles the debug area)

**Option B - Menu:**
- Go to: **View** → **Debug Area** → **Show Debug Area**

**Option C - Button:**
- Look at the **top-right** of Xcode window
- Find the button with **two overlapping rectangles** (split view icon)
- Click it to show/hide the debug area

### Step 3: Switch to Console Tab
Once the debug area opens at the bottom:
1. You'll see tabs like: "Variables", "Console", "All Output"
2. Click on **"All Output"** or **"Console"** tab
3. This is where NSLog messages appear

### Step 4: Use Your App
1. In the app on your iPhone, tap **"Real-time Heart Rate"**
2. Watch the console area - logs should appear there!

### Step 5: Filter Logs (Optional)
1. In the console area, there's a search box at the bottom-right
2. Type: `RAW HEART RATE` or `HR_CONTROL`
3. This filters to show only our logs

## Visual Guide:

```
Xcode Window Layout:
┌─────────────────────────────────────────┐
│  [Toolbar with Play button]            │
├─────────────────────────────────────────┤
│                                         │
│  [Your Code Editor]                    │
│                                         │
├─────────────────────────────────────────┤
│  ⬇️ DEBUG AREA (Press Cmd+Shift+Y) ⬇️   │
│  ┌───────────────────────────────────┐ │
│  │ [Variables] [Console] [All Output]│ │ ← Click "All Output"
│  │                                   │ │
│  │ 🔍 YOUR LOGS APPEAR HERE 👇      │ │
│  │ ╔══════════════════════════════╗  │ │
│  │ ║ RAW HEART RATE DATA         ║  │ │
│  │ ╚══════════════════════════════╝  │ │
│  │                                   │ │
│  │ [Search box] ← Filter here        │ │
│  └───────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

## What You're Currently Seeing:
- **Build Log** = Compilation messages (Copy files, Scan dependencies)
- This is NOT where runtime logs appear!

## What You Need to See:
- **Console Output** = Runtime logs (NSLog messages when app runs)
- This appears in the Debug Area at the bottom

## Quick Test:
1. Run your app (Play button)
2. Press **Cmd + Shift + Y** to open debug area
3. Tap "Real-time Heart Rate" in the app
4. Look at the bottom of Xcode - logs should appear!

## If Still No Logs:
1. Make sure app is actually running (not just built)
2. Check iPhone is selected (not Simulator)
3. Try clearing console: **Cmd + K** (then run again)
4. Make sure you're in Debug mode (not Release)
