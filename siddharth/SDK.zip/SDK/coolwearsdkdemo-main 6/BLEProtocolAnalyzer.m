//
//  BLEProtocolAnalyzer.m
//  sdkdemo
//
//  Created for firmware access exploration
//

#import "BLEProtocolAnalyzer.h"
#import <BluetoothLibrary/CEProductK6.h>
#import <BluetoothLibrary/CE_Cmd.h>
#import <BluetoothLibrary/FuncType.h>

@interface CE_CustomRawDataCmd : CE_Cmd
@property (nonatomic, assign) uint8_t opcode;
@property (nonatomic, strong) NSData *params;
@end

@implementation CE_CustomRawDataCmd
- (K6_DataFuncType)funcType {
    // Use the opcode as the data type - this might match firmware expectations
    return (K6_DataFuncType)self.opcode;
}

- (NSData *)cmdData:(int)type {
    // The SDK handles packet structure internally, we just provide the payload
    // Based on CE_HRControlCmd, commands send their payload directly
    NSMutableData *data = [NSMutableData data];
    
    // If params exist, send them as payload
    if (self.params && self.params.length > 0) {
        [data appendData:self.params];
    } else {
        // Default: send enable/request byte
        uint8_t enable = 0x01;
        [data appendBytes:&enable length:1];
    }
    
    return data;
}

- (BOOL)isSendEnd {
    return YES;
}
@end

@interface BLEProtocolAnalyzer ()
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *packets;
@property (nonatomic, assign) BOOL isLogging;
@property (nonatomic, assign) BOOL isExploring;
@property (nonatomic, strong) NSTimer *explorationTimer;
@property (nonatomic, assign) NSInteger currentTestOpcode;
@property (nonatomic, strong) NSMutableDictionary *protocolStructure;
@property (nonatomic, strong) NSMutableArray *testResults;
@end

@implementation BLEProtocolAnalyzer

+ (instancetype)shared {
    static BLEProtocolAnalyzer *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[BLEProtocolAnalyzer alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _packets = [NSMutableArray array];
        _isLogging = NO;
        _isExploring = NO;
        _currentTestOpcode = 0;
        _protocolStructure = [NSMutableDictionary dictionary];
        _testResults = [NSMutableArray array];
    }
    return self;
}

- (void)startLogging {
    if (self.isLogging) {
        NSLog(@"⚠️ BLE Protocol Analyzer already logging");
        return;
    }
    
    self.isLogging = YES;
    [self clearPackets];
    
    NSLog(@"🔬 Starting BLE Protocol Analyzer - capturing all RX/TX packets");
    
    // Enable raw data handlers
    __weak typeof(self) weakSelf = self;
    [CEProductK6.shareInstance setReceiveOriginalDataHandler:^(NSData *data) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) return;
        
        NSDictionary *packet = @{
            @"direction": @"RX",
            @"timestamp": @([[NSDate date] timeIntervalSince1970]),
            @"timestamp_readable": [NSDate date].description,
            @"data": data,
            @"hex": [strongSelf hexStringFromData:data],
            @"length": @(data.length),
            @"bytes": [strongSelf bytesArrayFromData:data]
        };
        
        [strongSelf.packets addObject:packet];
        
        NSLog(@"\n📡 RX[%lu bytes] - %@", (unsigned long)data.length, packet[@"hex"]);
        NSLog(@"   First byte: 0x%02X (possible header/type)", ((uint8_t *)data.bytes)[0]);
        
        // Analyze packet structure
        [strongSelf analyzePacket:packet];
    }];
    
    [CEProductK6.shareInstance setSendOriginalDataHandler:^(NSData *data) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) return;
        
        NSDictionary *packet = @{
            @"direction": @"TX",
            @"timestamp": @([[NSDate date] timeIntervalSince1970]),
            @"timestamp_readable": [NSDate date].description,
            @"data": data,
            @"hex": [strongSelf hexStringFromData:data],
            @"length": @(data.length),
            @"bytes": [strongSelf bytesArrayFromData:data]
        };
        
        [strongSelf.packets addObject:packet];
        
        NSLog(@"\n📡 TX[%lu bytes] - %@", (unsigned long)data.length, packet[@"hex"]);
        NSLog(@"   First byte: 0x%02X (possible header/opcode)", ((uint8_t *)data.bytes)[0]);
        
        // Analyze packet structure
        [strongSelf analyzePacket:packet];
    }];
    
    NSLog(@"✅ BLE Protocol Analyzer started - all BLE communication will be logged");
}

- (void)stopLogging {
    if (!self.isLogging) {
        return;
    }
    
    self.isLogging = NO;
    
    // Disable handlers
    [CEProductK6.shareInstance setReceiveOriginalDataHandler:nil];
    [CEProductK6.shareInstance setSendOriginalDataHandler:nil];
    
    NSLog(@"🛑 BLE Protocol Analyzer stopped - captured %lu packets", (unsigned long)self.packets.count);
}

- (NSArray<NSDictionary *> *)getCapturedPackets {
    return [self.packets copy];
}

- (void)clearPackets {
    [self.packets removeAllObjects];
    NSLog(@"🧹 Cleared captured packets");
}

- (NSString *)hexStringFromData:(NSData *)data {
    if (!data || data.length == 0) {
        return @"";
    }
    
    NSMutableString *hex = [NSMutableString string];
    const uint8_t *bytes = (const uint8_t *)data.bytes;
    for (NSUInteger i = 0; i < data.length; i++) {
        [hex appendFormat:@"%02X", bytes[i]];
        if (i < data.length - 1) {
            [hex appendString:@" "];
        }
    }
    return [hex copy];
}

- (NSArray<NSNumber *> *)bytesArrayFromData:(NSData *)data {
    NSMutableArray *bytes = [NSMutableArray array];
    const uint8_t *bytePtr = (const uint8_t *)data.bytes;
    for (NSUInteger i = 0; i < data.length; i++) {
        [bytes addObject:@(bytePtr[i])];
    }
    return [bytes copy];
}

- (void)analyzePacket:(NSDictionary *)packet {
    NSData *data = packet[@"data"];
    if (!data || data.length < 2) {
        return;
    }
    
    const uint8_t *bytes = (const uint8_t *)data.bytes;
    
    // Try to identify packet structure
    NSLog(@"   📊 Analysis:");
    NSLog(@"      Byte[0]: 0x%02X (Header?)", bytes[0]);
    if (data.length > 1) {
        NSLog(@"      Byte[1]: 0x%02X (Length? Opcode?)", bytes[1]);
    }
    if (data.length > 2) {
        NSLog(@"      Byte[2]: 0x%02X (Opcode? Type?)", bytes[2]);
    }
    
    // Look for patterns
    if (bytes[0] == 0xAA || bytes[0] == 0x55) {
        NSLog(@"      ⚠️ Possible header byte detected: 0x%02X", bytes[0]);
    }
}

- (NSString *)exportToJSON {
    NSDictionary *stats = [self getPacketStatistics];
    NSDictionary *structure = [self analyzeProtocolStructure];
    
    NSDictionary *export = @{
        @"exportTime": [NSDate date].description,
        @"totalPackets": @(self.packets.count),
        @"statistics": stats,
        @"protocolStructure": structure,
        @"packets": [self.packets copy],
        @"testResults": [self.testResults copy],
        @"analysis": @{
            @"purpose": @"BLE Protocol Reverse Engineering",
            @"goal": @"Find undocumented commands for raw sensor data access",
            @"notes": @"TX = sent to device, RX = received from device. Analyze byte patterns to identify command structure. Focus on test/debug commands (203-206) for raw sensor data access."
        }
    };
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:export
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    
    if (error) {
        NSLog(@"❌ JSON export error: %@", error);
        return nil;
    }
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (void)tryCustomCommand:(uint8_t)opcode params:(NSData *)params {
    NSLog(@"\n🔬 Attempting custom command:");
    NSLog(@"   Opcode: 0x%02X", opcode);
    NSLog(@"   Params: %@", params ? [self hexStringFromData:params] : @"None");
    
    CE_CustomRawDataCmd *customCmd = [[CE_CustomRawDataCmd alloc] init];
    customCmd.opcode = opcode;
    customCmd.params = params;
    
    NSUInteger packetCountBefore = self.packets.count;
    
    [CEProductK6.shareInstance sendCmdToDevice:customCmd complete:^(NSError *error) {
        NSUInteger packetCountAfter = self.packets.count;
        
        NSDictionary *testResult = @{
            @"opcode": @(opcode),
            @"params": params ? [self hexStringFromData:params] : @"",
            @"error": error ? error.localizedDescription : @"none",
            @"packetsBefore": @(packetCountBefore),
            @"packetsAfter": @(packetCountAfter),
            @"hasResponse": @(packetCountAfter > packetCountBefore),
            @"timestamp": @([[NSDate date] timeIntervalSince1970])
        };
        
        [self.testResults addObject:testResult];
        
        if (error) {
            NSLog(@"❌ Custom command 0x%02X failed: %@", opcode, error);
        } else {
            if (packetCountAfter > packetCountBefore) {
                NSLog(@"✅ Custom command 0x%02X sent - RESPONSE RECEIVED! (%lu new packets)", opcode, (unsigned long)(packetCountAfter - packetCountBefore));
            } else {
                NSLog(@"✅ Custom command 0x%02X sent - check for response in captured packets", opcode);
            }
        }
    }];
}

- (NSDictionary *)analyzeProtocolStructure {
    NSMutableDictionary *structure = [NSMutableDictionary dictionary];
    NSMutableArray *txPackets = [NSMutableArray array];
    NSMutableArray *rxPackets = [NSMutableArray array];
    
    for (NSDictionary *packet in self.packets) {
        if ([packet[@"direction"] isEqualToString:@"TX"]) {
            [txPackets addObject:packet];
        } else {
            [rxPackets addObject:packet];
        }
    }
    
    // Analyze TX packet patterns
    if (txPackets.count > 0) {
        NSMutableSet *firstBytes = [NSMutableSet set];
        NSMutableSet *secondBytes = [NSMutableSet set];
        NSMutableDictionary *lengthFrequency = [NSMutableDictionary dictionary];
        
        for (NSDictionary *packet in txPackets) {
            NSData *data = packet[@"data"];
            const uint8_t *bytes = (const uint8_t *)data.bytes;
            
            if (data.length > 0) {
                [firstBytes addObject:@(bytes[0])];
            }
            if (data.length > 1) {
                [secondBytes addObject:@(bytes[1])];
            }
            
            NSNumber *len = @(data.length);
            lengthFrequency[len] = @([lengthFrequency[len] intValue] + 1);
        }
        
        structure[@"tx"] = @{
            @"count": @(txPackets.count),
            @"firstBytes": [[firstBytes allObjects] sortedArrayUsingSelector:@selector(compare:)],
            @"secondBytes": [[secondBytes allObjects] sortedArrayUsingSelector:@selector(compare:)],
            @"lengthFrequency": lengthFrequency,
            @"commonLengths": [lengthFrequency keysSortedByValueUsingSelector:@selector(compare:)]
        };
    }
    
    // Analyze RX packet patterns
    if (rxPackets.count > 0) {
        NSMutableSet *firstBytes = [NSMutableSet set];
        NSMutableDictionary *lengthFrequency = [NSMutableDictionary dictionary];
        
        for (NSDictionary *packet in rxPackets) {
            NSData *data = packet[@"data"];
            const uint8_t *bytes = (const uint8_t *)data.bytes;
            
            if (data.length > 0) {
                [firstBytes addObject:@(bytes[0])];
            }
            
            NSNumber *len = @(data.length);
            lengthFrequency[len] = @([lengthFrequency[len] intValue] + 1);
        }
        
        structure[@"rx"] = @{
            @"count": @(rxPackets.count),
            @"firstBytes": [[firstBytes allObjects] sortedArrayUsingSelector:@selector(compare:)],
            @"lengthFrequency": lengthFrequency
        };
    }
    
    return [structure copy];
}

- (NSDictionary *)getPacketStatistics {
    NSInteger txCount = 0;
    NSInteger rxCount = 0;
    NSInteger totalBytes = 0;
    NSInteger minLength = INT_MAX;
    NSInteger maxLength = 0;
    
    for (NSDictionary *packet in self.packets) {
        NSInteger length = [packet[@"length"] intValue];
        totalBytes += length;
        
        if (length < minLength) minLength = length;
        if (length > maxLength) maxLength = length;
        
        if ([packet[@"direction"] isEqualToString:@"TX"]) {
            txCount++;
        } else {
            rxCount++;
        }
    }
    
    return @{
        @"totalPackets": @(self.packets.count),
        @"txPackets": @(txCount),
        @"rxPackets": @(rxCount),
        @"totalBytes": @(totalBytes),
        @"avgLength": @(self.packets.count > 0 ? totalBytes / self.packets.count : 0),
        @"minLength": @(minLength == INT_MAX ? 0 : minLength),
        @"maxLength": @(maxLength),
        @"testResults": [self.testResults copy]
    };
}

- (void)testKnownCommandPatterns {
    NSLog(@"\n🔬 Testing known command patterns for raw data access...");
    
    // Test debug/test commands that might give raw sensor data
    // DATA_TYPE_TEST_DEBUG = 203
    // DATA_TYPE_APP_TEST = 204
    // DATA_TYPE_FACTORY_TEST = 205
    
    // Test with various parameters
    NSMutableArray *testCommandsArray = [NSMutableArray array];
    
    NSDictionary *cmd1 = @{@"type": @(203), @"name": @"TEST_DEBUG", @"params": [NSData dataWithBytes:(uint8_t[]){0x01} length:1]};
    NSDictionary *cmd2 = @{@"type": @(204), @"name": @"APP_TEST", @"params": [NSData dataWithBytes:(uint8_t[]){0x01} length:1]};
    NSDictionary *cmd3 = @{@"type": @(205), @"name": @"FACTORY_TEST", @"params": [NSData dataWithBytes:(uint8_t[]){0x01} length:1]};
    NSDictionary *cmd4 = @{@"type": @(203), @"name": @"TEST_DEBUG_Raw", @"params": [NSData dataWithBytes:(uint8_t[]){0xFF} length:1]};
    NSDictionary *cmd5 = @{@"type": @(206), @"name": @"LEAKLIGHT_TEST"};
    
    [testCommandsArray addObject:cmd1];
    [testCommandsArray addObject:cmd2];
    [testCommandsArray addObject:cmd3];
    [testCommandsArray addObject:cmd4];
    [testCommandsArray addObject:cmd5];
    
    NSArray *testCommands = [testCommandsArray copy];
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    for (NSInteger i = 0; i < testCommands.count; i++) {
        NSDictionary *cmd = testCommands[i];
        dispatch_time_t delay = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(i * 2.0 * NSEC_PER_SEC));
        
        dispatch_after(delay, queue, ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"\n🔬 Testing %@ (type=%d)...", cmd[@"name"], [cmd[@"type"] intValue]);
                NSData *params = cmd[@"params"]; // Will be nil if key doesn't exist
                [self tryCustomCommand:[cmd[@"type"] intValue] params:params];
            });
        });
    }
}

- (void)startSystematicExploration {
    if (self.isExploring) {
        NSLog(@"⚠️ Systematic exploration already running");
        return;
    }
    
    if (!self.isLogging) {
        [self startLogging];
    }
    
    self.isExploring = YES;
    self.currentTestOpcode = 200; // Start from test/debug range
    
    NSLog(@"\n🚀 Starting systematic exploration of command opcodes...");
    NSLog(@"   Testing range: 200-255 (test/debug/factory range)");
    NSLog(@"   Delay between commands: 3 seconds");
    
    self.explorationTimer = [NSTimer scheduledTimerWithTimeInterval:3.0
                                                             target:self
                                                           selector:@selector(testNextOpcode)
                                                           userInfo:nil
                                                            repeats:YES];
    [self testNextOpcode]; // Start immediately
}

- (void)testNextOpcode {
    if (self.currentTestOpcode > 255) {
        [self stopSystematicExploration];
        NSLog(@"\n✅ Systematic exploration complete! Tested all opcodes 200-255");
        return;
    }
    
    uint8_t opcode = (uint8_t)self.currentTestOpcode;
    
    NSLog(@"\n🔬 [%d/56] Testing opcode 0x%02X (%d)...", 
          (int)(self.currentTestOpcode - 200 + 1),
          opcode, 
          opcode);
    
    // Try with different parameter sets
    if (self.currentTestOpcode % 3 == 0) {
        // Every 3rd command, try with enable parameter
        uint8_t enable = 0x01;
        NSData *params = [NSData dataWithBytes:&enable length:1];
        [self tryCustomCommand:opcode params:params];
    } else if (self.currentTestOpcode % 3 == 1) {
        // Try with raw data request parameter
        uint8_t rawData = 0xFF;
        NSData *params = [NSData dataWithBytes:&rawData length:1];
        [self tryCustomCommand:opcode params:params];
    } else {
        // No parameters
        [self tryCustomCommand:opcode params:nil];
    }
    
    self.currentTestOpcode++;
}

- (void)stopSystematicExploration {
    if (!self.isExploring) {
        return;
    }
    
    self.isExploring = NO;
    
    if (self.explorationTimer) {
        [self.explorationTimer invalidate];
        self.explorationTimer = nil;
    }
    
    NSLog(@"\n🛑 Systematic exploration stopped");
    
    // Generate report
    NSDictionary *stats = [self getPacketStatistics];
    NSDictionary *structure = [self analyzeProtocolStructure];
    
    NSLog(@"\n📊 Exploration Report:");
    NSLog(@"   Packets captured: %@", stats[@"totalPackets"]);
    NSLog(@"   TX packets: %@", stats[@"txPackets"]);
    NSLog(@"   RX packets: %@", stats[@"rxPackets"]);
    NSLog(@"   Commands tested: %lu", (unsigned long)self.testResults.count);
    
    NSArray *responses = [self.testResults filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"hasResponse == YES"]];
    NSLog(@"   Commands with responses: %lu", (unsigned long)responses.count);
    
    if (responses.count > 0) {
        NSLog(@"\n✅ SUCCESS! Found %lu commands that generated responses:", (unsigned long)responses.count);
        for (NSDictionary *result in responses) {
            NSLog(@"   - Opcode 0x%02X (%d): %@", [result[@"opcode"] intValue], [result[@"opcode"] intValue], result[@"error"]);
        }
    }
}

@end
