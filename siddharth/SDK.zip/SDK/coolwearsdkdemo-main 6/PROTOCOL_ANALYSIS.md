# BLE Protocol Analysis - Initial Findings

## Date: January 20, 2026

## Protocol Structure Identified

### TX Packets (Sent to Device)
```
00 01 00 [SEQ] [TYPE] 00 00 [PAYLOAD...]
```
- **Byte[0]**: `0x00` - TX header marker
- **Byte[1]**: `0x01` - Request/command indicator
- **Byte[2]**: `0x00` - Sub-type/flag
- **Byte[3]**: Sequence number (increments: 03, 04, 05, 06, 07, 08...)
- **Byte[4]**: `0x01` - Command indicator
- **Byte[5]**: **Data Type** (this is the key!)
  - `0x07` = DATA_TYPE_REAL_HEART
  - `0x13` = DATA_TYPE_REAL_ECG
  - `0x14` = DATA_TYPE_REAL_O2
  - `0x15` = DATA_TYPE_HR_CONTROL
  - `0x18` = DATA_TYPE_REAL_HR
- **Byte[6-19]**: Payload/data

### RX Packets (Received from Device)
```
00 CF 00 [SEQ] [TYPE] 00 00 [PAYLOAD...]
```
- **Byte[0]**: `0x00` - RX header marker
- **Byte[1]**: `0xCF` - Response indicator (possibly ACK)
- **Byte[2]**: `0x00` - Sub-type/flag
- **Byte[3]**: Sequence number (matches TX)
- **Byte[4]**: `0x24` - Response type indicator (may indicate ACK)
- **Byte[5]**: **Data Type** (matches requested type)
- **Byte[6-19]**: Response payload/data

## Command Type Mappings

Based on captured packets:

| Byte[5] | Decimal | Type | Description |
|---------|---------|------|-------------|
| `0x07` | 7 | DATA_TYPE_REAL_HEART | Real-time heart rate |
| `0x13` | 19 | DATA_TYPE_REAL_ECG | Real-time ECG |
| `0x14` | 20 | DATA_TYPE_REAL_O2 | Real-time O2/SpO2 |
| `0x15` | 21 | DATA_TYPE_HR_CONTROL | HR control command |
| `0x18` | 24 | DATA_TYPE_REAL_HR | Real-time HR (auto) |

## Key Observations

### 1. **Response Pattern**
- Device sends ACK immediately: `00 CF 00 [SEQ] 24 [TYPE] 00 00 01 00 01 00...`
- This appears to be command acknowledgment
- Actual data comes later in separate packets

### 2. **Data Transmission**
- Heart rate data: Type `0x07`, contains `heartInfos` array with `heartNum` and `time`
- O2 data: Type `0x14`, contains `data` array with `oxygen` and `time`
- All data is **processed values only** (BPM, SpO2%), not raw waveforms

### 3. **Sequence Numbers**
- Sequence numbers increment with each command: 03, 04, 05, 06, 07, 08...
- RX packets match TX sequence numbers
- Used for packet ordering/acknowledgment

### 4. **Payload Structure**
For processed heart rate (Type 0x07):
```
Bytes: 00 CF 00 [SEQ] 21 07 00 00 08 00 01 00 01 58 07 6F 69 4A 01 00
                                 ↑    ↑                ↑
                           SEQ match TYPE          Payload starts here
```

## Protocol Breakdown Example

### TX: Heart Rate Command
```
00 01 00 03 01 18 00 00 01 00 01 00 00 00 00 00 00 00 00 00
│  │  │  │  │  │
│  │  │  │  │  └─ Type: 0x18 (DATA_TYPE_REAL_HR)
│  │  │  │  └─ Command indicator: 0x01
│  │  │  └─ Sequence: 0x03
│  │  └─ Sub-type: 0x00
│  └─ Request/Command: 0x01
└─ TX Header: 0x00
```

### RX: Heart Rate Response (ACK)
```
00 CF 00 03 24 18 00 00 01 00 01 00 00 00 00 00 00 00 00 00
│  │  │  │  │  │
│  │  │  │  │  └─ Type: 0x18 (matches request)
│  │  │  │  └─ ACK indicator: 0x24
│  │  │  └─ Sequence: 0x03 (matches TX)
│  │  └─ Sub-type: 0x00
│  └─ Response/ACK: 0xCF
└─ RX Header: 0x00
```

### RX: Heart Rate Data
```
00 CF 00 07 21 07 00 00 08 00 01 00 01 58 07 6F 69 4A 01 00
│  │  │  │  │  │
│  │  │  │  │  └─ Type: 0x07 (DATA_TYPE_REAL_HEART)
│  │  │  │  └─ Data indicator: 0x21 (not ACK, actual data)
│  │  │  └─ Sequence: 0x07
│  │  └─ Sub-type: 0x00
│  └─ Response: 0xCF
└─ RX Header: 0x00
```

## Findings

### ✅ What We've Learned
1. **Protocol structure** is now mapped
2. **Command types** are identified by Byte[5]
3. **Sequence numbers** are used for packet ordering
4. **ACK vs Data** packets are distinguishable (Byte[4]: 0x24 = ACK, 0x21 = Data)

### ❌ What's Missing
1. **Raw sensor waveforms** - Still only getting processed values
2. **ADC values** - No raw sensor readings
3. **Waveform arrays** - No PPG signal arrays

### 🔍 Next Steps

1. **Test Debug/Test Commands** (203-206)
   - `0xCB` (203) - DATA_TYPE_TEST_DEBUG
   - `0xCC` (204) - DATA_TYPE_APP_TEST
   - `0xCD` (205) - DATA_TYPE_FACTORY_TEST
   - `0xCE` (206) - DATA_TYPE_LEAKLIGHT_TEST

2. **Systematic Exploration** (200-255)
   - Test all opcodes in test/debug range
   - Look for hidden commands
   - Find raw data access

3. **Protocol Manipulation**
   - Try different Byte[4] values (request vs query)
   - Experiment with payload formats
   - Test parameter variations

## Potential Raw Data Access Points

Based on protocol analysis:

1. **Debug Commands (0xCB-0xCE)**
   - Most likely to provide raw sensor access
   - Factory/test modes often expose diagnostic data

2. **Parameter Variations**
   - Current commands send `0x01` (enable)
   - Try `0xFF` (max), `0x02` (raw mode?), etc.

3. **Undocumented Types (200-255)**
   - Many unused types in range
   - May contain hidden capabilities

## Conclusion

The protocol structure is now understood! Next step: **Test debug/test commands (203-206) and systematically explore opcodes 200-255** to find raw sensor data access.
