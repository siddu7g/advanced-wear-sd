# How to See Console Logs in Xcode - Step by Step Guide

## Step 1: Open the Debug Area
1. In Xcode, look at the **bottom** of the screen
2. You should see a button with a **split screen icon** (or View menu → Show Debug Area)
3. Click it to show/hide the debug console

## Step 2: View Console Output
1. Once the debug area is open, you'll see tabs at the bottom
2. Make sure you're on the **"All Output"** or **"Console"** tab
3. This shows all NSLog output from your app

## Step 3: Filter Logs (Optional)
1. In the search box at the bottom right of console
2. Type: `RAW HEART RATE DATA` or `HR_CONTROL` to filter
3. This makes it easier to find our logs

## Step 4: Run Your App
1. Connect your iPhone
2. Select your device in Xcode (top toolbar)
3. Click the **Play button** (or Cmd+R) to run
4. Tap "Real-time Heart Rate" in the app
5. Watch the console for logs

## What to Look For:
- Logs starting with: `╔════════════════════════════════════════════════════════════════════╗`
- Lines saying: `🔍 RAW HEART RATE DATA - OPTION 1`
- Lines saying: `🔍 HR_CONTROL DATA - OPTION 2`
- Any fields that look like: `ppg`, `rawSignal`, `adc`, `waveform`, `sensorData`

## If You Still Don't See Logs:
1. Make sure you're running in **Debug** mode (not Release)
2. Check that your iPhone is selected as the device (not Simulator)
3. Try clearing the console (Cmd+K) and running again
4. Make sure the app is actually running (not paused at a breakpoint)

## Alternative: View Device Logs
1. Xcode menu: **Window** → **Devices and Simulators**
2. Select your iPhone
3. Click **"Open Console"** button
4. This shows all device logs
