//
//  DemoViewController.m
//  sdkdemo
//
//  Created by coolwear on 2022/9/20.
//

#import "FuncListViewController.h"
#import "ListSwtCell.h"
#import "DialViewController.h"
#import "AppViewController.h"
#import "AlarmViewController.h"
#import "FuncModel.h"
#import "RealTestViewController.h"
#import "DataManager.h"
#import "CE_HRControlCmd.h"
#import <BluetoothLibrary/CE_SyncECGCmd.h>
#import <BluetoothLibrary/CE_SyncHeartO2Cmd.h>
#import "BLEProtocolAnalyzer.h"
#import <objc/runtime.h>

@interface FuncListViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *data;
@end

@implementation FuncListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.whiteColor;
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(dataReceiveFinish:) name:@"DataReceivceFinish" object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(heartRateUpdated:) name:@"HeartRateDataUpdated" object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(heartRateUpdated:) name:@"ECGWaveformDataUpdated" object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(heartRateUpdated:) name:@"O2WaveformDataUpdated" object:nil];
    [self initData];
    [self initUI];
    
}


- (void)initData{
        
    FuncModel *dial = [[FuncModel alloc] initWithTitle:@"Watch Face" type:0 page:@"DialViewController"];
    FuncModel *app = [[FuncModel alloc] initWithTitle:@"App Notifications" type:0 page:@"AppViewController"];
    FuncModel *alarm = [[FuncModel alloc] initWithTitle:@"Alarm" type:0 page:@"AlarmViewController"];
    FuncModel *sms = [[FuncModel alloc] initWithTitle:@"SMS Alert" type:1];
    FuncModel *call = [[FuncModel alloc] initWithTitle:@"Call Alert" type:1];
    FuncModel *longsit = [[FuncModel alloc] initWithTitle:@"Sedentary Reminder" type:1];
    FuncModel *goal = [[FuncModel alloc] initWithTitle:@"Goal Reminder" type:1];
    FuncModel *water = [[FuncModel alloc] initWithTitle:@"Drink Water Reminder" type:1];
    FuncModel *time = [[FuncModel alloc] initWithTitle:@"Time Format" type:1];
    FuncModel *date = [[FuncModel alloc] initWithTitle:@"Date Format" type:1];
    FuncModel *find = [[FuncModel alloc] initWithTitle:@"Find Band" type:2];
    FuncModel *disturb = [[FuncModel alloc] initWithTitle:@"Do Not Disturb" type:1];
    FuncModel *raise = [[FuncModel alloc] initWithTitle:@"Raise to Wake" type:1];
    FuncModel *autoHr = [[FuncModel alloc] initWithTitle:@"Auto Heart Rate Detection" type:1];
    FuncModel *takePhoto = [[FuncModel alloc] initWithTitle:@"Smart Camera" type:1];
    FuncModel *ota = [[FuncModel alloc] initWithTitle:@"OTA" type:2];
    FuncModel *weather = [[FuncModel alloc] initWithTitle:@"Send Weather" type:2];
    FuncModel *contact = [[FuncModel alloc] initWithTitle:@"Contacts" type:0 page:@"ContactViewController"];
    FuncModel *realhr = [[FuncModel alloc] initWithTitle:@"Real-time Heart Rate" type:2];
    FuncModel *realo2 = [[FuncModel alloc] initWithTitle:@"Real-time Blood Pressure" type:2];
    FuncModel *realbp = [[FuncModel alloc] initWithTitle:@"Real-time Blood Oxygen" type:2];
    FuncModel *bleanalyzer = [[FuncModel alloc] initWithTitle:@"BLE Protocol Analyzer" type:2];
    self.data = @[dial, app, alarm, sms, call, longsit, goal, water, time, date, find, disturb, raise, autoHr, takePhoto, ota, weather, contact, realhr, realo2, realbp, bleanalyzer];
    
}

- (void)initUI{
    
    
    self.title = self.sp.name;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(backAction:)];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.rowHeight = 55;
    self.tableView.frame = self.view.bounds;
    [self.view addSubview:self.tableView];
    
}

- (void)dataReceiveFinish:(NSNotification *)noti{
    [self.tableView reloadData];
}

- (void)heartRateUpdated:(NSNotification *)notification {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (void)backAction:(id)sender{
    // Stop heart rate collection when leaving
    [[DataManager shared] stopHeartRateCollection];
    [[CEProductK6 shareInstance] releaseBind];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FuncModel *model = self.data[indexPath.row];
    
    if (model.type == 1) {
        ListSwtCell* cell = [[ListSwtCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.text = model.title;
        cell.swt.tag = indexPath.row;
        [cell.swt addTarget:self action:@selector(swtAction:) forControlEvents:UIControlEventTouchUpInside];
        [self updateCell:cell atIndexPath:indexPath];
        return cell;
    }
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    if (model.type != 1) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.textLabel.text = model.title;
    if (model.type == 2 && indexPath.row == 18){
        NSInteger currentHR = DataManager.shared.heartModel.heartNum;
        NSInteger rawDataCount = DataManager.shared.rawHeartRateData.count;
        NSInteger historyCount = DataManager.shared.heartRateHistory.count;
        NSInteger ecgCount = DataManager.shared.ecgWaveformData.count;
        NSInteger o2Count = DataManager.shared.o2WaveformData.count;
        NSInteger totalCount = rawDataCount > 0 ? rawDataCount : historyCount;
        
        NSMutableString *detailText = [NSMutableString string];
        if (currentHR > 0) {
            [detailText appendFormat:@"%ld BPM", (long)currentHR];
        }
        if (totalCount > 0 || ecgCount > 0 || o2Count > 0) {
            if (detailText.length > 0) [detailText appendString:@" | "];
            [detailText appendFormat:@"HR:%ld", (long)totalCount];
            if (ecgCount > 0) {
                [detailText appendFormat:@" ECG:%ld", (long)ecgCount];
            }
            if (o2Count > 0) {
                [detailText appendFormat:@" O2:%ld", (long)o2Count];
            }
        }
        if (detailText.length == 0) {
            detailText = [@"Tap to measure" mutableCopy];
        }
        cell.detailTextLabel.text = detailText;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    FuncModel *model = self.data[indexPath.row];
    if (model.type == 0) {
        Class class = NSClassFromString(model.page);
        if ([class isKindOfClass:RealTestViewController.class]){
            RealTestViewController* vc = [[RealTestViewController alloc] init];
            vc.type = indexPath.row;
            [self.navigationController pushViewController:vc animated:YES];
        }else{
            UIViewController *vc = [class new];
            [self.navigationController pushViewController:vc animated:YES];
        }

    }
    if (10 == indexPath.row) {
        YD_SyncFindDevCmd *tFindDevCmd = [[YD_SyncFindDevCmd alloc] initWithOnoff:1];
        [[CEProductK6 shareInstance] sendCmdToDevice:tFindDevCmd complete:nil];
    }
 
    if (15 == indexPath.row) {
        OtaViewController *vc = [[OtaViewController alloc] init];
        vc.customerId = DataManager.shared.devInfo.customer_id;
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (16 == indexPath.row){
        [self sendWeather];
    }
    if (18 == indexPath.row){
        // Option 1: Start standard heart rate measurement
        CE_SyncHeartRateCmd *cmd = [[CE_SyncHeartRateCmd alloc] init];
        cmd.status = 1;
        [CEProductK6.shareInstance sendCmdToDevice:cmd complete:nil];
        
        // Option 2: Try HR_CONTROL command to request raw sensor data
        // Test HR type
        CE_HRControlCmd *hrControlCmd = [[CE_HRControlCmd alloc] initWithOnoff:1 type:HR_CONTROL_TYPE_HR];
        NSLog(@"🔬 Sending HR_CONTROL command: onoff=1, type=HR_CONTROL_TYPE_HR");
        [CEProductK6.shareInstance sendCmdToDevice:hrControlCmd complete:^(NSError *error) {
            if (error) {
                NSLog(@"❌ HR_CONTROL HR error: %@", error);
            } else {
                NSLog(@"✅ HR_CONTROL HR sent successfully");
            }
        }];
        
        // Test ECG type (most likely to have waveform data)
        CE_HRControlCmd *ecgControlCmd = [[CE_HRControlCmd alloc] initWithOnoff:1 type:HR_CONTROL_TYPE_ECG];
        NSLog(@"🔬 Sending HR_CONTROL command: onoff=1, type=HR_CONTROL_TYPE_ECG");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [CEProductK6.shareInstance sendCmdToDevice:ecgControlCmd complete:^(NSError *error) {
                if (error) {
                    NSLog(@"❌ HR_CONTROL ECG error: %@", error);
                } else {
                    NSLog(@"✅ HR_CONTROL ECG sent successfully");
                }
            }];
        });
        
        // Test O2 type (might have waveform data)
        CE_HRControlCmd *o2ControlCmd = [[CE_HRControlCmd alloc] initWithOnoff:1 type:HR_CONTROL_TYPE_O2];
        NSLog(@"🔬 Sending HR_CONTROL command: onoff=1, type=HR_CONTROL_TYPE_O2");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [CEProductK6.shareInstance sendCmdToDevice:o2ControlCmd complete:^(NSError *error) {
                if (error) {
                    NSLog(@"❌ HR_CONTROL O2 error: %@", error);
                } else {
                    NSLog(@"✅ HR_CONTROL O2 sent successfully");
                }
            }];
        });
        
        // Start ECG measurement directly
        CE_SyncECGCmd *ecgCmd = [[CE_SyncECGCmd alloc] init];
        ecgCmd.status = 1;
        NSLog(@"🔬 Starting ECG measurement directly");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [CEProductK6.shareInstance sendCmdToDevice:ecgCmd complete:^(NSError *error) {
                if (error) {
                    NSLog(@"❌ ECG command error: %@", error);
                } else {
                    NSLog(@"✅ ECG command sent successfully");
                }
            }];
        });
        
        // Start O2 measurement directly
        CE_SyncHeartO2Cmd *o2Cmd = [[CE_SyncHeartO2Cmd alloc] init];
        o2Cmd.status = 1;
        NSLog(@"🔬 Starting O2 measurement directly");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [CEProductK6.shareInstance sendCmdToDevice:o2Cmd complete:^(NSError *error) {
                if (error) {
                    NSLog(@"❌ O2 command error: %@", error);
                } else {
                    NSLog(@"✅ O2 command sent successfully");
                }
            }];
        });
        
        // Start collecting raw signal data every 1 second
        [[DataManager shared] startHeartRateCollection];
        
        // Show export options after starting measurement
        [self showHeartRateExportOptions];
    }
    
    // BLE Protocol Analyzer
    if (21 == indexPath.row) {
        [self showBLEAnalyzerOptions];
    }
    if (19 == indexPath.row) {
        CE_SyncBloodPressureCmd *cmd = [[CE_SyncBloodPressureCmd alloc] init];
        cmd.status = 1;
        [CEProductK6.shareInstance sendCmdToDevice:cmd complete:nil];
    }
    if (20 == indexPath.row) {
        CE_SyncHeartO2Cmd *cmd = [[CE_SyncHeartO2Cmd alloc] init];
        cmd.status = 1;
        [CEProductK6.shareInstance sendCmdToDevice:cmd complete:nil];
    }
    
    // BLE Protocol Analyzer
    if (21 == indexPath.row) {
        [self showBLEAnalyzerOptions];
    }

}

- (void)swtAction:(UISwitch *)swt{
    
    NSInteger tag = swt.tag;
    if (3 == tag){
        YD_SyncSMSAlarmCmd *tSMSAlarmCmd = [[YD_SyncSMSAlarmCmd alloc] init];
        tSMSAlarmCmd.onoff = swt.on;
        [[CEProductK6 shareInstance] sendCmdToDevice:tSMSAlarmCmd complete:nil];
    }else if (4 == tag){
        YD_SyncCallAlarmCmd *tSMSAlarmCmd = [[YD_SyncCallAlarmCmd alloc] initWithOnoff:swt.on];
        [[CEProductK6 shareInstance] sendCmdToDevice:tSMSAlarmCmd complete:nil];
    }else if (5 == tag){
        CE_SyncLongSitRemindCmd *longSitCmd = [[CE_SyncLongSitRemindCmd alloc] init];
        longSitCmd.onoff = swt.on;
        longSitCmd.repeatDay = 0;
        longSitCmd.startTimeHour = 9;
        longSitCmd.startTimemin = 0;
        longSitCmd.endTimeHour = 20;
        longSitCmd.endTimeMin = 0;
        longSitCmd.noon_onoff = swt.on;
        [[CEProductK6 shareInstance] sendCmdToDevice:longSitCmd complete:nil];
    }else if (6 == tag) {
        YD_SyncFinishGoalCmd *tSMSAlarmCmd = [[YD_SyncFinishGoalCmd alloc] init];
        tSMSAlarmCmd.onoff = swt.on;
        [[CEProductK6 shareInstance] sendCmdToDevice:tSMSAlarmCmd complete:nil];
    }else if (7 == tag){
        YD_SyncDrinkAlarmCmd *drinkCmd = [[YD_SyncDrinkAlarmCmd alloc] init];
        drinkCmd.onoff = swt.on;
        drinkCmd.start_hour = 9;
        drinkCmd.start_min = 0;
        drinkCmd.end_hour = 20;
        drinkCmd.end_min = 59;
        drinkCmd.interval = 30;
        [[CEProductK6 shareInstance] sendCmdToDevice:drinkCmd complete:nil];
    }else if (8 == tag){
        DataManager.shared.date.format = swt.on;
        uint32_t absTime = [[NSDate date] timeIntervalSince1970];
        NSInteger offsetTime = (uint32_t)[NSTimeZone defaultTimeZone].secondsFromGMT;
        CE_SyncTimeCmd *timeCmd = [[CE_SyncTimeCmd alloc] initWithAbsTime:absTime
                                                                   offset:offsetTime
                                                                   format:DataManager.shared.date.format
                                                                 mdFormat:DataManager.shared.date.mdFormat];
        [[CEProductK6 shareInstance] sendCmdToDevice:timeCmd complete:nil];
    }else if (9 == tag){
        DataManager.shared.date.mdFormat = swt.on;
        uint32_t absTime = [[NSDate date] timeIntervalSince1970];
        NSInteger offsetTime = (uint32_t)[NSTimeZone defaultTimeZone].secondsFromGMT;
        CE_SyncTimeCmd *timeCmd = [[CE_SyncTimeCmd alloc] initWithAbsTime:absTime
                                                                   offset:offsetTime
                                                                   format:DataManager.shared.date.format
                                                                 mdFormat:DataManager.shared.date.mdFormat];
        [[CEProductK6 shareInstance] sendCmdToDevice:timeCmd complete:nil];
    }else if (11 == tag){
        CE_SyncDisturbCmd *disturbCmd = [[CE_SyncDisturbCmd alloc] init];
        NSMutableArray *disturbsArray = [NSMutableArray array];
        CE_DisturbItem *item = [[CE_DisturbItem alloc] init];
        item.start_time_hour = 9;
        item.start_time_min = 0;
        item.end_time_hour = 20;
        item.end_time_min = 59;
        [disturbsArray addObject:item];
        disturbCmd.disturbItems = disturbsArray;
        disturbCmd.switch_flag = swt.on;
        [[CEProductK6 shareInstance] sendCmdToDevice:disturbCmd complete:nil];
    }else if (12 == tag){
        YD_SyncUpBrightCmd *upBrightCmd = [[YD_SyncUpBrightCmd alloc] init];
        upBrightCmd.onoff = swt.on;
        upBrightCmd.start_hour = 9;
        upBrightCmd.start_min = 0;
        upBrightCmd.end_hour = 20;
        upBrightCmd.end_min = 59;
        [[CEProductK6 shareInstance] sendCmdToDevice:upBrightCmd complete:nil];
    }else if (13 == tag){
        YD_SyncAutoHeartCmd *autoHeartCmd = [[YD_SyncAutoHeartCmd alloc] init];
        autoHeartCmd.onoff = swt.on;
        [[CEProductK6 shareInstance] sendCmdToDevice:autoHeartCmd complete:nil];
    }else if (14 == tag){
        CE_SendPhotoCmd* photoCmd = [[CE_SendPhotoCmd alloc] init];
        photoCmd.onoff = swt.on;
        [[CEProductK6 shareInstance] sendCmdToDevice:photoCmd complete:nil];
    }
}

- (void)sendWeather{
    CE_SyncWeatherCmd *weatherCmd = [[CE_SyncWeatherCmd alloc] init];
    weatherCmd.time = (uint32_t)[[NSDate date] timeIntervalSince1970];
    NSInteger index = 0;
    // weatherModel.forecasts 数组长度小于3数据会发送，设备侧不会处理
    for (int i=0; i<3; i++) {
        CE_WeatherItem *weatherItem = [[CE_WeatherItem alloc] init];
       
        // weatherType = 0，使用旧协议的天气类型
        weatherItem.weather = 0;
        if (index == 0) {
            weatherItem.low_temperature = 28;
            weatherItem.high_temperature = 31;
            weatherCmd.todyWeather = weatherItem;
        } else if (index == 1) {
            weatherItem.low_temperature = 27;
            weatherItem.high_temperature = 32;
            weatherCmd.tomorrowWeather = weatherItem;
        } else if (index == 2) {
            weatherItem.low_temperature = 29;
            weatherItem.high_temperature = 30;
            weatherCmd.dayAfterTomorrowWeather = weatherItem;
        }else {
            break;
        }
        index ++;
    }
    
    [[CEProductK6 shareInstance] sendCmdToDevice:weatherCmd complete:^(NSError *error) {
        if (error == nil){
            NSLog(@"😄😄😄😄😄😄😄 send success");
        }
    }];
}

- (void)updateCell:(ListSwtCell *)cell atIndexPath:(NSIndexPath *)indexPath{
    
    DataManager *shared = DataManager.shared;
    if (3 == indexPath.row){
        cell.swt.on = shared.smsSwt.onoff;
    }
    if (4 == indexPath.row){
        cell.swt.on = shared.callSwt.onoff;
    }
    if (5 == indexPath.row) {
        cell.swt.on = shared.longSit.isOpen;
    }
    if (6 == indexPath.row) {
        cell.swt.on = shared.targetSwt.onoff;
    }
    if (7 == indexPath.row){
        cell.swt.on = shared.waterSwt.isOpen;
    }
    if (8 == indexPath.row) {
        cell.swt.on = shared.date.format;
        cell.detailTextLabel.text = shared.date.format == 0 ? @"12-hour" : @"24-hour";
    }
    if (9 == indexPath.row) {
        cell.swt.on = shared.date.mdFormat;
        cell.detailTextLabel.text = shared.date.mdFormat == 0 ? @"Month-Day" : @"Day-Month";
    }
    if (11 == indexPath.row){
        cell.swt.on = shared.disturb.switch_flag;
    }
    if (12 == indexPath.row){
        cell.swt.on = shared.raiseSwt.onoff;
    }
    if (13 == indexPath.row){
        cell.swt.on = shared.autoHrSwt.onoff;
    }
    if (14 == indexPath.row){
        cell.swt.on = shared.takePhotoSwt.onoff;
    }
}

- (void)showHeartRateExportOptions {
    NSInteger rawDataCount = [DataManager shared].rawHeartRateData.count;
    NSInteger historyCount = [DataManager shared].heartRateHistory.count;
    NSInteger ecgCount = [DataManager shared].ecgWaveformData.count;
    NSInteger o2Count = [DataManager shared].o2WaveformData.count;
    NSInteger totalCount = rawDataCount > 0 ? rawDataCount : historyCount;
    
    NSString *message = [NSString stringWithFormat:@"Testing ECG & O2 waveforms for raw sensor data.\n\nHR: %ld readings\nECG: %ld readings\nO2: %ld readings\n\nTap 'View JSON' or 'Export All' to see waveform data.", 
                         (long)totalCount, (long)ecgCount, (long)o2Count];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Waveform Data Collection"
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        // Stop collection when cancelled
        [[DataManager shared] stopHeartRateCollection];
    }]];
    
    // Always show View JSON - it will show "No data" if empty
    [alert addAction:[UIAlertAction actionWithTitle:@"View JSON" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self showJSONContent];
    }]];
    
    if (totalCount > 0 || ecgCount > 0 || o2Count > 0) {
        [alert addAction:[UIAlertAction actionWithTitle:@"Export All Waveforms" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self exportAllWaveformData];
        }]];
        
        if (ecgCount > 0) {
            [alert addAction:[UIAlertAction actionWithTitle:@"Export ECG Only" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self exportECGWaveformJSON];
            }]];
        }
        
        if (o2Count > 0) {
            [alert addAction:[UIAlertAction actionWithTitle:@"Export O2 Only" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self exportO2WaveformJSON];
            }]];
        }
        
        [alert addAction:[UIAlertAction actionWithTitle:@"Export HR Only" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self exportHeartRateJSON];
        }]];
        
        [alert addAction:[UIAlertAction actionWithTitle:@"Clear All" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            [[DataManager shared] clearHeartRateHistory];
            [[DataManager shared] clearWaveformData];
            [self.tableView reloadData];
            UIAlertController *confirmAlert = [UIAlertController alertControllerWithTitle:@"Cleared"
                                                                                 message:@"All waveform data cleared."
                                                                          preferredStyle:UIAlertControllerStyleAlert];
            [confirmAlert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:confirmAlert animated:YES completion:nil];
        }]];
    }
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)shareContent:(NSString *)content fileName:(NSString *)fileName fileType:(NSString *)fileType {
    // Save to Documents directory
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
    
    NSError *error;
    [content writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    
    if (error) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Export Failed"
                                                                       message:error.localizedDescription
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    // Show success message and share sheet
    UIAlertController *successAlert = [UIAlertController alertControllerWithTitle:@"Export Successful"
                                                                          message:[NSString stringWithFormat:@"File saved: %@\n\nTap 'Share File' to save to Files app.", fileName]
                                                                   preferredStyle:UIAlertControllerStyleAlert];
    [successAlert addAction:[UIAlertAction actionWithTitle:@"Share File" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        // Show share sheet
        NSURL *fileURL = [NSURL fileURLWithPath:filePath];
        UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:@[fileURL] applicationActivities:nil];
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            activityVC.popoverPresentationController.sourceView = self.view;
            activityVC.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2, 0, 0);
        }
        
        [self presentViewController:activityVC animated:YES completion:nil];
    }]];
    [successAlert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:successAlert animated:YES completion:nil];
}

- (void)exportAllWaveformData {
    NSString *jsonContent = [[DataManager shared] exportAllWaveformDataToJSON];
    if (!jsonContent) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"No Data"
                                                                       message:@"No waveform data to export."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd_HH-mm-ss"];
    NSString *dateString = [formatter stringFromDate:[NSDate date]];
    NSString *fileName = [NSString stringWithFormat:@"all_waveform_data_%@.json", dateString];
    
    [self shareContent:jsonContent fileName:fileName fileType:@"application/json"];
}

- (void)exportECGWaveformJSON {
    NSString *jsonContent = [[DataManager shared] exportECGWaveformToJSON];
    if (!jsonContent) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"No Data"
                                                                       message:@"No ECG waveform data to export."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd_HH-mm-ss"];
    NSString *dateString = [formatter stringFromDate:[NSDate date]];
    NSString *fileName = [NSString stringWithFormat:@"ecg_waveform_data_%@.json", dateString];
    
    [self shareContent:jsonContent fileName:fileName fileType:@"application/json"];
}

- (void)exportO2WaveformJSON {
    NSString *jsonContent = [[DataManager shared] exportO2WaveformToJSON];
    if (!jsonContent) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"No Data"
                                                                       message:@"No O2 waveform data to export."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd_HH-mm-ss"];
    NSString *dateString = [formatter stringFromDate:[NSDate date]];
    NSString *fileName = [NSString stringWithFormat:@"o2_waveform_data_%@.json", dateString];
    
    [self shareContent:jsonContent fileName:fileName fileType:@"application/json"];
}

- (void)exportHeartRateJSON {
    NSString *jsonContent = [[DataManager shared] exportHeartRateToJSON];
    if (!jsonContent) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"No Data"
                                                                       message:@"No heart rate data to export. Start measuring first."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    // Create file with readable name
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd_HH-mm-ss"];
    NSString *dateString = [formatter stringFromDate:[NSDate date]];
    NSString *fileName = [NSString stringWithFormat:@"heart_rate_data_%@.json", dateString];
    
    // Save to Documents directory
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
    
    NSError *error;
    [jsonContent writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    
    if (error) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Export Failed"
                                                                       message:error.localizedDescription
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    // Show success message with file location info
    NSInteger dataCount = [DataManager shared].heartRateHistory.count;
    NSString *message = [NSString stringWithFormat:@"Exported %ld readings to:\n%@\n\nUse 'Save to Files' in the share sheet to save it to your Files app.", (long)dataCount, fileName];
    
    UIAlertController *successAlert = [UIAlertController alertControllerWithTitle:@"Export Successful"
                                                                          message:message
                                                                   preferredStyle:UIAlertControllerStyleAlert];
    [successAlert addAction:[UIAlertAction actionWithTitle:@"Share File" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        // Show share sheet
        NSURL *fileURL = [NSURL fileURLWithPath:filePath];
        UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:@[fileURL] applicationActivities:nil];
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            activityVC.popoverPresentationController.sourceView = self.view;
            activityVC.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2, 0, 0);
        }
        
        [self presentViewController:activityVC animated:YES completion:nil];
    }]];
    [successAlert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:successAlert animated:YES completion:nil];
}

- (void)showJSONContent {
    // Try to export all waveform data first, then fall back to HR only
    NSString *jsonContent = [[DataManager shared] exportAllWaveformDataToJSON];
    if (!jsonContent) {
        jsonContent = [[DataManager shared] exportHeartRateToJSON];
    }
    if (!jsonContent) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"No Data"
                                                                       message:@"No waveform data available. Start measurements first."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    // Create a view controller to display JSON
    UIViewController *jsonVC = [[UIViewController alloc] init];
    jsonVC.title = @"Heart Rate JSON Data";
    
    UITextView *textView = [[UITextView alloc] init];
    textView.text = jsonContent;
    textView.font = [UIFont fontWithName:@"Courier" size:12];
    textView.editable = NO;
    textView.translatesAutoresizingMaskIntoConstraints = NO;
    [jsonVC.view addSubview:textView];
    
    [NSLayoutConstraint activateConstraints:@[
        [textView.topAnchor constraintEqualToAnchor:jsonVC.view.safeAreaLayoutGuide.topAnchor],
        [textView.leadingAnchor constraintEqualToAnchor:jsonVC.view.leadingAnchor],
        [textView.trailingAnchor constraintEqualToAnchor:jsonVC.view.trailingAnchor],
        [textView.bottomAnchor constraintEqualToAnchor:jsonVC.view.bottomAnchor]
    ]];
    
    // Add copy button
    UIBarButtonItem *copyButton = [[UIBarButtonItem alloc] initWithTitle:@"Copy" style:UIBarButtonItemStylePlain target:self action:@selector(copyJSONToClipboard)];
    jsonVC.navigationItem.rightBarButtonItem = copyButton;
    
    // Store JSON content for copying
    objc_setAssociatedObject(self, @"currentJSON", jsonContent, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:jsonVC];
    navController.navigationBar.prefersLargeTitles = NO;
    
    // Add close button
    UIBarButtonItem *closeButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(dismissJSONView)];
    jsonVC.navigationItem.leftBarButtonItem = closeButton;
    
    [self presentViewController:navController animated:YES completion:nil];
}

- (void)copyJSONToClipboard {
    NSString *jsonContent = objc_getAssociatedObject(self, @"currentJSON");
    if (jsonContent) {
        [UIPasteboard generalPasteboard].string = jsonContent;
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Copied"
                                                                       message:@"JSON data copied to clipboard"
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self.presentedViewController presentViewController:alert animated:YES completion:nil];
    }
}

- (void)dismissJSONView {
    [self dismissViewControllerAnimated:YES completion:nil];
    objc_setAssociatedObject(self, @"currentJSON", nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)showBLEAnalyzerOptions {
    BLEProtocolAnalyzer *analyzer = [BLEProtocolAnalyzer shared];
    NSArray *packets = [analyzer getCapturedPackets];
    BOOL isLogging = analyzer.isLogging;
    BOOL isExploring = analyzer.isExploring;
    
    NSString *status = isExploring ? @"🔴 EXPLORING" : (isLogging ? @"🟡 LOGGING" : @"⚪ Stopped");
    NSDictionary *stats = [analyzer getPacketStatistics];
    
    NSString *message = [NSString stringWithFormat:@"BLE Protocol Analyzer\n\nStatus: %@\nPackets: %lu\nTX: %@ | RX: %@\n\nPurpose: Reverse engineer BLE protocol to find undocumented commands for raw sensor data access.\n\nFocus: Test/Debug commands (203-206) for raw sensor data.", 
                         status,
                         (unsigned long)packets.count,
                         stats[@"txPackets"],
                         stats[@"rxPackets"]];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"BLE Protocol Analyzer"
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    if (!isLogging && !isExploring) {
        [alert addAction:[UIAlertAction actionWithTitle:@"Start Logging" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [[BLEProtocolAnalyzer shared] startLogging];
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Started"
                                                                              message:@"BLE Protocol Analyzer is now capturing all RX/TX packets. Check Xcode console for detailed logs."
                                                                       preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    
    if (isLogging && !isExploring) {
        [alert addAction:[UIAlertAction actionWithTitle:@"Stop Logging" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [[BLEProtocolAnalyzer shared] stopLogging];
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Stopped"
                                                                              message:@"BLE Protocol Analyzer stopped."
                                                                       preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    
    if (isLogging && !isExploring) {
        [alert addAction:[UIAlertAction actionWithTitle:@"🔬 Manual Parameter Testing" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self showManualParameterTesting];
        }]];
        
        [alert addAction:[UIAlertAction actionWithTitle:@"🚀 Systematic Exploration" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Start Exploration"
                                                                              message:@"This will systematically test all command opcodes (200-255) to find hidden commands. Takes ~3 minutes. Continue?"
                                                                       preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
            [confirm addAction:[UIAlertAction actionWithTitle:@"Start" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [[BLEProtocolAnalyzer shared] startSystematicExploration];
                UIAlertController *info = [UIAlertController alertControllerWithTitle:@"Exploration Started"
                                                                              message:@"Systematic exploration in progress. Testing opcodes 200-255. Check Xcode console for results. Takes ~3 minutes."
                                                                       preferredStyle:UIAlertControllerStyleAlert];
                [info addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
                [self presentViewController:info animated:YES completion:nil];
            }]];
            [self presentViewController:confirm animated:YES completion:nil];
        }]];
        
        [alert addAction:[UIAlertAction actionWithTitle:@"🔬 Test Known Patterns" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [[BLEProtocolAnalyzer shared] testKnownCommandPatterns];
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Testing Started"
                                                                              message:@"Testing known test/debug commands (203-206). Check Xcode console for results."
                                                                       preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    
    if (isExploring) {
        [alert addAction:[UIAlertAction actionWithTitle:@"Stop Exploration" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            [[BLEProtocolAnalyzer shared] stopSystematicExploration];
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Stopped"
                                                                              message:@"Systematic exploration stopped. Check Xcode console for results."
                                                                       preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    
    if (packets.count > 0) {
        [alert addAction:[UIAlertAction actionWithTitle:@"📊 View Statistics" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self showBLEStatistics];
        }]];
        
        [alert addAction:[UIAlertAction actionWithTitle:@"Export Packets" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self exportBLEPackets];
        }]];
        
        [alert addAction:[UIAlertAction actionWithTitle:@"Clear Packets" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            [[BLEProtocolAnalyzer shared] clearPackets];
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Cleared"
                                                                              message:@"All captured packets cleared."
                                                                       preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showBLEStatistics {
    BLEProtocolAnalyzer *analyzer = [BLEProtocolAnalyzer shared];
    NSDictionary *stats = [analyzer getPacketStatistics];
    NSDictionary *structure = [analyzer analyzeProtocolStructure];
    
    NSMutableString *message = [NSMutableString string];
    [message appendFormat:@"📊 BLE Protocol Statistics\n\n"];
    [message appendFormat:@"Total Packets: %@\n", stats[@"totalPackets"]];
    [message appendFormat:@"TX Packets: %@\n", stats[@"txPackets"]];
    [message appendFormat:@"RX Packets: %@\n", stats[@"rxPackets"]];
    [message appendFormat:@"Total Bytes: %@\n", stats[@"totalBytes"]];
    [message appendFormat:@"Avg Length: %@ bytes\n", stats[@"avgLength"]];
    [message appendFormat:@"Commands Tested: %lu\n\n", (unsigned long)[stats[@"testResults"] count]];
    
    NSArray *testResults = stats[@"testResults"];
    NSArray *responses = [testResults filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"hasResponse == YES"]];
    NSArray *dataResponses = [testResults filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"hasDataResponse == YES"]];
    
    if (responses.count > 0) {
        [message appendFormat:@"✅ Commands with responses: %lu\n", (unsigned long)responses.count];
        if (dataResponses.count > 0) {
            [message appendFormat:@"🎯 Commands with DATA responses: %lu ⭐\n", (unsigned long)dataResponses.count];
        }
        [message appendString:@"\nResponsive opcodes:\n"];
        for (NSDictionary *result in responses) {
            BOOL isData = [result[@"hasDataResponse"] boolValue];
            [message appendFormat:@"  • 0x%02X (%d)%@\n", 
             [result[@"opcode"] intValue], 
             [result[@"opcode"] intValue],
             isData ? @" ⭐ DATA" : @" (ACK)"];
        }
    } else {
        [message appendString:@"No responses yet.\n"];
    }
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Statistics"
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showManualParameterTesting {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Manual Parameter Testing"
                                                                   message:@"Test recognized commands (0xCB-0xCE) with different parameter values.\n\nGoal: Find parameters that return DATA (Byte[4]=0x21) instead of ACK."
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    // Test DEBUG commands with different parameters
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCB: TEST_DEBUG (0x00)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x00};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCB params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCB: TEST_DEBUG (0x01)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x01};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCB params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCB: TEST_DEBUG (0x02)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x02};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCB params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCB: TEST_DEBUG (0x03)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x03};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCB params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCB: TEST_DEBUG (0x80)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x80};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCB params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCB: TEST_DEBUG (0xFF)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0xFF};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCB params:params];
    }]];
    
    // APP_TEST
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCC: APP_TEST (0x00)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x00};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCC params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCC: APP_TEST (0x02)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x02};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCC params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCC: APP_TEST (0xFF)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0xFF};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCC params:params];
    }]];
    
    // FACTORY_TEST
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCD: FACTORY_TEST (0x00)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x00};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCD params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCD: FACTORY_TEST (0x02)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x02};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCD params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCD: FACTORY_TEST (0xFF)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0xFF};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCD params:params];
    }]];
    
    // LEAKLIGHT_TEST
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCE: LEAKLIGHT_TEST (0x00)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x00};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCE params:params];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"0xCE: LEAKLIGHT_TEST (0x01)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        uint8_t paramBytes[] = {0x01};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:0xCE params:params];
    }]];
    
    // Custom parameter input
    [alert addAction:[UIAlertAction actionWithTitle:@"🎯 Custom Test" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [self showCustomParameterInput];
    }]];
    
    // For iPad
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        alert.popoverPresentationController.sourceView = self.view;
        alert.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2, 0, 0);
    }
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showCustomParameterInput {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Custom Parameter Test"
                                                                   message:@"Enter command opcode and parameter value (hex, 0x00-0xFF)"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Opcode: 0xCB";
        textField.keyboardType = UIKeyboardTypeDefault;
    }];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Parameter: 0x02";
        textField.keyboardType = UIKeyboardTypeDefault;
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Test" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UITextField *opcodeField = alert.textFields[0];
        UITextField *paramField = alert.textFields[1];
        
        // Parse hex opcode
        NSString *opcodeStr = opcodeField.text;
        if ([opcodeStr hasPrefix:@"0x"] || [opcodeStr hasPrefix:@"0X"]) {
            opcodeStr = [opcodeStr substringFromIndex:2];
        }
        unsigned opcode;
        NSScanner *opcodeScanner = [NSScanner scannerWithString:opcodeStr];
        if (![opcodeScanner scanHexInt:&opcode] || opcode > 0xFF) {
            UIAlertController *error = [UIAlertController alertControllerWithTitle:@"Invalid Opcode"
                                                                           message:@"Opcode must be between 0x00 and 0xFF"
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            [error addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:error animated:YES completion:nil];
            return;
        }
        
        // Parse hex parameter
        NSString *paramStr = paramField.text;
        if ([paramStr hasPrefix:@"0x"] || [paramStr hasPrefix:@"0X"]) {
            paramStr = [paramStr substringFromIndex:2];
        }
        unsigned param;
        NSScanner *paramScanner = [NSScanner scannerWithString:paramStr];
        if (![paramScanner scanHexInt:&param] || param > 0xFF) {
            UIAlertController *error = [UIAlertController alertControllerWithTitle:@"Invalid Parameter"
                                                                           message:@"Parameter must be between 0x00 and 0xFF"
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            [error addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:error animated:YES completion:nil];
            return;
        }
        
        uint8_t paramBytes[] = {(uint8_t)param};
        NSData *params = [NSData dataWithBytes:paramBytes length:1];
        [[BLEProtocolAnalyzer shared] tryCustomCommand:(uint8_t)opcode params:params];
        
        UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Test Sent"
                                                                          message:[NSString stringWithFormat:@"Command 0x%02X with parameter 0x%02X sent. Check Xcode console for response.", opcode, param]
                                                                   preferredStyle:UIAlertControllerStyleAlert];
        [confirm addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:confirm animated:YES completion:nil];
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)exportBLEPackets {
    NSString *jsonContent = [[BLEProtocolAnalyzer shared] exportToJSON];
    if (!jsonContent) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Export Failed"
                                                                       message:@"Failed to export packets."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd_HH-mm-ss"];
    NSString *dateString = [formatter stringFromDate:[NSDate date]];
    NSString *fileName = [NSString stringWithFormat:@"ble_protocol_packets_%@.json", dateString];
    
    [self shareContent:jsonContent fileName:fileName fileType:@"application/json"];
}

@end
