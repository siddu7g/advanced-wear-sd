//
//  RealTestViewController.h
//  sdkdemo
//
//  Created by coolwear on 2023/5/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RealTestViewController : UIViewController
@property (nonatomic, assign) NSInteger type;
@end

NS_ASSUME_NONNULL_END
