//
//  AppViewController.h
//  sdkdemo
//
//  Created by coolwear on 2022/9/22.
//

#import "BaseFuncViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppViewController : BaseFuncViewController

@end

NS_ASSUME_NONNULL_END
