//
//  BaseFuncViewController.m
//  sdkdemo
//
//  Created by coolwear on 2022/9/21.
//

#import "BaseFuncViewController.h"

@interface BaseFuncViewController ()

@end

@implementation BaseFuncViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = UIColor.whiteColor;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
