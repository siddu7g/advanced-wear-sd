//
//  ContactViewController.h
//  sdkdemo
//
//  Created by coolwear on 2022/9/30.
//

#import "BaseFuncViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ContactViewController : BaseFuncViewController

@end

NS_ASSUME_NONNULL_END
