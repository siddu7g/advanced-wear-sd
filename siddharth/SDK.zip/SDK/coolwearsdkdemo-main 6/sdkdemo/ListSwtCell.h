//
//  ListSwtCell.h
//  sdkdemo
//
//  Created by coolwear on 2023/5/5.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ListSwtCell : UITableViewCell
@property (nonatomic, strong) UISwitch *swt;
@property (nonatomic, strong) UILabel *lab;
@end

NS_ASSUME_NONNULL_END
