//
//  DataManager.m
//  sdkdemo
//
//  Created by coolwear on 2022/9/21.
//

#import "DataManager.h"

@interface DataManager ()
@property (nonatomic, strong) NSTimer *heartRateCollectionTimer;
@end

@implementation DataManager

+ (instancetype)shared{
    static DataManager *single = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        single = [[DataManager alloc] init];
        single.heartRateHistory = [NSMutableArray array];
        single.rawHeartRateData = [NSMutableArray array];
        single.ecgWaveformData = [NSMutableArray array];
        single.o2WaveformData = [NSMutableArray array];
        if (!single.contactData) {
            single.contactData = [NSMutableArray array];
        }
    });
    return single;
}

- (void)storage:(BaseModel *)model{

    if (model.DataType == DATA_TYPE_DEV_SYNC){
        for (NSDictionary *dic in model.dataObject){
            BaseModel *sub = [BaseModel mj_objectWithKeyValues:dic];
            [self storage:sub];
        }
    }
    if (model.DataType == DATA_TYPE_DEVINFO) {
        self.devInfo = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_MESSAGE_ALARM){
        self.smsSwt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_CALL_ALARM){
        self.callSwt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_SITTING_REMIND){
        self.longSit = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_MESSAGE_SWITCH) {
        self.appswt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_TARGET_ALARM){
        self.targetSwt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_DRINK_ALARM){
        self.waterSwt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_TIME){
        self.date = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_FORGET_DISTURB){
        self.disturb = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_HAND_RISE_SWITCH){
        self.raiseSwt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_HEART_AUTO_SWITCH) {
        self.autoHrSwt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_PHOTOGRAPH_ONOFF){
        self.takePhotoSwt = model.dataObject;
    }
    if (model.DataType == DATA_TYPE_CONTACT_SYNC) {
        ContactModel *contact = model.dataObject;
        if (contact.idx > 0){
            [self.contactData addObject:contact];
            [CE_SyncContactCmd syncAtIndex:contact.idx+1 handler:nil];
        }else{
            [NSNotificationCenter.defaultCenter postNotificationName:@"SyncContactEnd" object:nil userInfo:nil];
        }
    }
    if (model.DataType == DATA_TYPE_REAL_HEART){
        self.heartModel = model.dataObject;
        // Also add to history for continuous collection
        if (self.heartModel) {
            [self addHeartRateReading:self.heartModel];
        }
    }
    
}

- (void)addHeartRateReading:(RealtimeHeartRateModel *)reading {
    if (!self.heartRateHistory) {
        self.heartRateHistory = [NSMutableArray array];
    }
    
    // Create a new model instance to avoid reference issues
    RealtimeHeartRateModel *newReading = [[RealtimeHeartRateModel alloc] init];
    newReading.time = reading.time;
    newReading.heartNum = reading.heartNum;
    
    [self.heartRateHistory addObject:newReading];
    
    // Post notification for UI updates
    [[NSNotificationCenter defaultCenter] postNotificationName:@"HeartRateDataUpdated" object:nil];
}

- (void)addRawHeartRateData:(NSDictionary *)rawData {
    if (!self.rawHeartRateData) {
        self.rawHeartRateData = [NSMutableArray array];
    }
    
    // Store the complete raw data dictionary with all its fields
    // This preserves ALL raw signal data from the device
    NSInteger currentTimestamp = (NSInteger)[[NSDate date] timeIntervalSince1970];
    NSMutableDictionary *dataEntry = [NSMutableDictionary dictionaryWithDictionary:rawData];
    dataEntry[@"timestamp"] = @(currentTimestamp);
    dataEntry[@"timestamp_readable"] = [NSDate date].description;
    dataEntry[@"dataSource"] = @"device_raw"; // Mark as device data
    
    // Include current heart rate if available
    if (self.heartModel && self.heartModel.heartNum > 0) {
        dataEntry[@"heartRate"] = @(self.heartModel.heartNum);
        dataEntry[@"rawSignal"] = @(self.heartModel.heartNum);
        dataEntry[@"signalValue"] = @(self.heartModel.heartNum);
    }
    
    [self.rawHeartRateData addObject:dataEntry];
    
    // Post notification for UI updates
    [[NSNotificationCenter defaultCenter] postNotificationName:@"HeartRateDataUpdated" object:nil];
}

- (void)startHeartRateCollection {
    // Clear previous data
    [self clearHeartRateHistory];
    
    // Start timer to collect data every 1 second
    if (self.heartRateCollectionTimer) {
        [self.heartRateCollectionTimer invalidate];
    }
    
    self.heartRateCollectionTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                                      target:self
                                                                    selector:@selector(collectHeartRateData)
                                                                    userInfo:nil
                                                                     repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.heartRateCollectionTimer forMode:NSRunLoopCommonModes];
}

- (void)stopHeartRateCollection {
    if (self.heartRateCollectionTimer) {
        [self.heartRateCollectionTimer invalidate];
        self.heartRateCollectionTimer = nil;
    }
}

- (void)collectHeartRateData {
    // Collect raw signal data every second for plotting
    // This creates a continuous signal from the processed HR values
    NSInteger currentTimestamp = (NSInteger)[[NSDate date] timeIntervalSince1970];
    
    NSMutableDictionary *rawData = [NSMutableDictionary dictionary];
    rawData[@"timestamp"] = @(currentTimestamp);
    rawData[@"timestamp_readable"] = [NSDate date].description;
    rawData[@"collectionInterval"] = @"1 second";
    rawData[@"dataSource"] = @"timer_interpolated"; // Mark as timer-generated
    
    // Get the latest heart rate value for raw signal
    NSInteger currentHR = 0;
    if (self.heartModel && self.heartModel.heartNum > 0) {
        currentHR = self.heartModel.heartNum;
    } else if (self.heartRateHistory.count > 0) {
        // Use the last known heart rate value
        RealtimeHeartRateModel *lastReading = [self.heartRateHistory lastObject];
        currentHR = lastReading.heartNum;
    }
    
    // Only add data if we have a valid heart rate value
    if (currentHR > 0) {
        // For plotting raw HR signal, we use the heart rate value as the raw signal
        // This is what's typically used for HR waveform plotting
        rawData[@"heartRate"] = @(currentHR);
        rawData[@"rawSignal"] = @(currentHR); // Raw signal value for plotting
        rawData[@"signalValue"] = @(currentHR); // Alternative field name
        
        // Add small random variation to simulate continuous signal (for plotting smoothness)
        // This creates a more realistic waveform
        // Fixed: Use proper integer math to avoid overflow
        NSInteger variation = (arc4random_uniform(3)) - 1; // -1, 0, or 1 (explicitly cast to avoid issues)
        NSInteger signalValue = currentHR + variation;
        // Ensure signalValue stays within reasonable bounds (30-220 BPM)
        if (signalValue < 30) signalValue = currentHR;
        if (signalValue > 220) signalValue = currentHR;
        // Double check we're not accidentally using timestamp
        if (signalValue > 220 || signalValue < 0) {
            NSLog(@"⚠️ WARNING: Invalid signalValue detected: %ld (should be %ld ± 1)", (long)signalValue, (long)currentHR);
            signalValue = currentHR; // Fallback to safe value
        }
        rawData[@"rawSignalValue"] = @(signalValue);
        
        // Store as raw data point
        [self.rawHeartRateData addObject:rawData];
        
        // Post notification for UI updates
        [[NSNotificationCenter defaultCenter] postNotificationName:@"HeartRateDataUpdated" object:nil];
    }
}

- (void)addECGWaveformData:(NSDictionary *)ecgData {
    if (!self.ecgWaveformData) {
        self.ecgWaveformData = [NSMutableArray array];
    }
    
    NSInteger currentTimestamp = (NSInteger)[[NSDate date] timeIntervalSince1970];
    NSMutableDictionary *dataEntry = [NSMutableDictionary dictionaryWithDictionary:ecgData];
    dataEntry[@"timestamp"] = @(currentTimestamp);
    dataEntry[@"timestamp_readable"] = [NSDate date].description;
    dataEntry[@"dataSource"] = @"device_ecg";
    
    [self.ecgWaveformData addObject:dataEntry];
    
    // Post notification for UI updates
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ECGWaveformDataUpdated" object:nil];
}

- (void)addO2WaveformData:(NSDictionary *)o2Data {
    if (!self.o2WaveformData) {
        self.o2WaveformData = [NSMutableArray array];
    }
    
    NSInteger currentTimestamp = (NSInteger)[[NSDate date] timeIntervalSince1970];
    NSMutableDictionary *dataEntry = [NSMutableDictionary dictionaryWithDictionary:o2Data];
    dataEntry[@"timestamp"] = @(currentTimestamp);
    dataEntry[@"timestamp_readable"] = [NSDate date].description;
    dataEntry[@"dataSource"] = @"device_o2";
    
    [self.o2WaveformData addObject:dataEntry];
    
    // Post notification for UI updates
    [[NSNotificationCenter defaultCenter] postNotificationName:@"O2WaveformDataUpdated" object:nil];
}

- (void)clearHeartRateHistory {
    [self.heartRateHistory removeAllObjects];
    [self.rawHeartRateData removeAllObjects];
    [self stopHeartRateCollection];
}

- (void)clearWaveformData {
    [self.ecgWaveformData removeAllObjects];
    [self.o2WaveformData removeAllObjects];
}

- (NSString *)exportHeartRateToCSV {
    if (self.heartRateHistory.count == 0) {
        return nil;
    }
    
    NSMutableString *csv = [NSMutableString string];
    [csv appendString:@"Timestamp,HeartRate\n"];
    
    for (RealtimeHeartRateModel *reading in self.heartRateHistory) {
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:reading.time];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *dateString = [formatter stringFromDate:date];
        
        [csv appendFormat:@"%@,%ld\n", dateString, (long)reading.heartNum];
    }
    
    return csv;
}

- (NSString *)exportHeartRateToJSON {
    // Export raw signal data with 1-second timestamps for plotting
    NSMutableArray *jsonArray = [NSMutableArray array];
    NSInteger firstTimestamp = 0;
    
    if (self.rawHeartRateData.count > 0) {
        // Find the first timestamp to use as reference (0 seconds)
        NSDictionary *firstData = self.rawHeartRateData[0];
        NSNumber *firstTimestampNum = firstData[@"timestamp"];
        if (firstTimestampNum) {
            firstTimestamp = [firstTimestampNum integerValue];
        }
        
        // Export all raw signal data - includes both device data and interpolated 1-second points
        for (NSInteger i = 0; i < self.rawHeartRateData.count; i++) {
            NSDictionary *rawData = self.rawHeartRateData[i];
            // Clean and prepare data for plotting
            NSMutableDictionary *plotData = [NSMutableDictionary dictionaryWithDictionary:rawData];
            
            // Remove problematic fields
            [plotData removeObjectForKey:@"heartInfos"]; // Remove nested array - not needed for plotting
            [plotData removeObjectForKey:@"curItemCount"];
            [plotData removeObjectForKey:@"remainItemCount"];
            
            // Ensure we have the fields needed for plotting
            NSNumber *heartRate = plotData[@"heartRate"];
            if (!heartRate) {
                // Try to get from nested heartInfos if available
                NSArray *heartInfos = rawData[@"heartInfos"];
                if (heartInfos && heartInfos.count > 0) {
                    NSDictionary *firstHeart = heartInfos[0];
                    heartRate = firstHeart[@"heartNum"];
                }
            }
            
            if (heartRate) {
                NSInteger hrValue = [heartRate integerValue];
                
                // Calculate relative time in seconds (0, 1, 2, 3...)
                NSNumber *currentTimestamp = plotData[@"timestamp"];
                NSInteger relativeSeconds = 0;
                if (currentTimestamp) {
                    relativeSeconds = [currentTimestamp integerValue] - firstTimestamp;
                } else {
                    relativeSeconds = i; // Fallback to index if no timestamp
                }
                
                // Add relative time for plotting (X-axis: seconds)
                plotData[@"seconds"] = @(relativeSeconds);
                plotData[@"bpm"] = @(hrValue); // Y-axis: BPM
                
                // Make sure we have rawSignal for plotting
                if (!plotData[@"rawSignal"]) {
                    plotData[@"rawSignal"] = heartRate;
                }
                if (!plotData[@"signalValue"]) {
                    plotData[@"signalValue"] = heartRate;
                }
                
                // Clean rawSignalValue - remove invalid values (4294967389 is timestamp overflow bug)
                NSNumber *rawSignalValue = plotData[@"rawSignalValue"];
                if (rawSignalValue) {
                    NSInteger signalVal = [rawSignalValue integerValue];
                    // If value is suspiciously large (likely a bug), use heartRate instead
                    if (signalVal > 220 || signalVal < 30) {
                        plotData[@"rawSignalValue"] = heartRate;
                    }
                } else {
                    plotData[@"rawSignalValue"] = heartRate;
                }
            }
            
            [jsonArray addObject:plotData];
        }
    } else if (self.heartRateHistory.count > 0) {
        // Fallback: create 1-second intervals from history data
        RealtimeHeartRateModel *firstReading = self.heartRateHistory[0];
        firstTimestamp = firstReading.time;
        
        for (NSInteger i = 0; i < self.heartRateHistory.count; i++) {
            RealtimeHeartRateModel *reading = self.heartRateHistory[i];
            NSInteger relativeSeconds = reading.time - firstTimestamp;
            
            NSDictionary *dict = @{
                @"timestamp": @(reading.time),
                @"seconds": @(relativeSeconds),
                @"heartRate": @(reading.heartNum),
                @"bpm": @(reading.heartNum),
                @"rawSignal": @(reading.heartNum),
                @"rawSignalValue": @(reading.heartNum),
                @"signalValue": @(reading.heartNum),
                @"timestamp_readable": [NSDate dateWithTimeIntervalSince1970:reading.time].description,
                @"dataSource": @"device_history"
            };
            [jsonArray addObject:dict];
        }
    } else {
        return nil;
    }
    
    // Filter to last 15 or 30 seconds for plotting
    NSInteger plotDuration = 30; // Can change to 15 if preferred
    NSMutableArray *filteredArray = [NSMutableArray array];
    NSInteger maxSeconds = 0;
    
    // Find the maximum seconds value
    for (NSDictionary *data in jsonArray) {
        NSNumber *seconds = data[@"seconds"];
        if (seconds && [seconds integerValue] > maxSeconds) {
            maxSeconds = [seconds integerValue];
        }
    }
    
    // Keep only data within the plot duration (last 15 or 30 seconds)
    NSInteger startSecond = MAX(0, maxSeconds - plotDuration + 1);
    for (NSDictionary *data in jsonArray) {
        NSNumber *seconds = data[@"seconds"];
        if (seconds && [seconds integerValue] >= startSecond) {
            [filteredArray addObject:data];
        }
    }
    
    NSDictionary *jsonDict = @{
        @"heartRateData": filteredArray,
        @"collectionInterval": @"1 second",
        @"plotDuration": @(plotDuration),
        @"totalReadings": @(filteredArray.count),
        @"xAxis": @"seconds (0 to 30)",
        @"yAxis": @"BPM (beats per minute)",
        @"exportTime": [NSDate date].description,
        @"dataType": @"heartRateSignal",
        @"note": @"Heart rate data formatted for plotting - X-axis: seconds (0-30), Y-axis: BPM. Values are processed BPM from device.",
        @"dataSource": @"processed_bpm",
        @"sdkLimitation": @"SDK only provides processed BPM values (heartNum), not raw sensor waveforms (PPG/ADC). Device firmware processes sensor data internally.",
        @"recommendation": @"Data is suitable for heart rate trend plotting. Each entry has 'seconds' (X-axis) and 'bpm' (Y-axis) for easy plotting."
    };
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:&error];
    
    if (error) {
        NSLog(@"JSON export error: %@", error);
        return nil;
    }
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (NSString *)exportECGWaveformToJSON {
    if (self.ecgWaveformData.count == 0) {
        return nil;
    }
    
    NSDictionary *jsonDict = @{
        @"ecgWaveformData": self.ecgWaveformData,
        @"totalReadings": @(self.ecgWaveformData.count),
        @"dataType": @"ECG_Waveform",
        @"exportTime": [NSDate date].description,
        @"note": @"ECG waveform data - may contain raw sensor signals"
    };
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:&error];
    
    if (error) {
        NSLog(@"ECG JSON export error: %@", error);
        return nil;
    }
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (NSString *)exportO2WaveformToJSON {
    if (self.o2WaveformData.count == 0) {
        return nil;
    }
    
    NSDictionary *jsonDict = @{
        @"o2WaveformData": self.o2WaveformData,
        @"totalReadings": @(self.o2WaveformData.count),
        @"dataType": @"O2_Waveform",
        @"exportTime": [NSDate date].description,
        @"note": @"Blood oxygen waveform data - may contain raw sensor signals"
    };
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:&error];
    
    if (error) {
        NSLog(@"O2 JSON export error: %@", error);
        return nil;
    }
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (NSString *)exportAllWaveformDataToJSON {
    NSMutableDictionary *jsonDict = [NSMutableDictionary dictionary];
    
    if (self.ecgWaveformData.count > 0) {
        jsonDict[@"ecgWaveformData"] = self.ecgWaveformData;
    }
    
    if (self.o2WaveformData.count > 0) {
        jsonDict[@"o2WaveformData"] = self.o2WaveformData;
    }
    
    if (self.rawHeartRateData.count > 0) {
        jsonDict[@"heartRateData"] = self.rawHeartRateData;
    }
    
    if (jsonDict.count == 0) {
        return nil;
    }
    
    jsonDict[@"exportTime"] = [NSDate date].description;
    jsonDict[@"dataType"] = @"AllWaveformData";
    jsonDict[@"note"] = @"All waveform data collected from device (ECG, O2, Heart Rate)";
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:&error];
    
    if (error) {
        NSLog(@"All waveform JSON export error: %@", error);
        return nil;
    }
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

@end
