//
//  AppSwtManager.m
//  sdkdemo
//
//  Created by coolwear on 2022/9/22.
//

#import "AppSwtModel.h"

@implementation AppSwtModel

@end
