//
//  ContactModel.m
//  sdkdemo
//
//  Created by coolwear on 2022/9/30.
//

#import "ContactModel.h"

@implementation ContactModel

@end
