//
//  RealtimeHeartRateModel.m
//  sdkdemo
//
//  Created by coolwear on 2023/5/8.
//

#import "RealtimeHeartRateModel.h"

@implementation RealtimeHeartRateModel

@end
