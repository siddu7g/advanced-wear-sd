//
//  AppSwtManager.h
//  sdkdemo
//
//  Created by coolwear on 2022/9/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppSwtModel : NSObject
@property (nonatomic, assign) BOOL allSwitch;
@property (nonatomic, assign) BOOL email;
@property (nonatomic, assign) BOOL facebook;
@property (nonatomic, assign) BOOL instagram;
@property (nonatomic, assign) BOOL kakaoTalk;
@property (nonatomic, assign) BOOL line;
@property (nonatomic, assign) BOOL linkedIn;
@property (nonatomic, assign) BOOL qq;
@property (nonatomic, assign) BOOL skype;
@property (nonatomic, assign) BOOL telegram;
@property (nonatomic, assign) BOOL twitter;
@property (nonatomic, assign) BOOL wechat;
@property (nonatomic, assign) BOOL whatsapp;
@property (nonatomic, assign) BOOL other;
@end

NS_ASSUME_NONNULL_END
