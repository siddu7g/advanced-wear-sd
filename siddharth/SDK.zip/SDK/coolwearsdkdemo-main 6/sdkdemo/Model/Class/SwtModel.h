//
//  SwtModel.h
//  sdkdemo
//
//  Created by coolwear on 2022/9/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SwtModel : NSObject
@property (nonatomic, assign) BOOL onoff;
@property (nonatomic, assign) BOOL isOpen;
@property (nonatomic, assign) BOOL switch_flag;
@end

NS_ASSUME_NONNULL_END
