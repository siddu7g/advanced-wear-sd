//
//  DateModel.h
//  sdkdemo
//
//  Created by coolwear on 2022/9/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DateModel : NSObject
@property (nonatomic, assign) NSInteger format;
@property (nonatomic, assign) NSInteger mdFormat;
@end

NS_ASSUME_NONNULL_END
