//
//  DataManager.h
//  sdkdemo
//
//  Created by coolwear on 2022/9/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DataManager : NSObject
@property (nonatomic, strong) DeviceInfoModel *devInfo;
@property (nonatomic, strong) AlarmDataModel *alarms;
@property (nonatomic, strong) LongSitModel *longSit;
@property (nonatomic, strong) DisturbModel *disturb;
@property (nonatomic, strong) AppSwtModel *appswt;
@property (nonatomic, strong) DateModel *date;
@property (nonatomic, strong) SwtModel *smsSwt;
@property (nonatomic, strong) SwtModel *callSwt;
@property (nonatomic, strong) SwtModel *targetSwt;
@property (nonatomic, strong) SwtModel *waterSwt;
@property (nonatomic, strong) SwtModel *raiseSwt;
@property (nonatomic, strong) SwtModel *autoHrSwt;
@property (nonatomic, strong) SwtModel *takePhotoSwt;
@property (nonatomic, strong) NSMutableArray<ContactModel *> *contactData;
@property (nonatomic, strong) RealtimeHeartRateModel *heartModel;
@property (nonatomic, strong) NSMutableArray<RealtimeHeartRateModel *> *heartRateHistory;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *rawHeartRateData; // Raw signal data with 1-second timestamps
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *ecgWaveformData; // ECG waveform data
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *o2WaveformData; // O2 waveform data

+ (instancetype)shared;

- (void)storage:(BaseModel *)model;
- (void)addHeartRateReading:(RealtimeHeartRateModel *)reading;
- (void)addRawHeartRateData:(NSDictionary *)rawData;
- (void)addECGWaveformData:(NSDictionary *)ecgData;
- (void)addO2WaveformData:(NSDictionary *)o2Data;
- (void)startHeartRateCollection;
- (void)stopHeartRateCollection;
- (void)clearHeartRateHistory;
- (void)clearWaveformData;
- (NSString *)exportHeartRateToCSV;
- (NSString *)exportHeartRateToJSON;
- (NSString *)exportECGWaveformToJSON;
- (NSString *)exportO2WaveformToJSON;
- (NSString *)exportAllWaveformDataToJSON;

@end

NS_ASSUME_NONNULL_END
