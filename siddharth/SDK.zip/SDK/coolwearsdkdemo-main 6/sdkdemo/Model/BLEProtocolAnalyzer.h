//
//  BLEProtocolAnalyzer.h
//  sdkdemo
//
//  Created for firmware access exploration
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * BLE Protocol Analyzer - Captures and analyzes raw Bluetooth Low Energy communication
 * 
 * Purpose: Reverse engineer BLE protocol to find:
 * - Undocumented commands
 * - Debug/diagnostic modes
 * - Raw sensor data access commands
 * - Hidden capabilities
 */
@interface BLEProtocolAnalyzer : NSObject

+ (instancetype)shared;

/**
 * Start capturing all BLE RX/TX packets
 */
- (void)startLogging;

/**
 * Stop capturing packets
 */
- (void)stopLogging;

/**
 * Get all captured packets
 * @return Array of packet dictionaries with direction, timestamp, data, hex string
 */
- (NSArray<NSDictionary *> *)getCapturedPackets;

/**
 * Clear captured packets
 */
- (void)clearPackets;

/**
 * Export captured packets to JSON
 */
- (NSString *)exportToJSON;

/**
 * Try sending a custom command with specified opcode and parameters
 * @param opcode Command opcode (0x00-0xFF)
 * @param params Parameter bytes
 */
- (void)tryCustomCommand:(uint8_t)opcode params:(NSData * _Nullable)params;

/**
 * Test a command with a specific single-byte parameter value
 * @param opcode Command opcode (0x00-0xFF)
 * @param paramValue Single byte parameter value (0x00-0xFF)
 */
- (void)testCommand:(uint8_t)opcode withParameter:(uint8_t)paramValue;

/**
 * Analyze captured packets to identify protocol structure
 */
- (NSDictionary *)analyzeProtocolStructure;

/**
 * Get packet patterns and statistics
 */
- (NSDictionary *)getPacketStatistics;

/**
 * Try known command patterns to reverse engineer structure
 */
- (void)testKnownCommandPatterns;

/**
 * Systematic exploration of all possible command opcodes
 */
- (void)startSystematicExploration;

/**
 * Stop systematic exploration
 */
- (void)stopSystematicExploration;

@property (nonatomic, assign, readonly) BOOL isLogging;
@property (nonatomic, assign, readonly) BOOL isExploring;

@end

NS_ASSUME_NONNULL_END
