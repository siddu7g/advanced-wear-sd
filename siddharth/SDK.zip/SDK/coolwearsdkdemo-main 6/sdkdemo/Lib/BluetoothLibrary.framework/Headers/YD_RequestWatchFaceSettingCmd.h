//
//  YD_RequestWatchFaceSettingCmd.h
//  StarWristSport
//
//  Created by kwan on 2019/10/7.
//  Copyright © 2019 celink. All rights reserved.
//

#import "CE_Cmd.h"

NS_ASSUME_NONNULL_BEGIN

@interface YD_RequestWatchFaceSettingCmd : CE_Cmd


@end

NS_ASSUME_NONNULL_END
