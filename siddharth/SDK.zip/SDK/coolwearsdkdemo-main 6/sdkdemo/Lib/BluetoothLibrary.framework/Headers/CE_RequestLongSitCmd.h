//
//  CE_RequestLongSitCmd.h
//  K6SDK
//
//  Created by LiJie on 2017/3/18.
//  Copyright © 2017年 LiJie. All rights reserved.
//

#import "CE_Cmd.h"

@interface CE_RequestLongSitCmd : CE_Cmd

@end
