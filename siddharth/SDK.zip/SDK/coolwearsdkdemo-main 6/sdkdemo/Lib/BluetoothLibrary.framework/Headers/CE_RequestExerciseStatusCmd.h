//
//  CE_RequestExerciseStatusCmd.h
//  StarWristSport
//
//  Created by ledong on 2018/3/30.
//  Copyright © 2018年 celink. All rights reserved.
//

#import "CE_Cmd.h"

@interface CE_RequestExerciseStatusCmd : CE_Cmd

@end
