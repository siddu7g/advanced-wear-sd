//
//  CE_SyncWatchFaceCmd.h
//  StarWristSport
//
//  Created by ledong on 2019/1/17.
//  Copyright © 2019年 celink. All rights reserved.
//

#import "CE_Cmd.h"

NS_ASSUME_NONNULL_BEGIN

@interface CE_SyncWatchFaceCmd : CE_Cmd

@end

NS_ASSUME_NONNULL_END
