//
//  CE_RequestOTAStatusCmd.h
//  K2SDKDemo
//
//  Created by cxq on 2016/12/28.
//  Copyright © 2016年 celink. All rights reserved.
//

#import "CE_Cmd.h"

@interface CE_RequestOTAStatusCmd : CE_Cmd


@end
