//
//  CE_SyncPhoneControlCmd.h
//  CE_BleSDK
//
//  Created by LiJie on 2017/3/2.
//  Copyright © 2017年 celink. All rights reserved.
//

#import "CE_Cmd.h"


@interface CE_SyncPhoneControlCmd : CE_Cmd


@property (nonatomic,assign) CALL_CMD_TYPE command; //手机侧电话接听挂断状态


@end
