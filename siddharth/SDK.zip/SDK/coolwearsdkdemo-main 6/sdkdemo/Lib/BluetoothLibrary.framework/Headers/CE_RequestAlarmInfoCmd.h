//
//  CE_RequestAlermInfoCmd.h
//  CE_BleSDK
//
//  Created by cxq on 2017/1/10.
//  Copyright © 2017年 celink. All rights reserved.
//

#import "CE_Cmd.h"

@interface CE_RequestAlarmInfoCmd : CE_Cmd

@end
