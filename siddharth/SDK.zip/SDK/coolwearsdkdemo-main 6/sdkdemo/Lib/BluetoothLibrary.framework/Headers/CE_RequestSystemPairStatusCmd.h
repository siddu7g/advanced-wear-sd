//
//  CE_RequestSystemPairStatusCmd.h
//  K2SDKDemo
//
//  Created by cxq on 2016/12/28.
//  Copyright © 2016年 celink. All rights reserved.
//

#import "CE_Cmd.h"


/**
 用于获取是否进行过系统配对
 */
@interface CE_RequestSystemPairStatusCmd : CE_Cmd

@end
