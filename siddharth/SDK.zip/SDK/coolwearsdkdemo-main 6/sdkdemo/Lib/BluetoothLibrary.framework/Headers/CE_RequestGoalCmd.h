//
//  CE_RequestGoalCmd.h
//  K6SDK
//
//  Created by LiJie on 2017/3/22.
//  Copyright © 2017年 LiJie. All rights reserved.
//

#import "CE_Cmd.h"

@interface CE_RequestGoalCmd : CE_Cmd

@end
