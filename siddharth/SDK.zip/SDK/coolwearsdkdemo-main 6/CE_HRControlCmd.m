//
//  CE_HRControlCmd.m
//  sdkdemo
//
//  Custom HR_CONTROL command to request raw sensor data
//

#import "CE_HRControlCmd.h"
#import <BluetoothLibrary/FuncType.h>

@implementation CE_HRControlCmd

- (instancetype)initWithOnoff:(uint8_t)onoff type:(HR_CONTROL_TYPE)type {
    if (self = [super init]) {
        self.onoff = onoff;
        self.type = type;
    }
    return self;
}

- (instancetype)init {
    return [self initWithOnoff:1 type:HR_CONTROL_TYPE_HR];
}

- (K6_DataFuncType)funcType {
    return DATA_TYPE_HR_CONTROL;
}

- (NSData *)cmdData:(int)type {
    // Create command data: [onoff (1 byte), type (1 byte)]
    uint8_t onoffByte = self.onoff;
    uint8_t typeByte = (uint8_t)self.type;
    
    NSMutableData *data = [NSMutableData data];
    [data appendBytes:&onoffByte length:1];
    [data appendBytes:&typeByte length:1];
    
    return data;
}

- (BOOL)isSendEnd {
    return YES;
}

@end
