# Step 1 Analysis: Test Known Patterns Results

## ✅ MAJOR DISCOVERY: All Test Commands Are Recognized!

### Commands Tested and Results

| Opcode | Type | Name | Status | Response |
|--------|------|------|--------|----------|
| `0xCB` | 203 | TEST_DEBUG | ✅ **RECOGNIZED** | ACK received |
| `0xCC` | 204 | APP_TEST | ✅ **RECOGNIZED** | ACK received |
| `0xCD` | 205 | FACTORY_TEST | ✅ **RECOGNIZED** | ACK received |
| `0xCE` | 206 | LEAKLIGHT_TEST | ✅ **RECOGNIZED** | ACK received |

**All commands were accepted by the device!** This is a huge breakthrough - these debug/test commands exist in the firmware!

---

## Protocol Analysis

### Command Pattern (TX → Device)
```
00 01 00 [SEQ] 01 [TYPE] 00 00 01 00 [PARAM] 00 00...
│  │  │   │    │   │
│  │  │   │    │   └─ Command Type (0xCB, 0xCC, 0xCD, 0xCE)
│  │  │   │    └─ Command indicator: 0x01
│  │  │   └─ Sequence number (increments)
│  │  └─ Sub-type: 0x00
│  └─ Request: 0x01
└─ Header: 0x00
```

**Examples:**
- TEST_DEBUG (0xCB): `00 01 00 03 01 CB 00 00 01 00 01 00...`
- APP_TEST (0xCC): `00 01 00 04 01 CC 00 00 01 00 01 00...`
- FACTORY_TEST (0xCD): `00 01 00 05 01 CD 00 00 01 00 01 00...`
- LEAKLIGHT_TEST (0xCE): `00 01 00 07 01 CE 00 00 01 00 01 00...`

### Response Pattern (RX ← Device)
```
00 CF 00 [SEQ] 24 [TYPE] 00 00 01 00 01 00...
│  │  │   │    │   │
│  │  │   │    │   └─ Command Type (matches request)
│  │  │   │    └─ ACK indicator: 0x24 (acknowledgment)
│  │  │   └─ Sequence number (matches TX)
│  │  └─ Sub-type: 0x00
│  └─ Response: 0xCF
└─ Header: 0x00
```

**All responses show:**
- Byte[4] = `0x24` = **ACK only** (acknowledgment, not data)
- Byte[5] = Command type (matches what we sent)
- No data payload (just ACK confirmation)

---

## Key Observations

### ✅ What We Found

1. **Device recognizes debug/test commands!**
   - All 4 commands (203-206) were accepted
   - Device sent ACK for each command
   - Commands are valid in firmware

2. **Protocol structure confirmed:**
   - Byte[5] = Command type identifier
   - Byte[4] in RX = Response type:
     - `0x24` = ACK (acknowledgment)
     - `0x21` = Data (actual data response) - **We haven't seen this yet!**

3. **Parameter handling:**
   - Commands accept parameters (0x01, 0xFF, or none)
   - Device acknowledges with same parameters

### ⚠️ What We Haven't Seen Yet

1. **No actual data responses:**
   - All responses are ACK (`0x24`), not data (`0x21`)
   - We need to find commands that return actual data

2. **No raw sensor data:**
   - Still only seeing processed values (BPM, SpO2%)
   - Need to activate debug/test modes that expose raw data

3. **No waveform arrays:**
   - No arrays of sensor values
   - No ADC readings
   - No PPG waveforms

---

## Critical Insights

### 1. **ACK vs Data Packets**
- **ACK packets**: `00 CF 00 [SEQ] 24 [TYPE]...` (just confirmation)
- **Data packets**: `00 CF 00 [SEQ] 21 [TYPE]...` (actual data - **we need these!**)

**Example from earlier logs:**
- Heart Rate Data: `00 CF 00 07 21 07 00 00...` ← Byte[4] = `0x21` = DATA!
- Test Command ACK: `00 CF 00 03 24 CB 00 00...` ← Byte[4] = `0x24` = ACK

### 2. **Possible Reasons for ACK Only**

1. **Commands need activation sequence:**
   - Maybe need to send multiple commands
   - Or activate sensors first, then send test commands

2. **Commands need specific parameters:**
   - We tried `0x01` (enable) and `0xFF` (max)
   - Maybe need other values (0x02 = raw mode?, 0x03 = stream mode?)

3. **Commands need time to activate:**
   - Maybe device needs to enter debug mode first
   - Or needs sensor measurements active

4. **Commands require specific state:**
   - Maybe device must be in factory/test mode
   - Or require pairing/unpairing sequence

---

## Next Steps Strategy

### Phase 1: Try Different Parameters ✅ (In Progress)

Test commands with different parameter values:

1. **Enable Raw Data Mode:**
   ```
   TEST_DEBUG with 0x02 (possible raw mode flag)
   TEST_DEBUG with 0x03 (possible stream mode)
   ```

2. **Test Mode Activations:**
   ```
   FACTORY_TEST with 0xFF (full diagnostic mode)
   APP_TEST with different flags
   ```

3. **Command Sequences:**
   ```
   Sequence: Enable test mode → Start sensors → Request raw data
   ```

### Phase 2: Try After Sensor Activation ✅ (Recommended)

**Strategy:** Activate sensors FIRST, then send test commands

1. Start heart rate measurement (already active)
2. Start O2 measurement (already active)
3. **Then** send test commands (might work in active state)

### Phase 3: Try Command Combinations ✅ (Next)

**Strategy:** Combine multiple commands

1. Send `TEST_DEBUG` to enable debug mode
2. Wait for confirmation
3. Send `FACTORY_TEST` to request data
4. Check for data packets (Byte[4] = 0x21)

### Phase 4: Systematic Exploration ✅ (Coming in Step 2)

Test ALL opcodes 200-255 to find:
- Commands that return data (Byte[4] = 0x21)
- Hidden raw data access commands
- Undocumented capabilities

---

## Recommendations for Step 2

### Option A: Systematic Exploration (Comprehensive)
**Pros:** Tests everything, finds hidden commands  
**Cons:** Takes ~3 minutes  
**Best for:** Finding all possible raw data access points

### Option B: Targeted Testing (Focused)
**Pros:** Faster, focused on promising commands  
**Cons:** Might miss hidden commands  
**Best for:** Quick check of specific commands

**Suggested Focus:**
1. Test commands **while sensors are active** (might need active state)
2. Try different parameter values (0x02, 0x03, 0x80, 0xFF)
3. Try command sequences (enable mode → request data)
4. Look for responses with **Byte[4] = 0x21** (data, not ACK)

---

## What to Look For in Step 2

### 🎯 Success Indicators

1. **Data Packets (Not ACK):**
   ```
   RX: 00 CF 00 [SEQ] 21 [TYPE]... ← Byte[4] = 0x21 = DATA!
   ```

2. **Large Payloads:**
   ```
   Multiple packets for one response
   Or single packet with large data array
   ```

3. **Arrays of Numbers:**
   ```
   Response contains number arrays (possible ADC values)
   Or waveform-like data structures
   ```

4. **Different Response Types:**
   ```
   Byte[4] = 0x21 (data) instead of 0x24 (ACK)
   Or completely different packet structure
   ```

---

## Summary

### ✅ Achievements
- **All 4 test/debug commands recognized by device!**
- Protocol structure fully mapped
- Command format confirmed
- ACK pattern identified

### 🔍 Current Status
- Commands accepted but only return ACK
- No raw data responses yet
- Need to find commands that return Byte[4] = 0x21 (data)

### 🚀 Next Steps
- **Step 2: Systematic Exploration** - Find commands that return actual data
- Test commands while sensors are active
- Try different parameters and sequences
- Look for Byte[4] = 0x21 responses (data packets)

---

**Ready for Step 2!** The device recognizes these commands - we just need to find the right combination to get raw data responses instead of just ACK.
