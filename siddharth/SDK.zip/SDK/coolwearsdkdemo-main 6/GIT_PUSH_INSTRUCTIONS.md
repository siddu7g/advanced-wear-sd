# Git Push Instructions for SDK Project

## Current Status
- Git repository is initialized
- Remote currently points to: `bluewings-website` repo
- Need to push to your private `sdkios` repo

## Steps to Push

### 1. Create GitHub Repository (if not already created)
1. Go to GitHub.com
2. Click "New repository"
3. Name it: `sdkios` (or your preferred name)
4. Make it **Private**
5. **Don't** initialize with README, .gitignore, or license
6. Copy the repository URL (e.g., `https://github.com/yourusername/sdkios.git`)

### 2. Add SDK Files to Git

Run these commands in Terminal (from the SDK directory):

```bash
cd "/Users/meghanas/Downloads/SdkDemo_ios/SDK/coolwearsdkdemo-main 6"

# Add .gitignore (to exclude parent directory files)
git add .gitignore

# Add all SDK project files
git add sdkdemo/
git add *.md
git add *.h
git add *.m
git add *.py
git add *.xcodeproj/
git add *.xcworkspace/
git add Podfile
git add plot_heart_rate.py

# Commit the changes
git commit -m "Add BLE Protocol Analyzer and reverse engineering tools

- Added BLEProtocolAnalyzer for protocol reverse engineering
- Added manual parameter testing for debug commands (0xCB-0xCE)
- Added systematic exploration of opcodes 200-255
- Enhanced data collection for ECG, O2, and HR waveforms
- Added comprehensive documentation and analysis guides
- Implemented raw signal extraction attempts
- Added JSON export for all waveform data"
```

### 3. Set Up Remote Repository

Replace `YOUR_USERNAME` and `YOUR_REPO_NAME` with your actual GitHub username and repo name:

```bash
# Remove old remote (if needed)
git remote remove origin

# Add your new private repo
git remote add origin https://github.com/YOUR_USERNAME/sdkios.git

# Or if using SSH:
# git remote add origin git@github.com:YOUR_USERNAME/sdkios.git
```

### 4. Push to GitHub

```bash
# Push to main branch
git push -u origin main

# If main branch doesn't exist, use:
# git push -u origin master
```

**Note:** You'll be prompted for GitHub credentials:
- **Username:** Your GitHub username
- **Password:** Use a **Personal Access Token** (not your password)
  - Go to GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
  - Generate new token with `repo` scope
  - Use that token as the password

### 5. Verify Push

Check your GitHub repo to confirm all files are there:
- `sdkdemo/` folder with all source files
- `BLEProtocolAnalyzer.h` and `.m`
- All `.md` documentation files
- `plot_heart_rate.py`

---

## Files Being Committed

### New Files Added:
- `BLEProtocolAnalyzer.h` / `.m` - BLE protocol reverse engineering tool
- `CE_HRControlCmd.h` / `.m` - Custom HR control command
- All analysis documentation (`.md` files)
- `plot_heart_rate.py` - Python plotting script

### Modified Files:
- `sdkdemo/Controller/FuncListViewController.m` - Added BLE analyzer UI
- `sdkdemo/Model/DataManager.h` / `.m` - Enhanced data collection
- `sdkdemo/Model/DataReceiver.m` - Enhanced logging and waveform capture

---

## Quick Command Summary

```bash
cd "/Users/meghanas/Downloads/SdkDemo_ios/SDK/coolwearsdkdemo-main 6"

# Stage files
git add .gitignore sdkdemo/ *.md *.h *.m *.py *.xcodeproj/ *.xcworkspace/ Podfile

# Commit
git commit -m "Add BLE Protocol Analyzer and reverse engineering tools"

# Set remote (replace with your repo URL)
git remote set-url origin https://github.com/YOUR_USERNAME/sdkios.git

# Push
git push -u origin main
```

---

## Troubleshooting

### If you get "remote origin already exists":
```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/sdkios.git
```

### If you get authentication errors:
- Use Personal Access Token instead of password
- Or set up SSH keys for GitHub

### If you want to exclude certain files:
- Edit `.gitignore` before committing
- Files already committed? Use: `git rm --cached filename`

---

**Ready to push!** Just replace `YOUR_USERNAME` and `YOUR_REPO_NAME` with your actual GitHub details.
