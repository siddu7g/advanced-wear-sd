# Installing Matplotlib for Heart Rate Plotting

## Quick Installation

Run this command in your terminal:
```bash
pip3 install matplotlib numpy
```

Or if you need sudo:
```bash
sudo pip3 install matplotlib numpy
```

## After Installation

Once matplotlib is installed, run the plotting script:
```bash
cd "/Users/meghanas/Downloads/SdkDemo_ios/SDK/coolwearsdkdemo-main 6"
python3 plot_heart_rate.py
```

This will:
1. Generate a plot showing heart rate over time
2. Save it as `heart_rate_plot.png`
3. Display the plot (if you have a display)

## Alternative: Using Conda/Virtual Environment

If you have conda:
```bash
conda install matplotlib numpy
```

Or create a virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate
pip install matplotlib numpy
python3 plot_heart_rate.py
```
