#!/usr/bin/env python3
"""
Heart Rate Plotting Script using Matplotlib
Plots heart rate data over time (seconds vs BPM)
"""

import json
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

# Your JSON data
data_json = {
    "plotDuration": 30,
    "exportTime": "2026-01-20 02:28:44 +0000",
    "note": "Heart rate data formatted for plotting - X-axis: seconds (0-30), Y-axis: BPM. Values are processed BPM from device.",
    "heartRateData": [
        {"timestamp_readable": "2026-01-20 02:28:14 +0000", "rawSignalValue": 69, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 2, "timestamp": 1768876094, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:15 +0000", "rawSignalValue": 69, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 3, "timestamp": 1768876095, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:16 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 4, "timestamp": 1768876096, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:17 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 5, "timestamp": 1768876097, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:18 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 6, "timestamp": 1768876098, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:19 +0000", "rawSignalValue": 69, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 7, "timestamp": 1768876099, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:20 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 8, "timestamp": 1768876100, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:21 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 9, "timestamp": 1768876101, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:22 +0000", "rawSignalValue": 69, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 10, "timestamp": 1768876102, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:23 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 11, "timestamp": 1768876103, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:24 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 12, "timestamp": 1768876104, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:25 +0000", "rawSignalValue": 69, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 13, "timestamp": 1768876105, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:26 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 14, "timestamp": 1768876106, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:27 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 15, "timestamp": 1768876107, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:28 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 16, "timestamp": 1768876108, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:29 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 17, "timestamp": 1768876109, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:30 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 18, "timestamp": 1768876110, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:31 +0000", "rawSignalValue": 69, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 19, "timestamp": 1768876111, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:32 +0000", "rawSignalValue": 68, "rawSignal": 68, "heartRate": 68, "signalValue": 68, "bpm": 68, "collectionInterval": "1 second", "seconds": 20, "timestamp": 1768876112, "dataSource": "timer_interpolated"},
        {"rawSignalValue": 68, "timestamp_readable": "2026-01-20 02:28:32 +0000", "rawSignal": 68, "heartRate": 68, "bpm": 68, "signalValue": 68, "seconds": 20, "timestamp": 1768876112, "dataSource": "device_raw"},
        {"timestamp_readable": "2026-01-20 02:28:33 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 21, "timestamp": 1768876113, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:34 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 22, "timestamp": 1768876114, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:35 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 23, "timestamp": 1768876115, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:36 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 24, "timestamp": 1768876116, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:37 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 25, "timestamp": 1768876117, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:38 +0000", "rawSignalValue": 68, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 26, "timestamp": 1768876118, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:39 +0000", "rawSignalValue": 68, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 27, "timestamp": 1768876119, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:40 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 28, "timestamp": 1768876120, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:41 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 29, "timestamp": 1768876121, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:42 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 30, "timestamp": 1768876122, "dataSource": "timer_interpolated"},
        {"timestamp_readable": "2026-01-20 02:28:43 +0000", "rawSignalValue": 67, "rawSignal": 67, "heartRate": 67, "signalValue": 67, "bpm": 67, "collectionInterval": "1 second", "seconds": 31, "timestamp": 1768876123, "dataSource": "timer_interpolated"}
    ],
    "xAxis": "seconds (0 to 30)",
    "dataSource": "processed_bpm",
    "dataType": "heartRateSignal",
    "yAxis": "BPM (beats per minute)",
    "sdkLimitation": "SDK only provides processed BPM values (heartNum), not raw sensor waveforms (PPG/ADC). Device firmware processes sensor data internally.",
    "recommendation": "Data is suitable for heart rate trend plotting. Each entry has 'seconds' (X-axis) and 'bpm' (Y-axis) for easy plotting.",
    "totalReadings": 31,
    "collectionInterval": "1 second"
}

# Extract data
heart_rate_data = data_json["heartRateData"]
seconds = [item["seconds"] for item in heart_rate_data]
bpm = [item["bpm"] for item in heart_rate_data]
data_source = [item.get("dataSource", "unknown") for item in heart_rate_data]

# Separate interpolated and device data for different styling
interpolated_indices = [i for i, src in enumerate(data_source) if src == "timer_interpolated"]
device_indices = [i for i, src in enumerate(data_source) if src == "device_raw"]

interpolated_seconds = [seconds[i] for i in interpolated_indices]
interpolated_bpm = [bpm[i] for i in interpolated_indices]
device_seconds = [seconds[i] for i in device_indices]
device_bpm = [bpm[i] for i in device_indices]

# Create the plot
plt.figure(figsize=(12, 6))
plt.style.use('seaborn-v0_8-darkgrid' if 'seaborn-v0_8-darkgrid' in plt.style.available else 'default')

# Plot interpolated data (line)
plt.plot(interpolated_seconds, interpolated_bpm, 'b-', linewidth=2, alpha=0.7, label='Interpolated Data', marker='o', markersize=4)

# Plot actual device readings (highlighted)
if device_seconds:
    plt.scatter(device_seconds, device_bpm, color='red', s=100, zorder=5, label='Device Reading', marker='*', edgecolors='darkred', linewidths=1.5)

# Add vertical line at device reading point
if device_seconds:
    plt.axvline(x=device_seconds[0], color='red', linestyle='--', alpha=0.5, linewidth=1)

# Customize the plot
plt.xlabel('Time (Seconds)', fontsize=12, fontweight='bold')
plt.ylabel('Heart Rate (BPM)', fontsize=12, fontweight='bold')
plt.title('Heart Rate Over Time (30 Seconds)\nX-axis: Seconds | Y-axis: BPM', fontsize=14, fontweight='bold', pad=20)

# Set axis limits with some padding
plt.xlim(min(seconds) - 1, max(seconds) + 1)
plt.ylim(min(bpm) - 2, max(bpm) + 2)

# Add grid
plt.grid(True, alpha=0.3, linestyle='--')

# Add legend
plt.legend(loc='best', fontsize=10)

# Add statistics text box
avg_bpm = np.mean(bpm)
min_bpm = min(bpm)
max_bpm = max(bpm)
stats_text = f'Statistics:\nAvg: {avg_bpm:.1f} BPM\nMin: {min_bpm} BPM\nMax: {max_bpm} BPM\nRange: {max_bpm - min_bpm} BPM'
plt.text(0.02, 0.98, stats_text, transform=plt.gca().transAxes, 
         fontsize=9, verticalalignment='top', 
         bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# Add annotation at device reading
if device_seconds:
    plt.annotate(f'Device Reading\n{device_bpm[0]} BPM at {device_seconds[0]}s', 
                xy=(device_seconds[0], device_bpm[0]), 
                xytext=(device_seconds[0] + 3, device_bpm[0] + 0.5),
                arrowprops=dict(arrowstyle='->', color='red', lw=1.5),
                fontsize=9, color='red', fontweight='bold',
                bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.7))

# Adjust layout
plt.tight_layout()

# Save the plot
output_file = 'heart_rate_plot.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight')
print(f"✅ Plot saved as: {output_file}")

# Show the plot
plt.show()

# Print summary
print(f"\n{'='*60}")
print("HEART RATE PLOT SUMMARY")
print(f"{'='*60}")
print(f"Total Data Points: {len(heart_rate_data)}")
print(f"Duration: {min(seconds)} to {max(seconds)} seconds ({max(seconds) - min(seconds) + 1} seconds)")
print(f"Average BPM: {avg_bpm:.2f}")
print(f"Min BPM: {min_bpm}")
print(f"Max BPM: {max_bpm}")
print(f"BPM Range: {max_bpm - min_bpm}")
print(f"{'='*60}\n")
