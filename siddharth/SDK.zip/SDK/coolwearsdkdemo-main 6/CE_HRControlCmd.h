//
//  CE_HRControlCmd.h
//  sdkdemo
//
//  Custom HR_CONTROL command to request raw sensor data
//

#import <BluetoothLibrary/CE_Cmd.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, HR_CONTROL_TYPE) {
    HR_CONTROL_TYPE_NULL = 0,
    HR_CONTROL_TYPE_HR = 1,
    HR_CONTROL_TYPE_BP = 2,
    HR_CONTROL_TYPE_O2 = 3,
    HR_CONTROL_TYPE_ECG = 4,
};

@interface CE_HRControlCmd : CE_Cmd

// 0 = off, 1 = on
@property (nonatomic, assign) uint8_t onoff;

// HR_CONTROL_TYPE - type of sensor data to request
@property (nonatomic, assign) HR_CONTROL_TYPE type;

- (instancetype)initWithOnoff:(uint8_t)onoff type:(HR_CONTROL_TYPE)type;

@end

NS_ASSUME_NONNULL_END
