# Manual Parameter Testing Guide

## What to Check in Console Logs

When testing commands, look for these patterns in the Xcode console:

### ✅ Success Indicators (DATA Response Found)
```
🎯 FOUND DATA RESPONSE! Byte[4] = 0x21 (data, not ACK)
✅✅✅ SUCCESS! Command 0xCB returned DATA (Byte[4]=0x21) - CHECK THIS OUT!
```

### ⚠️ ACK Only (No Data Yet)
```
✅ Custom command 0xCB sent - RESPONSE RECEIVED! (X new packets, ACK only)
```

### 📡 Packet Analysis
Look at the packet hex dumps:
```
📡 RX[20 bytes] - 00 CF 00 [SEQ] 24 [TYPE]...
```
- **Byte[4] = 0x24** = ACK (acknowledgment only)
- **Byte[4] = 0x21** = DATA (actual data response) ⭐ **THIS IS WHAT WE WANT!**

---

## Testing Strategy

### Phase 1: Test Different Parameters for 0xCB (TEST_DEBUG)

**Most Promising Parameters:**
1. **0x02** - Possible "raw data mode" flag
2. **0x03** - Possible "stream mode" flag  
3. **0x80** - Alternative enable flag
4. **0xFF** - Maximum/full mode

**Test Sequence:**
1. Test 0xCB with 0x02
2. Test 0xCB with 0x03
3. Test 0xCB with 0x80
4. Check console for Byte[4] = 0x21 responses

### Phase 2: Try Command Sequences

**Sequence A: Enable → Request**
```
1. Send 0xCB with 0x01 (enable debug mode)
2. Wait 2-3 seconds
3. Send 0xCB with 0x02 (request raw data?)
4. Monitor for Byte[4] = 0x21 responses
```

**Sequence B: Factory Mode → Request**
```
1. Send 0xCD (FACTORY_TEST) with 0xFF (enter factory mode)
2. Wait 2-3 seconds
3. Send 0xCB (TEST_DEBUG) with 0x02 (request debug data)
4. Monitor for data responses
```

### Phase 3: Test While Sensors Active

**Theory:** Debug commands might need sensors running to return data.

```
1. Start heart rate measurement (keep it running)
2. Start O2 measurement (keep it running)
3. While sensors are streaming (you'll see Byte[4] = 0x21 packets)
4. Send 0xCB with different parameters
5. Check if responses change to data type
```

---

## What to Look For

### In Console Logs:

1. **Packet Count Changes:**
   ```
   RESPONSE RECEIVED! (2 new packets)  ← Normal ACK
   RESPONSE RECEIVED! (5+ new packets) ← Possible data stream!
   ```

2. **Different Byte[4] Values:**
   ```
   Byte[4] = 0x24 ← ACK (what we're getting)
   Byte[4] = 0x21 ← DATA (what we want!) ⭐
   Byte[4] = 0x?? ← Other values (interesting!)
   ```

3. **Larger Payloads:**
   ```
   RX[20 bytes] ← Normal size
   RX[40+ bytes] ← Larger payload (possible data!)
   ```

4. **Multiple Packets:**
   ```
   One command → One response ← Normal
   One command → Multiple responses ← Possible data stream!
   ```

### In Packet Hex Dumps:

Look for patterns in the payload bytes:
```
00 CF 00 [SEQ] 24 CB 00 00 01 00 01 00... ← ACK pattern
00 CF 00 [SEQ] 21 CB 00 00 [DATA...]     ← Data pattern (what we want!)
```

---

## Next Steps After Testing

1. **If you find Byte[4] = 0x21 responses:**
   - Export packets to JSON
   - Analyze the data structure
   - Look for arrays of numbers (possible raw sensor values)

2. **If all responses are ACK (0x24):**
   - Try command sequences (enable mode → request data)
   - Test while sensors are active
   - Try different parameter combinations
   - Check for delayed responses (wait 10-30 seconds after command)

3. **If no responses:**
   - Command might not be recognized
   - Try different opcodes
   - Check device connection

---

## Current Status

Based on your test:
- ✅ Command 0xCB (TEST_DEBUG) is recognized
- ✅ Device responds with ACK
- ❌ No DATA responses yet (Byte[4] = 0x24 only)
- 🔍 Need to try different parameters or sequences

---

## Recommended Next Tests

1. **Try 0xCB with parameter 0x02** (most likely to work)
2. **Try 0xCB with parameter 0x03** (stream mode?)
3. **Try command sequence:** 0xCB(0x01) → wait → 0xCB(0x02)
4. **Test while sensors active:** Start HR/O2, then send 0xCB commands

Let me know what you see in the console logs and we'll analyze the results!
